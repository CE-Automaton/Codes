#include<bits/stdc++.h>
using namespace std;
int c,t,n,m,k,d,x,y,v;
long long dp[2][1001];
vector <pair<int,int> > G[100001];
int main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	
	scanf("%d%d",&c,&t);
	while(t--){
		scanf("%d%d%d%d",&n,&m,&k,&d);
		if(c<=9){
			for(int i=1;i<=n;i++) G[i].clear();
			for(int i=1;i<=m;i++){
				scanf("%d%d%d",&x,&y,&v);
				G[x].push_back({y,v});
			}
			memset(dp,-0x3f,sizeof(dp));
			dp[0][0]=0;
			for(int i=1;i<=n;i++){
				dp[1][0]=-1e16;
				for(int j=1;j<=min(i,k);j++) dp[1][j]=dp[0][j-1]-d;
				for(int j=0;j<=min(i,k);j++) dp[1][0]=max(dp[1][0],dp[0][j]);
				for(auto j:G[i]) for(int l=j.first;l<=min(i,k);l++) dp[1][l]+=j.second;
				swap(dp[0],dp[1]);
				memset(dp[1],-0x3f,sizeof(dp[1]));
			}
			long long ans=0;
			for(int i=0;i<=min(n,k);i++) ans=max(ans,dp[0][i]);
			printf("%lld\n",ans);
		}
		else{
			long long ans=0;
			for(int i=1;i<=m;i++){
				scanf("%d%d%d",&x,&y,&v);
				ans+=max(0ll,v-1ll*d*y);
			}
			printf("%lld\n",ans);
		}
	}
	return 0;
}
