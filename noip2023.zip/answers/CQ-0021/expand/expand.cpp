#include<bits/stdc++.h>
using namespace std;
int c,n,m,q,kx,ky,p,v,x[500001],y[500001],xx[500001],yy[500001];
int check(){
	if(n==2&&m==1){
		if(x[1]>y[1]&&x[2]>y[2]) return 1;
		if(x[1]<y[1]&&x[2]<y[2]) return 1;
	}
	else if(n==1&&m==2){
		if(x[1]>y[1]&&x[1]>y[2]) return 1;
		if(x[1]<y[1]&&x[1]<y[2]) return 1;
	}
	else{
		int ff=1;
		for(int i=1;i<=min(n,m);i++) if(x[i]<=y[i]) ff=0;
		if(ff==1) return 1;
		int f=1;
		for(int i=1;i<=min(n,m);i++) if(x[i]>=y[i]) f=0;
		if(f==1) return 1;
	}
	return 0;
}
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	
	scanf("%d%d%d%d",&c,&n,&m,&q);
	for(int i=1;i<=n;i++) scanf("%d",&x[i]),xx[i]=x[i];
	for(int i=1;i<=n;i++) scanf("%d",&y[i]),yy[i]=y[i];
	printf("%d",check());
	while(q--){
		for(int i=1;i<=n;i++) x[i]=xx[i];
		for(int i=1;i<=m;i++) y[i]=yy[i];
		scanf("%d%d",&kx,&ky);
		while(kx--){
			scanf("%d%d",&p,&v);
			x[p]=v;
		}
		while(ky--){
			scanf("%d%d",&p,&v);
			y[p]=v;
		}
		printf("%d",check());
	}
	return 0;
}
