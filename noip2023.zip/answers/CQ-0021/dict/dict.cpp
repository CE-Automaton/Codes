#include<bits/stdc++.h>
using namespace std;
int n,m,now=1,a[3001],id[6001],ans[3001];
char s[6001][3001];
bool cmp(int x,int y){
	for(int i=1;i<=m;i++) if(s[x][i]!=s[y][i]) return s[x][i]<s[y][i];
	return (x&1)>(y&1);
}
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("%s",s[0]+1);
		for(int j=1;j<=m;j++) a[j]=s[0][j]-97;
		sort(a+1,a+1+m);
		for(int j=1;j<=m;j++) s[i*2-1][j]=a[j]+97;
		reverse(a+1,a+1+m);
		for(int j=1;j<=m;j++) s[i*2][j]=a[j]+97;
	}
	for(int i=1;i<=n*2;i++) id[i]=i;
	sort(id+1,id+1+n*2,cmp);
	for(int i=1;i<=n*2;i++){
		if(id[i]&1) ans[(id[i]+1)/2]=now;
		else now=0;
	}
	for(int i=1;i<=n;i++) printf("%d",ans[i]);
	return 0;
}
