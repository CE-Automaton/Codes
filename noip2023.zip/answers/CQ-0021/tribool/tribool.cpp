#include<bits/stdc++.h>
using namespace std;
struct cz{
	int k,x,y;
	cz(int k=0,int x=0,int y=0):k(k),x(x),y(y){}
}e[11];
int c,t,n,m,x,y,u,v,aaa,ans[11],noww[11],fa[200001],ccc[100001],ttt[100001],siz[100001],val[100001];
pair<int,int> tag[100001],col[100001];
char s[2];
int find(int x){
	if(fa[x]==x) return x;
	else return find(fa[x]);
}
int get(int x){
	if(fa[x]==x) return 0;
	else return val[x]^get(fa[x]);
}
void bf(int x){
	if(x==n+1){
		for(int i=1;i<=n;i++) noww[i]=ans[i];
		for(int i=1;i<=m;i++){
			if(e[i].k==0){
				if(noww[e[i].y]==2) noww[e[i].x]=2;
				else noww[e[i].x]=noww[e[i].y]^1;
			}
			else if(e[i].k==1) noww[e[i].x]=noww[e[i].y];
			else noww[e[i].x]=e[i].k-2;
		}
		for(int i=1;i<=n;i++) if(ans[i]!=noww[i]) return;
		int kkk=0;
		for(int i=1;i<=n;i++) kkk+=(ans[i]==2);
		aaa=min(aaa,kkk);
		return;
	}
	ans[x]=0,bf(x+1);
	ans[x]=1,bf(x+1);
	ans[x]=2,bf(x+1);
}
int fff(int x){
	if(fa[x]!=x) fa[x]=fff(fa[x]);
	return fa[x];
}
int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	
	scanf("%d%d",&c,&t);
	while(t--){
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;i++) fa[i]=i,val[i]=0,col[i]={-1,0},tag[i]={0,0},siz[i]=1;
		if(c==1||c==2){
			aaa=114514;
			for(int i=1;i<=m;i++){
				scanf("%s%d",s,&e[i].x);
				if(s[0]=='-') e[i].k=0,scanf("%d",&e[i].y);
				else if(s[0]=='+') e[i].k=1,scanf("%d",&e[i].y);
				else if(s[0]=='T') e[i].k=2;
				else if(s[0]=='F') e[i].k=3;
				else e[i].k=4;
			}
			bf(1);
			printf("%d\n",aaa);
		}
		else if(c==3||c==4){
			for(int i=1;i<=n;i++) ccc[i]=-1;
			for(int i=1;i<=m;i++){
				scanf("%s%d",s,&x);
				if(s[0]=='T') ccc[x]=0;
				else if(s[0]=='F') ccc[x]=1;
				else ccc[x]=2;
			}
			int kkkk=0;
			for(int i=1;i<=n;i++) if(ccc[x]==2) kkkk++;
			printf("%d\n",kkkk);
		}
		else{
			for(int i=1;i<=m;i++){
				scanf("%s%d",s,&x);
				if(s[0]=='+'){
					scanf("%d",&y),u=find(x),v=find(y);
					if(u==v){
						if(get(x)!=get(y)) tag[u]={1,i};
					}
					else{
						if(siz[u]>siz[v]) swap(x,y),swap(u,v);
						val[u]=get(x)^get(y);
						siz[v]+=siz[u];
						fa[u]=v;
						tag[v]={tag[v].first|tag[u].first,max(tag[v].second,tag[v].second)};
					}
				}
				else if(s[0]=='-'){
					scanf("%d",&y),u=find(x),v=find(y);
					if(u==v){
						if(get(x)==get(y)) tag[u]={1,i};
					}
					else{
						if(siz[u]>siz[v]) swap(x,y),swap(u,v);
						val[u]=get(x)^get(y)^1;
						siz[v]+=siz[u];
						fa[u]=v;
						tag[v]={tag[v].first|tag[u].first,max(tag[v].second,tag[v].second)};
					}
				}
				else if(s[0]=='T') col[x]={1,i};
				else if(s[0]=='F') col[x]={0,i};
				else tag[find(x)]={1,i},col[x]={-1,i};
			}
			int ans=0;
			for(int i=1;i<=n;i++){
				if(find(i)==i&&tag[i].first==1) ans+=siz[i];
				else if(tag[find(i)].first&&tag[find(i)].second<col[i].second&&col[i].first!=-1) ans--; 
			}
			printf("%d\n",ans);
		}
	}
	return 0;
}
