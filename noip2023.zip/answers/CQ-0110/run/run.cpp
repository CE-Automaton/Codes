#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define pb push_back
#define fi first
#define se second
#define pii pair<int,int>
#define i64 __int128
#define lowbit(i) i&(-i)
const int N = 2e5+5;
int number;
ll n,m,k,d;
ll len,f[N],val[N],sz[N];
vector<ll> sum[N],p[N];
struct Seg{
	ll l,r,w;
}s[N];
bool cmp(Seg x,Seg y){
	return x.r<y.r; 
}
void init(){
	for(int i=1;i<=len;i++) sz[i] = val[i] = 0,f[i] = -1e18,p[i].clear(),sum[i].clear();
	len = 0;
}
ll calc(int l,int r){
	int pos = upper_bound(p[l].begin(),p[l].end(),r)-p[l].begin();
	pos--;
	if(pos<0 || pos>sz[l]) return 0;
	return sum[l][pos];
}
void solve(){
	cin >> n >> m >> k >> d;
	init();
	for(int i=1;i<=m;i++){
		ll x,y,w;
		cin >> x >> y >> w;
		s[i].l = x-y+1,s[i].r = x,s[i].w = w;
	}
	sort(s+1,s+1+m,cmp);
	if(number<=16){
		vector<int> vec;
		for(int i=1;i<=m;i++) vec.pb(s[i].l),vec.pb(s[i].r);
		sort(vec.begin(),vec.end()),vec.erase(unique(vec.begin(),vec.end()),vec.end());
		for(int i=0;i<vec.size();i++) val[++len] = vec[i];
		for(int i=1;i<=m;i++){
			s[i].l = lower_bound(vec.begin(),vec.end(),s[i].l)-vec.begin()+1;
			s[i].r = lower_bound(vec.begin(),vec.end(),s[i].r)-vec.begin()+1;
		}
		val[0] = -1e9;
		for(int i=1;i<=len;i++) p[i].pb(0),sum[i].pb(0);
		for(int i=1;i<=m;i++){
			if(val[s[i].r]-val[s[i].l]>=k) continue;
			p[s[i].l].pb(s[i].r);
			sum[s[i].l].pb(s[i].w);
			sz[s[i].l]++;
		}
		for(int i=1;i<=len;i++){
			for(int j=1;j<=sz[i];j++){
				sum[i][j] += sum[i][j-1];
			}
		}
		f[0] = 0;
		for(int i=1;i<=len;i++){
			ll w = 0;f[i] = f[i-1];
			for(int j=i;j>=1;j--){
				if(val[i]-val[j]>=k) break;
				w += calc(j,i);
				if(val[j]-val[j-1]>1) f[i] = max(f[i],f[j-1]+w-(val[i]-val[j]+1)*d); 
				else f[i] = max(f[i],f[j-2]+w-(val[i]-val[j]+1)*d);
			}
		}
		ll ans = 0;
		for(int i=1;i<=len;i++) ans = max(ans,f[i]);
		cout << ans << "\n";
	}else if(17<=number && number<=18){
		ll ans = 0;
		for(int i=1;i<=m;i++){
			if(s[i].r-s[i].l>=k) continue;
			ans += max(0ll,s[i].w-(s[i].r-s[i].l+1)*d);
		}
		cout << ans << "\n";
	}
}
int main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	cin.tie(0),cout.tie(0);
	ios::sync_with_stdio(0);
	cin >> number;
	int T;cin >> T;
	while(T--) solve();
	return 0;
}

