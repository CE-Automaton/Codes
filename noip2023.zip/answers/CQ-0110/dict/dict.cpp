#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define pb push_back
#define fi first
#define se second
#define pii pair<int,int>
#define i64 __int128
#define lowbit(i) i&(-i)
const int N = 3003;
const ll P = 131;
int n,m;
ll hs[N][N];
char s[N][N],t[N][N];
int p[N];
bool cmp(int x,int y){
	int l=1,r=m,pos=m+1;
	while(l<=r){
		int mid = (l+r)>>1;
		if(hs[x][mid]!=hs[y][mid]){
			pos = mid;
			r = mid-1;
		}else{
			l = mid+1;
		}
	}
	return t[x][pos]<t[y][pos];
}
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	cin.tie(0),cout.tie(0);
	ios::sync_with_stdio(0);
	cin >> n >> m;
	if(n==1){
		cout << 1 << '\n';
		return 0;
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin >> s[i][j];
		}
		sort(s[i]+1,s[i]+1+m);
		for(int j=1;j<=m;j++) t[i][j] = s[i][j];
		reverse(t[i]+1,t[i]+1+m);	
		for(int j=1;j<=m;j++) hs[i][j] = hs[i][j-1]*P+(t[i][j]-'a'+1);
	}
	for(int i=1;i<=n;i++) p[i] = i;
	sort(p+1,p+1+n,cmp);
	for(int i=1,j;i<=n;i++){
		if(p[1]!=i) j = p[1];
		else j = p[2];
		int ck = 0;
		for(int k=1;k<=m;k++){
			if(s[i][k]!=t[j][k]){
				ck = (s[i][k]<t[j][k]);
				break;
			}
		}
		cout << ck;
	}
	return 0;
}
