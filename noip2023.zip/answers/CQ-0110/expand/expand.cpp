#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define pb push_back
#define fi first
#define se second
#define pii pair<int,int>
#define i64 __int128
#define lowbit(i) i&(-i)
const int N = 5e5+5;
int c,n,m,q,f[2077][2077];
int vis[N],x[N],y[N],tx[N],ty[N];
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	cin.tie(0),cout.tie(0);
	ios::sync_with_stdio(0);
	cin >> c >> n >> m >> q;
	for(int i=1;i<=n;i++) cin >> x[i];
	for(int i=1;i<=m;i++) cin >> y[i];
	for(int t=0;t<=q;t++){
		int kx=0,ky=0;
		if(t) cin >> kx >> ky;
		for(int i=1;i<=n;i++) tx[i] = x[i];
		for(int i=1;i<=m;i++) ty[i] = y[i];
		for(int i=0;i<=n;i++){
			for(int j=0;j<=m;j++){
				f[i][j] = 0;
			}
		}
		for(int i=1;i<=kx;i++){
			int p,v;cin >> p >> v;
			tx[p] = v;
		}
		for(int i=1;i<=ky;i++){
			int p,v;cin >> p >> v;
			ty[p] = v;
		}
		if(tx[1]==ty[1]){
			cout << 0;
			continue;
		}
		int typ = (tx[1]>ty[1]),tmp = 1;
		f[1][1] = 1;
		while(tmp<m && (tx[1]>ty[tmp+1])==typ) tmp++,f[1][tmp] = 1;
		for(int i=1;i<n;i++){
			for(int j=1;j<=m;j++) vis[j] = 0;
			for(int j=m;j>=1;j--){
				if(f[i][j]==0) continue;
				int k = j;
				if(((tx[i+1]>ty[j])==typ && tx[i+1]!=ty[j])) f[i+1][j] = 1;
				vis[j] = 1;
				while(!vis[k+1] && k<m && ((tx[i+1]>ty[k+1])==typ && tx[i+1]!=ty[k+1])) k++,f[i+1][k] = 1;
			}
		}
		cout << f[n][m];
	}
	return 0;
}
//f(i,j)��ʾǰi������ǰj�����Ƿ����
//f(i,j)->f(i+1,[j~k])
