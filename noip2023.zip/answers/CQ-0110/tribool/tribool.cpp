#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define pb push_back
#define fi first
#define se second
#define pii pair<int,int>
#define i64 __int128
#define lowbit(i) i&(-i)
const int N = 5e5+5;
int number;
int fa[N],sp[N];
struct node{
	int typ,id; 
	int x; //0:F 1:T 2:U
}a[N];
int find(int u){
	if(u==fa[u]) return u;
	return fa[u] = find(fa[u]);
}
void merge(int u,int v){	
	if(!u || !v) return ;	
	u = find(u),v = find(v);
	if(u==v) return ;
	fa[u] = v; 
}
void solve(){
	int n,m;cin >> n >> m;
	for(int i=1;i<=n;i++) a[i].typ = a[i].x = 0,a[i].id = i;
	for(int i=1;i<=m;i++){
		int u,v;
		char ch;cin >> ch;
		if(ch=='+'){
			cin >> u >> v;
			a[u] = a[v];
		}else if(ch=='-'){
			cin >> u >> v;
			a[u] = a[v];
			if(a[v].typ<2){
				a[u].typ ^= 1;
			}else{
				if(a[u].x!=2) a[u].x ^= 1;
			}
		}else{
			cin >> u;
			a[u].typ = 2;
			if(ch=='F') a[u].x = 0;
			else if(ch=='T') a[u].x = 1;
			else a[u].x = 2;
		}
	}
	int ans = 0;
	for(int i=1;i<=2*n;i++) fa[i] = i;
	for(int i=1;i<=n;i++) sp[i] = (a[i].typ==2 && a[i].x==2);
	for(int i=1;i<=n;i++){
		if(a[i].typ==2){	
			if(a[i].x==2) ans++;	
			continue;
		}
		if(a[i].typ==0){
			merge(i,a[i].id),merge(i+n,a[i].id+n*(sp[a[i].id]==0));
		}else if(a[i].typ==1){
			merge(i,a[i].id+n*(sp[a[i].id]==0)),merge(i+n,a[i].id);
		}
	}
	for(int i=1;i<=n;i++){
		if(a[i].typ==2) continue;
		if(find(i)==find(i+n)) ans++;
	}
	cout << ans << '\n';
}
int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	cin.tie(0),cout.tie(0);
	ios::sync_with_stdio(0);
	cin >> number;
	int T;cin >> T;
	while(T--) solve();
	return 0;
}

