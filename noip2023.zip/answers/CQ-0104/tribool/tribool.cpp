#include<bits/stdc++.h>
#define rep(i,j,k) for(int i=j;i<=k;i++)
#define repp(i,j,k) for(int i=j;i>=k;i++)
#define mp make_pair
#define pii pair<int,int>
#define fir first
#define sec second
#define lowbit(i) i&-i
using namespace std;
typedef long long ll;
const int N=1e5+5,inf=1e9+7;
void read(int &p){
    int x=0,w=1;
    char ch=getchar();
    while(!isdigit(ch)){
        if(ch=='-')w=-1;
        ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	p=x*w;
}
/*
consider giving each point a new point as a new version when it is modified.
if it is modified from another point,add an egde between them.
and add an edgen from the first version to the last version of each point.
int each connected graph,choose one point and decide its type,dfs the graph to check
whether it is ok or not.
choose the type that let the U be the minn.
好运来！！！ 
*/
int T;
int n,m;
struct edge{
    int to,nxt,tp;//0:same 1:different
}e[4*N];
int fir[N*2],np;
void add(int x,int y,int tp){
//    printf("%d %d %d\n",x,y,tp);
    e[++np]=(edge){y,fir[x],tp};
    fir[x]=np;
}
int la[N],gv[N*2],sum,v[2*N];//1 T 2 F 3 U
stack<int>stk;
int bck(int x){
    if(x==1)return 2;
    if(x==2)return 1;
    return 3;
}
void dfs(int x){
    //printf("%d\n",x);
    if(gv[x]!=0&&v[x]!=gv[x])sum=-1;
    if(x<=n&&v[x]==3&&sum!=-1)sum++;
    for(int i=fir[x];i;i=e[i].nxt){
        int j=e[i].to,nt=e[i].tp;
        int targ;
        if(nt)targ=bck(v[x]);
        else targ=v[x];
        if(v[j]){
            if(v[j]!=targ)sum=-1;
            continue;
        }
        v[j]=targ,stk.push(j),dfs(j);
    }
}
void solve(){
    read(n),read(m),np=0;
    rep(i,1,n)
        la[i]=i;
    memset(gv,0,sizeof(gv)),memset(fir,0,sizeof(fir)),memset(v,0,sizeof(v));
    int nw=n;
    rep(i,1,m){
        char op;
        cin>>op,nw++;
        if(op=='+'){
            int x,y;
            read(x),read(y);
            add(nw,la[y],0),add(la[y],nw,0);
            la[x]=nw;
        }
        else if(op=='-'){
            int x,y;
            read(x),read(y);
            add(nw,la[y],1),add(la[y],nw,1);
            la[x]=nw;
        }
        else{
            int x;
            read(x),la[x]=nw;
            if(op=='T')gv[nw]=1;
            else if(op=='F')gv[nw]=2;
            else gv[nw]=3;
        }
    }
    rep(i,1,n)
        if(i!=la[i])add(i,la[i],0),add(la[i],i,0);
    int ans=0;
    rep(i,1,n){
        if(v[i])continue;
        int res=inf;
        rep(j,1,3){
            sum=0;
            while(!stk.empty())
                v[stk.top()]=0,stk.pop();
            v[i]=j,stk.push(i);
            //printf("!!\n");
            dfs(i);
            if(sum>=0)res=min(res,sum);
        }
        //printf("%d:%d\n",i,res);
        ans+=res;
        while(!stk.empty())
            stk.pop();
    }
    printf("%d\n",ans);
}
int idn;
int main(){
    freopen("tribool.in","r",stdin);
    freopen("tribool.out","w",stdout);
    read(idn),read(T);
    while(T--)
        solve();
    return 0;
}
//09:54 fin.