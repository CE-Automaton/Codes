#include<bits/stdc++.h>
#define rep(i,j,k) for(int i=j;i<=k;i++)
#define repp(i,j,k) for(int i=j;i>=k;i++)
#define mp make_pair
#define pii pair<int,int>
#define fir first
#define sec second
#define lowbit(i) i&-i
using namespace std;
typedef long long ll;
const int N=3005;
void read(int &p){
    int x=0,w=1;
    char ch=getchar();
    while(!isdigit(ch)){
        if(ch=='-')w=-1;
        ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	p=x*w;
}
//it is easy to find that we can put the smallest character in the i`s front and the biggest 
//in the other`s
//if i is not the strictlt biggest one,its ans is 0 because the strings are different 
//from each other.
//好运来
int maxn[N],minn[N];
char ch[N];
int main(){
    freopen("dict.in","r",stdin);
    freopen("dict.out","w",stdout);
    int n,m;
    read(n),read(m);
    rep(i,1,n){
        scanf("%s",ch+1);
        maxn[i]=0,minn[i]=100;
        rep(j,1,m){
            int nw=ch[j]-'a'+1;
            maxn[i]=max(maxn[i],nw),minn[i]=min(minn[i],nw);
        }
    }
    rep(i,1,n){
        bool ok=1;
        rep(j,1,n){
            if(i==j)continue;
            if(maxn[j]<=minn[i]){
                ok=0;
                break;
            }
        }
        printf("%d",ok);
    }
    return 0;
}
//08:50 fin.