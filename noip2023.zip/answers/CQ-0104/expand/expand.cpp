#include<bits/stdc++.h>
#define rep(i,j,k) for(int i=j;i<=k;i++)
#define repp(i,j,k) for(int i=j;i>=k;i++)
#define mp make_pair
#define ls(x) x*2
#define rs(x) x*2+1
#define pii pair<int,int>
#define fir first
#define sec second
#define lowbit(i) i&-i
using namespace std;
typedef long long ll;
const int N=5e5+5,M=1e5+5,inf=1e9+7;
void read(int &p){
    int x=0,w=1;
    char ch=getchar();
    while(!isdigit(ch)){
        if(ch=='-')w=-1;
        ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	p=x*w;
}
struct seg{
    int maxn[4*N],minn[4*N];
    void pushup(int x){
        minn[x]=min(minn[ls(x)],minn[rs(x)]);
        maxn[x]=max(maxn[ls(x)],maxn[rs(x)]);
    }
    void build(int x,int le,int ri){
        maxn[x]=0,minn[x]=inf;
        if(le==ri)return;
        int mid=(le+ri)>>1;
        build(ls(x),le,mid),build(rs(x),mid+1,ri);
    }
    void modify(int x,int le,int ri,int p,int v){
        if(le==ri){
            maxn[x]=minn[x]=v;
            return;
        }
        int mid=(le+ri)>>1;
        if(p<=mid)modify(ls(x),le,mid,p,v);
        else modify(rs(x),mid+1,ri,p,v);
        pushup(x);
    }
}T[2];
int c,n,m,q;
int a[2][N];
void check(){
    if(a[0][1]==a[1][1]||a[0][n]==a[1][m]){
        printf("0");
        return;
    }
    if(a[0][1]>a[1][1]){
        if(a[0][n]<a[1][m]){
            printf("0");
            return;
        }
        if(T[0].maxn[1]>T[1].maxn[1]&&T[0].minn[1]>T[1].minn[1])printf("1");
        else printf("0");
    }
    else{
        if(a[1][m]<a[0][n]){
            printf("0");
            return;
        }
        if(T[0].maxn[1]<T[1].maxn[1]&&T[0].minn[1]<T[1].minn[1])printf("1");
        else printf("0");
    }
}
int main(){
    freopen("expand.in","r",stdin);
    freopen("expand.out","w",stdout);
    read(c),read(n),read(m),read(q);
    T[0].build(1,1,n),T[1].build(1,1,m);
    rep(i,1,n)
        read(a[0][i]),T[0].modify(1,1,n,i,a[0][i]);
    rep(i,1,m)
        read(a[1][i]),T[1].modify(1,1,m,i,a[1][i]);
    check();
    while(q--){
        vector<pii>mod[2];
        int n1,n2;
        read(n1),read(n2);
        rep(i,1,n1){
            int x,y;
            read(x),read(y);
            mod[0].push_back(mp(x,a[0][x]));
            T[0].modify(1,1,n,x,y),a[0][x]=y;
        }
        rep(i,1,n2){
            int x,y;
            read(x),read(y);
            mod[1].push_back(mp(x,a[1][x]));
            T[1].modify(1,1,m,x,y),a[1][x]=y;
        }
        check();
        rep(i,0,n1-1){
            int x=mod[0][i].fir,y=mod[0][i].sec;
            a[0][x]=y,T[0].modify(1,1,n,x,y);
        }
        rep(i,0,n2-1){
            int x=mod[1][i].fir,y=mod[1][i].sec;
            a[1][x]=y,T[1].modify(1,1,m,x,y);
        }
    }
    return 0;
}