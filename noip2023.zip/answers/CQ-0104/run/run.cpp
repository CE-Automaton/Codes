#include<bits/stdc++.h>
#define rep(i,j,k) for(int i=j;i<=k;i++)
#define repp(i,j,k) for(int i=j;i>=k;i++)
#define mp make_pair
#define ls(x) x*2
#define rs(x) x*2+1
#define pii pair<int,int>
#define fir first
#define sec second
#define lowbit(i) i&-i
#define int long long
using namespace std;
typedef long long ll;
const int N=2e5+5,M=1e5+5,inf=1e18+7;
void read(int &p){
    int x=0,w=1;
    char ch=getchar();
    while(!isdigit(ch)){
        if(ch=='-')w=-1;
        ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	p=x*w;
}
/*
设dpi表示考虑到第i天结束跑步的最大能量，枚举开始跑步的时间j，
有转移dpi=-(i-j+1)*d+sum(j,i)+max(dpk,k<=j-2)。每当i往右移动一位的时候，每个值的变化量都是确定的。
于是可以线段树维护每一个下标j对应的值，前缀max维护后面那个东西，区间加区间max即可.
注意到开始结束跑步的时间一定是任务的起始/终止时间。于是离散化后即可做到mlogm.
好运来！
*/
int TT,idn;
int n,m,dp[N],maxn[N],k,d;
struct seg{
    int t[4*N],tag[4*N];
    void pushup(int x){
        t[x]=max(t[ls(x)],t[rs(x)]);
    }
    void pushdown(int x,int le,int ri){
        int mid=(le+ri)>>1;
        if(tag[x]==0)return;
        tag[ls(x)]+=tag[x],tag[rs(x)]+=tag[x];
        t[ls(x)]+=tag[x],t[rs(x)]+=tag[x];
        tag[x]=0;
    }
    void build(int x,int le,int ri){
        tag[x]=0,t[x]=-inf;
        if(le==ri)return;
        int mid=(le+ri)>>1;
        build(ls(x),le,mid),build(rs(x),mid+1,ri);
    }
    void add(int x,int le,int ri,int ql,int qr,int v){
        if(ql<=le&&qr>=ri){
            t[x]+=v,tag[x]+=v;
            return;
        }
        pushdown(x,le,ri);
        int mid=(le+ri)>>1;
        if(ql<=mid)add(ls(x),le,mid,ql,qr,v);
        if(qr>mid)add(rs(x),mid+1,ri,ql,qr,v);
        pushup(x);
    }
    void modify(int x,int le,int ri,int p,int v){
        if(le==ri){
            t[x]=v,tag[x]=0;
            return;
       }
       pushdown(x,le,ri);
       int mid=(le+ri)>>1;
       if(p<=mid)modify(ls(x),le,mid,p,v);
       else modify(rs(x),mid+1,ri,p,v);
       pushup(x);
    }
    int query(int x,int le,int ri,int ql,int qr){
        if(ql<=le&&qr>=ri)return t[x];
        pushdown(x,le,ri);
        int mid=(le+ri)>>1,res=-inf;
        if(ql<=mid)res=max(res,query(ls(x),le,mid,ql,qr));
        if(qr>mid)res=max(res,query(rs(x),mid+1,ri,ql,qr));
        pushup(x);
        return res;
    }
}T;
vector<pii>tsk[N];
struct tasks{
    int x,y,v;
}t[M];
int lsh[N],cntl,frm[N],led[N];
void solve(){
    read(n),read(m),read(k),read(d),cntl=0;
    rep(i,0,2e5+2)
        dp[i]=-inf,tsk[i].clear(),maxn[i]=-inf;
    rep(i,1,m){
        int x,y,v;
        read(x),read(y),read(v);
        t[i].x=x-y+1,t[i].y=x,t[i].v=v;
        lsh[++cntl]=t[i].x,lsh[++cntl]=t[i].y;
    }
        
    sort(lsh+1,lsh+cntl+1),cntl=unique(lsh+1,lsh+cntl+1)-lsh-1;
    rep(i,1,m){
        int x=lower_bound(lsh+1,lsh+cntl+1,t[i].x)-lsh;
        int y=lower_bound(lsh+1,lsh+cntl+1,t[i].y)-lsh;
    //    printf("%lld->%lld\n",t[i].x,x);
     //   printf("%lld->%lld\n",t[i].y,y);
        tsk[y].push_back(mp(x,t[i].v));
    }
    led[0]=1;
    rep(i,1,cntl){
        int nw=lsh[i],la=nw-k+1;
        frm[i]=lower_bound(lsh+1,lsh+cntl+1,la)-lsh;
        if(lsh[i-1]+1<lsh[i]||i==1)led[i]=i-1;
        else led[i]=i-2;
    //    printf("%lld:%lld %lld\n",i,led[i],frm[i]);
    }
    T.build(1,1,cntl);
    dp[0]=maxn[0]=0;
    rep(i,1,cntl){
        T.modify(1,1,cntl,i,maxn[led[i]]);
        if(i>1)T.add(1,1,cntl,1,i-1,-d*(lsh[i]-lsh[i-1]));
        T.add(1,1,cntl,i,i,-d);
        rep(j,0,(int)tsk[i].size()-1){
            int x=tsk[i][j].fir,v=tsk[i][j].sec;
            T.add(1,1,cntl,1,x,v);
        }
        dp[i]=T.query(1,1,cntl,frm[i],i);
        //printf("*%lld %lld\n",i,dp[i]);
        maxn[i]=max(maxn[i-1],dp[i]);
    }
    printf("%lld\n",maxn[cntl]);
}
signed main(){
    freopen("run.in","r",stdin);
    freopen("run.out","w",stdout);
    read(idn),read(TT);
    while(TT--)
        solve();
    return 0;
}