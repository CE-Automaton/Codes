#include <bits/stdc++.h>

#define x first
#define y second

using namespace std;

namespace fast_read{
	char buf[1000005], *s = buf, *t = buf, ch;
	inline char gc()
	{
		return s == t && (t = (s = buf) + fread(buf, 1, 1000000, stdin), s == t) ? EOF : *s ++ ;
	}
	template <typename T>
	inline void read(T &x)
	{
		x = 0, ch = gc();
		while(ch < '0' || ch > '9') ch = gc();
		while('0' <= ch && ch <= '9') x = x * 10 + ch - 48, ch = gc();
	}
};
using fast_read::read;

typedef long long LL;
typedef pair<int, int> PII;

const int N = 2e5 + 5;
const LL INF = 2e18;

int n, m, k;
LL d;
int l[N], r[N], w[N], x[N], s;
vector<PII> v[N];
struct node{
	int a, b;
	LL v, l, c;
}t[N * 4];

inline void add(int u, LL d)
{
	t[u].v += d, t[u].l += d;
	if(t[u].c != INF) t[u].c += d;
}
inline void cov(int u, LL d)
{
	t[u].v = t[u].c = d, t[u].l = 0;
}
inline void pushdown(int u)
{
	int ls = u << 1, rs = ls | 1;
	if(t[u].c != INF) cov(ls, t[u].c), cov(rs, t[u].c), t[u].c = INF;
	if(t[u].l) add(ls, t[u].l), add(rs, t[u].l), t[u].l = 0;
}
inline void build(int u, int a, int b)
{
	t[u].a = a, t[u].b = b;
	t[u].v = t[u].l = 0, t[u].c = INF;
	if(a != b)
	{
		int mid = a + b >> 1;
		build(u << 1, a, mid), build(u << 1 | 1, mid + 1, b);
	}
}
inline void modify(int u, int x, int y, LL d)
{
	if(x <= t[u].a && t[u].b <= y) return add(u, d);
	pushdown(u);
	int ls = u << 1, rs = ls | 1;
	if(t[ls].b >= x) modify(ls, x, y, d);
	if(t[rs].a <= y) modify(rs, x, y, d);
	t[u].v = max(t[ls].v, t[rs].v);
}
inline void change(int u, int x, int y, LL d)
{
	if(x <= t[u].a && t[u].b <= y) return cov(u, d);
	pushdown(u);
	int ls = u << 1, rs = ls | 1;
	if(t[ls].b >= x) change(ls, x, y, d);
	if(t[rs].a <= y) change(rs, x, y, d);
	t[u].v = max(t[ls].v, t[rs].v);
}
inline LL query(int u, int x, int y)
{
	if(x <= t[u].a && t[u].b <= y) return t[u].v;
	pushdown(u);
	int ls = u << 1, rs = ls | 1;
	LL res = -INF;
	if(t[ls].b >= x) res = query(ls, x, y);
	if(t[rs].a <= y) res = max(res, query(rs, x, y));
	return res;
}

int main()
{
	freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);
	
	int T;
	read(T), read(T);
	while(T -- )
	{
		read(n), read(m), read(k), read(d);
		memset(t, 0, sizeof t);
		s = 0;
		for(int i = 1; i <= m; i ++ )
		{
			int b;
			read(r[i]), read(b), read(w[i]);
			l[i] = r[i] - b;
			x[ ++ s] = l[i], x[ ++ s] = r[i];
		}
		
		sort(x, x + s + 1);
		s = unique(x, x + s + 1) - x - 1;
		for(int i = 1; i <= s; i ++ ) v[i].clear();
		for(int i = 1; i <= m; i ++ )
		{
			l[i] = lower_bound(x, x + s + 1, l[i]) - x;
			r[i] = lower_bound(x, x + s + 1, r[i]) - x;
			v[r[i]].push_back(make_pair(l[i], w[i]));
		}
		
		build(1, 0, s);
		for(int i = 1; i <= s; i ++ )
		{
			LL t = query(1, 0, i - 1);
			change(1, i, i, t);
			modify(1, 0, i - 1, -d * (x[i] - x[i - 1]));
			for(auto j : v[i]) modify(1, 0, j.x, j.y);
			if(x[i] > k)
			{
				int p = lower_bound(x, x + s + 1, x[i] - k) - x - 1;
				change(1, 0, p, -INF);
			}
		}
		
		printf("%lld\n", query(1, 0, s));
	}
	return 0;
}
