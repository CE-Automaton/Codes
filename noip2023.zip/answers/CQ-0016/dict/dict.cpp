#include <bits/stdc++.h>

using namespace std;

const int N = 3005;

int n, m;
char s[N];
int cnt[30];
int a[N], b[N], f, g;

int main()
{
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	f = g = 1e9;
	if(n == 1)
	{
		puts("1");
		return 0;
	}
	for(int i = 1; i <= n; i ++ )
	{
		scanf("%s", s + 1);
		memset(cnt, 0, sizeof cnt);
		for(int j = 1; j <= m; j ++ ) cnt[s[j] - 'a'] ++ ;
		for(int j = 0; j < 26; j ++ )
			if(cnt[j])
			{
				a[i] = j;
				break ;
			}
		for(int j = 25; j >= 0; j -- )
			if(cnt[j])
			{
				b[i] = j;
				break ;
			}
		if(b[i] < f) g = f, f = b[i];
		else if(b[i] < g) g = b[i];
	}
	for(int i = 1; i <= n; i ++ )
	{
		int t = b[i] == f ? g : f;
		putchar(a[i] < t ? '1' : '0');
	}
	return 0;
}
