#include <bits/stdc++.h>

using namespace std;

namespace fast_read{
	char buf[1000005], *s = buf, *t = buf, ch;
	inline char gc()
	{
		return s == t && (t = (s = buf) + fread(buf, 1, 1000000, stdin), s == t) ? EOF : *s ++ ;
	}
	template <typename T>
	inline void read(T &x)
	{
		x = 0, ch = gc();
		while(ch < '0' || ch > '9') ch = gc();
		while('0' <= ch && ch <= '9') x = x * 10 + ch - 48, ch = gc();
	}
};
using fast_read::read;

const int N = 5e5 + 5;

int n, m, T;
int ra[N], rb[N], a[N], b[N];

inline void solve()
{
	if(a[1] == b[1] || a[n] == b[m])
	{
		putchar('0');
		return ;
	}
	if(a[1] < b[1])
	{
		for(int i = 1; i <= n; i ++ ) a[i] = -a[i];
		for(int i = 1; i <= m; i ++ ) b[i] = -b[i];
	}
	if(a[n] < b[m])
	{
		putchar('0');
		return ;
	}
	int mx = -1e9;
	int lt = 1;
	for(int i = 1; i <= n; )
	{
		mx = a[i];
		int j = i + 1;
		while(j <= n && a[j] <= a[i]) j ++ ;
		if(j > n) break ;
		int mx = 1e9;
		for(int k = i; k <= j; k ++ ) mx = min(mx, a[k]);
		while(lt <= m && b[lt] >= mx)
		{
			lt ++ ;
			if(a[i] <= b[lt])
			{
				putchar('0');
				return ;
			}
		}
		if(lt > m)
		{
			putchar('0');
			return ;
		}
		i = j;
	}
	int rt = m;
	for(int i = n; i >= 1; )
	{
		int j = i - 1;
		while(j > 0 && a[j] < a[i]) j -- ;
		if(j <= 0) break ;
		int mx = 1e9;
		for(int k = j; k <= i; k ++ ) mx = min(mx, a[k]);
		while(rt > 0 && b[rt] >= mx)
		{
			rt -- ;
			if(a[i] <= b[rt])
			{
				putchar('0');
				return ;
			}
		}
		if(rt <= 0)
		{
			putchar('0');
			return ;
		}
		i = j;
	}
	if(rt < lt)
	{
		putchar('0');
		return ;
	}
	for(int i = lt; i <= rt; i ++ )
		if(mx <= b[i])
		{
			putchar('0');
			return ;
		}
	putchar('1');
	return ;
}

int main()
{
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);
	
	read(n), read(n), read(m), read(T);
	for(int i = 1; i <= n; i ++ ) read(ra[i]), a[i] = ra[i];
	for(int i = 1; i <= m; i ++ ) read(rb[i]), b[i] = rb[i];
	solve();
	while(T -- )
	{
		memcpy(a, ra, sizeof a);
		memcpy(b, rb, sizeof b);
		int k1, k2;
		read(k1), read(k2);
		while(k1 -- )
		{
			int p, v;
			read(p), read(v);
			a[p] = v;
		}
		while(k2 -- )
		{
			int p, v;
			read(p), read(v);
			b[p] = v;
		}
		solve();
	}
	return 0;
}
