#include <bits/stdc++.h>

using namespace std;

const int N = 1e5 + 5, M = 2e5 + 5;

int n, m;
int x[N], y[N];
int la[N], ne[M], en[M], idx;
int q[N], hh, tt;
int vis[N];
int dfn[N], low[N], dfst;
int sta[N];
int cir[N], cc;

inline void add(int a, int b)
{
	ne[ ++ idx] = la[a];
	la[a] = idx;
	en[idx] = b;
}
inline void bfs(int u, int d)
{
	if(vis[u]) return ;
	vis[u] = d;
	hh = tt = 0, q[0] = u;
	while(hh <= tt)
	{
		int u = q[hh ++ ];
		for(int i = la[u]; i; i = ne[i])
		{
			int v = en[i];
			if(!vis[v]) vis[v] = d, q[ ++ tt] = v;
		}
	}
}

inline void tarjan(int u, int fr)
{
	dfn[u] = low[u] = ++ dfst;
	sta[ ++ tt] = u;
	for(int i = la[u]; i; i = ne[i])
	{
		int v = en[i];
		if(!dfn[v])
		{
			tarjan(v, i);
			low[u] = min(low[u], low[v]);
		}
		else if(i != (fr ^ 1)) low[u] = min(low[u], dfn[v]);
	}
	if(low[u] == dfn[u])
	{
		if(sta[tt] != u)
		{
			cc = 0;
			int v;
			do{
				v = sta[tt -- ];
				cir[ ++ cc] = v;
			}while(v != u);
		}
		else tt -- ;
	}
}

int main()
{
	freopen("tribool.in", "r", stdin);
	freopen("tribool.out", "w", stdout);
	
	int T;
	scanf("%*d%d", &T);
	while(T -- )
	{
		memset(la, 0, sizeof la), idx = 1;
		memset(vis, 0, sizeof vis);
		memset(dfn, 0, sizeof dfn);
		memset(low, 0, sizeof low);
		dfst = 0;
		
		scanf("%d%d", &n, &m);
		for(int i = 1; i <= n; i ++ ) x[i] = i, y[i] = 0;
		for(int i = 1; i <= m; i ++ )
		{
			char op[3];
			int a, b;
			scanf("%s%d", op, &a);
			if(*op == 'T' || *op == 'F') x[a] = -1, y[a] = 0;
			else if(*op == 'U') x[a] = -2, y[a] = 0;
			else
			{
				scanf("%d", &b);
				x[a] = x[b], y[a] = y[b] ^ (*op == '-');
			}
		}
		
		for(int i = 1; i <= n; i ++ )
			if(x[i] > 0)
				add(i, x[i]), add(x[i], i);
		for(int i = 1; i <= n; i ++ )
		{
			if(x[i] < 0)
			{
				if(x[i] == -1) bfs(i, 1);
				else bfs(i, 2);
			}
			else if(x[i] == i)
			{
				if(y[i]) bfs(i, 2);
				else bfs(i, 1);
			}
		}
		
		for(int i = 1; i <= n; i ++ )
			if(!vis[i])
			{
				tt = 0;
				tarjan(i, -1);
				int t = 0;
				for(int j = 1; j <= cc; j ++ ) t ^= y[cir[j]];
				bfs(i, t + 1);
			}
		
		int ans = 0;
		for(int i = 1; i <= n; i ++ ) ans += vis[i] == 2;
		printf("%d\n", ans);
	}
	return 0;
}
