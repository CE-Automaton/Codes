#include<bits/stdc++.h>
using namespace std;
template<typename T> inline void read(T &x) {
    x = 0;
    int f = 1;
    char c = getchar();
    while(!isdigit(c)) {
        if(c == '-') f = -1;
        c = getchar();
    }
    while(isdigit(c)) x = x * 10 + c - '0', c = getchar();
    x *= f;
}
template<typename T, typename ...L> inline void read(T &x, L &...l) {
    read(x), read(l...);
}
typedef long long LL;
const int N = 4e5 + 10;
int c, T, n, m, k, d, l[N], r[N], w[N];
int lsh[N], tot;
LL dp[N], s[N];
vector<pair<int, int> > vec[N];
int find(int x) {
    return lower_bound(lsh + 1, lsh + 1 + tot, x) - lsh;
}
namespace SGT {
    #define ls (u << 1)
    #define rs (u << 1 | 1)
    LL mx[N << 2], tag[N << 2];
    void pushup(int u) {
        mx[u] = max(mx[ls], mx[rs]);
    }
    void build(int u = 1, int L = 1, int R = tot) {
        tag[u] = 0;
        if(L == R) {
            mx[u] = 1ll * lsh[L] * d;
            return; 
        }
        int mid = (L + R) >> 1;
        build(ls, L, mid), build(rs, mid + 1, R);
        pushup(u);
    }
    void upd(int u, LL v) {
        tag[u] += v;
        mx[u] += v;
    }
    void pushdown(int u) {
        if(!tag[u]) return;
        upd(ls, tag[u]), upd(rs, tag[u]);
        tag[u] = 0;
    }
    void add(int l, int r, LL v, int u = 1, int L = 1, int R = tot) {
        if(l <= L && R <= r) {
            upd(u, v);
            return;
        }
        pushdown(u);
        int mid = (L + R) >> 1;
        if(l <= mid) add(l, r, v, ls, L, mid);
        if(mid < r) add(l, r, v, rs, mid + 1, R);
        pushup(u);
    }
    LL qry(int l, int r, int u = 1, int L = 1, int R = tot) {
        if(l <= L && R <= r) return mx[u];
        pushdown(u);
        int mid = (L + R) >> 1;
        LL res = -1e18;
        if(l <= mid) res = qry(l, r, ls, L, mid);
        if(mid < r) res = max(res, qry(l, r, rs, mid + 1, R));
        return res;
    }
}
int main() {
    freopen("run.in", "r", stdin);
    freopen("run.out", "w", stdout);

    cin>>c>>T;
    while(T--) {
        tot = 0;
        read(n, m, k, d);
        for(int i = 1; i <= m; i++) {
            int x, y;
            read(x, y, w[i]);
            r[i] = x, l[i] = x - y + 1;
            lsh[++tot] = l[i], lsh[++tot] = r[i];
            lsh[++tot] = l[i] - 1;
        }
        sort(lsh + 1, lsh + 1 + tot);
        tot = unique(lsh + 1, lsh + 1 + tot) - lsh - 1;
        for(int i = 1; i <= tot; i++) vec[i].clear();
        for(int i = 1; i <= m; i++) {
            l[i] = find(l[i]), r[i] = find(r[i]);
            vec[r[i]].emplace_back(l[i], w[i]);
        }
        SGT::build();
        dp[0] = 0;
        for(int i = 1, j = 1; i <= tot; i++) {
            while(lsh[i] - lsh[j] >= k) j++;
            for(auto v: vec[i])
                SGT::add(1, v.first, v.second);
            if(i > 2) SGT::add(i, i, dp[i - 2]);
            dp[i] = max(dp[i - 1], SGT::qry(j, i) - 1ll * (lsh[i] + 1) * d);
        }
        printf("%lld\n", dp[tot]);
    }

    return 0;
}