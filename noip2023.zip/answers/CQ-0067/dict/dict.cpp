#include<bits/stdc++.h>
using namespace std;
#define mp(x, y) make_pair(x, y)
const int N = 3010;
int n, m, tot, rk1[N], rk2[N];
string s1[N], s2[N];
pair<string, int> s[N * 2];
void upd(int i, int cnt) {
    if(!rk1[i]) rk1[i] = cnt;
    else rk2[i] = cnt;
}
int main() {
    freopen("dict.in", "r", stdin);
    freopen("dict.out", "w", stdout);
    cin>>n>>m;
    for(int i = 1; i <= n; i++) {
        string tmp;
        cin>>tmp;
        sort(tmp.begin(), tmp.end());
        s[++tot] = mp(tmp, i);
        reverse(tmp.begin(), tmp.end());
        s[++tot] = mp(tmp, i);
    }
    sort(s + 1, s + 1 + tot);
    for(int i = 1, j, cnt = 0; i <= tot; i = j + 1) {
        cnt++, j = i;
        upd(s[i].second, cnt);
        while(j + 1 <= tot && s[j + 1].first == s[i].first) j++, upd(s[j].second, cnt);
    }
    for(int i = 1; i <= n; i++) {
        bool flg = 1;
        for(int j = 1; j <= n; j++) {
            if(i == j) continue;
            if(rk1[i] >= rk2[j]) {
                flg = 0;
                break;
            }
        }
        if(flg) putchar('1');
        else putchar('0');
    }
    cout<<endl;
    return 0;
}