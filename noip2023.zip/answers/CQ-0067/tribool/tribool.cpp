#include<bits/stdc++.h>
using namespace std;
const int N = 2e5 + 10;
int n, fa[N], id[N], op[N], c, T, m, sz[N];
bool vis[N], st[N];
vector<int> vec[N];
int find(int x) {
    return fa[x] == x ? x : fa[x] = find(fa[x]);
}
void merge(int x, int y) {
    x = find(x), y = find(y);
    if(x == y) return;
    fa[x] = y, sz[y] += sz[x];
}
int f(int x) {
    return (x <= n ? x : x - n);
}
int main() {
    freopen("tribool.in", "r", stdin);
    freopen("tribool.out", "w", stdout);
    cin>>c>>T;
    while(T--) {
        scanf("%d%d", &n, &m);
        int ans = 0;
        for(int i = 1; i <= n; i++) id[i] = i, op[i] = 0;
        // cerr<<"###############\n";
        for(int i = 1; i <= m; i++) {
            char o[2];
            int x, y;
            // cout<<i<<"!!!!!!!!!\n";
            scanf("%s%d", o, &x);
            switch(o[0]) {
                case 'T': {
                    id[x] = n + 1;
                    break;
                }
                case 'F': {
                    id[x] = n + 2;
                    break;
                }
                case 'U': {
                    id[x] = n + 3;
                    break;
                }
                case '+': {
                    scanf("%d", &y);
                    id[x] = id[y], op[x] = op[y];
                    break;
                }
                default: {
                    scanf("%d", &y);
                    id[x] = id[y], op[x] = op[y] ^ 1;
                    break;
                }
            }
        }
        for(int i = 1; i <= 2 * n; i++) {
            fa[i] = i, sz[i] = 1;
            vis[i] = st[i] = 0, vec[i].clear();
        }
        for(int i = 1; i <= n; i++) {
            if(id[i] > n) continue;
            if(op[i]) merge(i, id[i] + n), merge(i + n, id[i]);
            else merge(i, id[i]), merge(i + n, id[i] + n);
        }
        for(int i = 1; i <= n; i++) {
            int fat = find(i);
            if(find(i) == find(i + n)) {
                id[i] = n + 3;
                sz[fat]--;
            }
            if(id[i] == n + 3) st[fat] = st[find(i + n)] = 1;
        }
        for(int i = 1; i <= 2 * n; i++) vec[find(i)].emplace_back(i);
        for(int i = 1; i <= 2 * n; i++) {
            if(find(i) != i || vis[f(i)]) continue;
            for(auto v: vec[i]) vis[f(v)] = 1;
            if(st[i]) ans += sz[i];
        }
        printf("%d\n", ans);
    }

    return 0;
}
