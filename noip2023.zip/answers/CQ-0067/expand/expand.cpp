#include<bits/stdc++.h>
using namespace std;
template<typename T> inline void read(T &x) {
    x = 0;
    int f = 1;
    char c = getchar();
    while(!isdigit(c)) {
        if(c == '-') f = -1;
        c = getchar();
    }
    while(isdigit(c)) x = x * 10 + c - '0', c = getchar();
    x *= f;
}
template<typename T, typename ...L> inline void read(T &x, L &...l) {
    read(x), read(l...);
}
const int N = 5e5 + 10;
int c, n, m, q, x[N], y[N], tx[N], ty[N];
namespace case_1 {
    bool dp[2010][2010];
    bool chk() {
        if(tx[1] == ty[1]) return false;
        dp[0][0] = 1;
        for(int i = 1; i <= n; i++)
            for(int j = 1; j <= m; j++) {
                if((tx[1] > ty[1] && tx[i] > ty[j]) || (tx[1] < ty[1] && tx[i] < ty[j]))
                    dp[i][j] = dp[i - 1][j] | dp[i][j - 1] | dp[i - 1][j - 1];
                else dp[i][j] = 0;
            }
        return dp[n][m];
    }
    void solve() {
        memcpy(tx, x, sizeof tx), memcpy(ty, y, sizeof ty);
        putchar('0' + chk());
        while(q--) {
            int kx, ky, p, v;
            read(kx, ky);
            for(int i = 1; i <= max(n, m); i++) tx[i] = x[i], ty[i] = y[i];
            while(kx--) {
                read(p, v);
                tx[p] = v;
            }
            while(ky--) {
                read(p, v);
                ty[p] = v;
            }
            putchar('0' + chk());
        }
        puts("");
    }
}
namespace case_2 {
    bool chk() {
        if(tx[1] == ty[1]) return false;
        for(int i = 1, r = 1; i <= n; i++) {
            while(r <= m && ((tx[1] > ty[1] && tx[i] > ty[r + 1]) || (tx[1] < ty[1] && tx[i] < ty[r + 1]))) r++;
            if((tx[1] < ty[1] && tx[i] >= ty[r]) || (tx[1] > ty[1] && tx[i] <= ty[r])) return false;
        }
        return true;
    }
    void solve() {
        memcpy(tx, x, sizeof tx), memcpy(ty, y, sizeof ty);
        putchar('0' + chk());
        while(q--) {
            int kx, ky, p, v;
            read(kx, ky);
            for(int i = 1; i <= max(n, m); i++) tx[i] = x[i], ty[i] = y[i];
            while(kx--) {
                read(p, v);
                tx[p] = v;
            }
            while(ky--) {
                read(p, v);
                ty[p] = v;
            }
            putchar('0' + chk());
        }
        puts("");
    }
}
int main() {
    freopen("expand.in", "r", stdin);
    freopen("expand.out", "w", stdout);
    cin>>c>>n>>m>>q;
    for(int i = 1; i <= n; i++) read(x[i]);
    for(int i = 1; i <= m; i++) read(y[i]);
    if(n <= 2000 && m <= 2000) case_1::solve();
    else case_2::solve();

    return 0;
}