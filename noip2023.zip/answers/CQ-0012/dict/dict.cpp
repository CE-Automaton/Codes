#include<bits/stdc++.h>

using namespace std;

#define REP(i, l, r) for (int i = l; i <= r; i++)
#define PER(i, r, l) for (int i = r; i >= l; i--)

mt19937 engine(chrono::steady_clock::now().time_since_epoch().count());

template<class T>
T rand(T l, T r) { return uniform_int_distribution<>(l, r)(engine); }

const int maxN = 3e3 + 2, maxM = maxN * 2;

const int D1 = 37, pMod1 = 1e9 + 7;

const int D2 = 59, pMod2 = 998244353;

const int V = 26;

bool Mbe;

string s[maxM];
int hs1[maxM][maxN], hs2[maxM][maxN], p[maxM], f[maxN];
bool ans[maxN];

bool Med;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);
	
	int n, m;
	cin >> n >> m;
	REP(i, 1, n) {
		cin >> s[i], sort(s[i].begin(), s[i].end());
		s[i + n] = s[i], reverse(s[i + n].begin(), s[i + n].end());
	}
	REP(i, 1, 2 * n) REP(j, 0, m - 1) {
		p[i] = i;
		if (j) {
			hs1[i][j] = int(1LL * hs1[i][j - 1] * D1 % pMod1);
			hs2[i][j] = int(1LL * hs2[i][j - 1] * D2 % pMod2);
		}
		hs1[i][j] = (hs1[i][j] + s[i][j] - 'a' + 1) % pMod1;
		hs2[i][j] = (hs2[i][j] + s[i][j] - 'a' + 1) % pMod2;
	}
	sort(p + 1, p + 1 + 2 * n, [&](int a, int b) {
		int l = 0, r = m - 1;
		while (l < r) {
			int mid = (l + r + 1) >> 1;
			if (hs1[a][mid] == hs1[b][mid] && hs2[a][mid] == hs2[b][mid])
				l = mid;
			else r = mid - 1;
		}
		if (l == 0 && s[a][0] != s[b][0]) return s[a][0] < s[b][0];
		if (l == m - 1) return a > b;
		return s[a][l + 1] < s[b][l + 1];
	});
	int sum = 0;
	REP(i, 1, 2 * n) {
		if (p[i] > n) sum++, f[p[i] - n] = 1;
		else ans[p[i]] = !(sum - f[p[i]]);
	}
	REP(i, 1, n) cout << ans[i];
	cout << '\n';
//	cerr << 1.0 * (&Mbe - &Med) / 1024 / 1024 << '\n';
 
	return 0;
}

