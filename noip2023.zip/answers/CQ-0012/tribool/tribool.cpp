#include<bits/stdc++.h>

using namespace std;

#define REP(i, l, r) for (int i = l; i <= r; i++)
#define PER(i, r, l) for (int i = r; i >= l; i--)

mt19937 engine(chrono::steady_clock::now().time_since_epoch().count());

template<class T>
T rand(T l, T r) { return uniform_int_distribution<>(l, r)(engine); }

const int maxN = 2e5 + 10;

int n, tot, col[maxN], top[maxN];
bool bd;
vector<pair<int, int>> edges[maxN];
vector<int> vit;

inline int calc(int x, int y) {
	if (x == 2) return x;
	return x ^ y;
}

void addEdge(int u, int v, int x) {
	edges[u].emplace_back(v, x);
	edges[v].emplace_back(u, x);
//	cout << "edge: " << u << " <-> " << v << ' ' << x << '\n';
}

void dfs(int u) {
	vit.emplace_back(u);
	for (auto x: edges[u]) {
		int v = x.first, y = calc(col[u], x.second);
		if (col[v] == -1) col[v] = y, dfs(v);
		else if (col[v] != y) bd = true;
	}
}

void solve() {
	int m;
	cin >> n >> m, tot = n + 2;
	REP(i, 1, n + m + 2) edges[i].clear(), col[i] = -1;
	col[n + 1] = 0; //F
	col[n + 2] = 2; //U
	REP(i, 1, n) top[i] = i;
	while (m--) {
		char v;
		int x, y;
		cin >> v >> x, tot++;
		if (v == 'F') addEdge(n + 1, tot, 0);
		else if (v == 'T') addEdge(n + 1, tot, 1);
		else if (v == 'U') addEdge(n + 2, tot, 0);
		else {
			cin >> y;
			if (v == '+') addEdge(top[y], tot, 0);
			if (v == '-') addEdge(top[y], tot, 1);
		}
		top[x] = tot;
	}
	REP(i, 1, n) addEdge(top[i], i, 0);
	PER(i, n + 2, 1) if (col[i] == -1 || i > n) {
		if (col[i] == -1) col[i] = 0;
		vit.clear(), bd = false, dfs(i);
		if (bd) for (auto v: vit) col[v] = 2;
	}
	int ans = 0;
	REP(i, 1, n) ans += col[i] == 2;
	cout << ans << '\n';
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	freopen("tribool.in", "r", stdin);
	freopen("tribool.out", "w", stdout);
	
	int c, test;
	cin >> c >> test;
	REP(id, 1, test) {
//		cout << "testcase: " << id << '\n';
		solve();
//		cout << "---\n";
	}

	return 0;
}

