#include<bits/stdc++.h>

using namespace std;

#define REP(i, l, r) for (int i = l; i <= r; i++)
#define PER(i, r, l) for (int i = r; i >= l; i--)

mt19937 engine(chrono::steady_clock::now().time_since_epoch().count());

template<class T>
T rand(T l, T r) { return uniform_int_distribution<>(l, r)(engine); }

const int maxN = 5e5 + 3, maxM = 2e3 + 3;

int n, m, a[maxN], b[maxN], px[maxN], py[maxN], vx[maxN], vy[maxN];
bool dp[maxM][maxM];

void solve() {
	memset(dp, 0, sizeof dp);
//	REP(i, 1, n) cout << a[i] << " \n"[i == n];
//	REP(i, 1, m) cout << b[i] << " \n"[i == m];
	if (a[1] == b[1]) return cout << 0, void();
	int type = a[1] < b[1];
	REP(i, 1, n) REP(j, 1, m) {
		dp[i][j] = i + j == 2;
		if (type == 0 && a[i] <= b[j]) continue;
		if (type == 1 && a[i] >= b[j]) continue;
		dp[i][j] |= dp[i - 1][j];
		dp[i][j] |= dp[i][j - 1];
	}
	cout << dp[n][m];
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);
	
	int c, q;
	cin >> c >> n >> m >> q;
	REP(i, 1, n) cin >> a[i];
	REP(j, 1, m) cin >> b[j];
	solve();
	while (q--) {
		int kx, ky;
		cin >> kx >> ky;
		REP(i, 1, kx) cin >> px[i] >> vx[i], swap(a[px[i]], vx[i]);
		REP(i, 1, ky) cin >> py[i] >> vy[i], swap(b[py[i]], vy[i]);
		solve();
		REP(i, 1, kx) swap(a[px[i]], vx[i]);
		REP(i, 1, ky) swap(b[py[i]], vy[i]);
	}

	return 0;
}

