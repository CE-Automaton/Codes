#include<bits/stdc++.h>

using namespace std;

#define REP(i, l, r) for (int i = l; i <= r; i++)
#define PER(i, r, l) for (int i = r; i >= l; i--)

mt19937 engine(chrono::steady_clock::now().time_since_epoch().count());

template<class T>
T rand(T l, T r) { return uniform_int_distribution<>(l, r)(engine); }

const int maxN = 1e5 + 5;

const int long long inf = 0x3f3f3f3f3f3f3f3f;

class segmentTree {
	struct node {
		int l, r;
		long long mx, add;
		
		void updateAdd(long long x) {
			mx += x, add += x;
		}
	} tree[maxN << 2];
	
#define LS(u) (u << 1)
#define RS(u) (u << 1 | 1)
#define L(u) tree[u].l
#define R(u) tree[u].r
#define M(u) tree[u].mx
#define T(u) tree[u].add

	void pushUp(int u) { M(u) = max(M(LS(u)), M(RS(u))); }
	
	void pushDown(int u) {
		if (T(u)) {
			tree[LS(u)].updateAdd(T(u));
			tree[RS(u)].updateAdd(T(u));
			T(u) = 0;
		}
	}
	
	void build(int l, int r, int u = 1) {
		if (l > r) return;
		L(u) = l, R(u) = r, M(u) = -inf, T(u) = 0;
		if (l == r) return;
		int mid = (l + r) >> 1;
		build(l, mid, LS(u)), build(mid + 1, r, RS(u));
	}
	
public:
	segmentTree(int n) { build(0, n); }
	
	void modify(int l, int r, long long x, int u = 1) {
		if (R(u) < l || r < L(u)) return;
		if (l <= L(u) && R(u) <= r) return tree[u].updateAdd(x), void();
		pushDown(u);
		modify(l, r, x, LS(u)), modify(l, r, x, RS(u));
		pushUp(u);
	}
	
	long long query(int l, int r, int u = 1) {
		l = max(0, l);
		if (R(u) < l || r < L(u)) return -inf;
		if (l <= L(u) && R(u) <= r) return M(u);
		pushDown(u);
		return max(query(l, r, LS(u)), query(l, r, RS(u)));
	}
};

vector<pair<int, long long>> qu[maxN];

void solve() {
	int n, m, k;
	long long d;
	cin >> n >> m >> k >> d;
	segmentTree tr(n);
	long long res = -d * n;
	while (m--) {
		int x, y, v;
		cin >> x >> y >> v, res += v;
		qu[x].emplace_back(x - y + 1, v);
	}
	tr.modify(0, 0, inf);
	REP(i, 1, n) {
		long long tmp = tr.query(i - k - 1, i - 1) + d;
		tr.modify(i, i, tmp - tr.query(i, i));
		while (!qu[i].empty()) {
			int l = qu[i].back().first;
			long long v = qu[i].back().second;
			tr.modify(l, i, -v), qu[i].pop_back();
		}
	}
	cout << res + tr.query(n - k, n) << '\n'; 
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);
	
	int c, test;
	cin >> c >> test;
	while (test--) solve();

	return 0;
}

