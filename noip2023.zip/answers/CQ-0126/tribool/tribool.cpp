#include<bits/stdc++.h>

#define rep(i,l,r) for(int i=l;i<=r;i++)
#define per(i,l,r) for(int i=r;i>=l;i--)

using namespace std;

const int N=2e5+5;

int c,t;

struct node{
	char op;
	int x,y,t;
};

struct edge{
	int to;
	bool id;
};

node a[N];

vector<int>p[N];
vector<edge>e[N];

int n,m,cnt;

bool vis[N];
bool pd[N];

int tp[N];

int num;

void cl(int x){
	tp[x]=0,
	pd[x]=1;
	
	if(x<=n)
		vis[x]=1,
		num++;
	
	for(auto i:e[x])
		if(!pd[i.to])
			cl(i.to);
}

void cl2(int x){
	pd[x]=0;
	
	for(auto i:e[x])
		if(pd[i.to])
			cl2(i.to);
}

bool dfs(int x,int cl){
	tp[x]=cl;
	
	for(auto i:e[x]){
		int ncl=cl;
		if(i.id==1)
			ncl=3-ncl;
			
		if(a[i.to].op=='+'||a[i.to].op=='-'||a[i.to].op=='a'){
			if(!tp[i.to]){
				if(!dfs(i.to,ncl))
					return 0;
			}
			if(tp[i.to]!=ncl){
//				cout<<x<<" "<<i.to<<'\n';
				return 0;
			}
		}
		else{
			if(a[i.to].op=='U')
				return 0;
			if(a[i.to].op=='T'&&ncl==2)
				return 0;
			if(a[i.to].op=='F'&&ncl==1)
				return 0;
		}
	}
	
	return 1;
}

int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);

	ios::sync_with_stdio(false);
	cin.tie(0);

	cin>>c>>t;
	
	while(t--){
		cin>>n>>m;
		
		rep(i,1,n)
			a[++cnt]=node{'a',i,0,0},
			p[i].push_back(cnt);
		
		rep(i,1,m){
			cnt++;
			cin>>a[cnt].op>>a[cnt].x;
			a[cnt].t=i;
			
			if(a[cnt].op=='+'||a[cnt].op=='-')
				cin>>a[cnt].y;
				
			p[a[cnt].x].push_back(cnt);
		}
		
		rep(i,1,n){
			if(p[i].size()>1){
				e[p[i][0]].push_back(edge{p[i][p[i].size()-1],0});
				e[p[i][p[i].size()-1]].push_back(edge{p[i][0],0});
				
				int sz=p[i].size()-1;
				rep(j,1,sz){
					if(a[p[i][j]].op=='+'||a[p[i][j]].op=='-'){
						int l=0,r=p[a[p[i][j]].y].size()-1;
						while(l<r){
							int mid=(l+r+1)/2;
							if(a[p[a[p[i][j]].y][mid]].t<a[p[i][j]].t)
								l=mid;
							else 
								r=mid-1;
						}
						e[p[a[p[i][j]].y][l]].push_back(edge{p[i][j],a[p[i][j]].op=='-'});
						e[p[i][j]].push_back(edge{p[a[p[i][j]].y][l],a[p[i][j]].op=='-'});
					}
				}
			}
		}
		
//		rep(i,1,n*2)
//			for(auto j:e[i])
//				cout<<i<<" "<<j.to<<" "<<j.id<<'\n';
		
		int ans=0;
		
		rep(i,1,n){
			if(!vis[i]){
				num=0;
				cl(i);
				cl2(i);
//				cout<<i<<" "<<num<<'\n';
				if(!dfs(i,1)){
					num=0;
					cl(i);
					cl2(i);
					if(!dfs(i,2)){
//						cout<<i<<'\n';
						ans+=num;
					}
				}
			}
		}
		
		cout<<ans<<'\n';
		
		cnt=0;
		
		rep(i,1,n*2)
			p[i].clear();
		
		rep(i,1,n*2)
			e[i].clear();
		
		rep(i,1,n*2)
			vis[i]=0,
			tp[i]=0,
			pd[i]=0;
		
//		return 0;
	}

	return 0;
}
