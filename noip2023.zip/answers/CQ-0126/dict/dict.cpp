#include<bits/stdc++.h>

#define rep(i,l,r) for(int i=l;i<=r;i++)
#define per(i,l,r) for(int i=r;i>=l;i--)

using namespace std;

const int N=3e3+5;

string a[N],b[N];

int n,m;

int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	
	ios::sync_with_stdio(false);
	cin.tie(0);

	cin>>n>>m;
	
	rep(i,1,n){
		cin>>a[i];
		sort(a[i].begin(),a[i].end());
		
		b[i]=a[i];
		reverse(b[i].begin(),b[i].end());
	}
	
	string mx=b[1];
	rep(i,1,n)
		if(b[i]<mx)
			mx=b[i];
	
	rep(i,1,n)
		cout<<(a[i]<=mx);
	
	return 0;
}
