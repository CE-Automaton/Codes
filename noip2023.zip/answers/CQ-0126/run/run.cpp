#include<bits/stdc++.h>

#define int long long

#define rep(i,l,r) for(int i=l;i<=r;i++)
#define per(i,l,r) for(int i=r;i>=l;i--)

using namespace std;

const int N=1e5+5,M=1e3+5;

struct node{
	int l,r,v;
	
	void rd(){
		cin>>r>>l>>v,
		l=r-l+1;
	}
};

node a[N];

int c,t;

int n,m,k,d;

int dp[N],mx[N];

int dpp[M][M];

signed main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);

	ios::sync_with_stdio(false);
	cin.tie(0);

	cin>>c>>t;
	
	rep(test,1,t){
		cin>>n>>m>>k>>d;
		
		rep(i,1,m)
			a[i].rd();
		
		sort(a+1,a+m+1,[](node x,node y){return x.r<y.r;});
		
		if(17<=c&&c<=18){
			rep(i,1,m)
			{
				int l=0,r=i-1;
				
				while(l<r){
					int mid=(l+r+1)/2;
					
					if(a[mid].r<a[i].l)
						l=mid;
					else 
						r=mid-1;
				}
				
				dp[i]=max(mx[i-1],mx[l]+a[i].v-(a[i].r-a[i].l+1)*d);
				
				mx[i]=max(mx[i-1],dp[i]);
			}
			
			cout<<mx[m]<<'\n';
			
			continue;
		}
		
		if(1<=c&&c<=4){
			rep(i,1,n){
				mx[i]=mx[i-1];
				rep(j,1,i){
					if(i-j+1>k)
						break;
					
					int num=-(i-j+1)*d;
					per(kk,1,m){
//						if(a[kk].r<j)
//							break;
						if(j<=a[kk].l&&a[kk].r<=i)
							num+=a[kk].v;
					}
					
					dpp[i][j]=num+mx[max(0ll,j-2)];
					
					mx[i]=max(mx[i],dpp[i][j]);
				}
			}
//			rep(i,1,m)
//				cout<<a[i].v-(a[i].r-a[i].l+1)*d<<" ";
//			rep(i,1,n-1)
//				cout<<mx[i]<<" ";
			cout<<mx[n]<<'\n';
			
			continue;
		}
		
	}

	return 0;
}
