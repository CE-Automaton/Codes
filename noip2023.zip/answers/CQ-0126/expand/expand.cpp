#include<bits/stdc++.h>

#define rep(i,l,r) for(int i=l;i<=r;i++)
#define per(i,l,r) for(int i=r;i>=l;i--)

using namespace std;

const int N=5e5+5;

int c,n,m,q;

int x[N],y[N];

int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);

	ios::sync_with_stdio(false);
	cin.tie(0);

	cin>>c>>n>>m>>q;
	
	rep(i,1,n)
		cin>>x[i];
	
	rep(i,1,m)
		cin>>y[i];
		
	if(n==1&&m==1)
		cout<<(x[1]!=y[1]);
	
	rep(i,1,q){
		int kx,ky;
		cin>>kx>>ky;
		
		rep(j,1,kx){
			int p,v;
			cin>>p>>v,
			x[p]=v;
		}
		
		rep(j,1,ky){
			int p,v;
			cin>>p>>v,
			y[p]=v;
		}
		
		if(n==1&&m==1)
			cout<<(x[1]!=y[1]);
	}

	return 0;
}
