#include<bits/stdc++.h>
#define L(i,l,r) for(int i=(l);i<=(r);++i)
#define R(i,r,l) for(int i=(r);i>=(l);--i)
using namespace std;
using i64=long long;
namespace nqio {
	const int mxbf=1<<20;
	char ib[mxbf],*p1,*p2,c;
	bool s;
	struct q {
		void r(char&x) {
//			return x=getchar(),void();
			x=(p1==p2&&(p2=(p1=ib)+fread(ib,1,mxbf,stdin),p1==p2)?EOF:*p1++);
		} q&operator>>(char&x) {
			r(x);
			while(x<32)r(x);
			return *this;
		} q&operator>>(char*x) {
			r(c);
			while(c<32)r(c);
			while(c>=32)*x++=c,r(c);
			*x=0;
			return *this;
		} q&operator>>(string&x) {
			r(c);
			while(c<32)r(c);
			x=c,r(c);
			while(c>=32)x+=c,r(c);
			return *this;
		} template<typename t>q&operator>>(t&x) {
			r(c),s=0;
			while(!isdigit(c))s|=c==45,r(c);
			x=0;
			while(isdigit(c))x=x*10+(c^48),r(c);
			if(s)x=-x;
			return *this;
		}
	} qi;
	char ob[mxbf],*pp=ob,*pd=pp+mxbf,stk[127],*tp=stk;
	struct p {
		void f() {
			fwrite(ob,1,pp-ob,stdout),pp=ob;
		}~p() {
			f();
		} void w(char x) {
			if((*pp++=x,pp)==pd)f();
		} p&operator<<(char x) {
			w(x);
			return *this;
		} p&operator<<(char*x) {
			while(*x)w(*x++);
			return *this;
		} p&operator<<(string x) {
			for(char c:x)w(c);
			return *this;
		} template<typename t>p&operator<<(t x) {
			if(x==0)return w(48),*this;
			if(x<0)x=-x,w(45);
			while(x)*tp++=x%10^48,x/=10;
			while(tp!=stk)w(*--tp);
			return *this;
		}
	} qo;
}
using nqio::qi;
using nqio::qo;
namespace yihlaushih {
	bool _114;

	const int maxn=2e5+5;
	int n,m,k,d;
	int ha[maxn],hn;
	int l[maxn],r[maxn],v[maxn];
#define ls (p<<1)
#define rs (p<<1|1)
	const int maxt=maxn<<3;
	i64 mx[maxt],lzy[maxt];
	void modify(int p,int l,int r,int ql,int qr,i64 d) {
		if(ql<=l&&r<=qr) {
			mx[p]+=d,lzy[p]+=d;
			return ;
		}
		if(lzy[p]) {
			mx[ls]+=lzy[p],mx[rs]+=lzy[p];
			lzy[ls]+=lzy[p],lzy[rs]+=lzy[p];
			lzy[p]=0;
		}
		int mid=l+r>>1;
		if(ql<=mid)modify(ls,l,mid,ql,qr,d);
		if(mid<qr)modify(rs,mid+1,r,ql,qr,d);
		mx[p]=max(mx[ls],mx[rs]);
	} void op(int p,int l,int r,int pos,i64 d) {
		if(l==r) {
			mx[p]=d;
			return ;
		}
		if(lzy[p]) {
			mx[ls]+=lzy[p],mx[rs]+=lzy[p];
			lzy[ls]+=lzy[p],lzy[rs]+=lzy[p];
			lzy[p]=0;
		}
		int mid=l+r>>1;
		if(pos<=mid)op(ls,l,mid,pos,d);
		else op(rs,mid+1,r,pos,d);
		mx[p]=max(mx[ls],mx[rs]);
	} i64 query(int p,int l,int r,int ql,int qr) {
		if(ql<=l&&r<=qr) {
			return mx[p];
		}
		if(lzy[p]) {
			mx[ls]+=lzy[p],mx[rs]+=lzy[p];
			lzy[ls]+=lzy[p],lzy[rs]+=lzy[p];
			lzy[p]=0;
		}
		int mid=l+r>>1;
		i64 ret=0;
		if(ql<=mid)ret=query(ls,l,mid,ql,qr);
		if(mid<qr)ret=max(ret,query(rs,mid+1,r,ql,qr));
		return ret;
	}
#undef ls
#undef rs
	vector<int > app[maxn];

	bool _514;
	void _main() {
		fprintf(stderr,"floor mee:%lf MB\n",(&_114-&_514)/1024./1024.);
		freopen("run.in","r",stdin);
		freopen("run.out","w",stdout);
		int c,t;
		qi>>c>>t;
		while(t--) {
			qi>>n>>m>>k>>d;
			hn=0;
			L(i,1,m) {
				int x,y;
				qi>>x>>y>>v[i];
				l[i]=x-y+1,r[i]=x;
				ha[++hn]=l[i],ha[++hn]=r[i]+1;
			}
			sort(ha+1,ha+1+hn),hn=unique(ha+1,ha+1+hn)-ha-1;
//			L(i,1,hn)printf("dwdq:%d %d\n",i,ha[i]);
			L(i,1,m) {
				l[i]=lower_bound(ha+1,ha+1+hn,l[i])-ha;
				r[i]=lower_bound(ha+1,ha+1+hn,r[i]+1)-ha;
				app[r[i]].push_back(i);
//				printf("Fd;%d %d %d %d\n",i,l[i],r[i],v[i]);
			}
			memset(lzy,0,sizeof lzy);
			memset(mx,0,sizeof mx);
			i64 ans=0;
			int j=1;
			L(i,1,hn-1) {
				while(j<=i&&ha[i+1]-ha[j]>k)++j;
				modify(1,1,hn-1,1,i,-1ll*(ha[i+1]-ha[i])*d);
				for(int g:app[i+1]) {
					modify(1,1,hn-1,1,l[g],v[g]);
				}
				app[i+1].clear();
				if(i<hn-1)op(1,1,hn-1,i+1,ans);
				if(j<=i) {
					i64 f=query(1,1,hn-1,j,i);
					ans=max(ans,f);
//					printf("calc:%d %d %d\n",i,j,f);
				}
			}
			qo<<ans<<'\n';
		}
		return ;
	}
}
int main() {
	return yihlaushih::_main(),0;
}
/*
1 1
9 7 8 1
5 5 7
7 7 4
9 3 4
9 3 13
6 4 6
3 3 4
3 1 6

26

1 1
6 4 3 9
3 3 1
2 1 12
2 2 15
5 1 10
*/
