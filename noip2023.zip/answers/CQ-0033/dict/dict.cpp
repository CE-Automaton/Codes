#include<bits/stdc++.h>
#define L(i,l,r) for(int i=(l);i<=(r);++i)
#define R(i,r,l) for(int i=(r);i>=(l);--i)
using namespace std;
namespace nqio {
	const int mxbf=1<<20;
	char ib[mxbf],*p1,*p2,c;
	bool s;
	struct q {
		void r(char&x) {
//			return x=getchar(),void();
			x=(p1==p2&&(p2=(p1=ib)+fread(ib,1,mxbf,stdin),p1==p2)?EOF:*p1++);
		} q&operator>>(char&x) {
			r(x);
			while(x<32)r(x);
			return *this;
		} q&operator>>(char*x) {
			r(c);
			while(c<32)r(c);
			while(c>=32)*x++=c,r(c);
			*x=0;
			return *this;
		} q&operator>>(string&x) {
			r(c);
			while(c<32)r(c);
			x=c,r(c);
			while(c>=32)x+=c,r(c);
			return *this;
		} template<typename t>q&operator>>(t&x) {
			r(c),s=0;
			while(!isdigit(c))s|=c==45,r(c);
			x=0;
			while(isdigit(c))x=x*10+(c^48),r(c);
			if(s)x=-x;
			return *this;
		}
	} qi;
	char ob[mxbf],*pp=ob,*pd=pp+mxbf,stk[127],*tp=stk;
	struct p {
		void f() {
			fwrite(ob,1,pp-ob,stdout),pp=ob;
		}~p() {
			f();
		} void w(char x) {
			if((*pp++=x,pp)==pd)f();
		} p&operator<<(char x) {
			w(x);
			return *this;
		} p&operator<<(char*x) {
			while(*x)w(*x++);
			return *this;
		} p&operator<<(string x) {
			for(char c:x)w(c);
			return *this;
		} template<typename t>p&operator<<(t x) {
			if(x==0)return w(48),*this;
			if(x<0)x=-x,w(45);
			while(x)*tp++=x%10^48,x/=10;
			while(tp!=stk)w(*--tp);
			return *this;
		}
	} qo;
}
using nqio::qi;
using nqio::qo;
namespace yihlaushih {
	bool _114;

	int n,m;
	const int maxn=3005;
	string s[maxn];

int flag[maxn];
	bool _514;
	void _main() {
		fprintf(stderr,"floor mee:%lf MB\n",(&_114-&_514)/1024./1024.);
		freopen("dict.in","r",stdin);
		freopen("dict.out","w",stdout);
qi>>n>>m;
L(i,1,n)flag[i]=1;
string t;
L(i,1,n){
	qi>>s[i];
	sort(s[i].begin(),s[i].end());
	string g=s[i];
	reverse(s[i].begin(),s[i].end());
	if(i==1)t=s[i];
	else {
		if(g>=t)flag[i]=0;
		t=min(t,s[i]);
	}
}
R(i,n,1){
	string g=s[i];
	reverse(g.begin(),g.end());
	if(i==n)t=s[i];
	else {
		if(g>=t)flag[i]=0;
		t=min(t,s[i]);
	}
}
L(i,1,n)qo<<flag[i];
		return ;
	}
}
int main() {
	return yihlaushih::_main(),0;
}
/*
2 1
a
a
*/
