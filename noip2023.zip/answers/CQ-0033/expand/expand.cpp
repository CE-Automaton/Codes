//#include<bits/stdc++.h>
//#define L(i,l,r) for(int i=(l);i<=(r);++i)
//#define R(i,r,l) for(int i=(r);i>=(l);--i)
//using namespace std;
//namespace nqio {
//	const int mxbf=1<<20;
//	char ib[mxbf],*p1,*p2,c;
//	bool s;
//	struct q {
//		void r(char&x) {
//			return x=getchar(),void();
//			x=(p1==p2&&(p2=(p1=ib)+fread(ib,1,mxbf,stdin),p1==p2)?EOF:*p1++);
//		} q&operator>>(char&x) {
//			r(x);
//			while(x<32)r(x);
//			return *this;
//		} q&operator>>(char*x) {
//			r(c);
//			while(c<32)r(c);
//			while(c>=32)*x++=c,r(c);
//			*x=0;
//			return *this;
//		} q&operator>>(string&x) {
//			r(c);
//			while(c<32)r(c);
//			x=c,r(c);
//			while(c>=32)x+=c,r(c);
//			return *this;
//		} template<typename t>q&operator>>(t&x) {
//			r(c),s=0;
//			while(!isdigit(c))s|=c==45,r(c);
//			x=0;
//			while(isdigit(c))x=x*10+(c^48),r(c);
//			if(s)x=-x;
//			return *this;
//		}
//	} qi;
//	char ob[mxbf],*pp=ob,*pd=pp+mxbf,stk[127],*tp=stk;
//	struct p {
//		void f() {
//			fwrite(ob,1,pp-ob,stdout),pp=ob;
//		}~p() {
//			f();
//		} void w(char x) {
//			if((*pp++=x,pp)==pd)f();
//		} p&operator<<(char x) {
//			w(x);
//			return *this;
//		} p&operator<<(char*x) {
//			while(*x)w(*x++);
//			return *this;
//		} p&operator<<(string x) {
//			for(char c:x)w(c);
//			return *this;
//		} template<typename t>p&operator<<(t x) {
//			if(x==0)return w(48),*this;
//			if(x<0)x=-x,w(45);
//			while(x)*tp++=x%10^48,x/=10;
//			while(tp!=stk)w(*--tp);
//			return *this;
//		}
//	} qo;
//}
//using nqio::qi;
//using nqio::qo;
//namespace yihlaushih {
//	bool _114;
//
//	const int maxn=5e5+5;
//	int c,n,m,q;
//	int a[maxn],b[maxn];
//	int nxt[maxn];
//	int s1[maxn],s2[maxn];
//	int t1,t2;
//	int b1[maxn],b2[maxn];
//	int m1[maxn],m2[maxn];
//	inline void calc() {
//		int comp=0;
//		if(a[1]<b[1]&&a[n]<b[m]) {
//			comp=1;
//		}
//		if(a[1]>b[1]&&a[n]>b[m]) {
//			comp=2;
//		}
//		if(!comp)qo<<'0';
//		else {
//			auto ac=[&](int q,int p)->bool {
//				return comp==1?(q<p):(q>p);
//			};
//			auto bc=[&](int q,int p)->bool {
//				return comp==1?(q>p):(q<p);
//			};
//			t1=t2=0;
//			L(i,1,m) {
//				int j=i;
//				while(j<m&&!bc(b[j],b[j+1]))++j;
//				nxt[i]=j;
//				if(!t1||bc(b[nxt[s1[t1]]],b[nxt[i]]))s1[++t1]=i,m1[t1]=i;
//				else m1[t1]=i;
//				b1[i]=t1;
//				if(!t2||bc(b[s2[t2]],b[i]))s2[++t2]=i,m2[t2]=i;
//				else m2[t2]=i;
//				b2[i]=t2;
////				printf("%d %d %d %d\n",i,j,s1[t1],s2[t2]);
//				i=j;
//			}
//			printf("t1:%d\n",t1);
//			L(i,1,t1)printf("%d ",s1[i]);
//			printf("\n");
//			printf("t2:%d\n",t2);
//			L(i,1,t2)printf("%d ",s2[i]);
//			printf("\n");
//			int tp=1;
//			L(i,1,n) {
//				int j=i;
//				while(j<n&&!ac(a[j],a[j+1]))++j;
//				int l=1,r=tp,pos=0;
//				while(l<=r) {
//					int mid=l+r>>1;
//					printf("mid:%d %d %d\n",mid,s1[mid],nxt[s1[mid]],bc(b[nxt[s1[mid]]],a[i]));
//					if(!bc(b[nxt[s1[mid]]],a[i]))r=mid-1;
//					else l=mid+1,pos=mid;
//				}
//				tp=pos;
//				if(!tp)break;
//				l=b2[m1[tp]]+1,r=t2,pos=b2[m1[tp]];
//				while(l<=r){
//					int mid=l+r>>1;
//					if(ac(a[j],b[s2[mid]]))pos=mid,l=mid+1;
//					else r=mid-1;
//				}
//				tp=b1[m2[pos]];
//				printf("%d:%d\n",i,tp);
//				i=j;
//			}
//			if(tp&&tp==t1) {
//				qo<<'1';
//			} else {
//				qo<<'0';
//			}
//		}
//	}
//	int x[maxn],y[maxn];
//
//	bool _514;
//	void _main() {
//		fprintf(stderr,"floor mee:%lf MB\n",(&_114-&_514)/1024./1024.);
////		freopen("expand2.in","r",stdin);
////		freopen("expand.out","w",stdout);
//		qi>>c>>n>>m>>q;
//		L(i,1,n)qi>>x[i];
//		L(i,1,m)qi>>y[i];
//		L(i,1,n)a[i]=x[i];
//		L(i,1,m)b[i]=y[i];
//		calc();
//		while(q--) {
//			L(i,1,n)a[i]=x[i];
//			L(i,1,m)b[i]=y[i];
//			int k1,k2;
//			qi>>k1>>k2;
//			while(k1--) {
//				int p,v;
//				qi>>p>>v;
//				a[p]=v;
//			}
//			while(k2--) {
//				int p,v;
//				qi>>p>>v;
//				b[p]=v;
//			}
//			calc();
//		}
//		return ;
//	}
//}
//int main() {
//	return yihlaushih::_main(),0;
//}
///*
//
//195 303 437 815 365 302
//342 297 445 838 304 427
//
//1 6 6 0
//1 4 9 11 7 3
//6 2 10 12 5 8
//
//3 3 3 0
//8 6 9
//1 7 4
//*/
#include<bits/stdc++.h>
#define L(i,l,r) for(int i=(l);i<=(r);++i)
#define R(i,r,l) for(int i=(r);i>=(l);--i)
using namespace std;
namespace nqio {
	const int mxbf=1<<20;
	char ib[mxbf],*p1,*p2,c;
	bool s;
	struct q {
		void r(char&x) {
//			return x=getchar(),void();
			x=(p1==p2&&(p2=(p1=ib)+fread(ib,1,mxbf,stdin),p1==p2)?EOF:*p1++);
		} q&operator>>(char&x) {
			r(x);
			while(x<32)r(x);
			return *this;
		} q&operator>>(char*x) {
			r(c);
			while(c<32)r(c);
			while(c>=32)*x++=c,r(c);
			*x=0;
			return *this;
		} q&operator>>(string&x) {
			r(c);
			while(c<32)r(c);
			x=c,r(c);
			while(c>=32)x+=c,r(c);
			return *this;
		} template<typename t>q&operator>>(t&x) {
			r(c),s=0;
			while(!isdigit(c))s|=c==45,r(c);
			x=0;
			while(isdigit(c))x=x*10+(c^48),r(c);
			if(s)x=-x;
			return *this;
		}
	} qi;
	char ob[mxbf],*pp=ob,*pd=pp+mxbf,stk[127],*tp=stk;
	struct p {
		void f() {
			fwrite(ob,1,pp-ob,stdout),pp=ob;
		}~p() {
			f();
		} void w(char x) {
			if((*pp++=x,pp)==pd)f();
		} p&operator<<(char x) {
			w(x);
			return *this;
		} p&operator<<(char*x) {
			while(*x)w(*x++);
			return *this;
		} p&operator<<(string x) {
			for(char c:x)w(c);
			return *this;
		} template<typename t>p&operator<<(t x) {
			if(x==0)return w(48),*this;
			if(x<0)x=-x,w(45);
			while(x)*tp++=x%10^48,x/=10;
			while(tp!=stk)w(*--tp);
			return *this;
		}
	} qo;
}
using nqio::qi;
using nqio::qo;
namespace yihlaushih {
	bool _114;

	const int maxn=5e5+5;
	int c,n,m,q;
	int stk[maxn],tp;
	int a[maxn],b[maxn];
	int nxt[maxn];
	inline void calc() {
		int comp=0;
		if(a[1]<b[1]&&a[n]<b[m]) {
			comp=1;
		}
		if(a[1]>b[1]&&a[n]>b[m]) {
			comp=2;
		}
		if(!comp)qo<<'0';
		else {
			auto ac=[&](int q,int p)->bool {
				return comp==1?(q<p):(q>p);
			};
			auto bc=[&](int q,int p)->bool {
				return comp==1?(q>p):(q<p);
			};
			L(i,1,m) {
				int j=i;
				while(j<m&&!bc(b[j],b[j+1]))++j;
				nxt[i]=j;
				i=j;
			}
			tp=0;
			stk[++tp]=1;
			L(i,1,n) {
				int j=i;
				while(j<n&&!ac(a[j],a[j+1]))++j;
				while(tp&&!bc(b[nxt[stk[tp]]],a[i]))--tp;
				if(!tp)break;
				while(nxt[stk[tp]]<m&&ac(a[j],b[nxt[stk[tp]]+1])){
					int x=nxt[stk[tp]]+1;
//					while(tp&&!bc(b[nxt[stk[tp]]],b[nxt[x]]))--tp;
					stk[++tp]=x;
				}
//				printf("line:%d %d\n",i,j);
//				L(k,1,tp)printf("ins:%d %d\n",stk[k],nxt[stk[k]]);
				i=j;
			}
			if(tp&&nxt[stk[tp]]==m) {
				qo<<'1';
			} else {
				qo<<'0';
			}
		}
	}
	int x[maxn],y[maxn];

	bool _514;
	void _main() {
		fprintf(stderr,"floor mee:%lf MB\n",(&_114-&_514)/1024./1024.);
		freopen("expand.in","r",stdin);
		freopen("expand.out","w",stdout);
		qi>>c>>n>>m>>q;
		L(i,1,n)qi>>x[i];
		L(i,1,m)qi>>y[i];
		L(i,1,n)a[i]=x[i];
		L(i,1,m)b[i]=y[i];
		calc();
		while(q--) {
			L(i,1,n)a[i]=x[i];
			L(i,1,m)b[i]=y[i];
			int k1,k2;
			qi>>k1>>k2;
			while(k1--) {
				int p,v;
				qi>>p>>v;
				a[p]=v;
			}
			while(k2--) {
				int p,v;
				qi>>p>>v;
				b[p]=v;
			}
			calc();
		}
		return ;
	}
}
int main() {
	return yihlaushih::_main(),0;
}
/*

195 303 437 815 365 302
342 297 445 838 304 427

1 6 6 0
1 4 9 11 7 3
6 2 10 12 5 8
*/
