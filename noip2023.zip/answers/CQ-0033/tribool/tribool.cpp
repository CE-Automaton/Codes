#include<bits/stdc++.h>
#define L(i,l,r) for(int i=(l);i<=(r);++i)
#define R(i,r,l) for(int i=(r);i>=(l);--i)
using namespace std;
namespace nqio {
	const int mxbf=1<<20;
	char ib[mxbf],*p1,*p2,c;
	bool s;
	struct q {
		void r(char&x) {
//			return x=getchar(),void();
			x=(p1==p2&&(p2=(p1=ib)+fread(ib,1,mxbf,stdin),p1==p2)?EOF:*p1++);
		} q&operator>>(char&x) {
			r(x);
			while(x<32)r(x);
			return *this;
		} q&operator>>(char*x) {
			r(c);
			while(c<32)r(c);
			while(c>=32)*x++=c,r(c);
			*x=0;
			return *this;
		} q&operator>>(string&x) {
			r(c);
			while(c<32)r(c);
			x=c,r(c);
			while(c>=32)x+=c,r(c);
			return *this;
		} template<typename t>q&operator>>(t&x) {
			r(c),s=0;
			while(!isdigit(c))s|=c==45,r(c);
			x=0;
			while(isdigit(c))x=x*10+(c^48),r(c);
			if(s)x=-x;
			return *this;
		}
	} qi;
	char ob[mxbf],*pp=ob,*pd=pp+mxbf,stk[127],*tp=stk;
	struct p {
		void f() {
			fwrite(ob,1,pp-ob,stdout),pp=ob;
		}~p() {
			f();
		} void w(char x) {
			if((*pp++=x,pp)==pd)f();
		} p&operator<<(char x) {
			w(x);
			return *this;
		} p&operator<<(char*x) {
			while(*x)w(*x++);
			return *this;
		} p&operator<<(string x) {
			for(char c:x)w(c);
			return *this;
		} template<typename t>p&operator<<(t x) {
			if(x==0)return w(48),*this;
			if(x<0)x=-x,w(45);
			while(x)*tp++=x%10^48,x/=10;
			while(tp!=stk)w(*--tp);
			return *this;
		}
	} qo;
}
using nqio::qi;
using nqio::qo;
namespace yihlaushih {
	bool _114;

	int n,m;
	const int maxn=2e5+5;
	int val[maxn];
	vector<int > app[maxn];
	const int inf=0x3f3f3f3f;
	int fa[maxn],cc[maxn],typ[maxn];
	inline int getfa(int x,int &op) {
		if(x==0||x==inf)return 0;
		if(x==fa[x])return x;
		fa[x]=getfa(fa[x],cc[x]);
		op^=cc[x];
		return fa[x];
	}

	bool _514;
	void _main() {
		fprintf(stderr,"floor mee:%lf MB\n",(&_114-&_514)/1024./1024.);
		freopen("tribool.in","r",stdin);
		freopen("tribool.out","w",stdout);
		int c,t;
		qi>>c>>t;
		while(t--) {
			qi>>n>>m;
			int tot=n;
			L(i,1,tot) {
				val[i]=i;
				app[i].push_back(i);
			}
			L(i,1,m) {
				char op;
				int x;
				qi>>op>>x;
				if(op=='+') {
					int y;
					qi>>y;
					val[++n]=val[app[y].back()];
					app[x].push_back(n);
				} else if(op=='-') {
					int y;
					qi>>y;
					val[++n]=-val[app[y].back()];
					app[x].push_back(n);
				} else {
					val[++n]=(op=='U'?0:(op=='T'?inf:-inf));
					app[x].push_back(n);
				}
			}
//			L(i,1,tot){
//				printf("%d :FEFEWfew %d %d\n",i,app[i].back(),val[app[i].back()]);
//			}
			L(i,1,n)fa[i]=i,cc[i]=0,typ[i]=0;
			L(i,1,tot) {
				int x=app[i].front(),y=app[i].back();
				if(val[x]!=val[y]) {
					int tx=val[x]>0,ty=val[y]>0;
					int X=getfa(abs(val[x]),tx),Y=getfa(abs(val[y]),ty);
//					printf("comp:%d %d %d\n",i,X,Y);
					if(X==Y) {
						if(tx!=ty)typ[X]=1;
					} else {
						if(!X)X=Y;
						else if(X&&Y) {
							if(tx!=ty)cc[Y]^=1;
							fa[Y]=X;
							typ[X]|=typ[Y];
						}
						if((val[x]==0)||(val[y]==0))typ[X]=1;
					}
				}
			}
			int ans=0;
			L(i,1,tot) {
				int x=app[i].front(),op=0;
				int X=getfa(abs(val[x]),op);
				if(typ[X]==1)++ans;
				app[i].clear();
//				printf("final:%d %d %d %d\n",x,val[x],X,typ[X]);
			}
			qo<<ans<<'\n';
		}
		return ;
	}
}
int main() {
	return yihlaushih::_main(),0;
}
/*
1 1
10 10
- 7 5
+ 5 1
+ 1 7
+ 2 3
+ 3 4
+ 4 6
+ 6 8
- 8 9
+ 9 10
- 10 2
*/

