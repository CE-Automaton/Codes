//Author: Shunpower in NOIP2023
//May the force be with you and me.
#include <bits/stdc++.h>
#define fr1(i,a,b) for(int (i)=(a);(i)<=(b);(i)++)
#define fr2(i,a,b) for(int (i)=(a);(i)>=(b);(i)--)
#define pii pair<int,int>
#define ll long long
#define ull unsigned ll
#define pll pair<ll,ll>
#define fi first
#define se second
#define il inline
#define mp make_pair
#define pb push_back
#define ld long double
using namespace std;
const int N=1e5+10;
int c,T;
ll n,m,k,d;
vector <pll> clg[N];
ll dp[1010][1010];
void solve(){
    cin>>n>>m>>k>>d;
    if(c<=9){
	    fr1(i,0,n){
	    	clg[i].clear(); 
			fr1(j,0,k){
	    		dp[i][j]=-1e18;
			}
		}
		dp[0][0]=0;
        fr1(i,1,m){
            int x,y,v;
            cin>>x>>y>>v;
            clg[x].pb(mp(y,v));
        }
        fr1(i,1,n){
        	if(clg[i].empty()){
        		continue;
			}
			sort(clg[i].begin(),clg[i].end());
		}
        fr1(i,1,n){
            int poi=0;
            ll sum=0;
            fr1(j,0,k){
            	dp[i][0]=max(dp[i-1][j],dp[i][0]);
			}
            fr1(j,1,k){
                while(poi<clg[i].size()&&clg[i][poi].fi<=j){
                    sum+=clg[i][poi].se;
                    poi++;
                }
                dp[i][j]=dp[i-1][j-1]-d+sum;
//                cout<<i<<" "<<j<<"<- "<<dp[i][j]<<endl;
            }
        }
        ll ans=0;
        fr1(j,0,k){
            ans=max(ans,dp[n][j]);
//            cout<<"!"<<dp[n][j]<<endl;
        }
        cout<<ans<<'\n';
    }
    else if(c>=17&&c<=18){
		ll ans=0;
		fr1(i,1,m){
			int x,y,v;
			cin>>x>>y>>v;
			if(y>k){
				continue;
			}
			if(v>=1ll*y*d){
				ans+=v-1ll*y*d;
			}
		}
		cout<<ans<<'\n';
    }
    else{
    	cout<<"0\n";
	}
}
#define Griffin cute
int main(){
#ifdef Griffin 
    freopen("run.in","r",stdin);
    freopen("run.out","w",stdout);
#endif
    ios::sync_with_stdio(false);
    cin>>c>>T;
    while(T--){
        solve();
    }
    return 0;
}
//Be confident!
