//Author: Shunpower in NOIP2023
//May the force be with you and me.
#include <bits/stdc++.h>
#define fr1(i,a,b) for(int (i)=(a);(i)<=(b);(i)++)
#define fr2(i,a,b) for(int (i)=(a);(i)>=(b);(i)--)
#define pii pair<int,int>
#define ll long long
#define ull unsigned ll
#define pll pair<ll,ll>
#define fi first
#define se second
#define il inline
#define mp make_pair
#define pb push_back
#define ld long double
using namespace std;
const int N=3010;
int n,m;
string s[N];
int tmp[N][30];
int bol[N][30];
il bool check(int x,int y){
	fr1(i,0,25){
		bol[x][i]=tmp[x][i];
		bol[y][i]=tmp[y][i];
	}
    int l=-1,r=25;
    int lsum=0,rsum=0;
    while(l<=25){
        l++;
        lsum+=bol[x][l];
//        cout<<x<<" "<<y<<":"<<l<<" "<<r<<endl; 
//        cout<<lsum<<"?"<<rsum<<endl;
        while(rsum<lsum){
            if(bol[y][r]>lsum-rsum){
                bol[y][r]-=(lsum-rsum);
                if(r>l){
                	return 1;
				}
				if(r<l){
					return 0;
				}
                rsum=lsum;
                break;
            }
            else{
                rsum+=bol[y][r];
                if(bol[y][r]){
                	if(r>l){
                		return 1;
					}
                	if(r<l){
                		return 0;
					}
				}
                r--;
            }
//            cout<<"???"<<r<<" "<<bol[y][r]<<endl;
        }
    }
    return 0;
}
#define Griffin cute
int main(){
#ifdef Griffin 
    freopen("dict.in","r",stdin);
    freopen("dict.out","w",stdout);
#endif
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    cin>>n>>m;
    fr1(i,1,n){
        cin>>s[i];
    }
    fr1(i,1,n){
        fr1(j,0,m-1){
        	tmp[i][s[i][j]-'a']++;
            bol[i][s[i][j]-'a']++;
        }
    }
    fr1(i,1,n){
        bool flg=1;
        fr1(j,1,n){
        	if(i==j){
        		continue;
			}
            flg&=check(i,j);
            if(!flg){
                break;
            }
        }
        cout<<flg;
    }
    return 0;
}
//Be confident!
