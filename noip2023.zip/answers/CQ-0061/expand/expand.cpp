//Author: Shunpower in NOIP2023
//May the force be with you and me.
#include <bits/stdc++.h>
#define fr1(i,a,b) for(int (i)=(a);(i)<=(b);(i)++)
#define fr2(i,a,b) for(int (i)=(a);(i)>=(b);(i)--)
#define pii pair<int,int>
#define ll long long
#define ull unsigned ll
#define pll pair<ll,ll>
#define fi first
#define se second
#define il inline
#define mp make_pair
#define pb push_back
#define ld long double
using namespace std;
const int N=5e5+10;
int x[N],y[N],tmpx[N],tmpy[N];
int c,n,m,q;
int kx,ky;
int px,vx,py,vy;
bool dp[4010][4010];
int lst[4010];
int sum[4010];
void work(){
    fr1(i,1,n){
        fr1(j,1,m){
            dp[i][j]=0;
        }
    }
    dp[0][0]=1;
    fr1(i,1,n){
        sum[0]=dp[i-1][0];
        fr1(j,1,m){
            sum[j]=sum[j-1]+dp[i-1][j];
        }
        fr1(j,1,m){
            if(y[j]>=x[i]){
                lst[j]=j+1;
            }
            else{
                lst[j]=lst[j-1];
            }
        }
        fr1(j,1,m){
        	if(lst[j]>m){
        		continue;
			}
            dp[i][j]|=sum[j]-sum[lst[j]]+dp[i-1][lst[j]];
//            cout<<i<<" "<<j<<"<-"<<dp[i][j]<<" "<<lst[j]<<endl;
        }
    }
}
bool solve(){
    cin>>kx>>ky;
    fr1(i,1,kx){
        cin>>px>>vx;
        x[px]=vx;
    }
    fr1(i,1,ky){
        cin>>py>>vy;
        y[py]=vy;
    }
    if(c<=7){
    	work();
        bool flg1=dp[n][m];
        swap(n,m);
        swap(x,y);
        work();
        bool flg2=dp[m][n];
        swap(n,m);
        swap(x,y);
        return flg1|flg2;
    }
    else{
    	return 1&&(x[1]!=y[1])&&(x[n]!=y[m]);
	}
}
#define Griffin cute
int main(){
#ifdef Griffin 
    freopen("expand.in","r",stdin);
    freopen("expand.out","w",stdout);
#endif
    ios::sync_with_stdio(false);
    cin>>c>>n>>m>>q;
    fr1(i,1,n){
        cin>>x[i];
        tmpx[i]=x[i];
    }
    fr1(i,1,m){
        cin>>y[i];
        tmpy[i]=y[i];
    }
    if(c<=7){
	    work();
	    bool flg1=dp[n][m];
	    swap(n,m);
	    swap(x,y);
	//    cout<<"!!!"<<endl;
	    work();
	    bool flg2=dp[m][n];
	    swap(n,m);
	    swap(x,y);
	//    cout<<flg1<<endl;
	    cout<<(flg1|flg2); 	
	}
	else{
		cout<<1&&(x[1]!=y[1])&&(x[n]!=y[m]);
	}
    while(q--){
        cout<<solve();
        fr1(i,1,n){
            x[i]=tmpx[i];
        }
        fr1(i,1,m){
            y[i]=tmpy[i];
        }
    }
    return 0;
}
//Be confident!
