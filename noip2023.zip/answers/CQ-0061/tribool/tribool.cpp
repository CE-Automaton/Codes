//Author: Shunpower in NOIP2023
//May the force be with you and me.
#include <bits/stdc++.h>
#define fr1(i,a,b) for(int (i)=(a);(i)<=(b);(i)++)
#define fr2(i,a,b) for(int (i)=(a);(i)>=(b);(i)--)
#define pii pair<int,int>
#define ll long long
#define ull unsigned ll
#define pll pair<ll,ll>
#define fi first
#define se second
#define il inline
#define mp make_pair
#define pb push_back
#define ld long double
using namespace std;
const int N=2e5+10;
int c,T;
int n,m;
vector <int> ver[N];
vector <pii> g[N];
vector <pii> p[N];
int col[N];
int tot;
struct node{
    int bel;
    int val;//0:F 1:T 2:U -1:idk
} tf[N];
queue <int> wt;
struct edge{
    int u,v,w;
};
vector <edge> condi;
void pushdown(int x){
    if(ver[tf[x].bel].back()==x){
        int rt=ver[tf[x].bel][0];
        tf[rt].val=tf[x].val;
        wt.push(rt);
    }
    for(auto d:g[x]){
        int y=d.fi,w=d.se;
        if(tf[y].val!=-1){
            continue;
        }
        if(!w){
            if(tf[x].val<2){
                tf[y].val=tf[x].val^1;
            }
            else{
                tf[y].val=tf[x].val;
            }
        }
        else{
            tf[y].val=tf[x].val;
        }
        pushdown(y);
    }
}
void makelink(int x,int fr,int sum){
    if(ver[tf[x].bel].back()==x){
        condi.pb((edge){fr,tf[x].bel,sum});
    }
    for(auto d:g[x]){
        int y=d.fi,w=d.se;
        if(tf[y].val!=-1){
            continue;
        }
        if(!w){
            makelink(y,fr,sum^1);
        }
        else{
            makelink(y,fr,sum);
        }
    }
}
bool flg;
int siz;
void dfs(int x,int cl){
//	cout<<x<<" "<<cl<<endl;
	siz++;
	col[x]=cl;
	for(auto d:p[x]){
		int y=d.fi,w=d.se;
		if(col[y]!=-1){
			if(col[y]!=(cl^w)){
//				cout<<y<<"?"<<cl<<"?"<<w<<endl;
				flg=1;
			}
			continue;
		}
		dfs(y,cl^w);
	}
}
void solve(){
    cin>>n>>m;
//    cout<<n<<","<<m<<endl; 
    tot=n;
    fr1(i,1,n){
        tf[i]={i,-1};
        ver[i].pb(i);
    }
    fr1(i,1,m){
        char op;
        int x,y;
        cin>>op;
        if(op=='+'){
        	cin>>x>>y;
            tot++;
            int u=ver[y].back();
            g[u].pb(mp(tot,1));
            ver[x].pb(tot);
            tf[tot]={x,-1};
        }
        else if(op=='-'){
        	cin>>x>>y;
            tot++;
            int u=ver[y].back();
            g[u].pb(mp(tot,0));
            ver[x].pb(tot);
            tf[tot]={x,-1};
        }
        else{
        	cin>>x;
            tot++;
            int u=ver[x].back();
            g[u].pb(mp(tot,0));
            ver[x].pb(tot);
            tf[tot]={x,(op=='F'?0:(op=='T'?1:2))};
            wt.push(tot);
        }
    }
    while(!wt.empty()){
        pushdown(wt.front());
        wt.pop();
    }
    int ans=0;
    fr1(i,1,n){
        if(tf[i].val==-1){
            makelink(i,i,0);
        }
        else if(tf[i].val==2){
        	ans++;
		}
    }
//    cout<<ans<<endl;
    fr1(i,1,n){
    	p[i+n].pb(mp(i,0));
    	p[i].pb(mp(i+n,0));
	}
    for(auto d:condi){
    	p[d.u].pb(mp(d.v+n,d.w));
    	p[d.v+n].pb(mp(d.u,d.w));
//        cout<<d.u<<"->"<<d.v<<" by "<<d.w<<'\n';
    }
    fr1(i,1,n+n){
    	col[i]=-1;
	}
    fr1(i,1,n){
    	if(col[i]==-1&&!p[i].empty()){
    		dfs(i,0);
//    		cout<<i<<" "<<flg<<"?"<<endl;
    		if(flg){
    			ans+=siz/2;
			}
    		flg=0;
    		siz=0;
		}
	}
	cout<<ans<<'\n';
    condi.clear();
    fr1(i,1,n){
        ver[i].clear();
    }
    fr1(i,1,tot){
        g[i].clear();
    }
    fr1(i,1,n+n){
    	p[i].clear();
    	col[i]=0;
	}
}
#define Griffin cute
int main(){
#ifdef Griffin 
    freopen("tribool.in","r",stdin);
    freopen("tribool.out","w",stdout);
#endif
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    cin>>c>>T;
    while(T--){
        solve();
    }
    return 0;
}
//Be confident!
/*
好想做张峻豪先生的狗啊
好想做张峻豪先生的狗啊
好想做张峻豪先生的狗啊
好想做张峻豪先生的狗啊
好想做张峻豪先生的狗啊
好想做张峻豪先生的狗啊
我好爱他好好好
*/