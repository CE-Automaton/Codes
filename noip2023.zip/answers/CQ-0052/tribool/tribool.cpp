#include<bits/stdc++.h>
#define ll long long
#define eb emplace_back
#define mk make_pair
#define gc() getchar()
#define N 200009
#define cg(x) (x>n?x-n:x+n)
using namespace std;
inline int rd(){int x=0;char c=gc();while(c<'0'||c>'9')c=gc();while(c>='0'&&c<='9')x=x*10+c-'0',c=gc();return c;}
int c,t,n,m,id[N],val[N],fa[N];
inline int find(int x){return fa[x]==x?x:fa[x]=find(fa[x]);}
inline void merge(int x,int y){x=find(x),y=find(y);if(x!=y)fa[x]=y;}
int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	scanf("%d%d",&c,&t);
	while(t--){
		scanf("%d%d",&n,&m);for(int i=1;i<=n;i++)id[i]=i,val[i]=1;
		char op[4];
		for(int i=1,x,y;i<=m;i++){
			scanf("%s",op+1);
			if(op[1]=='T'){
				scanf("%d",&x);
				id[x]=0,val[x]=1;
			}
			else if(op[1]=='F'){
				scanf("%d",&x);
				id[x]=0,val[x]=-1;
			}
			else if(op[1]=='U'){
				scanf("%d",&x);
				id[x]=0,val[x]=0;
			}
			else if(op[1]=='+'){
				scanf("%d%d",&x,&y),id[x]=id[y],val[x]=val[y];
			}
			else{
				scanf("%d%d",&x,&y),id[x]=id[y],val[x]=-val[y];
			}
		}
		for(int i=1;i<=n*2+3;i++)fa[i]=i;
		for(int i=1;i<=n;i++){
			if(id[i]){
				if(val[i]==1)merge(i,id[i]),merge(cg(i),cg(id[i]));
				else merge(i,cg(id[i])),merge(cg(i),id[i]);
			}
			else{
				merge(i,n*2+2+val[i]),merge(cg(i),n*2+2-val[i]);
			}
		}
		int ans=0;
		for(int i=1;i<=n;i++){
			if(find(i)==find(cg(i))||find(i)==find(n*2+2))ans++;
		}
		printf("%d\n",ans);
	}
	return 0;
}
