#include<bits/stdc++.h>
#define ll long long
#define eb emplace_back
#define mk make_pair
#define gc() getchar()
#define N 100009
using namespace std;
inline int rd(){int x=0;char c=gc();while(c<'0'||c>'9')c=gc();while(c>='0'&&c<='9')x=x*10+c-'0',c=gc();return c;}
int c,n,m,q,a0[N],b0[N],a[N],b[N];
bool f[2009][2009];
namespace solve1{
	int mian(){
		f[0][0]=1;
		for(int i=1;i<=n;i++)a[i]=a0[i];
		for(int i=1;i<=m;i++)b[i]=b0[i];
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				f[i][j]=(1ll*(a[i]-b[j])*(a[1]-b[1])>0)&(f[i-1][j]|f[i][j-1]|f[i-1][j-1]);
			}
		}
		printf("%d",(int)f[n][m]);
		for(int Misaka=1;Misaka<=q;Misaka++){
			int kx,ky,p,v;
			scanf("%d%d",&kx,&ky);
			for(int i=1;i<=n;i++)a[i]=a0[i];
			for(int i=1;i<=m;i++)b[i]=b0[i];
			for(int i=1;i<=kx;i++)scanf("%d%d",&p,&v),a[p]=v;
			for(int i=1;i<=ky;i++)scanf("%d%d",&p,&v),b[p]=v;
			for(int i=1;i<=n;i++){
				for(int j=1;j<=m;j++){
					f[i][j]=(1ll*(a[i]-b[j])*(a[1]-b[1])>0)&(f[i-1][j]|f[i][j-1]|f[i-1][j-1]);
				}
			}
			printf("%d",(int)f[n][m]);
		}
		return 0;
	}
}
namespace solve2{
	int mian(){
		for(int i=1;i<=n;i++)a[i]=a0[i];
		for(int i=1;i<=m;i++)b[i]=b0[i];
		int mx=-0x3f3f3f3f,mn=0x3f3f3f3f;
		for(int i=2;i<=n;i++)mx=max(mx,a[i]);
		for(int i=1;i<m;i++)mn=min(mn,b[i]);
		mx<b[m]&&mn>a[1]?printf("1"):printf("0");
		for(int Misaka=1;Misaka<=q;Misaka++){
			int kx,ky,p,v;
			scanf("%d%d",&kx,&ky);
			for(int i=1;i<=n;i++)a[i]=a0[i];
			for(int i=1;i<=m;i++)b[i]=b0[i];
			for(int i=1;i<=kx;i++)scanf("%d%d",&p,&v),a[p]=v;
			for(int i=1;i<=ky;i++)scanf("%d%d",&p,&v),b[p]=v;
			int mx=-0x3f3f3f3f,mn=0x3f3f3f3f;
			for(int i=2;i<=n;i++)mx=max(mx,a[i]);
			for(int i=1;i<m;i++)mn=min(mn,b[i]);
			mx<b[m]&&mn>a[1]?printf("1"):printf("0");
		}
		return 0;
	}
}
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	scanf("%d%d%d%d",&c,&n,&m,&q);
	for(int i=1;i<=n;i++)scanf("%d",&a0[i]);
	for(int i=1;i<=m;i++)scanf("%d",&b0[i]);
	if(c<=7)solve1::mian();
	else solve2::mian();
	return 0;
}
