#include<bits/stdc++.h>
#define ll long long
#define eb emplace_back
#define mk make_pair
#define N 100009
#define gc() getchar()
#define int long long
using namespace std;
inline int rd(){int x=0;char c=gc();while(c<'0'||c>'9')c=gc();while(c>='0'&&c<='9')x=x*10+c-'0',c=gc();return c;}
int c,t,rt,rr[N],ff[N],n,m0,m,k,d;
struct Seg{int l,r,v,f;}a[N];
inline bool cmp(Seg x,Seg y){return x.r<y.r;}
int idx;
struct Node{
	int l,r,sum;
}tr[N*32];
inline void pushup(int u){tr[u].sum=tr[tr[u].l].sum+tr[tr[u].r].sum;}
void mdf(int &u,int l,int r,int d,int x){
	if(!u)u=++idx,tr[u].l=tr[u].r=tr[u].sum=0;
	if(l==r){tr[u].sum+=x;return ;}
	int mid=(l+r)>>1;if(d<=mid)mdf(tr[u].l,l,mid,d,x);else mdf(tr[u].r,mid+1,r,d,x);pushup(u); 
}
int qry(int u,int l,int r,int L,int R){
	if(!u)return 0;
	if(l>=L&&r<=R)return tr[u].sum;
	int mid=(l+r)>>1;
	if(R<=mid)return qry(tr[u].l,l,mid,L,R);
	if(L>mid)return qry(tr[u].r,mid+1,r,L,R);
	return qry(tr[u].l,l,mid,L,R)+qry(tr[u].r,mid+1,r,L,R);
}
namespace solve1{
	int ans;vector<Seg>v;
	void solve(){
		for(int i=1;i<(int)v.size();i++)v[i].v+=v[i-1].v;
		int res=0;
		for(int i=0;i<(int)v.size();i++){
			int l=i,r=v.size()-1;
			while(l<r){
				int mid=(l+r+1)>>1;
				if(v[mid].r-v[i].l+1>k)r=mid-1;
				else l=mid;
			}
			res=max(res,v[l].v-(i?v[i-1].v:0));
		}
		ans+=res;
	}
	int mian(){
		while(t--){
			scanf("%lld%lld%lld%lld",&n,&m0,&k,&d),m=idx=rt=ans=0;
			for(int i=1,x,y,l,r,v;i<=m0;i++){
				scanf("%lld%lld%lld",&x,&y,&v);l=x-y+1,r=x;
				if(r-l+1<=k&&v>(r-l+1)*d)a[++m]=(Seg){l,r,v-(r-l+1)*d};
			}
			sort(a+1,a+m+1,cmp);
			v.clear();
			for(int i=1;i<=m;i++){
				if(a[i].l>a[i-1].r+1){solve();v.clear();}
				v.eb(a[i]);
			}
			solve();
			printf("%lld\n",ans);
		}
		return 0;
	}
}
#undef int
int main(){
	#define int long long
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	scanf("%lld%lld",&c,&t);
	if(c==17||c==18){solve1::mian();return 0;}
	while(t--){
		scanf("%lld%lld%lld%lld",&n,&m0,&k,&d),m=idx=rt=0;
		for(int i=1,x,y,l,r,v;i<=m0;i++){
			scanf("%lld%lld%lld",&x,&y,&v);l=x-y+1,r=x;
			if(r-l+1<=k)a[++m]=(Seg){l,r,v};
		}
		sort(a+1,a+m+1,cmp);
		for(int i=1;i<=m;i++){
			rr[i]=a[i].r;mdf(rt,1,n,a[i].l,a[i].v);
			a[i].f=ff[max(lower_bound(rr+1,rr+i+1,a[i].l-1)-rr-1,0ll)]+a[i].v-(a[i].r-a[i].l+1)*d;
			for(int j=1;j<i;j++){
				int rl=min(a[j].l,a[i].l);
				if(a[i].r-rl+1<=k){
					a[i].f=max(a[i].f,qry(rt,1,n,rl,a[i].r)+ff[max(lower_bound(rr+1,rr+i+1,rl-1)-rr-1,0ll)]-(a[i].r-rl+1)*d);
				}
			}
			ff[i]=max(a[i].f,ff[i-1]);
		}
		printf("%lld\n",ff[m]);
	}
	return 0;
}
