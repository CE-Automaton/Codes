#include<bits/stdc++.h>
#define ll long long
#define eb emplace_back
#define mk make_pair
#define gc() getchar()
#define N 3009
#define ull unsigned long long
using namespace std;
inline int rd(){int x=0;char c=gc();while(c<'0'||c>'9')c=gc();while(c>='0'&&c<='9')x=x*10+c-'0',c=gc();return c;}
const ull bs=13331;
int n,m,rk[N][2],sc[N];ull pw[N];char c[N];
struct String{int id;ull s[N];}a[N<<1];
bool cmp(String x,String y){
	if(x.s[m]==y.s[m])return 1;
	int l=1,r=m;
	while(l<r){
		int mid=(l+r)>>1;
		if(x.s[mid]==y.s[mid])l=mid+1;
		else r=mid;
	}
	return x.s[l]-x.s[l-1]*bs<y.s[l]-y.s[l-1]*bs;
}
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	scanf("%d%d",&n,&m);pw[0]=1;for(int i=1;i<=m;i++)pw[i]=pw[i-1]*bs;
	for(int i=1;i<=n;i++){
		scanf("%s",c+1);
		for(int j='a';j<='z';j++)sc[j]=0;
		for(int j=1;j<=m;j++)sc[(int)c[j]]++;
		int idx=0;
		for(int j='a';j<='z';j++)for(int k=1;k<=sc[j];k++)c[++idx]=j;
		a[i].id=i;
		for(int j=1;j<=m;j++)a[i].s[j]=a[i].s[j-1]*bs+c[j];
		idx=0;
		for(int j='z';j>='a';j--)for(int k=1;k<=sc[j];k++)c[++idx]=j;
		a[i+n].id=i;
		for(int j=1;j<=m;j++)a[i+n].s[j]=a[i+n].s[j-1]*bs+c[j];
	}
	sort(a+1,a+n*2+1,cmp);
	for(int i=1,nw=0;i<=n*2;i++){
		if(a[i].s[m]!=a[i-1].s[m])nw++;
		if(!rk[a[i].id][0])rk[a[i].id][0]=nw;else rk[a[i].id][1]=nw;
	}
	for(int i=1;i<=n;i++){
		bool flag=0;
		for(int j=1;j<=n;j++)if(j!=i&&rk[j][1]<=rk[i][0]){flag=1;break;}
		if(!flag)printf("1");else printf("0");
	}
	return 0;
}
