#include<bits/stdc++.h>
using namespace std;

int ans[3005];
string s[3005], smn[3005], smx[3005], smx2[3005];

int main() {
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	int n,m; cin>>n>>m;
	for(int i=1;i<=n;i++) cin>>s[i];
	if(n==1) {
		cout<<1<<'\n';
		exit(0);
	}
	for(int i=1;i<=n;i++) {
		smn[i]=smx[i]=s[i];
		int mn=m-1, mx=m-1, a1=m-1, b1=m-1, a2=m-1, b2=m-1;
		for(int j=m-2;j>=0;j--) {
			if(s[i][j]>s[i][mn]) a1=j, b1=mn;
			else if(s[i][j]<s[i][mn]) mn=j;
			if(s[i][j]<s[i][mx]) a2=j, b2=mx;
			else if(s[i][j]>s[i][mx]) mx=j;
		}
		swap(smn[i][a1],smn[i][b1]);
		swap(smx[i][a2],smx[i][b2]);
		smx2[i]=smx[i];
	}
	for(int i=2;i<=n;i++) smx[i]=min(smx[i],smx[i-1]);
	for(int i=n-1;i>=1;i--) smx2[i]=min(smx2[i],smx2[i+1]);
	ans[1]=(smn[1]<smx2[2]);
	for(int i=2;i<n;i++) ans[i]=(smn[i]<min(smx[i-1],smx2[i+1]));
	ans[n]=(smn[n]<smx[n-1]);
	for(int i=1;i<=n;i++) cout<<ans[i]; cout<<'\n';
	return 0;
}
