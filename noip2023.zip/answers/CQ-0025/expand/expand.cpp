#include<bits/stdc++.h>
using namespace std;

const int maxn=5e5+5;
const int inf=1e9;

int c,n,m,Q;

int x[maxn], y[maxn];
int a[maxn], b[maxn], q[maxn];

int dp[2005][2005];

void solve1() {
	if(a[1]==b[1]) {
		cout<<0;
		return ;
	}
	if(a[1]<b[1]) {
		dp[1][1]=1;
		for(int i=1;i<=n;i++) {
			for(int j=1;j<=m;j++) {
				if(i+j==2) continue;
				if(a[i]<b[j]) {
					if(i>1&&j>1) dp[i][j]=max(dp[i-1][j],dp[i][j-1]);	
					else if(i>1) dp[i][j]=dp[i-1][j];
					else dp[i][j]=dp[i][j-1];
				}else dp[i][j]=0;
			}
		}
		cout<<dp[n][m];
	}else {
		dp[1][1]=1;
		for(int i=1;i<=n;i++) {
			for(int j=1;j<=m;j++) {
				if(i+j==2) continue;
				if(a[i]>b[j]) {
					if(i>1&&j>1) dp[i][j]=max(dp[i-1][j],dp[i][j-1]);	
					else if(i>1) dp[i][j]=dp[i-1][j];
					else dp[i][j]=dp[i][j-1];
				}else dp[i][j]=0;
			}
		}
		cout<<dp[n][m];
	}
	return ;
}

void solve2() {
	int pos=1, mx=0;
	for(int i=1;i<n;) {
		while(pos<=m&&b[pos]>a[i]) {
			if(!mx||b[pos]>=b[mx]) mx=pos; 
			++pos;
		}
		int id=i;
		++i;
		while(i<n&&a[i]<b[mx]) {
			if(a[i]<=a[id]) break;
			++i;
		}
		if(a[i]>=b[mx]) {
			cout<<0;
			return ;
		}
	}
	for(int i=mx;i<=m;i++) {
		if(a[n]>=b[i]) {
			cout<<0;
			return ;
		}
	}
	cout<<1;
	return ;
}

int main() {
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	cin>>c>>n>>m>>Q;
	for(int i=1;i<=n;i++) cin>>x[i], a[i]=x[i];
	for(int i=1;i<=m;i++) cin>>y[i], b[i]=y[i];
	if(c<8) solve1();
	else solve2();
	while(Q--) {
		for(int i=1;i<=n;i++) a[i]=x[i];
		for(int i=1;i<=m;i++) b[i]=y[i];
		int kx,ky;
		cin>>kx>>ky;
		for(int i=1;i<=kx;i++) {
			int p,v; cin>>p>>v;
			a[p]=v;
		}
		for(int i=1;i<=ky;i++) {
			int p,v; cin>>p>>v;
			b[p]=v;
		}
		if(c<8) solve1();
		else solve2();
	}
	cout<<'\n';
	return 0;
}
//CC��CCCC
