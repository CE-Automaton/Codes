#include<bits/stdc++.h>
using namespace std;

const int maxn=1e5+5;

int vs, flag, num;
int val[maxn], ks[maxn], dfn[maxn], fa[maxn], fx[maxn], siz[maxn];
vector<int> g[maxn];

int find(int x) {
	if(fa[x]!=x) return fa[x]=find(fa[x]);
	return x;
}

void merge(int x,int y) {
	x=find(x), y=find(y);
	fa[x]=y;
	return ;
}

void dfs(int x) {
	dfn[x]=++vs; num+= siz[x];
	for(int y:g[x]) {
		if(!dfn[y]) {
			fx[y]=x;
			dfs(y);
		}else if(dfn[y]>=dfn[x]) {
			int cnt2=1, p=y;
			while(p!=x) p=fx[p], ++cnt2;
			if(cnt2&1) flag=1;
		}
	}
	return ;
}

void solve() {
	int n,m; cin>>n>>m;
	for(int i=1;i<=n;i++) val[i]=i, ks[i]=1, g[i].clear(), fa[i]=i, siz[i]=dfn[i]=0;
	for(int i=1;i<=m;i++) {
		char ch; cin>>ch;
		if(ch=='+') {
			int u,v; cin>>u>>v;
			val[u]=val[v], ks[u]=ks[v];
		}else if(ch=='-') {
			int u,v; cin>>u>>v;
			val[u]=val[v], ks[u]=-ks[v];
		}else {
			int x; cin>>x;
			if(ch=='T') val[x]=0, ks[x]=1;
			if(ch=='F') val[x]=0, ks[x]=0;
			if(ch=='U') val[x]=0, ks[x]=2;
		}
	}
	int cnt=0;
	for(int i=1;i<=n;i++) if(val[i]&&ks[i]==1) merge(i,val[i]);
	for(int i=1;i<=n;i++) siz[find(i)]++;
	for(int i=1;i<=n;i++) {
		if(!val[i]) continue;
		else {
			if(ks[i]==1) continue;
			g[find(val[i])].push_back(find(i));
			g[find(i)].push_back(find(val[i]));
		}
	}
	for(int i=1;i<=n;i++) {
		if(!val[i]&&dfn[find(i)]==0) {
			num=0;
			dfs(find(i));
			if(ks[i]==2||ks[i]==-2) cnt+=num;
		}
	}
	for(int i=1;i<=n;i++) {
		if(find(i)==i&&dfn[i]==0) {
			flag=num=0;
			dfs(i);
			if(flag) cnt+=num;
		}
	}
	cout<<cnt<<'\n';
	return ;
}

int main() {
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	int c,t; cin>>c>>t;
	while(t--) solve();
	return 0;
}
