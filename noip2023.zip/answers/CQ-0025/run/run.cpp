#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
ll dp[1005][1005], f[1005][1005];

void solve() {
	memset(f,0,sizeof(f));
	memset(dp,-0x3f,sizeof(dp));
	ll n,m,k,d; cin>>n>>m>>k>>d;
	for(ll i=1;i<=m;i++) {
		ll x,y,v; cin>>x>>y>>v;
		f[x][y]+=v;
	}
	for(ll i=1;i<=n;i++) {
		for(ll j=1;j<=n;j++) f[i][j]+= f[i][j-1];
	}
	dp[0][0]=0;
	for(ll i=0;i<n;i++) {
		for(ll j=0;j<k;j++) {
			if(dp[i][j]==-0x3f3f3f3f3f3f3f3f) continue;
			dp[i+1][j+1]=max(dp[i+1][j+1],dp[i][j]-d+f[i+1][j+1]);
			dp[i+1][0]=max(dp[i+1][0],dp[i][j]);
		}
		dp[i+1][0]=max(dp[i+1][0],dp[i][k]);
	}
	ll ans=-0x3f3f3f3f3f3f3f3f;
	for(ll i=0;i<=k;i++) ans=max(ans,dp[n][i]);
	cout<<ans<<'\n';
	return ;
}

int main() {
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	ll c,t; cin>>c>>t;
	while(t--) solve();
	return 0;
}
