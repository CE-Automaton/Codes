#include<stdio.h>
#include<algorithm>
typedef long long ll;
struct node
{
    int l,r,v;
};
node a[100005];
int pos[200005];
ll tr[800005],add[800005];
void build(const int p,const int L,const int R)
{
    tr[p]=0xc0c0c0c0c0c0c0c0;
    add[p]=0;
    if(L==R){return;}
    const int M(L+R>>1);
    build(p<<1,L,M);
    build(p<<1|1,M+1,R);
}
inline void push_down(const int p)
{
    if(add[p])
    {
        tr[p<<1]+=add[p];
        add[p<<1]+=add[p];
        tr[p<<1|1]+=add[p];
        add[p<<1|1]+=add[p];
        add[p]=0;
    }
}
void modify(const int p,const int L,const int R,const int x,const ll y)
{
    if(L==R)
    {
        tr[p]=y;
        return;
    }
    const int M(L+R>>1);
    // push_down(p);
    if(x<=M)
    {
        modify(p<<1,L,M,x,y);
    }
    else
    {
        modify(p<<1|1,M+1,R,x,y);
    }
    tr[p]=std::max(tr[p<<1],tr[p<<1|1]);
}
void increase(const int p,const int L,const int R,const int x,const int y)
{
    if(R<=x)
    {
        tr[p]+=y;
        add[p]+=y;
        return;
    }
    const int M(L+R>>1);
    push_down(p);
    if(x>M)
    {
        increase(p<<1|1,M+1,R,x,y);
    }
    increase(p<<1,L,M,x,y);
    tr[p]=std::max(tr[p<<1],tr[p<<1|1]);
}
ll query(const int p,const int L,const int R,const int l,const int r)
{
    if(l<=L&&r>=R)
    {
        return tr[p];
    }
    const int M(L+R>>1);
    ll res(0xc0c0c0c0c0c0c0c0);
    push_down(p);
    if(l<=M)
    {
        res=std::max(res,query(p<<1,L,M,l,r));
    }
    if(r>M)
    {
        res=std::max(res,query(p<<1|1,M+1,R,l,r));
    }
    return res;
}
void solve()
{
    int n,m,k,d,N(0);
    scanf("%d%d%d%d",&n,&m,&k,&d);
    for(int i=1;i<=m;i++)
    {
        int x,y,v;
        scanf("%d%d%d",&x,&y,&v);
        a[i]={x-y,x,v};
        pos[++N]=x-y;
        pos[++N]=x;
    }
    std::sort(a+1,a+m+1,[](const node &x,const node &y){
        return x.r<y.r;
    });
    std::sort(pos+1,pos+N+1);
    build(1,0,N);
    modify(1,0,N,0,0);
    ll ans(0);
    for(int i=1,j=1;i<=N;i++)
    {
        while(j<=m&&a[j].r==pos[i])
        {
            // printf("%d %d\n",std::lower_bound(pos,pos+N+1,a[j].l)-pos,a[j].v);
            increase(1,0,N,std::lower_bound(pos,pos+N+1,a[j].l)-pos,a[j].v);
            ++j;
        }
        modify(1,0,N,i,1ll*pos[i]*d+ans);
        // printf("%d %d %d %lld\n",i,pos[i],std::lower_bound(pos,pos+N+1,pos[i]-k)-pos,query(1,0,N,std::lower_bound(pos,pos+N+1,pos[i]-k)-pos,i-1));
        ans=std::max(ans,-1ll*pos[i]*d+query(1,0,N,std::lower_bound(pos,pos+N+1,pos[i]-k)-pos,i-1));
    }
    printf("%lld\n",ans);
}
int main()
{
    freopen("run.in","r",stdin);
    freopen("run.out","w",stdout);
    int t;
    scanf("%*d%d",&t);
    while(t--)
    {
        solve();
    }
    return 0;
}