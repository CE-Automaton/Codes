#include<stdio.h>
#include<algorithm>
int testid,n,m;
int x[500005],y[500005];
int _x[500005],_y[500005];
int c[500005];
struct node
{
    int v,id;
    constexpr operator int()const{return v;}
};
int kx;
node px[500005],_px[500005];
node fx[500005];
int lt[500005],rt[500005];
void solve()
{
    if(x[1]==y[1]||x[n]==y[n]||(x[1]>y[1])!=(x[n]>y[m]))
    {
        putchar('0');
        return;
    }
    // 归并
    for(int i=1,j=1,k=1;i<=n||j<=kx;k++)
    {
        while(i<=n&&c[px[i].id])
        {
            ++i;
        }
        if(i<=n&&(j>kx||px[i].v<_px[j].v))
        {
            fx[k]=px[i++];
        }
        else
        {
            fx[k]=_px[j++];
        }
    }
    if(x[1]<y[1])// 分类讨论
    {
        // 计算 lt, rt
        int l(1),r(m);
        for(int i=1;i<=n;i++)
        {
            const int u(fx[i].id),v(x[u]);
            while(l<=n&&y[l]<=v)
            {
                ++l;
            }
            while(r>0&&y[r]<=v)
            {
                --r;
            }
            lt[u]=l,rt[u]=r;
        }
        int R(1);
        while(R<n&&x[1]<y[R+1])
        {
            ++R;
        }
        l=1,r=R;
        int xm(x[1]);
        for(int i=2;i<=n;i++)
        {
            xm=std::min(xm,x[i]);
            if(x[i]==xm)
            {
                while(R<n&&x[i]<y[R+1])
                {
                    ++R;
                }
                l=1,r=R;
            }
            else
            {
                l=std::max(l,lt[i]);
                r=std::min(r,rt[i]);
                if(l>r)
                {
                    putchar('0');
                    return;
                }
            }
        }
        while(r<n&&x[n]<y[r+1])
        {
            ++r;
        }
        putchar(r==n?'1':'0');
        return;
    }
    // 同理
    int l(1),r(m);
    for(int i=n;i>=1;i--)
    {
        const int u(fx[i].id),v(x[u]);
        while(l<=n&&y[l]>=v)
        {
            ++l;
        }
        while(r>0&&y[r]>=v)
        {
            --r;
        }
        lt[u]=l,rt[u]=r;
    }
    int R(1);
    while(R<n&&x[1]>y[R+1])
    {
        ++R;
    }
    l=1,r=R;
    int xm(x[1]);
    for(int i=2;i<=n;i++)
    {
        xm=std::max(xm,x[i]);
        if(x[i]==xm)
        {
            while(R<n&&x[i]>y[R+1])
            {
                ++R;
            }
            l=1,r=R;
        }
        else
        {
            l=std::max(l,lt[i]);
            r=std::min(r,rt[i]);
            if(l>r)
            {
                putchar('0');
                return;
            }
        }
    }
    while(r<n&&x[n]>y[r+1])
    {
        ++r;
    }
    putchar(r==n?'1':'0');
    return;
}
int main()
{
    freopen("expand.in","r",stdin);
    freopen("expand.out","w",stdout);
    int q;
    scanf("%d%d%d%d",&testid,&n,&m,&q);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",_x+i);
        px[i]={_x[i],i};
    }
    for(int i=1;i<=m;i++)
    {
        scanf("%d",_y+i);
    }
    std::sort(px+1,px+n+1);
    __builtin_memcpy(x+1,_x+1,n*sizeof(int));
    __builtin_memcpy(y+1,_y+1,m*sizeof(int));
    kx=0,solve();
    while(q--)
    {
        __builtin_memcpy(x+1,_x+1,n*sizeof(int));
        __builtin_memcpy(y+1,_y+1,m*sizeof(int));
        __builtin_memset(c+1,0,n*sizeof(int));
        int ky;
        scanf("%d%d",&kx,&ky);
        for(int i=1;i<=kx;i++)
        {
            int p,q;
            scanf("%d%d",&p,&q);
            x[p]=q,c[p]=1,_px[i]={q,p};
        }
        std::sort(_px+1,_px+kx+1);
        while(ky--)
        {
            int p,q;
            scanf("%d%d",&p,&q);
            y[p]=q;
        }
        solve();
    }
    putchar('\n');
    return 0;
}