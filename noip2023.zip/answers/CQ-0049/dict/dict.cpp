#include<stdio.h>
#include<algorithm>
char s[3005];
int min[3005],max[3005];
int main()
{
    freopen("dict.in","r",stdin);
    freopen("dict.out","w",stdout);
    int n,m;
    scanf("%d%d",&n,&m);
    for(int i=0;i<n;i++)
    {
        scanf("%s",s);
        min[i]=25,max[i]=0;
        for(int j=0;j<m;j++)
        {
            min[i]=std::min(min[i],s[j]-'a');
            max[i]=std::max(max[i],s[j]-'a');
        }
        // fprintf(stderr,"%d %d\n",min[i],max[i]);
    }
    for(int i=0;i<n;i++)
    {
        int fl(1);
        for(int j=0;j<n;j++)
        {
            if(i!=j&&(min[i]>max[j]||(min[i]==max[j]&&max[i]>min[j])))
            {
                fl=0;break;
            }
        }
        s[i]=fl^48;
    }
    s[n]=0;
    puts(s);
    return 0;
}