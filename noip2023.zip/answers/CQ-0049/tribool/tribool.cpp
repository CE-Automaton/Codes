#include<stdio.h>
struct edge
{
    int v,w,next;
};
edge e[100005];
int en,last[100005];
void add_edge(const int u,const int v,const int w)
{
    // printf("%d %d %d\n",u,v,w);
    e[++en]={v,w,last[u]};
    last[u]=en;
}
int val[100005];
void dfs(const int u)
{
    for(int i=last[u];i>0;i=e[i].next)
    {
        if(val[e[i].v]!=2)
        {
            val[e[i].v]=2;
            dfs(e[i].v);
        }
    }
}
int vis[100005];
bool dfs1(const int u)
{
    vis[u]=1;
    for(int i=last[u];i>0;i=e[i].next)
    {
        const int w(e[i].w?4-val[u]:val[u]);
        if(val[e[i].v]<=0)
        {
            val[e[i].v]=w;
            if(!dfs1(e[i].v)){return false;}
        }
        else if(vis[e[i].v]&&val[e[i].v]!=w)
        {
            return false;
        }
    }
    vis[u]=0;
    return true;
}
void solve()
{
    int n,m;
    scanf("%d%d",&n,&m);
    for(int i=0;i<n;i++)
    {
        val[i]=-i;
    }
    for(int i=0;i<m;i++)
    {
        char op[2];int x,y;
        scanf("%s",op);
        switch(op[0])
        {
            case 'T':
                scanf("%d",&x);
                val[x-1]=3;
                break;
            case 'F':
                scanf("%d",&x);
                val[x-1]=1;
                break;
            case 'U':
                scanf("%d",&x);
                val[x-1]=2;
                break;
            case '+':
                scanf("%d%d",&x,&y);
                val[x-1]=val[y-1];
                break;
            case '-':
                scanf("%d%d",&x,&y),--x,--y;
                if(val[y]<=0)
                {
                    val[x]=val[y]<=-n?val[y]+n:val[y]-n;
                }
                else
                {
                    val[x]=4-val[y];
                }
                break;
        }
    }
    __builtin_memset(last,0,n*sizeof(int));
    en=0;
    for(int i=0;i<n;i++)
    {
        if(val[i]<=0)
        {
            add_edge(val[i]<=-n?-val[i]-n:-val[i],i,val[i]<=-n);
        }
    }
    for(int i=0;i<n;i++)
    {
        if(val[i]==2)
        {
            dfs(i);
        }
    }
    for(int i=0;i<n;i++)
    {
        if(val[i]>0)
        {
            dfs1(i);
        }
    }
    for(int i=0;i<n;i++)
    {
        if(val[i]<=0)
        {
            val[i]=1;
            if(!dfs1(i))
            {
                val[i]=2;
                dfs(i);
            }
        }
    }
    int cnt(0);
    for(int i=0;i<n;i++)
    {
        cnt+=val[i]==2;
    }
    printf("%d\n",cnt);
}
int main()
{
    freopen("tribool.in","r",stdin);
    freopen("tribool.out","w",stdout);
    int t;
    scanf("%*d%d",&t);
    while(t--)
    {
        solve();
    }
    return 0;
}