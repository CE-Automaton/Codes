#include<bits/stdc++.h>
using namespace std;
int read(){
	int x=0,f=0;char c=getchar();
	while(c<'0'||c>'9')f|=(c=='-'),c=getchar();
	while(c>='0'&&c<='9')x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return f?-x:x;
}
int n,m,sum[3005],nxt[3005];
string s[3005],t[3005];
char c[3005];
signed main()
{
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;i++){
		scanf("%s",c+1);
		sort(c+1,c+m+1);
		s[i]=t[i]="";
		for(int j=1;j<=m;j++)s[i]+=c[j];
		for(int j=m;j>=1;j--)t[i]+=c[j];
	}
	sum[1]=1;
	for(int i=2;i<=n;i++){
		if(t[i]<t[sum[i-1]])sum[i]=i;
		else sum[i]=sum[i-1];
	}
	nxt[n]=n;
	for(int i=n-1;i>=1;i--){
		if(t[i]<t[nxt[i+1]])nxt[i]=i;
		else nxt[i]=nxt[i+1];
	}
	for(int i=1;i<=n;i++){
		bool f=1;
		if(i>1)f&=(s[i]<t[sum[i-1]]);
		if(i<n)f&=(s[i]<t[nxt[i+1]]);
		if(f)putchar('1');
		else putchar('0');
	}
	return 0;
}
