#include<bits/stdc++.h>
using namespace std;
int read(){
	int x=0,f=0;char c=getchar();
	while(c<'0'||c>'9')f|=(c=='-'),c=getchar();
	while(c>='0'&&c<='9')x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return f?-x:x;
}
int id,T,n,m,ans,tot,sum;
struct node{
	int op,pos;
}a[100010];
int h[100005],cnt;
struct edge{
	int v,w,nxt;
}e[300005];
void adde(int u,int v,int w){
	e[++cnt].nxt=h[u];
	h[u]=cnt;
	e[cnt].v=v;
	e[cnt].w=w;
}
bool vis[100005],on[100005],ch[100005];
stack<int>S;
vector<int>nd;
void dfs(int x,int las){
//	cerr<<x<<' '<<las<<endl;
	if(vis[x])return;
	vis[x]=1;
	S.push(x);
	if(x<=n)tot++;
	for(int i=h[x];i;i=e[i].nxt){
		if((i^1)==las||e[i].v==x)continue;
		if(vis[e[i].v]&&nd.empty()){
//			cerr<<"++"<<x<<" "<<e[i].v<<endl;
			while(1){
				int tmp=S.top();
				S.pop();
				nd.push_back(tmp);
//				cerr<<"=="<<tmp<<' '<<e[i].v<<endl;
				if(tmp==e[i].v)break;
			}
			for(int i=nd.size()-1;i>=0;i--)S.push(nd[i]);
		}
		else dfs(e[i].v,i);
	}
	S.pop();
}
void dfs1(int x,int las){
	if(ch[x])return;
//	cerr<<x<<' '<<las<<endl;
	ch[x]=1;
	for(int i=h[x];i;i=e[i].nxt){
		if(on[e[i].v]&&(i^1)!=las){
//			cerr<<x<<' '<<e[i].v<<' '<<e[i].w<<endl;
			sum+=e[i].w;
			dfs1(e[i].v,i);
			break;
		}
	}
}
signed main()
{
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	read();
	T=read();
	while(T--){
		n=read(),m=read();
		for(int i=1;i<=n+3;i++)a[i].op=0,a[i].pos=i;
		char op[5];
		int x,y;
		for(int i=1;i<=m;i++){
			scanf("%s",op+1);
			if(op[1]=='+'){
				x=read(),y=read();
				a[x].pos=a[y].pos;
				a[x].op=a[y].op;
			}
			else if(op[1]=='-'){
				x=read(),y=read();
				a[x].pos=a[y].pos;
				a[x].op=(a[y].op^1);
			}
			else if(op[1]=='T'){
				x=read();
				a[x].pos=n+1;
				a[x].op=0;
			}
			else if(op[1]=='F'){
				x=read();
				a[x].pos=n+2;
				a[x].op=0;
			}
			else{
				x=read();
				a[x].pos=n+3;
				a[x].op=0;
			}
		}
//		for(int i=1;i<=n;i++)cerr<<a[i].op<<' '<<a[i].pos<<endl;
		cnt=1;
		for(int i=1;i<=n+3;i++)h[i]=0,vis[i]=0;
		ans=0;
		for(int i=1;i<=n;i++){
			adde(i,a[i].pos,a[i].op);
			adde(a[i].pos,i,a[i].op);
		}
		tot=0;
		dfs(n+3,0);
		ans+=tot;
		for(int i=1;i<=n;i++){
			if(a[i].pos==i&&a[i].op==1){
				tot=0;
				dfs(i,0);
				ans+=tot;
			}
		}
		memset(on,0,sizeof(on));
		memset(ch,0,sizeof(ch));
//		cerr<<ans<<endl;
//		cerr<<"------"<<endl;
		for(int i=1;i<=n;i++){
			if(!vis[i]){
				tot=0;
				nd.clear();
//				cerr<<i<<endl;
				dfs(i,0);
				if(!nd.empty()){
					for(int x:nd)on[x]=1;
//					cerr<<endl;
					sum=0;
					dfs1(nd[0],0);
//					cerr<<"sum:"<<sum<<' '<<nd.size()<<endl;
					if(sum&1)ans+=tot;
				}
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
