#include<bits/stdc++.h>
using namespace std;
int read(){
	int x=0,f=0;char c=getchar();
	while(c<'0'||c>'9')f|=(c=='-'),c=getchar();
	while(c>='0'&&c<='9')x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return f?-x:x;
}
int c,n,m,q,a[500005],b[500005],x[500005],y[500005],maxx,maxy,minx,miny;
bool dp[2005][2005];
void solve(){
	maxx=maxy=-1,minx=miny=INT_MAX;
	for(int i=1;i<=n;i++)maxx=max(maxx,x[i]),minx=min(minx,x[i]);
	for(int i=1;i<=m;i++)maxy=max(maxy,y[i]),miny=min(miny,y[i]);
	if(x[1]<y[1]&&x[n]<y[m]){
		if(c<=7){
			for(int i=1;i<=n;i++)for(int j=1;j<=m;j++)dp[i][j]=0;
			dp[0][0]=1;
			for(int i=1;i<=n;i++){
				for(int j=1;j<=m;j++){
					if(x[i]<y[j]){
						dp[i][j]=(dp[i-1][j]||dp[i][j-1]||dp[i-1][j-1]);
					}
				}
			}
			if(dp[n][m])putchar('1');
			else putchar('0');
		}
		else if(c<=14){
			if(miny<=minx)putchar('0');
			else putchar('1');
		}
		else{
			if(maxx>=maxy)putchar('0');
			else putchar('1');
		}
	}
	else if(x[1]>y[1]&&x[n]>y[m]){
		if(c<=7){
			for(int i=1;i<=n;i++)for(int j=1;j<=m;j++)dp[i][j]=0;
			dp[0][0]=1;
			for(int i=1;i<=n;i++){
				for(int j=1;j<=m;j++){
					if(x[i]>y[j]){
						dp[i][j]=(dp[i-1][j]||dp[i][j-1]||dp[i-1][j-1]);
					}
	//				cerr<<dp[i][j]<<' ';
				}
	//			cerr<<endl;
			}
			if(dp[n][m])putchar('1');
			else putchar('0');
		}
		else if(c<=14){
			
		}
		else{
			if(maxx<=maxy)putchar('0');
			else putchar('1');
		}
	}
	else putchar('0');
}
signed main()
{
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	c=read();
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;i++)a[i]=x[i]=read();
	for(int i=1;i<=m;i++)b[i]=y[i]=read();
	solve();
	while(q--){
		int kx=read(),ky=read();
		for(int i=1;i<=n;i++)x[i]=a[i];
		for(int i=1;i<=m;i++)y[i]=b[i];
		while(kx--){
			int p=read(),c=read();
			x[p]=c;
		}
		while(ky--){
			int p=read(),c=read();
			y[p]=c;
		}
		solve();
	}
	return 0;
}
