#include <bits/stdc++.h>


using namespace std;


int cid, n, m, q, a, b, x, y;
int X[500003], Y[500003], tempX[500003], tempY[500003];
bool f[2003][2003];


void solve() {
	if (X[1] == Y[1] || X[n] == Y[m] || (X[1] > Y[1]) != (X[n] > Y[m])) printf("0");
	else {
		if (cid <= 7) {
			memset(f, false, sizeof f);
			f[0][0] = 1;
			for (int i = 1; i <= n; ++ i) {
				for (int j = 1; j <= m; ++ j) {
					if (X[i] != Y[j] && (X[i] > Y[j]) == (X[1] > Y[1])) {
						f[i][j] = f[i - 1][j] | f[i][j - 1] | f[i - 1][j - 1];
					}
				}
			}
			printf(f[n][m] ? "1" : "0");
		} else printf("0");
	}
}


int main() {
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);
	scanf("%d %d %d %d", &cid, &n, &m, &q);
	for (int i = 1; i <= n; ++ i) scanf("%d", &tempX[i]), X[i] = tempX[i];
	for (int i = 1; i <= m; ++ i) scanf("%d", &tempY[i]), Y[i] = tempY[i];
	solve();
	while (q --) {
		scanf("%d %d", &a, &b);
		while (a --) {
			scanf("%d %d", &x, &y);
			X[x] = y;
		}
		while (b --) {
			scanf("%d %d", &x, &y);
			Y[x] = y;
		}
		solve();
		for (int i = 1; i <= n; ++ i) X[i] = tempX[i];
		for (int i = 1; i <= m; ++ i) Y[i] = tempY[i];
	}
	return 0;
}
