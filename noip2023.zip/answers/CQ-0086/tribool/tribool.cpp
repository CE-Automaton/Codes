#include <bits/stdc++.h>


using namespace std;


int cid, T, n, m, x, y;
char ch;
int a[100003], fath[100003], sz[100003], f[100003];
bool flag[100003];


int getfath(int i) {
	return i == fath[i] ? i : getfath(fath[i]);
}

int getdis(int i) {
	return i == fath[i] ? 0 : getdis(fath[i]) ^ f[i];
}


void Merge(int u, int v) {
	int fu = getfath(u), du = getdis(u);
	int fv = getfath(abs(v)), dv = getdis(abs(v));
	int w = (v < 0);
	if (fu != fv) {
		if (sz[fu] < sz[fv]) swap(fu, fv), swap(du, dv);
		fath[fv] = fu;
		sz[fu] += sz[fv];
		flag[fu] |= flag[fv];
		f[fv] = w ^ du ^ dv;
	} else if (du ^ dv ^ w) flag[fu] = true;
}


int main() {
	freopen("tribool.in", "r", stdin);
	freopen("tribool.out", "w", stdout);
	scanf("%d %d", &cid, &T);
	while (T --) {
		scanf("%d %d", &n, &m);
		for (int i = 1; i <= n; ++ i) {
			a[i] = i;
			fath[i] = i;
			sz[i] = 1;
			f[i] = 0;
		}
		while (m --) {
			scanf(" %c", &ch);
			if (ch == 'T') {
				scanf("%d", &x);
				a[x] = n + 1;
			} else if (ch == 'F') {
				scanf("%d", &x);
				a[x] = -(n + 1);
			} else if (ch == 'U') {
				scanf("%d", &x);
				a[x] = 0;
			} else if (ch == '+') {
				scanf("%d %d", &x, &y);
				a[x] = a[y];
			} else {
				scanf("%d %d", &x, &y);
				a[x] = -a[y];
			}
		}
		for (int i = 1; i <= n; ++ i) flag[i] = (!a[i]);
		for (int i = 1; i <= n; ++ i) if (a[i] && abs(a[i]) <= n) Merge(i, a[i]);
		int ans = 0;
		for (int i = 1; i <= n; ++ i)
			if (flag[getfath(i)]) ++ ans;
		printf("%d\n", ans);
	}
	return 0;
}
