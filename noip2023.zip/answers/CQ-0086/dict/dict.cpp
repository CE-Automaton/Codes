#include <bits/stdc++.h>


using namespace std;


int n, m;
char s[3007];
char minn[3007], maxx[3007];


int main() {
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);
	scanf("%d %d", &n, &m);
	for (int i = 1; i <= n; ++ i) {
		scanf("%s", s + 1);
		minn[i] = maxx[i] = s[1];
		for (int j = 2; j <= m; ++ j) {
			minn[i] = min(minn[i], s[j]);
			maxx[i] = max(maxx[i], s[j]);
		}
	}
	for (int i = 1; i <= n; ++ i) {
		bool flag = true;
		for (int j = 1; j <= n; ++ j) {
			if (i != j) {
				if (minn[i] >= maxx[j]) {
					flag = false;
					break;
				}
			}
			
		}
		printf(flag ? "1" : "0");
	}
	return 0;
}
