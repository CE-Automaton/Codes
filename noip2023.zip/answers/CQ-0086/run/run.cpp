#include <bits/stdc++.h>


using namespace std;


struct Node {
	int x, y, v;
};


int cid, T;
int n, m, K, D;
Node arr[100003];
long long f[100003], presum[100003];
priority_queue<pair<int, int> > pq;
pair<int, int> pq2[100003];


int main() {
	freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);
	scanf("%d %d", &cid, &T);
	while (T --) {
		scanf("%d %d %d %d", &n, &m, &K, &D);
		for (int i = 1; i <= m; ++ i) {
			scanf("%d %d %d", &arr[i].x, &arr[i].y, &arr[i].v);
			if (arr[i].y > K) -- m, -- i;
		}
		sort(arr + 1, arr + m + 1, [](Node n1, Node n2) {return n1.x < n2.x;});
		if (cid <= 9) {
			memset(f, -0x3f, sizeof f);
			f[0] = 0;
			for (int i = 1, k = 1; i <= n; ++ i) {
				while (k <= m && arr[k].x <= i) ++ k;
				long long sum = 0;
				for (int j = 1, l = k - 1; j <= min(K, i); ++ j) {
					while (l && arr[l].x >= i - j + 1) {
						pq.push(make_pair(arr[l].x - arr[l].y + 1, l));
						-- l;
					}
					while (!pq.empty() && pq.top().first >= i - j + 1) {
						sum += arr[pq.top().second].v;
						pq.pop();
					}
					f[i] = max(f[i], (i > j ? f[i - j - 1] : 0) + sum - (long long)(D) * j);
				}
				f[i] = max(f[i], f[i - 1]);
				while (!pq.empty()) pq.pop();
			}
			printf("%lld\n", f[n]);
		} else if (cid <= 11 || cid == 15 || cid == 16) {
			memset(f, -0x3f, sizeof f);
			f[0] = 0;
			for (int i = 1; i <= m; ++ i) {
				pq2[i] = make_pair(arr[i].x - arr[i].y + 1, i);
				for (int j = i; j > 1 && pq2[j].first < pq2[j - 1].first; -- j) swap(pq2[j - 1], pq2[j]);
				long long sum = 0;
				for (int j = 1, k = i, l = i; j <= min(K, arr[i].x); ++ j) {
					while (l && arr[l].x >= arr[i].x - j) -- l;
					while (k && pq2[k].first >= arr[i].x - j + 1) {
						sum += arr[pq2[k].second].v;
						-- k;
					}
					f[i] = max(f[i], (l ? f[l] : 0) + sum - (long long)(D) * j);
				}
				f[i] = max(f[i], f[i - 1]);
			}
			printf("%lld\n", f[m]);
		} else if (cid == 17 || cid == 18) {
			for (int i = 1; i <= m; ++ i) presum[i] = presum[i - 1] + arr[i].v;
			memset(f, -0x3f, sizeof f);
			f[0] = 0;
			for (int i = 1, j = 1; i <= m; ++ i) {
				if (i != 1 && arr[i].x - arr[i].y + 1 > arr[i - 1].x + 1) j = i;
				else while (arr[i].x - (arr[j].x - arr[j].y + 1) >= K) ++ j;
				if (j != 1 && arr[j - 1].x == arr[j].x - arr[j].y) f[i] = max(f[i], f[j - 2] + presum[i] - presum[j - 1] - (long long)(D) * (arr[i].x - (arr[j].x - arr[j].y)));
				else f[i] = max(f[i], f[j - 1] + presum[i] - presum[j - 1] - (long long)(D) * (arr[i].x - (arr[j].x - arr[j].y)));
				f[i] = max(f[i], f[i - 1]);
			}
			printf("%lld\n", f[m]);
		} else {
			for (int i = 1; i <= m; ++ i) presum[i] = presum[i - 1] + arr[i].v;
			memset(f, -0x3f, sizeof f);
			f[0] = 0;
			for (int i = 1, j = 1, k = 1; i <= m; ++ i) {
				if (i != 1 && arr[i].x - arr[i].y + 1 > arr[i - 1].x + 1) j = i;
				else while (arr[i].x - (arr[j].x - arr[j].y + 1) >= K) ++ j;
				while (arr[k].x < arr[j].x - arr[j].y) ++ k;
				f[i] = max(f[i], f[k - 1] + presum[i] - presum[j - 1] - (long long)(D) * (arr[i].x - (arr[j].x - arr[j].y)));
				f[i] = max(f[i], f[i - 1]);
			}
			printf("%lld\n", f[m]);
		}
	}
	return 0;
}
