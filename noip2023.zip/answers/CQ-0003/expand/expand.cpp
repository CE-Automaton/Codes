#include<bits/stdc++.h>
using namespace std;
mt19937_64 myrand(time(NULL));
inline int Rand(int l,int r) {
    return myrand()%(r-l+1)+l;
}
const int N=500005,M=2005;
int id,n,m,q;
int a[N],b[N],A[N],B[N];
bool f[M][M];
inline void sol() {
    if (id<=7) {
        memset(f,0,sizeof f);
        f[1][1]=(a[1]!=b[1]);
        for (int i=1;i<=n;i++) {
            for (int j=1;j<=m;j++) {
                if (i!=n&&j!=m&&1ll*(a[i+1]-b[j+1])*(a[1]-b[1])>0) f[i+1][j+1]|=f[i][j];
                if (i!=n&&1ll*(a[i+1]-b[j])*(a[1]-b[1])>0) f[i+1][j]|=f[i][j];
                if (j!=m&&1ll*(a[i]-b[j+1])*(a[1]-b[1])>0) f[i][j+1]|=f[i][j];
            }
        }
        if (f[n][m]) putchar('1');
        else putchar('0');
    } else {
        int tim;
        if (id==8||id==9||id==15||id==16) tim=20;
        else tim=5;
        while (tim--) {
            int x=1,y=1,cho;
            int cnt,X[5]={},Y[5]={};
            while (x<n||y<m) {
                cnt=0;
                if (a[1]<b[1]&&x!=n&&a[x]>a[x+1]) {
                    x++;
                    continue;
                }
                if (a[1]>b[1]&&x!=n&&a[x]<a[x+1]) {
                    x++;
                    continue;
                }
                if (a[1]<b[1]&&y!=m&&b[y]<b[y+1]) {
                    y++;
                    continue;
                }
                if (a[1]>b[1]&&y!=m&&b[y]>b[y+1]) {
                    y++;
                    continue;
                }
                if (x!=n&&1ll*(a[x+1]-b[y])*(a[1]-b[1])>0) X[++cnt]=1,Y[cnt]=0;
                if (y!=m&&1ll*(a[x]-b[y+1])*(a[1]-b[1])>0) Y[++cnt]=1,X[cnt]=0;
                if (x!=n&&y!=m&&1ll*(a[x+1]-b[y+1])*(a[1]-b[1])>0&&!cnt) X[++cnt]=1,Y[cnt]=1;
                if (!cnt) break;
                cho=Rand(1,cnt);
                x+=X[cho],y+=Y[cho];
            }
            if (x==n&&y==m) {
                putchar('1');
                return;
            }
        }
        putchar('0');
    }
    return;
}
int main() {
    freopen("expand.in","r",stdin);
    freopen("expand.out","w",stdout);
    scanf("%d %d %d %d",&id,&n,&m,&q);
    for (int i=1;i<=n;i++) scanf("%d",&a[i]),A[i]=a[i];
    for (int i=1;i<=m;i++) scanf("%d",&b[i]),B[i]=b[i];
    sol();
    for (int i=1;i<=q;i++) {
        int kx,ky,x,y;
        scanf("%d %d",&kx,&ky);
        while (kx--) {
            scanf("%d %d",&x,&y);
            a[x]=y;
        }
        while (ky--) {
            scanf("%d %d",&x,&y);
            b[x]=y;
        }
        sol();
        for (int j=1;j<=n;j++) a[j]=A[j];
        for (int j=1;j<=m;j++) b[j]=B[j];
    }
    return 0;
}