#include<bits/stdc++.h>
using namespace std;
const int N=3005;
int n,m;
char ma[N],mi[N],pre[N],suf[N];
char a[N][N];
int main() {
    freopen("dict.in","r",stdin);
    freopen("dict.out","w",stdout);
    scanf("%d %d",&n,&m);
    for (int i=1;i<=n;i++) {
        scanf("%s",a[i]+1);
        for (int j=1;j<=m;j++) {
            if (!ma[i]||a[i][j]>ma[i]) ma[i]=a[i][j];
            if (!mi[i]||a[i][j]<mi[i]) mi[i]=a[i][j];
        }
        if (i==1) pre[i]=ma[i];
        else pre[i]=min(pre[i-1],ma[i]);
    }
    if (n==1) {
        printf("1");
        return 0;
    }
    for (int i=n;i>=1;i--) {
        if (i==n) suf[i]=ma[i];
        else suf[i]=min(suf[i+1],ma[i]);
    }
    for (int i=1;i<=n;i++) {
        if (i==1) {
            if (suf[i+1]<=mi[i]) putchar('0');
            else putchar('1');
        } else if (i==n) {
            if (pre[i-1]<=mi[i]) putchar('0');
            else putchar('1');
        } else {
            if (suf[i+1]<=mi[i]||pre[i-1]<=mi[i]) putchar('0');
            else putchar('1');
        }
    }
    return 0;
}