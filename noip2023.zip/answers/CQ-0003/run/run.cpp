#include<bits/stdc++.h>
using namespace std;
using LL=long long;
// inline void print(LL x) {
//     if (x<=-1e17) printf("%d ",-1);
//     else printf("%lld ",x);
// }
inline int read() {
    int f=0;
    char c=getchar();
    while (!isdigit(c)) c=getchar();
    while (isdigit(c)) f=(f<<3)+(f<<1)+c-'0',c=getchar();
    return f;
}
const int N=200005;
const LL inf=1000000000000000000;
int id,tt,n,m,lim,k,d;
int lsh[N],tot;
struct node {int l,r,v;}a[N];
vector<node>vec[N];
struct SegmentTree {
    LL dat[N<<2],tag[N<<2];
    inline void pushdown(int p) {
        dat[p<<1]+=tag[p],dat[p<<1|1]+=tag[p];
        tag[p<<1]+=tag[p],tag[p<<1|1]+=tag[p];
        tag[p]=0;
        return;
    }
    void update1(int p,int l,int r,int L,int R,LL d) {
        if (L>R) return;
        if (L<=l&&r<=R) {
            dat[p]+=d,tag[p]+=d;
            return;
        }
        pushdown(p);
        int mid=(l+r)>>1;
        if (L<=mid) update1(p<<1,l,mid,L,R,d);
        if (R>mid) update1(p<<1|1,mid+1,r,L,R,d);
        dat[p]=max(dat[p<<1],dat[p<<1|1]);
        return;
    }
    void update2(int p,int l,int r,int x,LL d) {
        if (l==r) {
            dat[p]=d;
            return;
        }
        pushdown(p);
        int mid=(l+r)>>1;
        if (x<=mid) update2(p<<1,l,mid,x,d);
        else update2(p<<1|1,mid+1,r,x,d);
        dat[p]=max(dat[p<<1],dat[p<<1|1]);
        return;
    }
    void update3(int p,int l,int r,int x,LL d) {
        if (l==r) {
            dat[p]+=d;
            return;
        }
        pushdown(p);
        int mid=(l+r)>>1;
        if (x<=mid) update3(p<<1,l,mid,x,d);
        else update3(p<<1|1,mid+1,r,x,d);
        dat[p]=max(dat[p<<1],dat[p<<1|1]);
        return;
    }
    LL getmax(int p,int l,int r,int L,int R) {
        if (L<=l&&r<=R) return dat[p];
        pushdown(p);
        int mid=(l+r)>>1;
        LL res=-inf;
        if (L<=mid) res=max(res,getmax(p<<1,l,mid,L,R));
        if (R>mid) res=max(res,getmax(p<<1|1,mid+1,r,L,R));
        return res;
    }
}T;
int main() {
    freopen("run.in","r",stdin);
    freopen("run.out","w",stdout);
    id=read(),tt=read();
    while (tt--) {
        n=read(),m=read(),k=read(),d=read();
        tot=0;
        for (int i=1,x,y,v;i<=m;i++) {
            x=read(),y=read(),v=read();
            a[i]={x-y+1,x,v};
            lsh[++tot]=x-y+1,lsh[++tot]=x;
        }
        sort(lsh+1,lsh+tot+1);
        tot=unique(lsh+1,lsh+tot+1)-lsh-1;
        for (int i=1;i<=m;i++) {
            a[i].l=lower_bound(lsh+1,lsh+tot+1,a[i].l)-lsh;
            a[i].r=lower_bound(lsh+1,lsh+tot+1,a[i].r)-lsh;
            vec[a[i].r].push_back(a[i]);
        }
        lim=tot+1;
        for (int i=1;i<(lim<<2);i++) T.dat[i]=-inf,T.tag[i]=0;
        T.update2(1,1,lim,1,0);
        int idx=1;
        lsh[0]=-1;
        for (int i=1;i<=tot;i++) {
            LL res=T.getmax(1,1,lim,1,lim);
            T.update2(1,1,lim,i+1,res);
            if (lsh[i]!=lsh[i-1]+1) T.update2(1,1,lim,i,res-d);
            else T.update3(1,1,lim,i,-d);
            while (idx<=tot&&lsh[i]-lsh[idx]+1>k) T.update2(1,1,lim,idx,-inf),idx++;
            T.update1(1,1,lim,1,i-1,-1ll*d*(lsh[i]-lsh[i-1]));
            for (auto x:vec[i]) {
                // printf("%d %d\n",i,lsh[i]);
                T.update1(1,1,lim,1,x.l,x.v);
            }
            // for (int j=1;j<=i+1;j++) print(T.getmax(1,1,lim,j,j));
            // puts("");
        }
        printf("%lld\n",T.getmax(1,1,lim,1,lim));
        for (int i=1;i<=tot;i++) vec[i].clear();
    }
    return 0;
}