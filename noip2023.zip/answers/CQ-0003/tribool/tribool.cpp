#include<bits/stdc++.h>
using namespace std;
const int N=100005;
int id,T;
int n,m,ans,deg[N],col[N];
struct node {
    int id;
    bool f;
    int tp;
}a[N];
vector<pair<int,int> >G[N];
bool vis[N],solved[N];
queue<int>q;
inline void bfs() {
    for (int i=1;i<=n;i++) if (!deg[i]) q.push(i);
    while (!q.empty()) {
        int p=q.front();
        q.pop();
        if (a[p].id) vis[p]=1;
        deg[a[p].id]--;
        if (!deg[a[p].id]) q.push(a[p].id);
    }
    return;
}
void dfs(int p,int&keg,int ban) {
    solved[p]=1;
    keg+=(col[p]==2);
    for (auto x:G[p]) {
        if (x.first==ban) continue;
        col[x.first]=x.second?(4-col[p]):(col[p]);
        dfs(x.first,keg,ban);
    }
    return;
}
int main() {
    freopen("tribool.in","r",stdin);
    freopen("tribool.out","w",stdout);
    ios::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);
    cin>>id>>T;
    while (T--) {
        ans=0;
        cin>>n>>m;
        memset(deg,0,sizeof deg);
        memset(vis,0,sizeof vis);
        memset(solved,0,sizeof solved);
        for (int i=1;i<=n;i++) G[i].clear(),a[i].id=i,a[i].f=0,a[i].tp=0;
        for (int i=1;i<=m;i++) {
            char opt;
            int x,y;
            cin>>opt>>x;
            if (opt=='T') {
                a[x].id=a[x].f=0;
                a[x].tp=1;
            } else if (opt=='U') {
                a[x].id=a[x].f=0;
                a[x].tp=2;
            } else if (opt=='F') {
                a[x].id=a[x].f=0;
                a[x].tp=3;
            } else if (opt=='+') {
                cin>>y;
                a[x]=a[y];
            } else {
                cin>>y;
                a[x]=a[y];
                if (a[x].id) a[x].f^=1;
                else a[x].tp=4-a[x].tp;
            }
        }
        for (int i=1;i<=n;i++) {
            if (a[i].id) deg[a[i].id]++,G[a[i].id].push_back(make_pair(i,a[i].f));
        }
        bfs();
        for (int i=1;i<=n;i++) {
            if (!vis[i]&&!solved[i]) {
                if (!deg[i]) {
                    col[i]=a[i].tp;
                    dfs(i,ans,0);
                } else {
                    int minn=1e9;
                    for (int j=1;j<=3;j++) {
                        int cnt=0;
                        col[i]=j;
                        dfs(i,cnt,i);
                        int should=a[i].f?(4-col[a[i].id]):(col[a[i].id]);
                        if (should==col[i]) minn=min(minn,cnt);
                    }
                    ans+=minn;
                }
            }
        }
        cout<<ans<<endl;
    }
    return 0;
}