#include<bits/stdc++.h>

template <class T>
void read(T &x) {
    x = 0; char c = getchar(); bool f = 0;
    while (!isdigit(c)) f = c == '-', c = getchar();
    while (isdigit(c)) x = x * 10 + c - '0', c = getchar();
    x = f? (-x) : x;
}

const int INF = 0x3f3f3f3f;

void solve(int c) {
    int n, m;
    std::cin >> n >> m;
    std::cerr << n << " " << m << "\n";
    struct op {
        char op;
        int x, y;
    };
    std::vector <op> a(m + 1);
    std::vector <std::vector<int> > vec(n + 1);
    for (int i = 1; i <= m; i++) {
        std::cin >> a[i].op >> a[i].x;
        if (a[i].op == '+') {
            std::cin >> a[i].y;
        }
        if (a[i].op == '-') {
            std::cin >> a[i].y;
        }
    }

    if (c <= 2) {
        int ret = 0x3f3f3f3f;
        std::vector <int> arr(n + 1);
        auto count = [&]() {
            int ret = 0;
            for (int i = 1; i <= n; i++) {
                if (arr[i] == 0) ret++;
            }
            return ret;
        };
        auto check = [&]() {
            std::vector <int> tmp = arr;
            for (int i = 1; i <= m; i++) {
                if (a[i].op == '+') tmp[a[i].x] = tmp[a[i].y];
                if (a[i].op == '-') tmp[a[i].x] = -tmp[a[i].y];
                if (a[i].op == 'T') tmp[a[i].x] = 1;
                if (a[i].op == 'F') tmp[a[i].x] = -1;
                if (a[i].op == 'U') tmp[a[i].x] = 0;
            }
            return tmp == arr;
        };

        auto dfs = [&](auto self, int u) -> void{
            if (u == n + 1) {
                if (check()) {
                    ret = std::min(ret, count());
                }
                return;
            }
            arr[u] = 0;
            self(self, u + 1);
            arr[u] = 1;
            self(self, u + 1);
            arr[u] = -1;
            self(self, u + 1);
        };

        dfs(dfs, 1);
        std::cout << ret << "\n";
        return;
    }

    if (c <= 4) {
        std::vector <int> arr(n + 1, 114514);
        for (int i = 1; i <= m; i++) {
            if (a[i].op == 'T') arr[a[i].x] = 1;
            if (a[i].op == 'F') arr[a[i].x] = -1;
            if (a[i].op == 'U') arr[a[i].x] = 0;
        }
        int ret = 0;
        for (int i = 1; i <= n; i++) {
            if (arr[i] == 0) ret++; 
        }
        std::cout << ret << "\n";
        return;
    }

    std::cout << 0 << "\n";
}

int main() {
    freopen("tribool.in", "r", stdin);
    freopen("tribool.out", "w", stdout);

    std::ios::sync_with_stdio(0);
    std::cin.tie(0);
    std::cout.tie(0);

    int t = 1, c;
    std::cin >> c >> t;
    while (t--) {
        solve(c);
    }

    return 0;
}
