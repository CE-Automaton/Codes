#include<bits/stdc++.h>

template <class T>
void read(T &x) {
    x = 0; char c = getchar(); bool f = 0;
    while (!isdigit(c)) f = c == '-', c = getchar();
    while (isdigit(c)) x = x * 10 + c - '0', c = getchar();
    x = f? (-x) : x;
}

#define ll long long
const int MAXN = 3005;
const ll MOD = 998244353;
const ll P1 = 131;
const ll P2 = 13331;
std::string s[MAXN];
std::string str[MAXN][2];

ll mul1[MAXN], mul2[MAXN];
void init() {
    mul1[0] = 1; mul2[0] = 1;
    for (int i = 1; i < MAXN; i++) {
        mul1[i] = mul1[i - 1] * P1 % MOD;
        mul2[i] = mul2[i - 1] * P2 % MOD;
    } 
}

struct Hash {
    ll h1[MAXN], h2[MAXN];
    void init(const std::string &s) {
        for (int i = 1; i < s.size(); i++) {
            h1[i] = ((h1[i - 1] * P1 % MOD) + (s[i] - 'a')) % MOD;
            h2[i] = ((h2[i - 1] * P2 % MOD) + (s[i] - 'a')) % MOD;
        }
    }
    std::pair <ll, ll> hash(int l, int r) {
        ll x = h1[r] - (h1[l - 1] * mul1[r - l + 1] % MOD); x += MOD; x %= MOD;
        ll y = h2[r] - (h2[l - 1] * mul2[r - l + 1] % MOD); y += MOD; y %= MOD;
        return std::make_pair(x, y);
    }
}H[MAXN][2];

bool ans[MAXN];

bool cmp(char a, char b) {
    return a > b;
}

void solve() {
    int n, m;
    std::cin >> n >> m;
    for (int i = 1; i <= n; i++) {
        std::cin >> s[i];
        s[i] = "$" + s[i];
        std::sort(s[i].begin() + 1, s[i].end());
        str[i][0] = s[i];
        H[i][0].init(s[i]);
        std::sort(s[i].begin() + 1, s[i].end(), cmp);
        str[i][1] = s[i];
        H[i][1].init(s[i]);
        ans[i] = 1;
    }

    auto check = [&](int x, int y) {
        int l = 1, r = m, pos = 0;
        while (l <= r) {
            int mid = (l + r) >> 1;
            if (H[x][0].hash(1, mid) != H[y][1].hash(1, mid)) r = mid - 1;
            else pos = mid, l = mid + 1;
        }
        if (pos == m) return (bool)0;
        return str[x][0][pos + 1] < str[y][1][pos + 1];
    };
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            if (i == j) continue;
            if (!check(i, j)) {
                ans[i] = 0;
                break;
            }
        }
    }

    for (int i = 1; i <= n; i++) {
        std::cout << ans[i];
    }
    std::cout << "\n";
}

int main() {
    freopen("dict.in", "r", stdin);
    freopen("dict.out", "w", stdout);

    std::ios::sync_with_stdio(0);
    std::cin.tie(0);
    std::cout.tie(0);

    init();
    int t = 1;
    while (t--) {
        solve();
    }

    return 0;
}