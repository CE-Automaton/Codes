#include<bits/stdc++.h>

template <class T>
void read(T &x) {
    x = 0; char c = getchar(); bool f = 0;
    while (!isdigit(c)) f = c == '-', c = getchar();
    while (isdigit(c)) x = x * 10 + c - '0', c = getchar();
    x = f? (-x) : x;
}

#define ll long long
const int MAXN = 1e5 + 5;
const ll INF = 1e16;

struct Sgt {
    struct Node {
        int l, r;
        ll mx, tag;
    }t[MAXN << 2];
    void pushup(int p) {
        t[p].mx = std::max(t[p << 1].mx, t[p << 1 | 1].mx);
    }
    void pushtag(int p, ll tg) {
        t[p].mx += tg; t[p].tag += tg;
    }
    void pushdown(int p) {
        if (t[p].tag) {
            pushtag(p << 1, t[p].tag);
            pushtag(p << 1 | 1, t[p].tag);
            t[p].tag = 0;
        }
    }
    void build(int p, int l, int r) {
        t[p].l = l; t[p].r = r; t[p].tag = t[p].mx = 0;
        if (t[p].l == t[p].r) return;
        int mid = (t[p].l + t[p].r) >> 1;
        build(p << 1, l, mid); build(p << 1 | 1, mid + 1, r);
    }
    ll query(int p, int l, int r) {
        if (l <= t[p].l && t[p].r <= r) return t[p].mx;
        pushdown(p);
        int mid = (t[p].l + t[p].r) >> 1;
        ll ret = -INF;
        if (l <= mid) ret = std::max(ret, query(p << 1, l, r));
        if (r > mid) ret = std::max(ret, query(p << 1 | 1, l, r));
        return ret;
    }
    void update(int p, int l, int r, ll delta) {
        if (l <= t[p].l && t[p].r <= r) {
            pushtag(p, delta);
            return;
        }
        pushdown(p);
        int mid = (t[p].l + t[p].r) >> 1;
        if (l <= mid) update(p << 1, l, r, delta);
        if (r > mid) update(p << 1 | 1, l, r, delta);
        pushup(p);
    }
    void modify(int p, int pos, ll x) {
        if (t[p].l == t[p].r) {
            t[p].mx = x;
            return;
        }
        pushdown(p);
        int mid = (t[p].l + t[p].r) >> 1;
        if (pos <= mid) modify(p << 1, pos, x);
        else modify(p << 1 | 1, pos, x);
        pushup(p);
    }
}t;

void solve(int c) {
    int n, m, k, d;
    std::cin >> n >> m >> k >> d;
    std::vector <std::vector<std::pair<int, int> > > a(n + 1);
    for (int i = 1; i <= m; i++) {
        // std::cin >> a[i].x >> a[i].y >> a[i].v;
        int x, y, v;
        std::cin >> x >> y >> v;
        a[x].push_back(std::make_pair(y, v));
    }
    if (c <= 14) {
        // for (int i = 1; i <= n; i++) {
        //     for (int j = 0; j <= i; j++) {
        //         dp[i][j] = -INF;
        //     }
        // }
        // dp[0][0] = 0;
        // for (int i = 1; i <= n; i++) {
        //     for (int j = 1; j <= k; j++) {
        //         dp[i][j] = std::max(dp[i][j], dp[i - 1][j - 1] - d);
        //     }
        //     for (int j = 0; j < i; j++) {
        //         dp[i][0] = std::max(dp[i][0], dp[i - 1][j]);
        //     }
        //     for (const auto &p : a[i]) {
        //         for (int j = p.first; j <= i; j++) {
        //             dp[i][j] += p.second;
        //         }
        //     }
            // for (int j = 0; j <= i; j++) {
                // std::cerr << i << " " << j << " " << dp[i][j] << "\n";
            // }
        // }
        // ll mx = -INF;
        // for (int i = 0; i <= n; i++) mx = std::max(mx, dp[n][i]);
        // std::cout << mx << "\n";
        t.build(1, 0, n);
        for (int i = 1; i <= n; i++) {
            int pos = (i - 1) - (k + 1) + 1;
            pos = std::max(pos, 0);
            ll mx = t.query(1, pos, i - 1);
            t.modify(1, i, mx);
            t.update(1, pos, i - 1, -d);
            for (const auto &p : a[i]) {
                int y = p.first, v = p.second;
                pos = i - y; 
                if (pos >= 0) {
                    t.update(1, 0, pos, v);
                }
            }
            // for (int j = 0; j <= n; j++) {
            //     std::cerr << i << " " << j << " " << t.query(1, j, j) << "\n";
            // }
        }
        int pos = n - (k + 1) + 1;
        pos = std::max(pos, 0);
        std::cout << t.query(1, pos, n) << "\n";
        return;
    }
    std::cout << 0 << "\n";
}

int main() {
    freopen("run.in", "r", stdin);
    freopen("run.out", "w", stdout);

    std::ios::sync_with_stdio(0);
    std::cin.tie(0);
    std::cout.tie(0);

    int c, t = 1;
    std::cin >> c >> t;
    while (t--) {
        solve(c);
    }

    return 0;
}
