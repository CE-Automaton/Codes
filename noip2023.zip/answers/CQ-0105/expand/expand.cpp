#include<bits/stdc++.h>

template <class T>
void read(T &x) {
    x = 0; char c = getchar(); bool f = 0;
    while (!isdigit(c)) f = c == '-', c = getchar();
    while (isdigit(c)) x = x * 10 + c - '0', c = getchar();
    x = f? (-x) : x;
}

const int MAXN = 5e5 + 5;

void solve(int c) {
    int n, m, q;
    std::cin >> n >> m >> q;
    std::vector <int> a(n + 1), b(m + 1);
    for (int i = 1; i <= n; i++) std::cin >> a[i];
    for (int i = 1; i <= m; i++) std::cin >> b[i];
    std::vector <int> pa(MAXN), va(MAXN), pb(MAXN), vb(MAXN), tmpa(MAXN), tmpb(MAXN);
    auto check = [&]() {
        std::vector <int> tmpa, tmpb;
        tmpa.push_back(a[1]); tmpb.push_back(b[1]);
        if (a.size() >= 3) tmpa.push_back(a.back());
        if (b.size() >= 3) tmpb.push_back(b.back());
        while (tmpa.size() < 3) tmpa.push_back(tmpa.back());
        while (tmpb.size() < 3) tmpb.push_back(tmpb.back());
        if (tmpa[1] != tmpb[1] && tmpa.back() != tmpb.back() && ((tmpa[1] > tmpb[1]) == (tmpa.back() > tmpb.back()))) {
            std::cout << 1;
        }
        else std::cout << 0;
    };
    check();
    while (q--){
        int kx, ky;
        std::cin >> kx >> ky;
        for (int i = 1; i <= kx; i++) {
            std::cin >> pa[i] >> va[i];
            tmpa[i] = a[pa[i]];
            a[pa[i]] = va[i];
        }
        for (int i = 1; i <= ky; i++) {
            std::cin >> pb[i] >> vb[i];
            tmpb[i] = b[pb[i]];
            b[pb[i]] = vb[i];
        }
        check();
        for (int i = kx; i; i--) {
            a[pa[i]] = tmpa[i];
        }
        for (int i = ky; i; i--) {
            b[pb[i]] = tmpb[i];
        }        
    }
    return;
}

int main() {
    freopen("expand.in", "r", stdin);
    freopen("expand.out", "w", stdout);

    std::ios::sync_with_stdio(0);
    std::cin.tie(0);
    std::cout.tie(0);

    int t = 1;
    int c;
    std::cin >> c;
    while (t--) {
        solve(c);
    }

    return 0;
}
