#include<bits/stdc++.h>
#define LL long long
#define mes(s, x) memset(s, x, sizeof s)
#define Maxn 100005
#define lc i << 1
#define rc i << 1 | 1
#define bmid int mid = l[i] + r[i] >> 1
using namespace std;
LL read(){
    char c = getchar();
    while(!(c == '-' || ('0' <= c && c <= '9'))) c = getchar();
    int f = 1;
    if(c == '-'){
        f = -1;
        c = getchar();
    }
    LL tot = 0;
    while('0' <= c && c <= '9'){
        tot = 10 * tot + c - '0';
        c = getchar();
    }
    return f * tot;
}
struct task{
    int l, r, v;
    bool operator<(const task i)const{
        return r < i.r;
    }
} q[Maxn];
int re[2 * Maxn], len;
LL dp[2 * Maxn];
struct segtree{
    int l[8 * Maxn], r[8 * Maxn];
    LL x[8 * Maxn], lz[8 * Maxn];
    void build(int i, int L, int R){
        l[i] = L, r[i] = R, x[i] = lz[i] = 0;
        if(l[i] == r[i]) return;
        bmid;
        build(lc, L, mid);
        build(rc, mid + 1, R);
    }
    void push_up(int i){
        x[i] = max(x[lc], x[rc]);
    }
    void push_down(int i){
        if(lz[i]){
            x[lc] += lz[i];
            x[rc] += lz[i];
            lz[lc] += lz[i];
            lz[rc] += lz[i];
            lz[i] = 0;
        }
    }
    void upd(int i, int p, LL k){
        if(l[i] == r[i]){
            x[i] = k;
            return;
        }
        bmid;
        push_down(i);
        if(p <= mid) upd(lc, p, k);
        else upd(rc, p, k);
        push_up(i);
    }
    void add(int i, int L, int R, int k){
        if(R < l[i] || r[i] < L) return;
        if(L <= l[i] && r[i] <= R){
            x[i] += k;
            lz[i] += k;
            return;
        }
        push_down(i);
        add(lc, L, R, k);
        add(rc, L, R, k);
        push_up(i);
    }
    LL ask(int i, int L, int R){
        if(R < l[i] || r[i] < L) return -1e18;
        if(L <= l[i] && r[i] <= R) return x[i];
        push_down(i);
        return max(ask(lc, L, R), ask(rc, L, R));
    }
} t;
int main(){
    freopen("run.in", "r", stdin);
    freopen("run.out", "w", stdout);
    read();
    int T = read(), n, m, k, d, x, y, z;
    while(T--){
        n = read(), m = read(), k = read(), d = read();
        for(int i = 1; i <= m; i++){
            y = read(), x = read(), z = read();
            x = y - x + 1;
            q[i] = {x - 1, y + 1, z};
            re[i] = x - 1, re[m + i] = y + 1;
        }
        sort(q + 1, q + m + 1);
        re[2 * m + 1] = 1000000001;
        sort(re, re + 2 * m + 2);
        len = unique(re, re + 2 * m + 2) - re - 1;
        for(int i = 1; i <= m; i++){
            q[i].l = lower_bound(re, re + len + 1, q[i].l) - re;
            q[i].r = lower_bound(re, re + len + 1, q[i].r) - re;
        }
        t.build(1, 0, len);
        x = 0, y = 0;
        for(int i = 1; i <= len; i++){
            t.upd(1, i - 1, dp[i - 1] + 1ll * (re[i - 1] + 1) * d);
            while(x < m && q[x + 1].r <= i){
                x++;
                t.add(1, 0, q[x].l, q[x].v);
            }
            while(re[i] - re[y] - 1 > k) y++;
            dp[i] = max(dp[i - 1], t.ask(1, y, i - 1) - 1ll * re[i] * d);
            // printf("%d:%lld\n", i, dp[i]);
        }
        printf("%lld\n", dp[len]);
    }
    return 0;
}
