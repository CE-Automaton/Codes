#include<bits/stdc++.h>
#define LL long long
#define mes(s, x) memset(s, x, sizeof s)
#define Maxn 100005
using namespace std;
LL read(){
    char c = getchar();
    while(!(c == '-' || ('0' <= c && c <= '9'))) c = getchar();
    int f = 1;
    if(c == '-'){
        f = -1;
        c = getchar();
    }
    LL tot = 0;
    while('0' <= c && c <= '9'){
        tot = 10 * tot + c - '0';
        c = getchar();
    }
    return f * tot;
}
int base[256], a[Maxn], cnt, f[4 * Maxn], siz[4 * Maxn];
int newa(int i){
    cnt += 2;
    f[cnt - 1] = cnt - 1;
    f[cnt] = cnt;
    return a[i] = cnt - 1;
}
int find(int i){
    if(i == f[i]) return i;
    return f[i] = find(f[i]);
}
void merge(int i, int j){
    i = find(i), j = find(j);
    if(i == j) return;
    f[i] = j;
    siz[j] += siz[i];
}
int main(){
    freopen("tribool.in", "r", stdin);
    freopen("tribool.out", "w", stdout);
    read();
    int T = read(), n, m, p, x, y, ans;
    char tp;
    while(T--){
        int n = read(), m = read();
        mes(siz, 0);
        for(int i = 0; i < 2 * n + 4; i++) f[i] = i;
        base['T'] = 2 * n, base['F'] = 2 * n + 1, base['U'] = 2 * n + 2;
        merge(2 * n + 2, 2 * n + 3);
        cnt = 2 * n + 3;
        for(int i = 0; i < n; i++){
            a[i] = 2 * i;
            siz[2 * i] = 1;
        }
        for(int i = 1; i <= m; i++){
            scanf("\n%c", &tp);
            if(tp == '+' || tp == '-'){
                x = read() - 1, y = read() - 1;
                y = a[y];
                x = newa(x);
                if(tp == '+'){
                    merge(x, y);
                    merge(x ^ 1, y ^ 1);
                }else{
                    merge(x, y ^ 1);
                    merge(x ^ 1, y);
                }
            }else{
                x = newa(read() - 1), y = base[tp];
                merge(x, y);
                merge(x ^ 1, y ^ 1);
            }
        }
        for(int i = 0; i < n; i++) merge(2 * i, a[i]), merge(2 * i + 1, a[i] ^ 1);
        ans = 0;
        for(int i = 0; i <= cnt; i++) if(i == f[i] && i == find(i ^ 1)) ans += siz[i];
        printf("%d\n", ans);
    }
    return 0;
}
