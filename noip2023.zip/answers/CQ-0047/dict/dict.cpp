#include<bits/stdc++.h>
#define LL long long
#define mes(s, x) memset(s, x, sizeof s)
#define Maxn 3005
using namespace std;
LL read(){
    char c = getchar();
    while(!(c == '-' || ('0' <= c && c <= '9'))) c = getchar();
    int f = 1;
    if(c == '-'){
        f = -1;
        c = getchar();
    }
    LL tot = 0;
    while('0' <= c && c <= '9'){
        tot = 10 * tot + c - '0';
        c = getchar();
    }
    return f * tot;
}
int n, m;
char s[Maxn][Maxn], t[Maxn][Maxn];
bool ans[Maxn];
bool cmp(char i, char j){
    return i > j;
}
bool cmpstr(char *s, char *t){
    for(int i = 0; i < m; i++){
        if(s[i] < t[i]) return 1;
        if(s[i] > t[i]) return 0;
    }
    return 0;
}
int main(){
    freopen("dict.in", "r", stdin);
    freopen("dict.out", "w", stdout);
    n = read(), m = read();
    for(int i = 1; i <= n; i++){
        scanf("%s", s[i]);
        memcpy(t[i], s[i], m * sizeof(char));
        sort(s[i], s[i] + m);
        sort(t[i], t[i] + m, cmp);
    }
    int p = 1;
    for(int i = 2; i <= n; i++){
        if(cmpstr(t[i], t[p])) p = i;
    }
    for(int i = 1; i <= n; i++) if(i != p) ans[i] = cmpstr(s[i], t[p]);
    ans[p] = 1;
    for(int i = 1; i <= n; i++) if(i != p && !cmpstr(s[p], t[i])) ans[p] = 0;
    for(int i = 1; i <= n; i++) putchar('0' + ans[i]); 
    return 0;
}