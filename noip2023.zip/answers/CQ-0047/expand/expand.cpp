#include<bits/stdc++.h>
#define LL long long
#define mes(s, x) memset(s, x, sizeof s)
#define Maxn 500005
using namespace std;
LL read(){
    char c = getchar();
    while(!(c == '-' || ('0' <= c && c <= '9'))) c = getchar();
    int f = 1;
    if(c == '-'){
        f = -1;
        c = getchar();
    }
    LL tot = 0;
    while('0' <= c && c <= '9'){
        tot = 10 * tot + c - '0';
        c = getchar();
    }
    return f * tot;
}
int a0[Maxn], b0[Maxn], a[Maxn], b[Maxn];
struct node{
    int x, y;
} c[Maxn], d[Maxn];
bool solve(int n, int m){
    if(a[1] > b[1]){
        for(int i = 1; i <= max(n, m); i++) swap(a[i], b[i]);
        swap(n, m);
    }
    if(a[1] >= b[1] || a[n] >= b[m]) return 0;
    int x, y;
    x = y = a[1];
    for(int i = 1; i <= n; i++){
        x = max(x, a[i]);
        y = min(y, a[i]);
        c[i] = {x, y};
    }
    x = y = b[1];
    for(int i = 1; i <= m; i++){
        x = max(x, b[i]);
        y = min(y, b[i]);
        d[i] = {x, y};
    }
    if(c[n].x >= d[m].x || c[n].y >= d[m].y) return 0;
    x = 0;
    for(int i = 1; i <= n; i++){
        while(x < m && c[i].x >= d[x + 1].x) x++;
        if(x && c[i].y >= d[x].y) return 0;
    }
    for(int i = 1; 2 * i <= n; i++) swap(a[i], a[n + 1 - i]);
    for(int i = 1; 2 * i <= m; i++) swap(b[i], b[m + 1 - i]);
    x = y = a[1];
    for(int i = 1; i <= n; i++){
        x = max(x, a[i]);
        y = min(y, a[i]);
        c[i] = {x, y};
    }
    x = y = b[1];
    for(int i = 1; i <= m; i++){
        x = max(x, b[i]);
        y = min(y, b[i]);
        d[i] = {x, y};
    }
    x = 0;
    for(int i = 1; i <= n; i++){
        while(x < m && c[i].x >= d[x + 1].x) x++;
        if(x && c[i].y >= d[x].y) return 0;
    }
    return 1;
}
int main(){
    freopen("expand.in", "r", stdin);
    freopen("expand.out", "w", stdout);
    read();
    int n = read(), m = read(), q = read(), k0, k1, x, y;
    for(int i = 1; i <= n; i++) a0[i] = a[i] = read();
    for(int i = 1; i <= m; i++) b0[i] = b[i] = read();
    printf("%d", solve(n, m));
    for(int i = 1; i <= q; i++){
        memcpy(a + 1, a0 + 1, n * sizeof(int));
        memcpy(b + 1, b0 + 1, m * sizeof(int));
        k0 = read(), k1 = read();
        while(k0--){
            x = read(), y = read();
            a[x] = y;
        }
        while(k1--){
            x = read(), y = read();
            b[x] = y;
        }
        printf("%d", solve(n, m));
    }
    return 0;
}