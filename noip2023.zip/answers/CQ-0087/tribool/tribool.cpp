#include<bits/stdc++.h>
#define ll long long
#define mid (l+r>>1)
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define Pi pair<int,int>
#define pb push_back
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57){if(c=='-')w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-'0',c=getchar();return s*w;}
const int N=1e5+5,M=1e6+5,inf=(1LL<<31)-1;
using namespace std;
int testid,T,n,m;
struct node{
	int opt,x,y;
}a[N];
inline void init(){
	n=read(),m=read();
	rep(i,1,m){
		char opt;
		cin >>opt;
		if(opt=='+')a[i].opt=1,a[i].x=read(),a[i].y=read();
		else if(opt=='-')a[i].opt=-1,a[i].x=read(),a[i].y=read();
		else {
			a[i].opt=0;
			a[i].x=read();
			if(opt=='T')a[i].y=1;
			if(opt=='F')a[i].y=-1;
			if(opt=='U')a[i].y=0;
		}
	}
}
int val[15],ans,wei[15];
inline void baoli(int pos){
	if(pos==n+1){
		int s=0;
		rep(i,1,n)wei[i]=val[i],s+=(val[i]==0);
		rep(i,1,m)if(a[i].opt==0)wei[a[i].x]=a[i].y;
		else wei[a[i].x]=wei[a[i].y]*a[i].opt;
		rep(i,1,n)if(wei[i]!=val[i])return;
		ans=min(ans,s);
		return;
	}
	rep(i,-1,1)val[pos]=i,baoli(pos+1);
}
inline void subtask1(){
	ans=inf;
	baoli(1);
	cout <<ans<<'\n';
}
int val2[N];
inline void subtask2(){
	ans=0;
	rep(i,1,n)val2[i]=-2;
	rep(i,1,m)val2[a[i].x]=a[i].y;
	rep(i,1,n)ans+=val2[i]==0;
	cout <<ans<<'\n';
}
inline void solve(){
	if(testid<=2)subtask1();
	else subtask2();
}
int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	testid=read(),T=read();
	while(T--){
		init();
		solve();
	}
	return 0;
}
/*40 min��40pts��ֻ���������*/ 
