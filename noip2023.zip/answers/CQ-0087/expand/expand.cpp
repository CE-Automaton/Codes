#include<bits/stdc++.h>
#define ll long long
#define mid (l+r>>1)
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define Pi pair<int,int>
#define pb push_back
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57){if(c=='-')w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-'0',c=getchar();return s*w;}
const int N=5e5+5,M=1e6+5,inf=(1LL<<31)-1;
using namespace std;
int testid,n,m,q,a[N],b[N],c[N],d[N];
inline void cop(){
	rep(i,1,n)c[i]=a[i];
	rep(i,1,m)d[i]=b[i];
}
bool dp[2005][2005];//dp_i,j ��ʾ����ǰƥ������ a_i,b_j �Ƿ���У�����ö�ٱ�ת�Ƶ��� 
inline bool getans(){
	if(n==1&&m==1)return c[1]!=d[1];
	if(c[1]==d[1]||c[n]==d[m])return 0;
	int mxc=-1,mxd=-1;
	rep(i,1,n)mxc=max(mxc,c[i]);
	rep(i,1,m)mxd=max(mxd,d[i]);
	if(mxc==mxd)return 0;
	if(mxc<mxd){
		if(c[1]>d[1]||c[n]>d[m])return 0;
		rep(i,1,n)rep(j,1,m)dp[i][j]=0; 
		dp[1][1]=1;
		//c С�� d 
		rep(i,1,n)rep(j,1,m)if(dp[i][j]){
			if(i==n&&j==m)return 1;
			//3 ��ת��
			//first:c�����ƶ�һλ
			if(i<n){
				if(c[i+1]<d[j])dp[i+1][j]=1;
			}
			if(j<m){
				if(c[i]<d[j+1])dp[i][j+1]=1;
			}
			if(i<n&&j<m){
				if(c[i+1]<d[j+1])dp[i+1][j+1]=1; 
			}
		}
		return 0;
	}
	if(c[1]<d[1]||c[n]<d[m])return 0;
	rep(i,1,n)rep(j,1,m)dp[i][j]=0; 
	dp[1][1]=1;
	rep(i,1,n)rep(j,1,m)if(dp[i][j]){
		if(i==n&&j==m)return 1;
		if(i<n){
			if(c[i+1]>d[j])dp[i+1][j]=1;
		}
		if(j<m){
			if(c[i]>d[j+1])dp[i][j+1]=1;
		}
		if(i<n&&j<m){
			if(c[i+1]>d[j+1])dp[i+1][j+1]=1; 
		}
	}
	return 0;
}//try to dp
inline void solve(){
	cop();
	int kx=read(),ky=read();
	rep(i,1,kx){
		int x=read(),y=read();
		c[x]=y;
	}
	rep(i,1,ky){
		int x=read(),y=read();
		d[x]=y;
	}
	cout <<getans();
}
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	testid=read(),n=read(),m=read(),q=read();
	rep(i,1,n)a[i]=read();
	rep(i,1,m)b[i]=read();
	cop();
	cout <<getans();
	while(q--)solve();
	return 0;
}
/*
30min,35pts��ֻ��n^2 ��dp
 
*/ 
