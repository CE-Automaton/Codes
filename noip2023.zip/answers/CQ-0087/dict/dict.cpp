#include<bits/stdc++.h>
#define ll long long
#define mid (l+r>>1)
#define rep(x,y,z) for(int x=(y);x<=(z);x++)
#define per(x,y,z) for(int x=(y);x>=(z);x--)
#define e(x) for(int i=h[x],y=to[i];i;i=nxt[i],y=to[i])
#define Pi pair<int,int>
#define pb push_back
#define ui unsigned ll
inline int read(){int s=0,w=1;char c=getchar();while(c<48||c>57){if(c=='-')w=-1;c=getchar();}while(c>=48&&c<=57)s=(s<<1)+(s<<3)+c-'0',c=getchar();return s*w;}
const int N=3e3+5,M=1e6+5,inf=(1LL<<31)-1;
using namespace std;
int n,m;
string s[N];
struct node{
	int id,ct[26];
	bool ty;
}a[N<<1];
inline bool cmp(node a,node b){
	if(a.ty==1&&b.ty==1){
		rep(i,0,25)if(a.ct[i]!=b.ct[i])return a.ct[i]<b.ct[i];
	}else if(a.ty==0&&b.ty==0){
		per(i,25,0)if(a.ct[i]!=b.ct[i])return a.ct[i]>b.ct[i];
	}
	else if(a.ty==1&&b.ty==0){
		int ml=25,mr=0;
		rep(i,0,25){
			if(a.ct[i])ml=min(ml,i);
			if(b.ct[i])mr=max(mr,i);
		}
		if(ml>mr)return 1;
		if(ml<mr)return 0;
		if(a.ct[ml]!=b.ct[mr])return 1;
		if(a.ct[ml]!=m)return 1;
	}else {
		int ml=0,mr=25;
		rep(i,0,25){
			if(a.ct[i])ml=max(ml,i);
			if(b.ct[i])mr=min(mr,i);
		}
		if(ml>mr)return 1;
		if(ml<mr)return 0;
		if(a.ct[ml]!=b.ct[mr])return 0;
		if(a.ct[ml]!=m)return 0;
	}
	return a.ty<b.ty;
}
bool ans[N];
int ct[26];
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	n=read(),m=read();
	rep(i,1,n)cin >>s[i];
	rep(i,1,n){
		rep(j,0,m-1)a[i<<1].ct[s[i][j]-'a']++;
		rep(j,0,25)a[(i<<1)-1].ct[j]=a[i<<1].ct[j];
		a[(i<<1)-1].id=a[i<<1].id=i;
		a[i<<1].ty=1,a[(i<<1)-1].ty=0;
		//cout <<a[(i<<1)-1].s<<" "<<a[i<<1].s<<endl;
	}
	sort(a+1,a+n*2+1,cmp);
	int ct=0;
	rep(i,1,n<<1){
		if(a[i].ty==0)ct++;
		else {
			if(ct==n)ans[a[i].id]=1;
		}
	}
	rep(i,1,n)cout <<ans[i];
	return 0;
}
/*
4 7
abandon
bananaa
baannaa
notnotn
*/
/*
��Сʱ������ǩ�˿��� 

���� T4 �����ˣ�����string �ĳ��������ǰ��Ż����ϰ� 

12:44 ������д��룬��ʼ�����ļ��� 
*/
