#include<bits/stdc++.h>
#define endl '\n'
#define ull unsigned long long
using namespace std;
const int mod=1e9+9,P1=137,P2=10007;
int n,m;
int cnt[30],pw1[3005];
ull pw2[3005];
string s[2][3005];
int hs1[2][3005][3005];
ull hs2[2][3005][3005];
inline bool check(int x){
	for(int i=1;i<=n;i++){
		if(i==x) continue;
		int l=1,r=m,cur=0;
		while(l<=r){
			int mid=(l+r)>>1;
			if(hs1[0][x][mid]==hs1[1][i][mid]&&hs2[0][x][mid]==hs2[1][i][mid]) l=mid+1,cur=mid;
			else r=mid-1;
		}
		if(cur==m) return 0;
		if(s[0][x][cur]>=s[1][i][cur]) return 0;
	}
	return 1;
}
signed main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	cin>>n>>m;
	pw1[0]=pw2[0]=1;
	for(int i=1;i<=m;i++){
		pw1[i]=1ll*pw1[i-1]*P1%mod;
		pw2[i]=pw2[i-1]*P2;
	}
	for(int i=1;i<=n;i++){
		string S; cin>>S;
		for(char c:S) cnt[c-'a']++;
		for(int j=0;j<26;j++){
			int k=cnt[j];
			while(k--) s[0][i]+=char(j+'a');
		}
		for(int j=25;j>=0;j--){
			int k=cnt[j];
			while(k--) s[1][i]+=char(j+'a');
		}
		for(int j=1;j<=m;j++){
			hs1[0][i][j]=(1ll*hs1[0][i][j-1]*P1+s[0][i][j-1])%mod;
			hs2[0][i][j]=hs2[0][i][j-1]*P2+s[0][i][j-1];
			
			hs1[1][i][j]=(1ll*hs1[1][i][j-1]*P1+s[1][i][j-1])%mod;
			hs2[1][i][j]=hs2[1][i][j-1]*P2+s[1][i][j-1];
		}
		for(int j=0;j<26;j++) cnt[j]=0;
	}
	for(int i=1;i<=n;i++){
		if(check(i)) cout<<'1';
		else cout<<'0';
	}
	return 0;
}
