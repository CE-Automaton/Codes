#include<bits/stdc++.h>
#define endl '\n'
#define int long long
using namespace std;
const int inf=1e16;
int TP,T,rt;
int n,m,k,d;
vector<pair<int,int>> h[100005];
mt19937 rnd(time(0));
	int tot;
	struct node{int lc,rc,sz,rd,tag,d,mx;}t[500005];
	#define lc(p) t[p].lc
	#define rc(p) t[p].rc
	#define sz(p) t[p].sz
	#define rd(p) t[p].rd
	#define tag(p) t[p].tag
	#define mx(p) t[p].mx
	#define d(p) t[p].d
	#define pii pair<int,int>
	void clear(){
		for(int i=0;i<=tot;i++) t[i].lc=t[i].rc=t[i].sz=t[i].rd=t[i].tag=t[i].mx=t[i].d=0;
		tot=0,mx(0)=d(0)=-inf;
	}
	inline void update(int p){
		mx(p)=d(p);
		if(lc(p)) mx(p)=max(mx(p),mx(lc(p)));
		if(rc(p)) mx(p)=max(mx(p),mx(rc(p)));
		sz(p)=sz(lc(p))+sz(rc(p))+1;
	}
	int build(int l,int r){
		if(l>r) return 0;
		int mid=(l+r)>>1;
		int p=++tot; t[p].d=mid?-inf:0;
		lc(p)=build(l,mid-1),rc(p)=build(mid+1,r);
		update(p); return p;
	}
	inline void ch(int p,int k){
		mx(p)+=k,d(p)+=k,tag(p)+=k;
	}
	inline void spread(int p){
		if(!tag(p)) return;
		if(lc(p)) ch(lc(p),tag(p));
		if(rc(p)) ch(rc(p),tag(p));
		tag(p)=0;
	}
	pii split(int p,int k){
		if(!k) return {0,p};
		spread(p);
		if(k<=sz(lc(p))){
			auto cur=split(lc(p),k);
			lc(p)=cur.second,update(p);
			return {cur.first,p};
		}else{
			auto cur=split(rc(p),k-sz(lc(p))-1);
			rc(p)=cur.first,update(p);
			return {p,cur.second};
		}
	}
	int merge(int a,int b){
		if(!a||!b) return a+b;
		spread(a),spread(b);
		if(rd(a)<rd(b)){
			rc(a)=merge(rc(a),b);
			update(a); return a;
		}else{
			lc(b)=merge(a,lc(b));
			update(b); return b;
		}
	}
inline void solve(){
	cin>>n>>m>>k>>d,clear();
	for(int i=1;i<=n;i++) h[i].clear();
	for(int i=1;i<=m;i++){
		int x,y,v; cin>>x>>y>>v;
		if(y<=k) h[x].push_back({y,v});
	}
	rt=build(0,k);
	for(int i=1;i<=n;i++){
		int mx=t[rt].mx;
		ch(rt,-d);
		auto cur=split(rt,k);
		t[cur.second].d=t[cur.second].mx=mx;
		rt=merge(cur.second,cur.first);
		for(auto tmp:h[i]){
			auto cur=split(rt,tmp.first);
			ch(cur.second,tmp.second);
			rt=merge(cur.first,cur.second);
		}
	}
	cout<<t[rt].mx<<endl;
}
signed main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	cin>>TP>>T;
	while(T--) solve();
	return 0;
}
