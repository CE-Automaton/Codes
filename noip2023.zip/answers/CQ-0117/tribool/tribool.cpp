#include<bits/stdc++.h>
#define endl '\n'
using namespace std;
int TP,T;
int n,m;
int a[100005],fa[200005],vst[200005];
int find(int x){return fa[x]==x?x:fa[x]=find(fa[x]);}
inline void solve(){
	cin>>n>>m;
	for(int i=1;i<=n;i++) a[i]=0;
	while(m--){
		char op; cin>>op;
		int x,y; cin>>x;
		if(op=='T') a[x]=n*2+1;
		if(op=='F') a[x]=n*2+2;
		if(op=='U') a[x]=n*2+3;
		if(op=='+'){
			cin>>y;
			if(!a[y]) a[x]=y;
			else a[x]=a[y];
		}
		if(op=='-'){
			cin>>y;
			if(!a[y]) a[x]=y+n;
			else{
				if(a[y]<=n*2){
					if(a[y]<=n) a[x]=a[y]+n;
					else a[x]=a[y]-n;
				}else{
					if(a[y]==n*2+1) a[x]=n*2+2;
					else if(a[y]==n*2+2) a[x]=n*2+1;
					else if(a[y]==n*2+3) a[x]=n*2+3;
				}
			}
		}
	}
	for(int i=1;i<=n*2+3;i++) fa[i]=i,vst[i]=0;
	for(int i=1;i<=n;i++){
		if(!a[i]) continue;
		if(a[i]<=n*2){
			if(a[i]<=n) fa[find(i)]=find(a[i]),fa[find(i+n)]=find(a[i]+n);
			else fa[find(i)]=find(a[i]),fa[find(i+n)]=find(a[i]-n);
		}else{
			if(a[i]==n*2+1) fa[find(i)]=find(n*2+1);
			if(a[i]==n*2+2) fa[find(i)]=find(n*2+2);
			if(a[i]==n*2+3) fa[find(i)]=fa[find(i+n)]=find(n*2+3);
		}
	}
	for(int i=1;i<=n;i++){
		if(find(i)==find(n+i)){
			fa[find(i)]=find(n*2+3);
		}
	}
	int ans=0;
	for(int i=1;i<=n;i++){
		if(find(i)==find(n*2+3)||find(n+i)==find(n*2+3)) ans++;
	}
	cout<<ans<<endl;
}
signed main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	cin>>TP>>T;
	while(T--) solve();
	return 0;
}
