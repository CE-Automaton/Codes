#include<bits/stdc++.h>
#define endl '\n'
using namespace std;
int TP,n,m,q;
int A[500005],B[500005],a[500005],b[500005];
int f[2005][2005];
inline bool check(){
	if(a[1]==b[1]||a[n]==b[n]) return 0;
	for(int i=0;i<=n;i++) for(int j=0;j<=m;j++) f[i][j]=0;
	f[0][0]=1;
	if(a[1]>b[1]){
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				if(a[i]>b[j]) f[i][j]|=f[i-1][j-1]|f[i-1][j]|f[i][j-1];
			}
		}
	}else{
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				if(a[i]<b[j]) f[i][j]|=f[i-1][j-1]|f[i-1][j]|f[i][j-1];
			}
		}
	}
	return f[n][m];
}
signed main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	cin>>TP>>n>>m>>q;
	for(int i=1;i<=n;i++) cin>>A[i],a[i]=A[i];
	for(int i=1;i<=m;i++) cin>>B[i],b[i]=B[i];
	cout<<check();
	while(q--){
		int kx,ky; cin>>kx>>ky;
		for(int i=1;i<=n;i++) a[i]=A[i];
		for(int i=1;i<=m;i++) b[i]=B[i];
		while(kx--){
			int x,y; cin>>x>>y;
			a[x]=y;
		}
		while(ky--){
			int x,y; cin>>x>>y;
			b[x]=y;
		}
		cout<<check();
	}
	return 0;
}
