#include <cstdio>
#include <algorithm>
#include <vector>

namespace nOCE {
	char str[6005][3005];
	int id[6005], m;
	struct cmp {
		inline bool operator () (const int a, const int b) const {
			for (int i = 1; i <= m; ++ i)
				if (str[a][i] < str[b][i]) return true;
				else if (str[a][i] > str[b][i]) return false;
			return a > b;
		}
	};
	
	void Ma_in() {
		int n; scanf("%d%d", &n, &m);
		for (int i = 1; i <= n; ++ i) {
			scanf("%s", str[i] + 1);
			std::sort(str[i] + 1, str[i] + m + 1);
		}
		for (int i = n + 1; i <= n + n; ++ i) {
			for (int j = 1; j <= m; ++ j) str[i][j] = str[i - n][j];
			std::sort(str[i] + 1, str[i] + m + 1);
			std::reverse(str[i] + 1, str[i] + m + 1);
		}
		for (int i = 1; i <= n + n; ++ i) id[i] = i;
		std::sort(id + 1, id + n + n + 1, cmp());
		for (int i = 1; i <= n; ++ i) {
			int p = 0;
			for (int j = 1; j <= n + n; ++ j) if (id[j] == i) {p = j; break;}
			bool flag = true;
			for (int j = 1; j < p; ++ j) if (id[j] > n && id[j] != i + n) {flag = false; break;}
			putchar(flag ? '1' : '0');
		}
		puts("");
	}
}

int main() {
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);
	nOCE::Ma_in();
}
