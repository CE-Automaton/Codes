#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#define int long long

using std::max;

namespace nOCE {
	int sum[1005][1005], dp[300005], n, m, k, d;
	int b[300005];
	bool mark[300005];
	struct seg {int l, r, v;} a[300005];
	struct node {
		int l, r, v, tag;
	} tree[1200005];
	std::vector<int> vec[300005];
	void build(int p, int l, int r) {
		tree[p].l = l, tree[p].r = r, tree[p].v = -4e18, tree[p].tag = 0;
		if (tree[p].l != tree[p].r) {
			build(p << 1, l, l + r >> 1);
			build(p << 1 | 1, (l + r >> 1) + 1, r);
		}
	}
	inline void pushdown(int p) {
		tree[p << 1].v += tree[p].tag, tree[p << 1].tag += tree[p].tag;
		tree[p << 1 | 1].v += tree[p].tag, tree[p << 1 | 1].tag += tree[p].tag;
		tree[p].tag = 0;
	}
	void update(int p, int l, int r, int d) {
		if (l <= tree[p].l && tree[p].r <= r) {tree[p].v += d, tree[p].tag += d; return;}
		int mid = tree[p].l + tree[p].r >> 1; if (tree[p].tag) pushdown(p);
		if (l <= mid) update(p << 1, l, r, d);
		if (mid < r) update(p << 1 | 1, l, r, d);
		tree[p].v = max(tree[p << 1].v, tree[p << 1 | 1].v);
	}
	void set(int p, int x, int d) {
		if (tree[p].l == tree[p].r) {tree[p].v = d; return;}
		int mid = tree[p].l + tree[p].r >> 1; if (tree[p].tag) pushdown(p);
		x <= mid ? set(p << 1, x, d) : set(p << 1 | 1, x, d);
		tree[p].v = max(tree[p << 1].v, tree[p << 1 | 1].v);
	}
	int query(int p, int l, int r) {
		if (l <= tree[p].l && tree[p].r <= r) return tree[p].v;
		int mid = tree[p].l + tree[p].r >> 1, ans = -4e18; pushdown(p);
		if (l <= mid) ans = query(p << 1, l, r);
		if (mid < r) ans = max(ans, query(p << 1 | 1, l, r));
		return ans;
	}
	void solve1() {//n <= 1000 
		memset(sum, 0, sizeof sum);
		memset(dp, 0, sizeof dp);
		for (int i = 1; i <= m; ++ i) sum[a[i].l][a[i].r] += a[i].v;
		for (int i = n; i; -- i)
		for (int j = i; j <= n; ++ j)
			if (i != j) sum[i][j] += sum[i + 1][j] + sum[i][j - 1] - sum[i + 1][j - 1];
		for (int i = 1; i <= n; ++ i) {
			dp[i] = dp[i - 1];
			for (int j = max(1ll, i - k + 1); j <= i; ++ j)
				dp[i] = max(dp[i], (j >= 2 ? dp[j - 2] : 0) + sum[j][i] - (i - j + 1) * d);
		}
		printf("%lld\n", dp[n]);
		return;
	}
	void solve2() {
		for (int i = 0; i <= 300000; ++ i) vec[i].clear();
		int len = 0;
		for (int i = 1; i <= m; ++ i) b[++ len] = a[i].l - 1, b[++ len] = a[i].l, b[++ len] = a[i].r;
		std::sort(b + 1, b + len + 1);
		len = std::unique(b + 1, b + len + 1) - b - 1;
		memset(mark, 0, sizeof mark);
		for (int i = 1; i <= m; ++ i) {
			a[i].l = std::lower_bound(b + 1, b + len + 1, a[i].l) - b;
			a[i].r = std::lower_bound(b + 1, b + len + 1, a[i].r) - b;
			vec[a[i].r].emplace_back(i);
			mark[a[i].l] = true;
		}
		build(1, 1, len);
		memset(dp, 0, sizeof dp);
		int mx = 0;
		for (int i = 1; i <= len; ++ i) {
			set(1, i, (i >= 2 ? dp[i - 2] : 0ll) + b[i] * d);
			if (vec[i].size()) {
				for (int j : vec[i]) update(1, 1, a[j].l, a[j].v);
				int j = std::lower_bound(b + 1, b + len + 1, b[i] - k + 1) - b;
				dp[i] = max(mx, query(1, j, i) - (b[i] + 1) * d);
				mx = dp[i];
			} else dp[i] = mx;
		}
		printf("%lld\n", mx);
	}
	void MAIN(int casid) {
		scanf("%lld%lld%lld%lld", &n, &m, &k, &d);
		for (int i = 1; i <= m; ++ i) {
			int x, y;
			scanf("%lld%lld%lld", &x, &y, &a[i].v);
			a[i].l = x - y + 1, a[i].r = x;
		}
		solve2();
	}
}

signed main() {
	freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);
	int casid, _; scanf("%lld%lld", &casid, &_);
	while (_ --) nOCE::MAIN(casid);
	return 0;
}
