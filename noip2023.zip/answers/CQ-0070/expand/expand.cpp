#include <cstdio>
#include <algorithm>
#include <vector>
#include <cstring>
#define gc (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 100000, stdin), p1 == p2) ? EOF : *p1 ++)

char buf[100000], *p1, *p2;
inline int read() {
	char ch; int x = 0, f = 1; while ((ch = gc) < 48) if (ch == '-') f = -1;
	do x = x * 10 + ch - 48; while ((ch = gc) >= 48); return x * f;
}
using std::min;
namespace nOCE {
	int a[500005], b[500005], A[500005], B[500005], n, m, q;
	char str[500005];
	struct ST {
		int Log[500005], st[19][500005];
		void init() {
			for (int i = 2; i <= m; ++ i) Log[i] = Log[i >> 1] + 1;
			for (int i = 1; i <= m; ++ i) st[0][i] = b[i];
			for (int i = 1; i <= 18; ++ i)
			for (int j = 1; j + (1 << i) - 1 <= m; ++ j)
				st[i][j] = min(st[i - 1][j], st[i - 1][j + (1 << i - 1)]);
		}
		inline int query(int l, int r) {
			if (l > r) return 2e9;
			int k = Log[r - l + 1];
			return min(st[k][l], st[k][r - (1 << k) + 1]);
		}
	} rmq[2];
	int findr(int x, int y) {
		if (b[x] >= y) return -1;
		int l = x, r = m;
		while (l < r) {
			int mid = l + r + 1 >> 1;
			if (-rmq[1].query(x, mid) < y) l = mid;
			else r = mid - 1;
		}
		return l;
	}
	int findl(int x, int y) {
		if (!x || rmq[0].query(1, x) >= y) return -1;
		int l = 1, r = x;
		while (l < r) {
			int mid = l + r + 1 >> 1;
			if (rmq[0].query(mid, x) < y) l = mid;
			else r = mid - 1;
		}
		return l;
	}
	bool check() {
		int j = 0;
		for (int i = 1; i <= n; ++ i) {
			int nxt = (j < m ? findr(j + 1, a[i]) : -1);
			if (nxt != -1) j = nxt;
			else {
				j = (j && b[j] < a[i] ? j : findl(j, a[i]));
				if (j == -1) return false;
			}
		}
		return j == m;
	}
	bool solve() {
		if (a[1] < b[1]) {
			for (int i = 1; i <= n; ++ i) a[i] = -a[i];
			for (int i = 1; i <= m; ++ i) b[i] = -b[i];
		}
		rmq[0].init();
		for (int i = 1; i <= m; ++ i) b[i] = -b[i];
		rmq[1].init();
		for (int i = 1; i <= m; ++ i) b[i] = -b[i];
		return check();
	}
	void MAIN(int casid) {
		n = read(), m = read(), q = read();
		for (int i = 1; i <= n; ++ i) a[i] = read();
		for (int i = 1; i <= m; ++ i) b[i] = read();
		memcpy(A, a, sizeof a);
		memcpy(B, b, sizeof b);
		str[0] = '0' + solve();
		for (int i = 1; i <= q; ++ i) {
			memcpy(a, A, sizeof A);
			memcpy(b, B, sizeof B);
			int kx = read(), ky = read();
			while (kx --) {int p = read(), v = read(); a[p] = v;}
			while (ky --) {int p = read(), v = read(); b[p] = v;}
			str[i] = '0' + solve();
		}
		str[q + 1] = 0; puts(str);
	}
}

int main() {
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);
	int casid; scanf("%d", &casid);
	nOCE::MAIN(casid);
	return 0; 
}
