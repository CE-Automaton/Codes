#include <cstdio>
#include <cstring>
#include <vector>

namespace nOCE {
	
struct node {int tp, rev, x;} s[100005];//tp=0 constant tp=1 variant
node getrev(node a) {
	if (a.tp == 0) {
		if (a.x != 2) a.x = 1 - a.x;
		return a;
	} else {a.rev ^= 1; return a;}
}
char str[105];
std::vector<int> G[100005];
int id[100005], fa[100005], fa2[100005], sze[100005], from[100005], to[100005], val[100005];
bool mark[100005], vis[100005];
int find(int x) {return fa[x] == x ? x : fa[x] = find(fa[x]);}
int find2(int x) {return fa2[x] == x ? x : fa2[x] = find2(fa2[x]);}
void dfs(int u) {
	vis[u] = true;
	for (int v : G[u]) if (!vis[v]) val[v] = val[u] ^ 1, dfs(v);
}

void MAIN() {
	memset(id, 0, sizeof id);
	memset(fa, 0, sizeof fa);
	memset(fa2, 0, sizeof fa2);
	memset(sze, 0, sizeof sze);
	memset(mark, 0, sizeof mark);
	memset(vis, 0, sizeof vis);
	for (int i = 0; i <= 100000; ++ i) G[i].clear();
	int n, m; scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; ++ i) s[i] = node{1, 0, i};
	for (int i = 1; i <= n; ++ i) fa[i] = i;
	for (int i = 1; i <= m; ++ i) {
		int u;
		scanf("%s%d", str, &u);
		if (str[0] == '+' || str[0] == '-') {
			int v; scanf("%d", &v);
			if (str[0] == '+') s[u] = s[v];
			else s[u] = getrev(s[v]);
		} else if (str[0] == 'T') s[u] = node{0, 0, 0};
		else if (str[0] == 'F') s[u] = node{0, 0, 1};
		else s[u] = node{0, 0, 2};
	}
	for (int i = 1; i <= n; ++ i)
		if (s[i].tp == 1 && !s[i].rev) fa[find(i)] = find(s[i].x);
		else if (s[i].tp == 0 && s[i].x == 2) s[i].tp = s[i].rev = 1, s[i].x = i;
	int cnt = 0, tot = 0;
	for (int i = 1; i <= n; ++ i) if (i == find(i)) id[i] = ++ cnt;
	for (int i = 1; i <= cnt; ++ i) fa2[i] = i;
	for (int i = 1; i <= n; ++ i)
		if (s[i].tp == 1 && s[i].rev) {
			int x = id[find(i)], y = id[find(s[i].x)];
			if (find2(x) != find2(y)) {
				G[x].push_back(y), G[y].push_back(x);
				fa2[find2(x)] = find2(y);
			} else from[++ tot] = x, to[tot] = y;
		}
	for (int i = 1; i <= cnt; ++ i) if (i == find2(i)) dfs(i);
	for (int i = 1; i <= n; ++ i) ++ sze[find2(id[find(i)])];
	for (int i = 1; i <= tot; ++ i) if (val[from[i]] == val[to[i]]) mark[find2(from[i])] = true;
	int ans = 0;
	for (int i = 1; i <= cnt; ++ i) if (i == find2(i) && mark[i]) ans += sze[i];
	printf("%d\n", ans);
}

}
int main() {
	freopen("tribool.in", "r" , stdin);
	freopen("tribool.out", "w" , stdout);
	int _; scanf("%*d%d", &_);
	while (_ --) nOCE::MAIN();
	return 0; 
}
