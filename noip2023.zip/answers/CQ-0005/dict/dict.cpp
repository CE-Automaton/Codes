#include<bits/stdc++.h>
#define ll long long
#define fir first
#define sec second
#define pii pair<int,int>
using namespace std;

const int maxn=3005;
const int Simga=26;
const int inf=0x3f3f3f3f;

namespace Solve {
	int mi[maxn];
	int mx[maxn];
	void clear() {
	
	}
	void main(int tid) {
		int n,m;
		cin>>n>>m;
		for(int i=1;i<=n;i++) {
			string s;
			cin>>s;
			mi[i]=*min_element(s.begin(),s.end());
			mx[i]=*max_element(s.begin(),s.end());
		}
		for(int i=1;i<=n;i++) {
			bool ok=true;
			for(int j=1;j<=n;j++) {
				if(j==i) {
					continue;
				}
				if(mx[j]<=mi[i]) {
					ok=false;
				}
			}
			cout<<ok;
		}
		cout<<"\n";
	}
	void init() {
		
	}
}

signed main() {
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	int T=1;
//	cin>>T;
	Solve::init();
	for(int t=1;t<=T;t++) {
		Solve::main(t);
		Solve::clear();
	}
	cerr<<"Time: "<<clock()<<"ms\n";
}
