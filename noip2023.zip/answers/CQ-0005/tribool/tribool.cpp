#include<bits/stdc++.h>
#define ll long long
#define fir first
#define sec second
#define pii pair<int,int>
using namespace std;

const int maxn=200005;
const int inf=0x3f3f3f3f;

namespace Solve {
	int n,m;
	int v[maxn];
	bool vis[maxn];
	vector<int> p;
	vector<pii> graph[maxn];
	int c[maxn];
	bool ok;
	void clear() {
		memset(v,0,sizeof(v));
		memset(vis,0,sizeof(vis));
		memset(c,0,sizeof(c));
		for(int i=1;i<=n;i++) {
			graph[i].clear();
		}
	}
	void add(int x,int y,int z) {
		graph[x].push_back({y,z});
		graph[y].push_back({x,z});
	}
	void dfs(int x) {
		if(vis[x]) {
			return ;
		}
		vis[x]=true;
		p.push_back(x);
		for(pii p:graph[x]) {
			dfs(p.fir);
		}
	}
	void color(int x,int col) {
		if(c[x]) {
			if(c[x]!=col) {
				ok=false;
			}
			return ;
		}
		c[x]=col;
		for(pii p:graph[x]) {
			int to=p.fir;
			if(p.sec) {
				color(to,3-col);
			} else {
				color(to,col);
			}
		}
	}
	bool ck(int x) {
		ok=true;
		color(x,1);
		return ok;
	}
	void main(int tid) {
		cin>>n>>m;
		iota(v+1,v+n+1,1);
		int T=n+1,F=-T;
		for(int i=1;i<=m;i++) {
			char c;
			int x,y;
			cin>>c;
			if(c=='+') {
				cin>>x>>y;
				v[x]=v[y];
			} else if(c=='-') {
				cin>>x>>y;
				v[x]=-v[y];
			} else if(c=='U') {
				cin>>x;
				v[x]=0;
			} else if(c=='T') {
				cin>>x;
				v[x]=T;
			} else {
				cin>>x;
				v[x]=F;
			}
		}
		for(int i=1;i<=n;i++) {
			if(1<=v[i]&&v[i]<=n) {
				add(i,v[i],0);
			} else if(-n<=v[i]&&v[i]<=-1) {
				add(i,-v[i],1);
			}
		}
		int ans=0;
		for(int i=1;i<=n;i++) {
			if(!vis[i]) {
				p.clear();
				dfs(i);
				int res=0;
				bool ok=false;
				for(int x:p) {
					if(!v[x]||v[x]==T||v[x]==F) {
						ok=true;
						res=v[x];
					}
				}
				if(ok) {
					ans+=(!res)*p.size();
				} else {
					ans+=(!ck(i))*p.size();
				}
			}
		}
		cout<<ans<<"\n";
	}
	void init() {
		
	}
}

signed main() {
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	int type,T=1;
	cin>>type>>T;
	Solve::init();
	for(int t=1;t<=T;t++) {
		Solve::main(t);
		Solve::clear();
	}
	cerr<<"Time: "<<clock()<<"ms\n";
}
