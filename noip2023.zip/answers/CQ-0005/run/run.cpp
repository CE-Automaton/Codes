#include<bits/stdc++.h>
#define ll long long
#define int long long
#define fir first
#define sec second
#define pii pair<int,int>
using namespace std;

const int maxn=600005;
const int inf=3e18;

namespace Solve {
	int type;
	int n,m,k,d;
	void clear() {
	
	}
	char buf[(1<<24)+5],*P,*Q;
	#define getchar() ((P==Q&&(Q=(P=buf)+fread(buf,1,1<<24,stdin),P==Q))?EOF:*P++)
	int read() {
		int x=0,f=1;
		char c=getchar();
		while(c<'0'||c>'9') {
			if(c=='-') {
				f=-1;
			}
			c=getchar();
		}
		while('0'<=c&&c<='9') {
			x=x*10+c-'0';
			c=getchar();
		}
		return x*f;
	}
	namespace SOL {
		struct Task {
			int x,y,v;
		} a[maxn];
		struct Treap {
			struct Node {
				int l,r,key,x,y,fir,mx,dt,dv;
			} a[maxn];
			int cnt;
			int rt;
			mt19937 rnd;
			Treap():rnd(73385) {
				a[0].mx=-inf;
			}
			void clear() {
				cnt=rt=0;
				memset(a,0,sizeof(a));
				a[0].mx=-inf;
			}
			int r() {
				return uniform_int_distribution<int>(1,inf)(rnd);
			}
			void pushup(int x) {
				a[x].mx=max({a[a[x].l].mx,a[a[x].r].mx,a[x].fir});
			}
			void spread(int x,int t) {
				a[x].x+=t;
				a[x].y+=t;
				a[x].fir-=t*d;
				a[x].mx-=t*d;
				a[x].dt+=t;
			}
			void spreadv(int x,int t) {
				a[x].fir+=t;
				a[x].mx+=t;
				a[x].dv+=t;
			}
			void pushdown(int x) {
				spread(a[x].l,a[x].dt);
				spread(a[x].r,a[x].dt);
				a[x].dt=0;
				spreadv(a[x].l,a[x].dv);
				spreadv(a[x].r,a[x].dv);
				a[x].dv=0;
			}
			int newNode(int x,int y,int v) {
				a[++cnt]={0,0,r(),x,y,v,v,0,0};
				return cnt;
			}
			void split(int now,int v,int &x,int &y) {
				if(!now) {
					x=y=0;
					return ;
				}
				pushdown(now);
				if(a[now].y<=v) {
					x=now;
					split(a[now].r,v,a[x].r,y);
				} else {
					y=now;
					split(a[now].l,v,x,a[y].l);
				}
				pushup(now);
			}
			int merge(int x,int y) {
				if(!x||!y) {
					return x+y;
				}
				if(a[x].key<a[y].key) {
					pushdown(x);
					a[x].r=merge(a[x].r,y);
					pushup(x);
					return x;
				} else {
					pushdown(y);
					a[y].l=merge(x,a[y].l);
					pushup(y);
					return y;
				}
			}
			Node& fir(int x) {
				while(a[x].l) {
					pushdown(x);
					x=a[x].l;
				}
				return a[x];
			} 
			Node& lst(int x) {
				while(a[x].r) {
					pushdown(x);
					x=a[x].r;
				}
				return a[x];
			} 
			void insert(int x,int y,int v) {
				int X,Y;
				split(rt,x,X,Y);
				rt=merge(merge(X,newNode(x,y,v)),Y);
			}
			void popback(int &r) {
				int X,Y;
				split(r,lst(r).x-1,X,Y);
				r=X;
			}
			void move() {
				int val=a[rt].mx;
				spread(rt,1);
				Node &v=lst(rt);
				if(v.x>k) {
					popback(rt);
				} else {
					v.y--;
				}
				insert(0,0,val);
			}
			void update(int t) {
				int X,Y;
				split(rt,fir(rt).y,X,Y);
				if(a[X].y) {
					int W=newNode(0,0,a[X].fir);
					a[X].x++;
					a[X].fir-=d;
					rt=merge(X,Y);
					X=W,Y=rt;
				}
				spread(Y,t);
				while(Y&&lst(Y).x>k) {
					popback(Y);
				}
				if(Y) {
					Node &v=lst(Y);
					v.y=k;
				}
				int W; 
				if(Y) {
					W=newNode(1,fir(Y).x-1,a[X].fir-d);
				} else {
					W=newNode(1,k,a[X].fir-d);
				}
				rt=merge(merge(X,W),Y);
			}
			void add(int x,int v) {
				int X,Y,Z;
				split(rt,x-1,X,Y);
				split(Y,fir(Y).y,Z,Y);
				if(a[Z].x==x) {
					spreadv(Z,v);
					spreadv(Y,v);
					rt=merge(merge(X,Z),Y);
				} else {
					int t=a[Z].y;
					a[Z].y=x-1;
					int W=newNode(x,t,a[Z].fir-(a[Z].y-a[Z].x+1)*d);
					spreadv(W,v);
					spreadv(Y,v);
					rt=merge(merge(X,Z),merge(W,Y));
				}
			}
			int ask() {
				return a[rt].mx;
			}
			void dfs(int x) {
				if(!x) {
					return ;
				}
				pushdown(x);
				dfs(a[x].l);
				cerr<<a[x].x<<" "<<a[x].y<<" "<<a[x].fir<<"\n";
				dfs(a[x].r);
			}
			void dfs() {
				dfs(rt);
			}
		} s;
		void clear() {
			s.clear();
		}
		void solve() {
			vector<int> u={0,n};
			for(int i=1;i<=m;i++) {
				a[i].x=read();
				a[i].y=read();
				a[i].v=read();
				u.push_back(a[i].x);
			}
			sort(a+1,a+m+1,[&](Task a,Task b) {
				return a.x<b.x;
			});
			sort(u.begin(),u.end());
			u.erase(unique(u.begin(),u.end()),u.end());
			s.insert(0,0,0);
			s.insert(1,k,-inf);
			int pos=1;
			for(int i=1;i<(int)u.size();i++) {
				int pre=u[i-1],cur=u[i],t=cur-pre-1;
				s.move();
//				cerr<<"After move:\n";
//				s.dfs();
				if(t) {
					s.update(t);
//					cerr<<"After update:\n";
//					s.dfs();
				}
				while(pos<=m&&a[pos].x==cur) {
					if(a[pos].y<=k) {
						s.add(a[pos].y,a[pos].v);
					}
					pos++;
//					cerr<<"After add:\n";
//					s.dfs();
				}
			}
			cout<<s.ask()<<"\n";
		}
	}
	void main(int tid) {
		n=read(),m=read(),k=read(),d=read(); 
		SOL::solve();
		SOL::clear();
	}
	void init() {
		
	}
}

signed main() {
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	int T=1;
	Solve::type=Solve::read();
	T=Solve::read(); 
	Solve::init();
	for(int t=1;t<=T;t++) {
		Solve::main(t);
		Solve::clear();
	}
	cerr<<"Time: "<<clock()<<"ms\n";
}
