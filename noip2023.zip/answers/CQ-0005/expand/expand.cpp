#include<bits/stdc++.h>
#define ll long long
#define fir first
#define sec second
#define pii pair<int,int>
using namespace std;

const int maxn=500005;
const int inf=0x3f3f3f3f;

namespace Solve {
	int n,m;
	int type,q;
	int ta[maxn];
	int tb[maxn];
	int a[maxn];
	int b[maxn];
	int t[maxn];
	void clear() {
	
	}
	namespace BF {
		const int maxn=2005;
		bool f[2][maxn];
		bool ck() {
			memset(f[1],0,sizeof(f[1])); 
			f[1][1]=true;
			for(int i=1;i<=n;i++) {
				memset(f[(i+1)&1],0,sizeof(f[(i+1)&1])); 
				for(int j=1;j<=m;j++) {
					if(f[i&1][j]) {
						if(a[i+1]>b[j+1]) {
							f[(i+1)&1][j+1]=true;
						}
						if(a[i]>b[j+1]) {
							f[i&1][j+1]=true;
						}
						if(a[i+1]>b[j]) {
							f[(i+1)&1][j]=true;
						}
					}
				}
			}
			return f[n&1][m];
		}
	}
	namespace TT {
		const int maxn=4005;
		bool f[2][maxn];
		bool ck(int n,int m) {
			memset(f[1],0,sizeof(f[1])); 
			f[1][1]=true;
			n=min(n,4000);
			m=min(m,4000);
			for(int i=1;i<=n;i++) {
				memset(f[(i+1)&1],0,sizeof(f[(i+1)&1])); 
				bool ok=false;
				for(int j=1;j<=m;j++) {
					if(f[i&1][j]) {
						if(a[i+1]>b[j+1]) {
							f[(i+1)&1][j+1]=true;
						}
						if(a[i]>b[j+1]) {
							f[i&1][j+1]=true;
						}
						if(a[i+1]>b[j]) {
							f[(i+1)&1][j]=true;
						}
						ok=true;
					}
				}
				if(!ok) {
					return false;
				}
			}
			return true;
		}
	}
	bool ck() {
		if(type<=7) {
			return BF::ck();
		} else {
			return TT::ck(n,m);
		}
	}
	bool calc() {
		if(a[1]==b[1]) {
			return false;
		} else if(a[1]>b[1]) {
			return ck();
		} else {
			swap(n,m);
			memcpy(t,b,sizeof(t));
			memcpy(b,a,sizeof(b));
			memcpy(a,t,sizeof(a));
			bool res=ck();
			swap(n,m);
			return res;
		}
	}
	void main(int tid) {
		cin>>type>>n>>m>>q;
		for(int i=1;i<=n;i++) {
			cin>>a[i]; 
		}
		for(int i=1;i<=m;i++) {
			cin>>b[i];
		}
		memcpy(ta,a,sizeof(ta));
		memcpy(tb,b,sizeof(tb));
		cout<<calc();
		while(q--) {
			memcpy(a,ta,sizeof(a));
			memcpy(b,tb,sizeof(b));
			int p,q;
			cin>>p>>q;
			for(int i=1;i<=p;i++) {
				int x,y;
				cin>>x>>y;
				a[x]=y;
			}
			for(int i=1;i<=q;i++) {
				int x,y;
				cin>>x>>y;
				b[x]=y;
			}
			cout<<calc();
		}
		cout<<"\n";
	}
	void init() {
		
	}
}

signed main() {
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	int T=1;
//	cin>>T;
	Solve::init();
	for(int t=1;t<=T;t++) {
		Solve::main(t);
		Solve::clear();
	}
	cerr<<"Time: "<<clock()<<"ms\n";
}
