#include <bits/stdc++.h>
#define int long long
#define ls (lr << 1)
#define rs (lr << 1 | 1)
#define mid ((l + r) >> 1)
using namespace std;

inline int read() {
    int x = 0, f = 0; char ch = getchar();
    while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
    while(ch >= '0' and ch <= '9') x = (x << 3) + (x << 1) + (ch ^ 48), ch = getchar();
    return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
    do { __stk[++__top] = x % 10, x /= 10; } while(x);
    while(__top) putchar('0' + __stk[__top--]);
}

void Max(int &x, int y) { y > x and (x = y); }
void Min(int &x, int y) { y < x and (x = y); }

bool stmer;

const int N = 2e5 + 10;

struct node {
    int x, y, v;
    bool operator < (const node &p) const { return x < p.x; }
} a[N];

int n, m, k, d, cnt;
int b[N], f[N], w[N];

struct tree {
    int x, tag;
} t[N << 2];

void build(int l, int r, int lr) {
    t[lr] = { d, 0 }; if(l == r) return;
    build(l, mid, ls), build(mid + 1, r, rs);
}

void update(int lr, int x) { t[lr].x += x, t[lr].tag += x; }

void pushdown(int lr) { if(t[lr].tag) update(ls, t[lr].tag), update(rs, t[lr].tag), t[lr].tag = 0; }

void modify(int l, int r, int L, int R, int x, int lr) {
    if(l >= L and r <= R) return update(lr, x);
    pushdown(lr);
    if(mid >= L) modify(l, mid, L, R, x, ls);
    if(mid < R) modify(mid + 1, r, L, R, x, rs);
    t[lr].x = max(t[ls].x, t[rs].x);
}

int query(int l, int r, int L, int R, int lr) {
    if(l >= L and r <= R) return t[lr].x; pushdown(lr);
    if(mid >= L and mid < R) return max(query(l, mid, L, R, ls), query(mid + 1, r, L, R, rs));
    return mid >= L ? query(l, mid, L, R, ls) : query(mid + 1, r, L, R, rs);
}

void solve() {
    n = read(), m = read(), k = read(), d = read(), cnt = 0;
    for(int i = 1; i <= m; i++) {
        int x = read(), y = read(), v = read();
        if(x - y >= 0) a[i] = { x, y, v }, b[++cnt] = x + 1, b[++cnt] = x - y;
        else i--, m--;
    } 
    b[++cnt] = 0, sort(b + 1, b + cnt + 1);
    n = unique(b + 1, b + cnt + 1) - b - 1;
    sort(a + 1, a + m + 1), build(1, n, 1);

    for(int i = 1; i <= n; i++) f[i] = 0;

    for(int i = 1, now = 1; i <= n; i++) {
        while(now <= m and a[now].x < b[i]) {
            int pos = upper_bound(b + 1, b + n + 1, a[now].x - a[now].y) - b - 1;
            if(pos >= 1) modify(1, n, 1, pos, a[now].v, 1); now++;
        }
        if(i - 1) modify(1, n, 1, i - 1, (b[i - 1] - b[i]) * d, 1);
        int pos = lower_bound(b + 1, b + n + 1, b[i] - 1 - k) - b;
        Min(pos, i - 1);
        if(pos >= 1) f[i] = query(1, n, pos, i - 1, 1);
        Max(f[i], f[i - 1]), modify(1, n, i, i, f[i], 1);
    }
    write(f[n]), putchar('\n');
}

bool edmer;
signed main() {
    freopen("run.in", "r", stdin);
    freopen("run.out", "w", stdout);
    cerr << "[Memery] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";

    int sid = read(), T = read();
    while(T--) solve();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
    return 0;
}