#include <bits/stdc++.h>
using namespace std;

inline int read() {
    int x = 0, f = 0; char ch = getchar();
    while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
    while(ch >= '0' and ch <= '9') x = (x << 3) + (x << 1) + (ch ^ 48), ch = getchar();
    return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
    do { __stk[++__top] = x % 10, x /= 10; } while(x);
    while(__top) putchar('0' + __stk[__top--]);
}

void Max(int &x, int y) { y > x and (x = y); }
void Min(int &x, int y) { y < x and (x = y); }

bool stmer;

const int N = 2e5 + 10, M = 20;

struct edge {
    int v, w;
};

int n, m, ans, cnt, top;
int fa[N], s[N], lat[N], f[N], dep[N], stk[N];

vector<edge> e[N];

bool vis[N], v[N], flag;

int find(int x) {
    if(fa[x] == x) return x;
    find(fa[x]), s[x] ^= s[fa[x]];
    return fa[x] = fa[fa[x]];
}

void add(int u, int v, int w) { e[u].push_back({ v, w }), e[v].push_back({ u, w }); }

void dfs(int x) {
    vis[x] = 1, flag |= v[x];
    if(x <= n) stk[++top] = x;

    for(edge l : e[x]) {
        if(!vis[l.v]) dep[l.v] = dep[x] + 1, f[l.v] = f[x] ^ l.w, dfs(l.v);
        else if((f[l.v] ^ f[x]) != l.w) flag = 1;
    }
}

void solve() {
    for(int i = 1; i <= cnt; i++) fa[i] = i, s[i] = 0, e[i].clear(), vis[i] = 0, v[i] = 0;
    
    n = cnt = read(), m = read(), ans = 0;
    for(int i = 1; i <= n; i++) fa[i] = i, s[i] = 0, lat[i] = i;

    for(int i = 1; i <= m; i++) {
        char ch = getchar();
        while(ch != 'T' and ch != 'F' and ch != 'U' and ch != '+' and ch != '-') ch = getchar(); 
        if(ch == '+') {
            int x = read(), y = read();
            fa[++cnt] = lat[y], lat[x] = cnt, s[cnt] = 0;
        }
        else if(ch == '-') {
            int x = read(), y = read();
            fa[++cnt] = lat[y], lat[x] = cnt, s[cnt] = 1;
        }
        else lat[read()] = ++cnt, v[cnt] = (ch == 'U'), fa[cnt] = cnt;
    }
    // for(int i = 1; i <= n; i++) cout << i << " " << lat[i] << " " << find(lat[i]) << " " << s[lat[i]] << '\n';
    for(int i = 1; i <= n; i++) find(lat[i]), add(find(lat[i]), lat[i], s[lat[i]]), add(i, lat[i], 0);
    for(int i = 1; i <= n; i++) if(!vis[i]) {
        f[i] = flag = top = 0, dep[i] = 1, dfs(i);
        if(flag) ans += top;
        else {
            int sum = top;
            while(top) {
                int x = stk[top--];
                if(f[x] ^ f[lat[x]]) { flag = 1; break; }
            }
            if(flag) ans += sum;
        }
    }

    write(ans), putchar('\n');
}

bool edmer;
signed main() {
    freopen("tribool.in", "r", stdin);
    freopen("tribool.out", "w", stdout);
    cerr << "[Memery] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";

    int sid = read(), T = read();
    while(T--) solve();

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
    return 0;
}