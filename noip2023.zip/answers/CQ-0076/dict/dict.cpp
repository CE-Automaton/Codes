#include <bits/stdc++.h>
using namespace std;

inline int read() {
    int x = 0, f = 0; char ch = getchar();
    while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
    while(ch >= '0' and ch <= '9') x = (x << 3) + (x << 1) + (ch ^ 48), ch = getchar();
    return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
    do { __stk[++__top] = x % 10, x /= 10; } while(x);
    while(__top) putchar('0' + __stk[__top--]);
}

void Max(int &x, int y) { y > x and (x = y); }
void Min(int &x, int y) { y < x and (x = y); }

bool stmer;

const int N = 3010;

int n, m;
int L[N], R[N], c[30];

char s[N];

bool edmer;
signed main() {
    freopen("dict.in", "r", stdin);
    freopen("dict.out", "w", stdout);
    cerr << "[Memery] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";

    n = read(), m = read();
    for(int i = 1; i <= n; i++) {
        scanf("%s", s), L[i] = 26; 
        for(int j = 0; j < m; j++)
            Min(L[i], s[j] - 'a'), Max(R[i], s[j] - 'a');
        c[R[i]]++;
    }

    for(int i = 1; i <= n; i++) {
        int cnt = -(R[i] > L[i]);
        for(int j = L[i] + 1; j < 26; j++) cnt += c[j];
        if(cnt >= n - 1) putchar('1'); else putchar('0');
    }

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
    return 0;
}