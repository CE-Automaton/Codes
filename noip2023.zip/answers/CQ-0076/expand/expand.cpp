#include <bits/stdc++.h>
using namespace std;

inline int read() {
    int x = 0, f = 0; char ch = getchar();
    while(ch < '0' or ch > '9') f |= (ch == '-'), ch = getchar();
    while(ch >= '0' and ch <= '9') x = (x << 3) + (x << 1) + (ch ^ 48), ch = getchar();
    return f ? -x : x;
}

int __stk[128], __top;
inline void write(int x) {
    if(x < 0) putchar('-'), x = -x;
    do { __stk[++__top] = x % 10, x /= 10; } while(x);
    while(__top) putchar('0' + __stk[__top--]);
}

void Max(int &x, int y) { y > x and (x = y); }
void Min(int &x, int y) { y < x and (x = y); }

bool stmer;

const int N = 5e5 + 10, inf = 1e9;

struct oper {
    int p, x;
} opx[N], opy[N];

int sid, n, m, q;
int a[N], b[N];

bool f[N];

namespace sub1 {
    bool main() {
        for(int i = 1; i <= m; i++) f[i] = 0;
        f[1] = 1;
        for(int i = 1; i <= n; i++) 
            for(int j = 1; j <= m; j++)
                f[j] = ((f[j - 1] or f[j]) and (a[i] < b[j]));
        return f[m];
    }
}

namespace sub2 {
    bool main() {
        int i = 1, j = 1, g = 1, h = 1;
        while(1) {
            int x = g + h, s = i, t = j;
            while(g < n and a[g + 1] < b[j]) if(a[++g] <= a[s]) s = g;
            i = s;
            while(h < m and a[i] < b[h + 1]) if(b[++h] >= b[t]) t = h;
            j = t;
            if(x == g + h) break;
        }
        return i == n and j == m;
    }
}

bool check() {
    bool flag = 0, res = 0; 

    if(a[1] > b[1]) {
        flag = 1;
        for(int i = 1; i <= n; i++) a[i] = inf - a[i];
        for(int i = 1; i <= m; i++) b[i] = inf - b[i];
    }

    if(max(n, m) <= 2000) res = sub1 :: main();
    else res = sub2 :: main();

    if(flag) {
        for(int i = 1; i <= n; i++) a[i] = inf - a[i];
        for(int i = 1; i <= m; i++) b[i] = inf - b[i];
    }

    return res;
}

bool edmer;
signed main() {
    freopen("expand.in", "r", stdin);
    freopen("expand.out", "w", stdout);
    cerr << "[Memery] " << (&stmer - &edmer) / 1024 / 1024 << " MB\n";

    sid = read(), n = read(), m = read(), q = read();
    for(int i = 1; i <= n; i++) a[i] = read();
    for(int i = 1; i <= m; i++) b[i] = read();

    putchar(check() + '0');
    for(int i = 1; i <= q; i++) {
        int kx = read(), ky = read();
        
        for(int j = 1; j <= kx; j++) {
            int p = read(), x = read();
            opx[j] = { p, a[p] }, a[p] = x;
        }
        for(int j = 1; j <= ky; j++) {
            int p = read(), x = read();
            opy[j] = { p, b[p] }, b[p] = x;
        }

        putchar(check() + '0');
        
        for(int j = kx; j; j--) a[opx[j].p] = opx[j].x;
        for(int j = ky; j; j--) b[opy[j].p] = opy[j].x;
    }

    cerr << "[Runtime] " << (double) clock() / CLOCKS_PER_SEC << " seconds\n";
    return 0;
}