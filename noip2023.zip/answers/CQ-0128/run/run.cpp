#include<bits/stdc++.h>
#define int long long
#define min(a,b) (a<b?a:b)
#define max(a,b) (a>b?a:b)
using namespace std;
int dp[1005][1005],c,t,n,m,k,d,x,y,v,ts[1005][1005];
signed main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	cin>>c>>t;
	if(c==17||c==18){
		for(int i=1;i<=t;i++){
			int ans=0;
			cin>>n>>m>>k>>d;
			for(int i=1;i<=m;i++){
				cin>>x>>y>>v;
				if(y<=k) ans+=max(0,v-y*d);
			}
			cout<<ans<<endl;
		}
		return 0;
	}
	for(int i=1;i<=t;i++){
		memset(dp,0xcf,sizeof(dp));
		memset(ts,0,sizeof(ts));
		cin>>n>>m>>k>>d;
		for(int i=1;i<=m;i++) cin>>x>>y>>v,ts[x][y]+=v;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=k;j++){
				ts[i][j]+=ts[i][j-1];
			}
		}
		dp[0][0]=0;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=k;j++){
				dp[i][j]=max(dp[i][j],dp[i-1][j-1]-d);
				dp[i][j]+=ts[i][j];
			}
			for(int j=0;j<=k;j++) dp[i][0]=max(dp[i][0],dp[i-1][j]);
		}
		int ans=0;
		for(int i=0;i<=k;i++) ans=max(ans,dp[n][i]);
		cout<<ans<<endl;
	}
}