#include<bits/stdc++.h>
#define int long long
#define min(a,b) (a<b?a:b)
#define max(a,b) (a>b?a:b)
#define ab(a) (a>0?a:-a)
using namespace std;
int c,n,m,q,x[500005],y[500005],p,v,fx[500005],fy[500005];
bool dp[5005][5005];
bool init(int n,int m,int *x,int *y){
	if(x[n]<=y[n]) return 0;
	memset(dp,0,sizeof(dp));
	dp[1][1]=1;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(y[j]>=x[i]) dp[i][j]=0;
			if(dp[i][j]==1){
				if(x[i+1]>y[j]) dp[i+1][j]|=1;
				if(x[i]>y[j+1]) dp[i][j+1]|=1;
			}
		}
	}
	return dp[n][m];
}
signed main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	cin>>c>>n>>m>>q;
	for(int i=1;i<=n;i++) cin>>x[i],fx[i]=x[i];
	for(int i=1;i<=m;i++) cin>>y[i],fy[i]=y[i];
	if(c>7){
		for(int i=1;i<=q+1;i++) cout<<0;
		return 0;
	}
	if(x[1]>y[1]) cout<<init(n,m,x,y);
	else if(x[1]==y[1]) cout<<0;
	else cout<<init(m,n,y,x);
//	cout<<endl;
	for(int i=1;i<=q;i++){
		int kx,ky;
		cin>>kx>>ky;
		for(int i=1;i<=kx;i++) cin>>p>>v,x[p]=v;
		for(int i=1;i<=ky;i++) cin>>p>>v,y[p]=v;
		if(x[1]>y[1]) cout<<init(n,m,x,y);
		else if(x[1]==y[1]) cout<<0;
		else cout<<init(m,n,y,x);
//		cout<<endl;
		for(int i=1;i<=n;i++) x[i]=fx[i];
		for(int i=1;i<=m;i++) y[i]=fy[i];
	}
}
