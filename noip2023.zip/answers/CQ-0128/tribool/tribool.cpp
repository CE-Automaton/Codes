#include<bits/stdc++.h>
#define int long long
#define min(a,b) (a<b?a:b)
#define max(a,b) (a>b?a:b)
#define ab(a) (a>0?a:-a)
using namespace std;
int c,t,fx[100005],x,y,n,m,op[100005],ans;
char ch;
int vis[100005];
int ask(int a){
	if(a==0) return 1;
	if(a==1) return 0;
	return 2;
}
void merge(int x,int y,int f){
	if(fx[y]!=-1){
		op[x]=0;
		if(f==1) fx[x]=fx[y];
		else fx[x]=ask(fx[y]);
	}
	else op[x]=f*op[y],fx[x]=-1;
}
void change(char ch,int x){
	if(ch=='U') fx[x]=2,op[x]=0;
	else if(ch=='T') fx[x]=1,op[x]=0;
	else fx[x]=0,op[x]=0;
}
signed main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	cin>>c>>t;
	for(int i=1;i<=t;i++){
		ans=0;
		memset(fx,-1,sizeof(fx));
		memset(op,0,sizeof(op));
		memset(vis,0,sizeof(vis));
		cin>>n>>m;
		for(int j=1;j<=n;j++) op[j]=j;
		for(int j=1;j<=m;j++){
			cin>>ch;
			if(ch=='-') cin>>x>>y,merge(x,y,-1);
			else if(ch=='+') cin>>x>>y,merge(x,y,1);
			else cin>>x,change(ch,x); 
		}
//		for(int j=1;j<=n;j++) cout<<op[j]<<" "<<fx[j]<<endl;
		for(int j=1;j<=n;j++){
			if(op[j]==-j||fx[j]==2) vis[j]=-1,ans++;
			else if(op[j]==j||fx[j]>=0) vis[j]=1;
		}
//		for(int j=1;j<=n;j++) cout<<vis[j]<<" ";
//		cout<<endl;
		for(int j=1;j<=n;j++){
			if(vis[j]!=0||fx[j]>=0) continue;
			int fx=j;
//			cout<<"6-debug"<<vis[6]<<" "<<"1-debug"<<vis[1]<<endl;
			while(!vis[fx]){
				vis[fx]=2;
				fx=ab(op[fx]);
			}
			int k=vis[fx];
//			cout<<k<<" "<<fx<<" "<<vis[fx];
			if(k==2){
				int cnt=0,ed=fx,sum=0;
//				cout<<"deg";
				while(vis[fx]==2&&fx!=ed||sum==0){
					sum++;
					if(op[fx]<0) cnt++;
//					cout<<fx<<" "<<op[fx]<<endl; 
					fx=ab(op[fx]);
				}
				if(cnt%2==1) k=-1;
				else k=1;
//				cout<<"dag";
			}
//			cout<<k<<endl;
			fx=j;
			while(vis[fx]==2){
				vis[fx]=k;
				if(k==-1) ans++;
				fx=ab(op[fx]);
			}
		}
		cout<<ans<<endl;
//		return 0;
	}
}
/*
1 3
3 3
- 2 1
- 3 2
+ 1 3
3 3
- 2 1
- 3 2
- 1 3
2 2
T 2
U 2
*/
