#include<bits/stdc++.h>
#define int long long
#define min(a,b) (a<b?a:b)
#define max(a,b) (a>b?a:b)
using namespace std;
int n,m;
char c[3005][3005];
int cnt[3005][35],f[3005],maxn[3005],minn[3005];
signed main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	memset(minn,0x3f,sizeof(minn));
	cin>>n>>m;
	if(n==1) return cout<<1,0;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>c[i][j];
			cnt[i][c[i][j]-'a']++;
			minn[i]=min(minn[i],c[i][j]-'a');
			maxn[i]=max(maxn[i],c[i][j]-'a');
		}
//		cout<<minn[i]<<" "<<maxn[i]<<endl;
	}
	for(int i=1;i<=n;i++){
		bool f=0;
		int mix=minn[i];
		for(int j=1;j<=n;j++){
			if(i==j) continue;
			int jx=maxn[j];
			if(jx<=mix) f=1;
			if(f) break;
		}
		if(f) cout<<0;
		else cout<<1;
	}
}
/*
4 7
abandon
bananaa
baannaa
notnotn
*/
