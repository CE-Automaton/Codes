#include<bits/stdc++.h>
#define ll long long
#define fi first
#define se second
#define pb push_back
using namespace std;
const int N=1e5+10;
int C,T;
int n,m,f[N],fth[N],fa[N],sz[N],val[N],vs[N];
int find(int x){
    if(fa[x]==x)return x;
    int tmp=fa[x];
    fa[x]=find(fa[x]);
    val[x]^=val[tmp];
    return fa[x];
}
void unionset(int x,int y,int z){
    int u=find(x),v=find(y);
    if(u!=v){
        fa[u]=v,val[u]=val[x]^val[y]^z,vs[v]|=vs[u],sz[v]+=sz[u];
    }
    else if((val[x]^val[y])!=z){
        vs[u]=1;
    }
}
int main(){
    freopen("tribool.in","r",stdin);
    freopen("tribool.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    cin>>C>>T;
    while(T--){
        cin>>n>>m;
        for(int i=1;i<=n+3;i++)fth[i]=fa[i]=i,f[i]=val[i]=vs[i]=0,sz[i]=1;
        vs[n+3]=1,sz[n+3]=0;
        for(int i=1;i<=m;i++){
            string str;int x,y;
            cin>>str;
            if(str[0]=='+'){
                cin>>x>>y;
                fth[x]=fth[y],f[x]=f[y];
            }
            else if(str[0]=='-'){
                cin>>x>>y;
                fth[x]=fth[y],f[x]=f[y]^1;
            }
            else if(str[0]=='T'){
                cin>>x;
                fth[x]=n+1,f[x]=0;
            }
            else if(str[0]=='F'){
                cin>>x;
                fth[x]=n+2,f[x]=0;
            }
            else if(str[0]=='U'){
                cin>>x;
                fth[x]=n+3,f[x]=0;
            }
        }
        for(int i=1;i<=n;i++){
            unionset(i,fth[i],f[i]);
        }
        int res=0;
        for(int i=1;i<=n+3;i++){
            if(fa[i]==i&&vs[i])res+=sz[i];
        }
        cout<<res<<"\n";
    }
}