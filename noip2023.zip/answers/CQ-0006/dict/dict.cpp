#include<bits/stdc++.h>
#define ll long long
#define fi first
#define se second
#define pb push_back
using namespace std;
const int N=3005;
string lsh[N<<1];
int n,m,cnt,p[N],q[N],pre[N],suf[N];
string s[N],tmp;
int get(string x){
    return lower_bound(lsh+1,lsh+1+cnt,x)-lsh;
}
int main(){
    freopen("dict.in","r",stdin);
    freopen("dict.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    cin>>n>>m;
    for(int i=1;i<=n;i++){
        cin>>s[i];
        tmp=s[i],sort(tmp.begin(),tmp.end()),lsh[++cnt]=tmp;
        reverse(tmp.begin(),tmp.end()),lsh[++cnt]=tmp;
    }
    sort(lsh+1,lsh+1+cnt);
    pre[0]=cnt+1;
    for(int i=1;i<=n;i++){
        tmp=s[i],sort(tmp.begin(),tmp.end()),reverse(tmp.begin(),tmp.end());
        p[i]=get(tmp);reverse(tmp.begin(),tmp.end()),q[i]=get(tmp);
        pre[i]=min(pre[i-1],p[i]);
    }
    suf[n+1]=cnt+1;
    for(int i=n;i>=1;i--){
        suf[i]=min(suf[i+1],p[i]);
    }
    for(int i=1;i<=n;i++){
        if(q[i]<min(pre[i-1],suf[i+1])){
            cout<<1;
        }
        else{
            cout<<0;
        }
    }
}