#include<bits/stdc++.h>
#define ll long long
#define fi first
#define se second
#define pb push_back
using namespace std;
const int N=2005;
int C,n,m,Q;
int a[N],b[N],ta[N],tb[N];
bool f[N][N];
int solve(int *a,int *b,int n,int m){
    if(a[1]==b[1]||a[n]==b[m]){
        return 0;
    }
    if((a[1]>b[1])^(a[n]>b[m])){
        return 0;
    }
    if(a[1]>b[1]){
        swap(n,m),swap(a,b);
    }
    f[0][0]=1;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
            if(a[i]>=b[j]){
                f[i][j]=0;
                continue;
            }
            f[i][j]=f[i-1][j]|f[i-1][j-1]|f[i][j-1];
        }
    }
    return f[n][m];
}
int main(){
    freopen("expand.in","r",stdin);
    freopen("expand.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    cin>>C>>n>>m>>Q;
    for(int i=1;i<=n;i++)cin>>a[i],ta[i]=a[i];
    for(int i=1;i<=m;i++)cin>>b[i],tb[i]=b[i];
    cout<<solve(ta,tb,n,m);
    for(int i=1;i<=Q;i++){
        int kx,ky;
        cin>>kx>>ky;
        for(int j=1;j<=n;j++)ta[j]=a[j];
        for(int j=1;j<=m;j++)tb[j]=b[j];
        for(int j=1;j<=kx;j++){
            int x,y;cin>>x>>y,ta[x]=y;
        }
        for(int j=1;j<=ky;j++){
            int x,y;cin>>x>>y,tb[x]=y;
        }
        cout<<solve(ta,tb,n,m);
    }
}