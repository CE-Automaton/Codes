#include<bits/stdc++.h>
#define ll long long
#define fi first
#define se second
#define pb push_back
#define inf 0x3f3f3f3f3f3f3f3f
using namespace std;
const int N=2e5+5;
int C,T,rt,tot;
int n,m,K,lsh[N],cnt;
ll d;
struct node{
    int l,r,v;
}q[N];
int get(int x){
    return lower_bound(lsh+1,lsh+1+cnt,x)-lsh;
}
mt19937 gen(114514);
struct node2{
    int l,r,sz,fix;
    ll val,tag,mx;
}t[N];
vector<int>vec[N];
void Add(int p,ll x){
    if(!p)return;
    t[p].tag+=x,t[p].val+=x,t[p].mx+=x;
}
int newnode(ll val){
    tot++;
    t[tot].sz=1,t[tot].fix=gen(),t[tot].val=t[tot].mx=val;
    return tot;
}
void pushup(int p){
    t[p].sz=t[t[p].l].sz+t[t[p].r].sz+1;
    t[p].mx=max({t[t[p].l].mx,t[t[p].r].mx,t[p].val});
}
void pushdown(int p){
    if(t[p].tag)Add(t[p].l,t[p].tag),Add(t[p].r,t[p].tag),t[p].tag=0;
}
void split(int rt,int &x,int &y,int val){
    if(!rt){
        x=y=0;
        return;
    }
    if(t[t[rt].l].sz+1<=val){
        x=rt;
        pushdown(x);
        split(t[x].r,t[x].r,y,val-t[t[x].l].sz-1);
        pushup(x);
    }
    else{
        y=rt;
        pushdown(y);
        split(t[y].l,x,t[y].l,val);
        pushup(y);
    }
}
int merge(int x,int y){
    if(!x||!y){
        return x+y;
    }
    if(t[x].fix>t[y].fix){
        pushdown(x);
        t[x].r=merge(t[x].r,y);
        pushup(x);
        return x;
    }
    else{
        pushdown(y);
        t[y].l=merge(x,t[y].l);
        pushup(y);
        return y;
    }
}
int main(){
    freopen("run.in","r",stdin);
    freopen("run.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    cin>>C>>T;t[0].mx=-inf;
    while(T--){
        cin>>n>>m>>K>>d,cnt=0;
        for(int i=1;i<=m;i++){
            cin>>q[i].r>>q[i].l>>q[i].v;
            q[i].r++,q[i].l=q[i].r-q[i].l;
            lsh[++cnt]=q[i].l,lsh[++cnt]=q[i].r;
        }sort(lsh+1,lsh+1+cnt),cnt=unique(lsh+1,lsh+1+cnt)-lsh-1;
        for(int i=1;i<=cnt;i++)vec[i].clear();
        for(int i=1;i<=m;i++){
            q[i].l=get(q[i].l),q[i].r=get(q[i].r);
            vec[q[i].r].pb(i);
        }
        while(tot)t[tot].l=t[tot].r=t[tot].sz=t[tot].tag=t[tot].mx=0,tot--;
        rt=newnode(0);
        for(int i=2;i<=cnt;i++){
            ll tmp=t[rt].mx,c=1ll*(lsh[i]-lsh[i-1])*d;
            Add(rt,-c);int _x=newnode(tmp);
            rt=merge(_x,rt);
            int j=get(lsh[i]-K);
            for(auto e:vec[i]){
                int l=q[e].l,v=q[e].v,x,y;
                split(rt,x,y,i-l),Add(y,v),rt=merge(x,y);
            }
            int x,y;
            split(rt,x,y,i-j+1),rt=x;
        }
        cout<<t[rt].mx<<"\n";
    }
}