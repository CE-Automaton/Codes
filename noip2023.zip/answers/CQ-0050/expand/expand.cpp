#include <bits/stdc++.h>
using namespace std;
const int N=500005,INF=0x3f3f3f3f;
struct node {int x,y;}qx[N],qy[N];
int T,n,m,q,a[N],b[N];
map<tuple<int,int,int,int>,bool>mp;
inline int read()
{
	int s=0;
	char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9') s=s*10+(ch^48),ch=getchar();
	return s;
}
bool check(int l,int r,int L,int R)
{
	if(a[l]==b[L]||a[r]==b[R]) return 0;
	if((a[l]<b[L])!=(a[r]<b[R])) return 0;
	return a[l]<b[L];
}
bool solve(int l,int r,int L,int R)
{
	if(L>R) return 1;
	if(!check(l,r,L,R)) return 0;
	if(mp.count(make_tuple(l,r,L,R))) return mp[make_tuple(l,r,L,R)];
	bool &res=mp[make_tuple(l,r,L,R)];
	int mx=-INF;
	for(int i=L;i<=R;i++) mx=max(mx,b[i]);
	for(int i=l;i<=r;i++) if(a[i]>=mx) return res=0;
	if(l==r) return res=1;
	for(int i=L;i<=R;i++) if(mx==b[i])
		for(int x=l;x<=r;x++)
			for(int y=x;y<=r;y++)
				if(solve(l,x,L,i-1)&&solve(y,r,i+1,R)) return res=1;
	return res=0;
}
int main()
{
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	T=read(),n=read(),m=read(),q=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=m;i++) b[i]=read();
	bool bj=!check(1,n,1,m);
	if(bj)
	{
		for(int i=1;i<=n;i++) a[i]=-a[i];
		for(int i=1;i<=m;i++) b[i]=-b[i];
	}
	putchar(solve(1,n,1,m)+'0');
	if(bj)
	{
		for(int i=1;i<=n;i++) a[i]=-a[i];
		for(int i=1;i<=m;i++) b[i]=-b[i];
	}
	while(q--)
	{
		int kx=read(),ky=read();
		for(int i=1;i<=kx;i++) qx[i].x=read(),qx[i].y=read(),swap(a[qx[i].x],qx[i].y);
		for(int i=1;i<=ky;i++) qy[i].x=read(),qy[i].y=read(),swap(b[qy[i].x],qy[i].y);
		bj=!check(1,n,1,m);
		if(bj)
		{
			for(int i=1;i<=n;i++) a[i]=-a[i];
			for(int i=1;i<=m;i++) b[i]=-b[i];
		}
		mp.clear();
		putchar(solve(1,n,1,m)+'0');
		if(bj)
		{
			for(int i=1;i<=n;i++) a[i]=-a[i];
			for(int i=1;i<=m;i++) b[i]=-b[i];
		}
		for(int i=1;i<=kx;i++) swap(a[qx[i].x],qx[i].y);
		for(int i=1;i<=ky;i++) swap(b[qy[i].x],qy[i].y);
	}
	return 0;
}
