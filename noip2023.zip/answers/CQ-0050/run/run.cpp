#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=100005;
int T,n,m,k,d;
ll f[105],g[105];
struct que
{
	int x,y,v;
	bool operator < (const que &a)const {return x<a.x;}
}q[N];
vector<pair<int,int>>p[N];
struct node {int l,r; ll res,bj;}t[N<<3];
void pushup(int x) {t[x].res=max(t[x<<1].res,t[x<<1|1].res);}
void upd(int x,ll v) {t[x].res+=v,t[x].bj+=v;}
void pushdown(int x)
{
	if(t[x].bj) upd(x<<1,t[x].bj),upd(x<<1|1,t[x].bj),t[x].bj=0;
}
void build(int x,int l,int r)
{
	t[x].l=l,t[x].r=r,t[x].res=0;
	if(l==r) return;
	int mid=(l+r)>>1;
	build(x<<1,l,mid),build(x<<1|1,mid+1,r);
}
void add(int x,int l,int r,ll v)
{
	if(r<t[x].l||l>t[x].r) return;
	if(l<=t[x].l&&r>=t[x].r) {upd(x,v); return;}
	pushdown(x);
	add(x<<1,l,r,v),add(x<<1|1,l,r,v);
	pushup(x);
}
void change(int x,int k,ll v)
{
	if(t[x].l==t[x].r) {t[x].res=v; return;}
	pushdown(x);
	int mid=(t[x].l+t[x].r)>>1;
	change(x<<1|(k>mid),k,v);
	pushup(x);
}
ll ask(int x,int l,int r)
{
	if(r<t[x].l||l>t[x].r) return -2e18;
	if(l<=t[x].l&&r>=t[x].r) return t[x].res;
	pushdown(x);
	return max(ask(x<<1,l,r),ask(x<<1|1,l,r));
}
inline int read()
{
	int s=0;
	char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9') s=s*10+(ch^48),ch=getchar();
	return s;
}
void solve()
{
	n=read(),m=read(),k=read(),d=read();
	if(n>100000&&k<=100)
	{
		for(int i=1;i<=m;i++) q[i].x=read(),q[i].y=read(),q[i].v=read();
		sort(q+1,q+1+m);
		int now=0;
		for(int i=0;i<=k;i++) f[i]=0;
		for(int i=1;i<=m;i++)
		{
			int dt=q[i].x-now;
			ll mx=-2e18;
			for(int j=0;j<=k;j++) mx=max(mx,f[j]);
			for(int j=0;j<=k;j++)
			{
				if(j>=dt) g[j]=f[j-dt]-1ll*dt*d;
				else g[j]=mx-1ll*j*d;
			}
			for(int j=0;j<=k;j++) f[j]=g[j];
			for(int j=q[i].y;j<=k;j++) f[j]+=q[i].v;
			now=q[i].x;
		}
		int dt=n-now;
		ll mx=-2e18;
		for(int j=0;j<=k;j++) mx=max(mx,f[j]);
		for(int j=0;j<=k;j++)
		{
			if(j>=dt) g[j]=f[j-dt]-1ll*dt*d;
			else g[j]=mx-1ll*j*d;
		}
		for(int j=0;j<=k;j++) f[j]=g[j];
		mx=-2e18;
		for(int j=0;j<=k;j++) mx=max(mx,f[j]);
		printf("%lld\n",mx);
		return;
	}
	for(int i=1;i<=n;i++) p[i].clear();
	for(int i=1,x,y,v;i<=m;i++)
	{
		x=read(),y=read(),v=read();
		p[x].emplace_back(y,v);
	}
	build(1,0,2*n);
	int l=0,r=k;
	for(int i=1;i<=n;i++)
	{
		change(1,r+1,ask(1,l,r));
		add(1,l+1,r,-d);
		l++,r++;
		for(auto it:p[i]) add(1,l,r-it.first,it.second);
	}
	printf("%lld\n",max(0ll,ask(1,l,r)));
}
int main()
{
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	T=read();
	int t=read();
	while(t--) solve();
	return 0;
}

