#include <bits/stdc++.h>
using namespace std;
const int N=400005;
int T,n,m,prt[N],sz[N],lst[N],cnt,id[N][2];
bool u[N],v[N];
struct que {char op; int x,y;}q[N];
int find(int x) {return x==prt[x]?x:prt[x]=find(prt[x]);}
void merge(int x,int y)
{
	x=find(x),y=find(y);
	if(x==y) return;
	if(sz[x]>sz[y]) swap(x,y);
	prt[x]=y,sz[y]+=sz[x];
}
inline int read()
{
	int s=0;
	char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9') s=s*10+(ch^48),ch=getchar();
	return s;
}
inline char readop()
{
	char ch=getchar();
	while(ch!='+'&&ch!='-'&&ch!='T'&&ch!='F'&&ch!='U') ch=getchar();
	return ch;
}
int get(int x,int y) {return y==0?x:id[y][x>n];}
void solve()
{
	n=read(),m=read();
	for(int i=1;i<=2*n;i++) lst[i]=0;
	cnt=2*n;
	for(int i=1;i<=m;i++) id[i][0]=id[i][1]=0;
	for(int i=1;i<=m;i++)
	{
		q[i].op=readop(),q[i].x=read();
		id[i][0]=++cnt,id[i][1]=++cnt;
		if(q[i].op=='+'||q[i].op=='-') q[i].y=read();
	}
	for(int i=1;i<=cnt;i++) prt[i]=i,u[i]=v[i]=0,sz[i]=1;
	for(int i=1;i<=m;i++)
	{
		int x=id[i][0],fx=id[i][1];
		if(q[i].op=='+')
		{
			int y=get(q[i].y,lst[q[i].y]),fy=get(q[i].y+n,lst[q[i].y+n]);
			merge(x,y),merge(fx,fy);
		}
		else if(q[i].op=='-')
		{
			int y=get(q[i].y,lst[q[i].y]),fy=get(q[i].y+n,lst[q[i].y+n]);
			merge(x,fy),merge(fx,y);
		}
		else u[x]=u[fx]=q[i].op=='U';
		lst[q[i].x]=lst[q[i].x+n]=i;
	}
	int ans=0;
	for(int i=1;i<=2*n;i++) merge(get(i,0),get(i,lst[i]));
	for(int i=1;i<=cnt;i++) if(u[i]) v[find(i)]=1;
	for(int i=1;i<=n;i++)
	{
		int x=get(i,0),fx=get(i+n,0);
		if(find(x)==find(fx)||v[find(x)]||v[find(fx)]) ans++;
	}
	printf("%d\n",ans);
}
int main()
{
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	int t; T=read(),t=read();
	while(t--) solve();
	return 0;
}
/*
1 1
10 10
- 7 6
+ 4 1
+ 6 4
T 1
+ 2 9
- 9 10
U 10
+ 5 5
U 8
T 3

1 1
3 3
- 2 1
- 3 2
- 1 3
*/
