#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int,int>pi;
#define fi first
#define se second
const int N=3e5+5;
bool ST;
int _type,n,m,k,d,num,b[N];
ll f[N];
vector<pi>c[N];
struct node{int l,r,v;}a[N];
struct sgt{
	struct tree{int l,r;ll mx,tg;}t[N<<2];
	inline void upd(int p){t[p].mx=max(t[p<<1].mx,t[p<<1|1].mx);}
	inline void Ad(int p,ll k){t[p].mx+=k,t[p].tg+=k;}
	inline void down(int p){if(t[p].tg)Ad(p<<1,t[p].tg),Ad(p<<1|1,t[p].tg),t[p].tg=0;}
	void build(int p,int l,int r) {
		t[p]={l,r,-(ll)4e18,0};if(l==r)return;
		int mid=t[p].l+t[p].r>>1;build(p<<1,l,mid),build(p<<1|1,mid+1,r);
	}
	void ins(int p,int x,ll k) {
		if(t[p].l==t[p].r)return t[p].mx=k,void();
		int mid=t[p].l+t[p].r>>1;down(p);
		if(x<=mid)ins(p<<1,x,k);else ins(p<<1|1,x,k);
		upd(p);
	}
	void Add(int p,int l,int r,int k) {
		if(t[p].l>=l&&t[p].r<=r)return Ad(p,k);
		int mid=t[p].l+t[p].r>>1;down(p);
		if(l<=mid)Add(p<<1,l,r,k);
		if(r>mid)Add(p<<1|1,l,r,k);
		upd(p);
	}
	ll ask(int p,int l,int r) {
		if(t[p].l>=l&&t[p].r<=r)return t[p].mx;
		int mid=t[p].l+t[p].r>>1;ll res=0;down(p);
		if(l<=mid)res=max(res,ask(p<<1,l,r));
		if(r>mid)res=max(res,ask(p<<1|1,l,r));
		return res;
	}
}T;
void solve() {
	cin>>n>>m>>k>>d,num=0,b[++num]=n,b[++num]=1;
	for(int i=1;i<=m;i++) {
		cin>>a[i].r>>a[i].l>>a[i].v,a[i].l=a[i].r-a[i].l+1;
		if(a[i].r-a[i].l+1<=k) {
			b[++num]=a[i].l,b[++num]=a[i].r;
			if(a[i].r-k+1>=1)b[++num]=a[i].r-k+1;
		}
	}
	sort(b+1,b+num+1),num=unique(b+1,b+num+1)-b-1;
	for(int i=1;i<=m;i++) {
		if(a[i].r-a[i].l+1>k)continue;
		a[i].l=lower_bound(b+1,b+num+1,a[i].l)-b;
		a[i].r=lower_bound(b+1,b+num+1,a[i].r)-b;
		c[a[i].r].push_back({a[i].l,a[i].v});
	}
	T.build(1,1,num);
	for(int i=1;i<=num;i++) {
		if(b[i]==1)T.ins(1,1,0);
		else if(b[i-1]+1==b[i])T.ins(1,i,f[i-2]+1ll*d*(b[i]-1));
		else T.ins(1,i,f[i-1]+1ll*d*(b[i]-1));
		int pos=lower_bound(b+1,b+num+1,b[i]-k+1)-b;
		for(pi j:c[i])T.Add(1,pos,j.fi,j.se);
		f[i]=max(f[i-1],T.ask(1,pos,i)-1ll*d*b[i]),c[i].clear();
	}
	cout<<f[num]<<'\n';
}
bool ED;
int main() {
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
//	cerr<<fixed<<setprecision(5)<<(&ST-&ED)/1024.0/1024.0<<" MB\n";
	int tt;cin>>_type>>tt;
	while(tt--)solve();
	return 0;
}
