#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e5+10;
bool ST;
int _type,n,m,st[N],t[N],a[N],fa[N],sz[N];
bool vis[N];
int gf(int x){return x==fa[x]?x:fa[x]=gf(fa[x]);}
void solve() {
	cin>>n>>m;
	for(int i=1;i<=n+3;i++)fa[i]=t[i]=i,sz[i]=a[i]=vis[i]=0;
	while(m--) {
		char c;int x,y;cin>>c>>x;
		if(c=='T')t[x]=n+1,a[x]=0;
		else if(c=='F')t[x]=n+2,a[x]=0;
		else if(c=='U')t[x]=n+3,a[x]=0;
		else if(c=='+')cin>>y,t[x]=t[y],a[x]=a[y];
		else cin>>y,t[x]=t[y],a[x]=a[y]^1;
	}
	for(int i=1;i<=n+3;i++)fa[gf(i)]=gf(t[i]);
	for(int i=1;i<=n+3;i++)sz[gf(i)]++;
	int ans=0;
	for(int i=1;i<=n+3;i++) {
		if(i==gf(i)) {
			int x=i,y=0,fl=0,top=0;
			while(!vis[x])vis[x]=1,st[++top]=x,x=t[x];
			do y=st[top--],fl^=a[y];while(y!=x);
			fl|=(gf(n+3)==i),ans+=fl*sz[i];
		}
	}cout<<ans-1<<'\n';
}
bool ED;
int main() {
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
//	cerr<<fixed<<setprecision(5)<<(&ST-&ED)/1024.0/1024.0<<" MB\n";
	int tt;cin>>_type>>tt;
	while(tt--)solve();
	return 0;
}
