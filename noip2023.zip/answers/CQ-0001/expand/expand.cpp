#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=5e5+5;
bool ST;
int _type,n,m,q,a[N],b[N],A[N],B[N],c[N],d[N];
bool calc(int*a,int*b,int n,int m) {
	int mx=0,j=0;
	for(int i=1;i<=n;i++) {
		while(j<m&&a[i]<b[j+1])mx=max(mx,b[++j]);
		if(a[i]>=mx)return 0;
	}
	return j==m;
}
bool solve(int*a,int*b,int n,int m) {
	if(a[1]==b[1]||a[n]>=b[m])return 0;
	int pos=1;c[0]=d[0]=0;
	for(int i=1;i<=n;i++)if(a[i]<a[pos])pos=i;
	for(int i=n;i>=pos;i--)c[++c[0]]=a[i];
	for(int i=m;i;i--)d[++d[0]]=b[i];
	return calc(a,b,pos,m)&&calc(c,d,n-pos+1,m);
}
bool ED;
int main() {
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
//	cerr<<fixed<<setprecision(5)<<(&ST-&ED)/1024.0/1024.0<<" MB\n";
	cin>>_type>>n>>m>>q;
	for(int i=1;i<=n;i++)cin>>a[i],A[i]=a[i];
	for(int i=1;i<=m;i++)cin>>b[i],B[i]=b[i];
	cout<<(a[1]<b[1]?solve(a,b,n,m):solve(b,a,m,n));
	while(q--) {
		int kx,ky,x,y;cin>>kx>>ky;
		for(int i=1;i<=n;i++)a[i]=A[i],b[i]=B[i];
		while(kx--)cin>>x>>y,a[x]=y;
		while(ky--)cin>>x>>y,b[x]=y;
		cout<<(a[1]<b[1]?solve(a,b,n,m):solve(b,a,m,n));
	}
	return 0;
}
