#include<bits/stdc++.h>
using namespace std;
const int N=2e5+5;

void file(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
}

int nex[N],coef[N];
char w[N],op[5];
int c,T,n,m;
bool vis[N],fg[N];

char rev(char x){
	if(x=='T')return 'F';
	if(x=='F')return 'T';
	return 'U';
}

void work(){
	for(int i=1;i<=n;++i)if(w[i]==0){
		
//		for(int j=1;j<=n;++j)
//			if(w[j])cout<<j<<" "<<w[j]<<endl;
		
		vector<int>vec;
		
		int cur=i;
		while(!vis[cur]&&!w[cur]&&cur)
			vec.push_back(cur),
			vis[cur]=true,cur=nex[cur];
			
		vec.push_back(cur);
		
//		for(auto v:vec)
//			cerr<<v<<" ";cerr<<endl;
		
			
		if(!cur){
			assert(vec[vec.size()-1]==0);
			w[vec[vec.size()-2]]='T';
			for(int j=vec.size()-3;j>=0;--j){
				int x=vec[j],y=vec[j+1];
				assert(nex[x]==y);
				assert(w[y]);
				if(coef[x]==1)w[x]=w[y];
				else w[x]=rev(w[y]);
			}
			continue;
		}
			
		if(w[cur]){
			for(int j=vec.size()-2;j>=0;--j){
				int x=vec[j],y=vec[j+1];
				assert(nex[x]==y);
				assert(w[y]);
				if(coef[x]==1)w[x]=w[y];
				else w[x]=rev(w[y]);
			}
			continue;
		}
		
			
		if(vis[cur]){
			
//			for(auto v:vec)
//				cerr<<v<<" ";cerr<<endl;
			
			int pos=-1;
			for(int j=0;j<(int)vec.size();++j)
				if(vec[j]==cur){pos=j;break;}
			
			assert(pos!=vec.size()-1);
			assert(pos!=-1);
			assert(vec[pos]==cur);
				
			fg[vec.back()]=1;
			for(int j=vec.size()-2;j>=pos+1;--j){
				int x=vec[j],y=vec[j+1];
				assert(nex[x]==y);
				if(coef[x]==1)fg[x]=fg[y];
				else fg[x]=(!fg[y]);
			}
			int now=fg[vec[pos+1]];
			if(coef[cur]==-1)now=(!now);
			
			if(now==fg[cur])w[cur]='T';
			else w[cur]='U';
			
			for(int j=vec.size()-2;j>=0;--j){
				if(j==pos)continue;
				int x=vec[j],y=vec[j+1];
				assert(nex[x]==y);
				
				assert(w[y]);
				if(coef[x]==1)w[x]=w[y];
				else w[x]=rev(w[y]);
			}	
		}	
	}
}

char ori[N],val[N];
char OP[N];
int I[N],J[N];
int ans;
bool check(){
	for(int i=1;i<=n;++i)val[i]=ori[i];
	for(int i=1;i<=m;++i){
		if(op[i]=='+')val[I[i]]=val[J[i]];
		else val[I[i]]='U';
	}
	for(int i=1;i<=n;++i)if(val[i]!=ori[i])return false;
	return true;
}
int calc(){
	int res=0;
	for(int i=1;i<=n;++i)if(ori[i]=='U')++res;
	return res;
}
void dfs(int u){
	if(u==n+1){
		if(check())ans=min(ans,calc());
		return ;
	}
	ori[u]='U';
	dfs(u+1);
	ori[u]='T';
	dfs(u+1);
	ori[u]='F';
	dfs(u+1);
}
void bf(){
	ans=1e9;
	dfs(1);
	
	cout<<ans<<'\n';
}

void solve(){
	cin>>n>>m;
	
	int id=n;
	for(int i=1;i<=n+m;++i)
		nex[i]=0,w[i]=0,vis[i]=0,val[i]=0,fg[i]=0;
	
	for(int _=1,i,j;_<=m;++_){
		cin>>op>>i,j=-1;
		if(op[0]=='+'||op[0]=='-')cin>>j;
		
		OP[_]=op[0];
		I[_]=i;
		J[_]=j;
		
		if(j==-1){
			++id;
			w[id]=op[0];
			nex[i]=id,coef[i]=1;
			
			if(op[0]=='U')fg[i]=1;
			else fg[i]=0;
		} else {
			if(i==j&&op[0]=='+')continue;
			else {
				nex[i]=j,coef[i]=(op[0]=='+'?1:-1);
				fg[i]=fg[nex[i]];
			}
		}
	}
	for(int i=1;i<=n;++i)if(fg[i])w[i]='U';
	
//	for(int i=1;i<=n;++i)
//		cerr<<i<<" "<<nex[i]<<" "<<coef[i]<<endl;
	
//	for(int i=1;i<=n;++i)
//		cerr<<nex[i]<<" "<<coef[i]<<endl;
	
//	for(int i=1;i<=n;++i)if(nex[i]==i&&coef[i]==-1) w[i]='U';
//	for(int i=1;i<=n;++i)if(nex[i]>n) w[i]='U';
//	for(int i=1;i<=n;++i)if(!nex[i]) w[i]='T';
//	
//	for(int i=1;i<=n;++i)if(!w[i]){
//		int cur=i;
//		while(!w[cur])cur=nex[cur];
//		w[i]=w[cur];
//		
//		if(cur==nex[cur])cerr<<1<<endl;
//	}
//	
//	for(int i=1;i<=n;++i)
//		cerr<<w[i]<<" ";cerr<<endl;
	
	work();

	int ans=0;
	for(int i=1;i<=n;++i)
		if(w[i]=='U')++ans;
	cout<<ans<<'\n';
}

signed main(){
//	freopen("tribool4.in","r",stdin);
//	freopen("mine.out","w",stdout);
//	freopen("data.in","r",stdin);
//	freopen("tribool1.in","r",stdin);
	file();
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	
	cin>>c>>T;	
	while(T--)solve();
	return 0;
}
