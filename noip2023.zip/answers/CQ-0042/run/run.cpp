#include<bits/stdc++.h>
#define int long long
#define ls rt<<1
#define rs rt<<1|1
#define mid ((l+r)>>1)
#define pii pair<int,int>
#define fi first
#define se second
using namespace std;
const int N=2e5+5;
const int inf=1e16;

char buf[1<<23],*p1=buf,*p2=buf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
int read(){
	int s=0,w=1;char ch=getchar();
	while(!isdigit(ch)){if(ch=='-')w=-1;ch=getchar();}
	while(isdigit(ch))s=s*10+(ch^48),ch=getchar();
	return s*w;
}
void file(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
}

vector<int>vec;
vector<pii>item[N];
int l[N],r[N],v[N];
int cas,T,n,m,sz,k,d;

int f[N];
struct Tree{
	int mx,tag;
} t[N<<2];

void pushup(int rt){
	t[rt].mx=max(t[ls].mx,t[rs].mx);
}
void upd(int rt,int v){
	t[rt].mx+=v,t[rt].tag+=v;
}
void pushdown(int rt){
	if(t[rt].tag==0)return ;
	upd(ls,t[rt].tag),upd(rs,t[rt].tag);
	t[rt].tag=0;
}
void build(int l,int r,int rt){
	t[rt].tag=0;
	if(l==r)return t[rt].mx=vec[l-1]*d,void();
	build(l,mid,ls),build(mid+1,r,rs),pushup(rt);
}
void change(int l,int r,int rt,int L,int R,int v){
	if(L<=l&&r<=R)return upd(rt,v),void(); pushdown(rt);
	if(L<=mid)change(l,mid,ls,L,R,v);
	if(mid<R)change(mid+1,r,rs,L,R,v);
	pushup(rt);
}
int query(int l,int r,int rt,int L,int R){
	if(L<=l&&r<=R)return t[rt].mx; pushdown(rt);
	int res=-inf;
	if(L<=mid)res=max(res,query(l,mid,ls,L,R));
	if(mid<R)res=max(res,query(mid+1,r,rs,L,R));
	return res;
}

void solve(){
	n=read(),m=read(),k=read(),d=read();
	
	vec.clear();
	
	for(int i=1;i<=m;++i)
		r[i]=read(),l[i]=read(),v[i]=read(),l[i]=r[i]-l[i]+1,
		vec.push_back(l[i]),vec.push_back(r[i]);
	sort(vec.begin(),vec.end());
	vec.erase(unique(vec.begin(),vec.end()),vec.end());
	sz=vec.size();
	
	for(int i=1;i<=m;++i)
		l[i]=lower_bound(vec.begin(),vec.end(),l[i])-vec.begin()+1,
		r[i]=lower_bound(vec.begin(),vec.end(),r[i])-vec.begin()+1,
		item[r[i]].push_back(pii(l[i],v[i]));
		
	f[0]=0;
	for(int i=1;i<=sz;++i)
		f[i]=-inf;
		
	build(1,sz,1);
		
	for(int i=1,j=1;i<=sz;++i){
		
		for(auto it:item[i]) 
			change(1,sz,1,1,it.fi,it.se);
				
		if(vec[i-2]+1==vec[i-1])
			change(1,sz,1,i,i,f[i-2]);
		else 
			change(1,sz,1,i,i,f[i-1]);
		
		
		while(vec[i-1]-vec[j-1]+1>k)++j;
		
		f[i]=query(1,sz,1,j,i);
		
		f[i]-=(vec[i-1]+1)*d;
		
		f[i]=max(f[i],f[i-1]);
	}
	
	printf("%lld\n",f[sz]);
	
	for(int i=1;i<=sz;++i)
		item[i].clear();
}

signed main(){
//	freopen("run5.in","r",stdin);
//	freopen("mine.out","w",stdout);
//	freopen("data.in","r",stdin);
	
	file();
	cas=read(),T=read();
	while(T--)solve();
	return 0;
}

