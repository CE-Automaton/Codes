#include<bits/stdc++.h>
using namespace std;
const int N=1e6+5;

char buf[1<<23],*p1=buf,*p2=buf;
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
int read(){
	int s=0,w=1;char ch=getchar();
	while(!isdigit(ch)){if(ch=='-')w=-1;ch=getchar();}
	while(isdigit(ch))s=s*10+(ch^48),ch=getchar();
	return s*w;
}
void file(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
}

int A[N],B[N],a[N],b[N];
int c,n,m,q;

bool f[205][205];

signed main(){
	file();
	
	c=read(),n=read(),m=read(),q=read();
	
	for(int i=1;i<=n;++i)A[i]=read(),a[i]=A[i];
	for(int i=1;i<=m;++i)B[i]=read(),b[i]=B[i];
	
	
	for(int _=0;_<=q;++_){		
	
		if(n<=200&&m<=200){
			memset(f,0,sizeof(f));	
			f[0][0]=1;
			for(int i=1;i<=n;++i)
				for(int j=1;j<=m;++j)
					for(int k=j;k>=1;--k)
						if(b[k]>a[i])
							f[i][j]|=f[i-1][k]|f[i-1][k-1];
						else break;
						
			if(f[n][m])putchar('1');
			else {
				memset(f,0,sizeof(f));	
				f[0][0]=1;
				for(int i=1;i<=m;++i)
					for(int j=1;j<=n;++j)
						for(int k=j;k>=1;--k)
							if(a[k]>b[i])
								f[i][j]|=f[i-1][k]|f[i-1][k-1];
							else break;	
				if(f[m][n])putchar('1');
				else putchar('0');
			}
		} else {
			
			putchar('0');
			
		}
		
		if(_<q){
			for(int i=1;i<=n;++i)a[i]=A[i];
			for(int i=1;i<=m;++i)b[i]=B[i];
		
			int kx=read(),ky=read();
			for(int i=1,px,vx;i<=kx;++i)	
				px=read(),vx=read(),a[px]=vx;
			for(int i=1,py,vy;i<=ky;++i)	
				py=read(),vy=read(),b[py]=vy;
		}
	}
	return 0;
}

