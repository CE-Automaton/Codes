#include<bits/stdc++.h>
using namespace std;
const int N=3005;
const int M=3005;

void file(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
}

char s[N];
vector<int>mn[N],mx[N];
string a[N],b[N];
string mn1,mn2,mx1,mx2;
int n,m;

signed main(){
//	freopen("dict4.in","r",stdin);
//	freopen("mine.out","w",stdout);
	file();
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	
	cin>>n>>m;
	for(int i=1;i<=n;++i){
		cin>>s;
		for(int j=0;j<m;++j)
			mn[i].push_back(s[j]-'a'),
			mx[i].push_back(s[j]-'a');
		sort(mn[i].begin(),mn[i].end());
		sort(mx[i].begin(),mx[i].end(),greater<int>());	
		for(int j=0;j<m;++j)
			a[i].push_back(mn[i][j]+'a'),
			b[i].push_back(mx[i][j]+'a');
//		cerr<<a[i]<<" "<<b[i]<<endl;
	}
	
	for(int i=0;i<m;++i)
		mn1.push_back('z'),mn2.push_back('z'),
		mx1.push_back('a'),mx2.push_back('a');
	
	for(int i=1;i<=n;++i){
		if(b[i]<mn1)mn2=mn1,mn1=b[i];
		else if(b[i]<mn2)mn2=b[i];
		
		if(a[i]>mx1)mx2=mx1,mx1=a[i];
		else if(a[i]>mx2)mx2=a[i];
	}
	
//	cerr<<mn1<<endl;
//	cerr<<mn2<<endl;
//	cerr<<mx1<<endl;
//	cerr<<mx2<<endl;
	
	for(int i=1;i<=n;++i){
		if(b[i]==mn1){
			if(a[i]<mn2)putchar('1');
			else putchar('0');
		} else{
			if(a[i]<mn1)putchar('1');
			else putchar('0');
		}
	}
	return 0;
}

