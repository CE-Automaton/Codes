//16
#include<bits/stdc++.h>
typedef long long ll;
using namespace std;
int c, t;
int n, m, k, d;
ll dp[105], maxn[105], ans;
struct node {
	int y, v;
	bool operator <(const node &t) const{
		return y < t.y;
	}
};
vector<node> w[1005];
int main() {
	freopen("run.in", "r", stdin); 
	freopen("run.out", "w", stdout);
	scanf("%d %d", &c, &t);
	while(t--) {
		ans = 0;
		scanf("%d %d %d %d", &n, &m, &k, &d);
		for(int i = 1; i <= n; i++) w[i].clear();
		for(int i = 0; i <= n; i++) dp[i] = maxn[i] = 0;
		for(int i = 1, x, y, v; i <= m; i++) {
			scanf("%d %d %d", &x, &y, &v);
			w[x].push_back(node({y, v}));
		}
		for(int i = 1; i <= n; i++) {
			if(!w[i].empty()) sort(w[i].begin(), w[i].end()); 
		}
		for(int i = 1; i <= n; i++) {
			for(int j = 1; j <= k; j++) {
				if(i - j < 0) break;
				ll sum = 0;
				for(int l = i - j + 1; l <= i; l++) {
					for(int ff = 0; ff < w[l].size(); ff++) {
						if(w[l][ff].y <= j - (i - l)) sum += w[l][ff].v;
						else break;
					}
				}
				dp[i] = max(dp[i], maxn[i - j - 1] + sum - 1ll * d * j);
			}
			ans = max(ans, dp[i]);
//			cout<<dp[i]<<endl;
			maxn[i] = max(maxn[i - 1], dp[i]);
		}
		printf("%lld\n", ans);
	} 
	return 0;
}
