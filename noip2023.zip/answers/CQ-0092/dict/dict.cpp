//100
#include<bits/stdc++.h>
using namespace std;
const int inf = 0x3f3f3f3f;
int n, m;
char s[3005][3005];
int minn[3005], maxn[3005];
int main() {
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);
	scanf("%d %d", &n, &m);
	for(int i = 1; i <= n; i++) {
		minn[i] = inf, maxn[i] = -inf;
		for(int j = 1; j <= m; j++) {
			cin>>s[i][j];
			minn[i] = min(minn[i], s[i][j] - 'a');
			maxn[i] = max(maxn[i], s[i][j] - 'a');
		}
	}
	for(int i = 1; i <= n; i++) {
		int flg = true;
		for(int j = 1; j <= n; j++) {
			if(i == j) continue;
			if(maxn[j] <= minn[i]) {
				flg = false;
				break;
			}
		} 
		printf("%d", flg);
	}
	return 0;
}
