#include<bits/stdc++.h>
using namespace std;
int c, n, m, q;
int x[500005], y[500005];
//struct node {
//	int x, p, y;
//	bool operator <(const node &t) const {
//		return y > t.y || y == t.y && x > t.x || y == t.y && x == y.x && p > t.p;
//	}	
//};
namespace sub2 {
	int tim[500005];
	void solve() {
		bool flg;
//		priority_queue<node> q;
		for(int i = 1; i <= n; i++) scanf("%d", &x[i]);
		for(int i = 1; i <= m; i++) {
//			scanf("%d", &y[i]), tim[i] = q, q.push_back(node({i, q, y[i]}));
		}
		if(x[n] < y[m]) putchar('1');
		else putchar('0');
		while(q--) {
			int kx, ky;
			scanf("%d %d", &kx, &ky);
			for(int i = 1, p, v; i <= kx; i++) {
				scanf("%d %d", &p, &v);
				x[p] = v;
			}
			for(int i = 1, p, v; i <= ky; i++) {
				scanf("%d %d", &p, &v);
				y[p] = v;
			}
			cout<<x[n]<<' '<<y[m]<<endl;
			if(x[n] < y[m]) putchar('1');
			else putchar('0');
		}
	}
};
int main() {
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);
	scanf("%d %d %d %d", &c, &n, &m, &q);
//	if(8 <= c && c <= 14) {
//		sub2::solve();
//	} else {
//		bool flg = false;
		for(int i = 1; i <= n; i++) scanf("%d", &x[i]);
		for(int i = 1; i <= m; i++) scanf("%d", &y[i]);
		if(x[n] < y[m] && x[1] < y[1] || x[n] > x[m] && x[1] > y[1]) putchar('1');
		else putchar('0');
		while(q--) {
			int kx, ky;
			scanf("%d %d", &kx, &ky);
			for(int i = 1, p, v; i <= kx; i++) {
				scanf("%d %d", &p, &v);
				x[p] = v;
			}
			for(int i = 1, p, v; i <= ky; i++) {
				scanf("%d %d", &p, &v);
				y[p] = v;
			}
//			cout<<x[n]<<' '<<y[m]<<endl;
			if(x[n] < y[m] && x[1] < y[1] || x[n] > x[m] && x[1] > y[1]) putchar('1');
			else putchar('0');
		}
//	}
	return 0;
}
