#include<bits/stdc++.h>
using namespace std;
int c, t;
int n, m;
char opt[100005];
int x[100005], y[100005];
int pre[100005], a[100005];
bool flg = false;
void dfs(int d, int cnt) {
	if(flg) return;
	if(d == n + 1) {
		for(int i = 1; i <= n; i++) a[i] = pre[i];
		for(int i = 1; i <= m; i++) {
			if(opt[i] == 'T') a[x[i]] = 1;
			else if(opt[i] == 'F') a[x[i]] = 0;
			else if(opt[i] == 'U') a[x[i]] = -1;
			else if(opt[i] == '+') a[x[i]] = a[y[i]];
			else if(opt[i] == '-') {
				if(a[y[i]] == -1) a[x[i]] = -1;
				else a[x[i]] = 1 - a[y[i]];
			}
		}
		bool vis = true;
		for(int i = 1; i <= n; i++) {
			if(pre[i] != a[i]) vis = false;
		}
		if(vis) {
			cout<<cnt<<endl;
			flg = true;
		}
		return;
	}
	pre[d] = 0;
	dfs(d + 1, cnt);
	pre[d] = 1;
	dfs(d + 1, cnt);
	pre[d] = -1;
	dfs(d + 1, cnt + 1);
	pre[d] = 0;
}
int main() {
	freopen("tribool.in", "r", stdin);
	freopen("tribool.out", "w", stdout);
	scanf("%d %d", &c, &t);
	if(1 <= c && c <= 2) {
		while(t--) {
			scanf("%d %d", &n, &m);
			for(int i = 1; i <= m; i++) {
				while((opt[i] = getchar()) && (opt[i] != 'T' && opt[i] != 'F' && opt[i] != 'U' && opt[i] != '+' && opt[i] != '-'));
				if(opt[i] == 'T' || opt[i] == 'F') {
					scanf("%d", &x[i]);
				} else if(opt[i] == 'U') {
					scanf("%d", &x[i]);
				} else if(opt[i] == '+') {
					scanf("%d %d", &x[i], &y[i]);
				} else if(opt[i] == '-') {
					scanf("%d %d", &x[i], &y[i]);
				}
			}
			flg = false;
			dfs(1, 0);
		}
	} else if(3 <= c && c <= 4) {
		while(t--) {
			scanf("%d %d", &n, &m);
			for(int i = 1; i <= n; i++) pre[i] = false;
			for(int i = 1; i <= m; i++) {
				while((opt[i] = getchar()) && (opt[i] != 'T' && opt[i] != 'F' && opt[i] != 'U' && opt[i] != '+' && opt[i] != '-'));
				if(opt[i] == 'T' || opt[i] == 'F') {
					scanf("%d", &x[i]);
					pre[x[i]] = false;
				} else if(opt[i] == 'U') {
					scanf("%d", &x[i]);
					pre[x[i]] = true;
				}
			}
			int ans = 0;
			for(int i = 1; i <= n; i++) {
				ans += pre[i]; 
			}
			printf("%d\n", ans);
		}	
	} else if(5 <= c) {
		while(t--) {
			int cnt = 0;
			scanf("%d %d", &n, &m);
			for(int i = 1; i <= n; i++) pre[i] = 0;
			for(int i = 1; i <= m; i++) {
				while((opt[i] = getchar()) && (opt[i] != 'T' && opt[i] != 'F' && opt[i] != 'U' && opt[i] != '+' && opt[i] != '-'));
				if(opt[i] == 'U') {
					scanf("%d", &x[i]);
					pre[x[i]] = 1;
				} else {
					scanf("%d %d", &x[i], &y[i]);
					pre[x[i]] = pre[y[i]];
//					if(x[i] == y[i]) pre[x[i]] = true;
				}
			}
//			for(int i = m; i >= 1; i--) {
////				while((opt[i] = getchar()) && (opt[i] != 'T' && opt[i] != 'F' && opt[i] != 'U' && opt[i] != '+' && opt[i] != '-'));
//				if(opt[i] == 'U') {
////					scanf("%d", &x[i]);
//					pre[x[i]] = 1;
//				} else {
////					scanf("%d %d", &x[i], &y[i]);
//					pre[x[i]] = pre[y[i]];
//				}
//			}
			int ans = 0;
			for(int i = 1; i <= n; i++) {
				ans += pre[i]; 
			}
			printf("%d\n", ans);
		}
	}
	return 0;
}
