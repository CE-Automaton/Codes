#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=3005;
int n,m,mi[N],mx[N];
char s[N];
int main(){freopen("dict.in","r",stdin),freopen("dict.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("%s",s+1),mi[i]=26;
		for(int j=1;j<=m;j++)mi[i]=min(mi[i],s[j]-'a'),mx[i]=max(mx[i],s[j]-'a');
	}
	for(int i=1;i<=n;i++){
		bool tag=1;
		for(int j=1;j<=n;j++)if(i!=j){
			if(mi[i]>=mx[j])tag=0;
		}
		printf("%d",tag);
	}
}
