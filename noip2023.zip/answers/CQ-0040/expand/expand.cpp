#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=5e5+5;
int T,t,n,m,a[N],b[N],s1[N],s2[N],f1[N],f2[N],tot1,tot2;
int nn,mm,c[N],d[N],C[N],D[N],op;
void solve(){
	if(c[1]==d[1])return cout<<'0',void();
	if(c[1]<d[1])n=nn,m=mm,memcpy(a,c,sizeof(c)),memcpy(b,d,sizeof(d));
	else n=mm,m=nn,memcpy(b,c,sizeof(c)),memcpy(a,d,sizeof(d));
	s1[0]=s2[0]=0,tot1=tot2=0,a[0]=1e9+5,b[0]=-5;
	for(int i=1;i<=n;i++)if(a[i]<a[s1[tot1]])s1[++tot1]=i;
	for(int i=1;i<=m;i++)if(b[i]>b[s2[tot2]])s2[++tot2]=i;
	for(int j=1,k=1,i=1;i<=s1[tot1];i++){
		while(k<=tot2&&b[s2[k]]<=a[i])k++;
		if(k>tot2)return cout<<'0',void();
		if(s1[j]==i)f1[j++]=k;
	}
	for(int j=1,k=1,i=1;i<=s2[tot2];i++){
		while(k<=tot1&&a[s1[k]]>=b[i])k++;
		if(k>tot1)return cout<<'0',void();
		if(s2[j]==i)f2[j++]=k;
	}
	int l1=1,l2=1;
	while(l1<tot1||l2<tot2){
		if((l1==tot1||f1[l1+1]>l2)&&(l2==tot2||f2[l2+1]>l1))return cout<<'0',void();
		while(l1<tot1&&f1[l1+1]<=l2)l1++;
		while(l2<tot2&&f2[l2+1]<=l1)l2++;
	}
	l1=s1[tot1],l2=s2[tot2],s1[0]=l1-1,s2[0]=l2-1,tot1=tot2=0;
	for(int i=l1;i<=n;i++){
		while(tot1&&a[s1[tot1]]>a[i])tot1--;
		s1[++tot1]=i;
	}
	for(int i=l2;i<=m;i++){
		while(tot2&&b[s2[tot2]]<b[i])tot2--;
		s2[++tot2]=i;
	}
	for(int j=tot1,k=tot2,i=n;i>=l1;i--){
		while(k&&b[s2[k]]<=a[i])k--;
		if(!k)return cout<<'0',void();
		if(s1[j-1]+1==i)f1[j--]=k;
	}
	for(int j=tot2,k=tot1,i=m;i>=l2;i--){
		while(k&&a[s1[k]]>=b[i])k--;
		if(!k)return cout<<'0',void();
		if(s2[j-1]+1==i)f2[j--]=k;
	}
	l1=tot1,l2=tot2;
	while(l1>1||l2>1){
		if((l1==1||f1[l1]<l2)&&(l2==1||f2[l2]<l1))return cout<<'0',void();
		if(l1==1||f1[l1]<l2)l2--;
		else l1--;
	}
	cout<<'1';
}
int main(){freopen("expand.in","r",stdin),freopen("expand.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	cin>>T>>nn>>mm>>t;
	for(int i=1;i<=nn;i++)cin>>C[i];
	for(int i=1;i<=mm;i++)cin>>D[i];
	memcpy(c,C,sizeof(c)),memcpy(d,D,sizeof(d)),solve();
	for(int p,q,x,y,i=1;i<=t;i++){
		op=i;
		cin>>p>>q,memcpy(c,C,sizeof(c)),memcpy(d,D,sizeof(d));
		while(p--)cin>>x>>y,c[x]=y;
		while(q--)cin>>x>>y,d[x]=y;
		solve();
	}
}
