#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=3e5+5,M=N<<2;
int T,t,n,m,len,d,qx[N],qy[N],qz[N],p[N],tot;ll asw;vector<pair<int,int>>v[N];
struct tree {
	int l[M],r[M];ll ma[M],tag[M];
	#define ls (k<<1)
	#define rs (k<<1|1)
	void Pd(int k,ll v){
		ma[k]+=v,tag[k]+=v;
	}
	void pd(int k){
		if(tag[k])Pd(ls,tag[k]),Pd(rs,tag[k]),tag[k]=0;
	}
	void pu(int k){
		ma[k]=max(ma[ls],ma[rs]);
	}
	void build(int L=1,int R=tot,int k=1){
		ma[k]=1ll*d*p[R],tag[k]=0,l[k]=L,r[k]=R;
		if(L==R)return;int mid=L+R>>1;
		build(L,mid,ls),build(mid+1,R,rs);
	}
	void add(int u,int v,int k=1){
		if(u<l[k])return;if(r[k]<=u)return Pd(k,v);
		pd(k),add(u,v,ls),add(u,v,rs),pu(k);
	}
	ll ask(int L,int R,int k=1){
		if(R<l[k]||r[k]<L)return -1e18;if(L<=l[k]&&r[k]<=R)return ma[k];
		return pd(k),max(ask(L,R,ls),ask(L,R,rs));
	}
	void change(int u,ll v,int k=1){
		if(u<l[k]||r[k]<u)return;if(l[k]==r[k])return ma[k]=v,void();
		pd(k),change(u,v,ls),change(u,v,rs),pu(k);
	}
}tt;
int main(){freopen("run.in","r",stdin),freopen("run.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	cin>>T>>t;
	while(t--){
		cin>>n>>m>>len>>d,tot=0;
		for(int i=1;i<=m;i++)cin>>qy[i]>>qx[i]>>qz[i],p[++tot]=qy[i]-qx[i]-1,tot++,p[tot]=p[tot-1]+1,p[++tot]=qy[i];
		sort(p+1,p+1+tot),tot=unique(p+1,p+1+tot)-p-1,tt.build();
		for(int x,y,i=1;i<=m;i++){
			x=lower_bound(p+1,p+1+tot,qy[i]-qx[i])-p,y=lower_bound(p+1,p+1+tot,qy[i])-p,v[y].push_back({x,qz[i]});
		}
		for(int i=1;i<=tot;i++){
			for(auto j:v[i])tt.add(j.first,j.second);
			int w=lower_bound(p+1,p+1+tot,p[i]-len)-p;
			ll res=tt.ask(w,i)-1ll*d*p[i];
			if(i==tot)asw=res;
			else tt.change(i+1,res+1ll*d*p[i+1]);
			v[i].clear();
		}
		cout<<asw<<'\n';
	}
}
