#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=1e5+5;
int T,t,n,m,f[N],g[N*2],fa[N*2],asw;bool tag;
int get(int u){return fa[u]==u?u:fa[u]=get(fa[u]);}
void merge(int x,int y){
	x=get(x),y=get(y);
	if(x!=y)g[x]|=g[y],fa[y]=x;
}
int main(){freopen("tribool.in","r",stdin),freopen("tribool.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	cin>>T>>t;
	while(t--){
		cin>>n>>m,iota(fa,fa+1+2*n,0),iota(f,f+1+n,0),fill(g+1,g+1+2*n,0),asw=0;
		char op;
		for(int x,y,i=1;i<=m;i++){
			cin>>op>>x;
			if(op=='T')f[x]=-1;
			else if(op=='F')f[x]=-2;
			else if(op=='U')f[x]=-3;
			else if(op=='+')cin>>y,f[x]=f[y];
			else {
				cin>>y;
				if(f[y]>n)f[x]=f[y]-n;
				else if(f[y]>=1)f[x]=f[y]+n;
				else if(f[y]==-1)f[x]=-2;
				else if(f[y]==-2)f[x]=-1;
				else f[x]=-3;
			}
		}
		for(int i=1;i<=n;i++){
			if(f[i]<=0)g[get(i)]=f[i],g[get(i+n)]=f[i]==-1?-2:(f[i]==-2?-1:-3);
			else {
				if(f[i]<=n)merge(i,f[i]),merge(i+n,f[i]+n);
				else merge(i,f[i]),merge(i+n,f[i]-n);
			}
		}
		for(int i=1;i<=n;i++)if(get(i)==get(i+n)||g[get(i)]==-3)asw++;
		cout<<asw<<'\n';
	}
}
