#include<bits/stdc++.h>
using namespace std;
char ch;
int read(){
    int x=0;bool f=0;
    ch=getchar();
    while(!isdigit(ch))ch=getchar();
    while(isdigit(ch))x=(x<<1)+(x<<3)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
const int maxn=2e5+2;
int C,T;
int n,m;
struct node{
    int ty,id;
}va[maxn];
struct UFS{
    int fa[maxn*2],siz[maxn*2];
    void init(int mx){
        for(int i=1;i<=mx;i++)fa[i]=i,siz[i]=1;
        return ;
    }
    int find(int x){
        if(x==fa[x])return x;
        return fa[x]=find(fa[x]);
    }
    void merge(int u,int v){
        u=find(u),v=find(v);
        if(u==v)return ;
        if(siz[u]>siz[v])swap(u,v);
        fa[u]=v,siz[v]+=siz[u];
        return ;
    }
}ufs;
vector<int>rt;
vector<int>G[maxn*2],has[maxn*2];
int ans[maxn*2],dep[maxn*2],bel[maxn*2];
bool vis[maxn*2],ins[maxn*2],use[maxn*2];
int id(int x,int ty){return ty*n+x;}
void add(int u,int v){
    G[u].push_back(v);
}
void dfs(int x,int f,int R){
    bel[x]=R,has[R].push_back(x);
    vis[x]=1,ins[x]=1,dep[x]=dep[f]+1;
    for(int i=0,v;i<G[x].size();i++){
        v=G[x][i];
        if(vis[v]){
            if(ins[v]&&(dep[x]-dep[v])%2==0)ans[x]=1;
            continue;
        }
        dfs(v,x,R);
    }
    ins[x]=0;
    return ;
}
int main(){
    freopen("tribool.in","r",stdin);
    freopen("tribool.out","w",stdout);
    C=read(),T=read();
    while(T--){
        n=read(),m=read();
        for(int i=1;i<=2*n;i++)G[i].clear(),has[i].clear(),vis[i]=use[i]=ans[i]=0;
        rt.clear(),ufs.init(2*n);
        int x,y;
        for(int i=1;i<=n;i++)va[i].ty=0,va[i].id=i;
        for(int i=1;i<=m;i++){
            while(ch!='+'&&ch!='-'&&ch!='T'&&ch!='F'&&ch!='U')ch=getchar();
            // cout<<i<<' '<<ch<<'\n';
            if(ch=='T'||ch=='F'||ch=='U'){
                int vo=((ch=='U')?2:((ch=='T')?1:0));
                x=read();
                va[x]=(node){2,vo};
            }
            else if(ch=='+'){
                x=read(),y=read();
                va[x]=va[y];
            }
            else {
                x=read(),y=read();
                va[x]=va[y];
                if(va[x].ty==2&&va[x].id<2)va[x].id^=1;
                if(va[x].ty<2)va[x].ty^=1;
            }
        }
        for(int i=1;i<=n;i++){
            // printf("va :%d (%d %d)\n",i,va[i].ty,va[i].id);
            if(va[i].ty<2)ufs.merge(id(va[i].id,va[i].ty),id(i,0));
        }
        // for(int i=1;i<=n;i++)printf("rtof %d =(%d %d) (%d %d)\n",i,ufs.find(id(i,0)),ufs.find(id(i,1)),id(i,0),id(i,1));
        for(int i=1,rt0,rt1;i<=n;i++){
            rt0=ufs.find(id(i,0)),rt1=ufs.find(id(i,1));
            if(rt0==rt1)ans[rt0]=ans[rt1]=1;
            else add(rt0,rt1),add(rt1,rt0);
            if(rt0==id(i,0))rt.push_back(id(i,0));
            if(rt1==id(i,1))rt.push_back(id(i,1));
            if(va[i].ty==2&&va[i].id==2)ans[rt0]=ans[rt1]=1;
        }
        for(int i=0;i<rt.size();i++){
            if(!vis[rt[i]])dfs(rt[i],0,rt[i]);
        }
        for(int i=1;i<=2*n;i++){
            if(ans[i]==1&&!use[bel[i]]){
                for(int j=0;j<has[bel[i]].size();j++)ans[has[bel[i]][j]]=1;
                use[bel[i]]=1;
            }
        }
        int outnum=0;
        for(int i=1;i<=n;i++)outnum+=ans[ufs.find(id(i,0))];
        printf("%d\n",outnum);
    }
    return 0;
}