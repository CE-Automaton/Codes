#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;
    char ch=getchar();
    while(!isdigit(ch))ch=getchar();
    while(isdigit(ch))x=(x<<1)+(x<<3)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
const int maxn=2e5+2;
int Cid,T;
int n,m,K,D;
bool use[maxn];
struct node{
    int l,r,v;
}s[maxn];
bool cmpr(node A,node B){
    return A.r<B.r;
}
bool check_n(){
    for(int i=2;i<=n;i++)if(s[i-1].r>=s[i].l)return 0;
    return 1;
}
struct node_pa{
    int l,r;
    bool operator < (const node_pa &A)const{
        return (l!=A.l)?(l<A.l):(r<A.r);
    }
};
map<node_pa,int>id;
namespace brute1{
    int len;
    int ve[maxn*2];
    node ns[maxn];
    vector<int>vo[maxn*2];
    long long dp[maxn*2];
    void solve(){
        // printf("boom\n");
        len=0;
        for(int i=1;i<=m;i++)ve[++len]=s[i].l,ve[++len]=s[i].r;
        sort(ve+1,ve+len+1);
        len=unique(ve+1,ve+len+1)-ve-1;
        for(int i=1;i<=len;i++)vo[i].clear();
        // for(int i=1;i<=len;i++)printf("%d ",ve[i]);
        // putchar('\n');
        for(int i=1;i<=m;i++){
            if(use[i])continue;
            ns[i].l=lower_bound(ve+1,ve+len+1,s[i].l)-ve;
            ns[i].r=lower_bound(ve+1,ve+len+1,s[i].r)-ve;
            vo[ns[i].r].push_back(i);
        }
        long long mx=0;
        memset(dp,0,sizeof(dp));
        bool ff=0;
        for(int i=1;i<=len;i++){
            long long sum=0;
            for(int j=i;j<=len&&ve[j]-ve[i]+1<=K;j++){
                for(int k=0;k<vo[j].size();k++){
                    // printf("vo[%d][%d]=%d %d %d\n",j,k,vo[j][k],s[vo[j][k]].l,ve[i]);
                    if(s[vo[j][k]].l>=ve[i])sum+=1ll*s[vo[j][k]].v;
                }
                dp[j]=max(dp[j],mx+sum-1ll*D*(ve[j]-ve[i]+1));
                // printf("upd(%d %d) %lld %lld %lld %lld\n",i,j,mx,sum,1ll*D*(ve[j]-ve[i]+1),dp[j]);
            }
            if(ff)mx=max(mx,dp[i-1]);
            if(ve[i]+1==ve[i+1])ff=1;
            else ff=0,mx=max(mx,dp[i]);
        }
        mx=max(mx,dp[len]);
        printf("%lld\n",mx);
    }
}
namespace brute2{
    void solve(){
        long long ans=0;
        for(int i=1;i<=m;i++)if(s[i].r-s[i].l+1<=K)ans+=1ll*s[i].v;
        printf("%lld\n",ans);
    }
}
int main(){
    freopen("run.in","r",stdin);
    freopen("run.out","w",stdout);
    Cid=read(),T=read();
    while(T--){
        n=read(),m=read(),K=read(),D=read();
        for(int i=1;i<=m;i++){
            s[i].r=read(),s[i].l=s[i].r-read()+1,s[i].v=read();
        }
        sort(s+1,s+m+1,cmpr);
        for(int i=1;i<=m;i++){
            if(id[(node_pa){s[i].l,s[i].r}]!=0)s[id[(node_pa){s[i].l,s[i].r}]].v+=s[i].v,use[i]=1;
            else id[(node_pa){s[i].l,s[i].r}]=i;
        }
        if(K<=100||min(n,m)<=1000)brute1::solve();
        else if(check_n())brute2::solve();
        for(int i=1;i<=m;i++)id[(node_pa){s[i].l,s[i].r}]=0,use[i]=0;
    }
    return 0;
}