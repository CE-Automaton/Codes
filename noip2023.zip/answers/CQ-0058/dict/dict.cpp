#include<bits/stdc++.h>
using namespace std;
#define ull unsigned long long
const int maxn=3e3+7;
const ull pri=37;
int n,m;
char s[maxn][maxn],a[maxn][maxn],b[maxn][maxn];
ull pw[maxn],ha[maxn][maxn],hb[maxn][maxn];
bool ans[maxn];
bool cmp1(char A,char B){return A<B;}
bool cmp2(char A,char B){return A>B;}
ull query(int id,int l,int r,int ty){
    if(l>r)return 0;
    if(!ty)return hb[id][r]-hb[id][l-1]*pw[r-l+1];
    else return ha[id][r]-ha[id][l-1]*pw[r-l+1];
}
bool check(int A,int B){
    int l=0,r=m,mid,pos;
    while(l<=r){
        mid=(l+r)>>1;
        if(query(A,1,mid,0)==query(B,1,mid,1))pos=mid,l=mid+1;
        else r=mid-1;
    }
    // if(A==1)printf("pos=%d\n",pos),cout<<b[A][pos+1]<<' '<<a[B][pos+1]<<'\n';
    // if(A==4&&B==2)printf("pos: %d\n",pos),cout<<b[A][pos+1]<<'\n'<<a[B][pos+1]<<'\n'<<"la:"<<(query(A,1,1,0)==query(B,1,1,1))<<'\n';
    if(pos==m||b[A][pos+1]>a[B][pos+1])return 0;
    else return 1;
}
int main(){
    freopen("dict.in","r",stdin);
    freopen("dict.out","w",stdout);
    scanf("%d%d",&n,&m);
    pw[0]=1;for(int i=1;i<=m;i++)pw[i]=pw[i-1]*pri;
    for(int i=1;i<=n;i++){
        scanf("%s",s[i]+1);
        for(int j=1;j<=m;j++){
            a[i][j]=b[i][j]=s[i][j];
        }
        sort(a[i]+1,a[i]+m+1,cmp2);
        sort(b[i]+1,b[i]+m+1,cmp1);
        for(int j=1;j<=m;j++){
            ha[i][j]=ha[i][j-1]*pri+(ull)(a[i][j]-'a');
            hb[i][j]=hb[i][j-1]*pri+(ull)(b[i][j]-'a');
        }
    }
    // cerr<<"Boom\n";
    // printf("check %d\n",check(4,2));
    for(int i=1;i<=n;i++){
        ans[i]=1;
        for(int j=1;j<=n;j++){
            if(i==j)continue;
            ans[i]&=check(i,j);
        }
        putchar(ans[i]+'0');
    }
    return 0;
}