#include<bits/stdc++.h>
using namespace std;
int read(){
    int x=0;bool f=0;
    char ch=getchar();
    while(!isdigit(ch))ch=getchar();
    while(isdigit(ch))x=(x<<1)+(x<<3)+ch-'0',ch=getchar();
    return (f)?-x:x;
}
int Cid;
int n,m,Q;
namespace brute1{
    const int maxn=2e3+2;
    int xr[maxn],yr[maxn];
    struct node{
        int ty,x,v;
    };
    vector<node>rep;
    bool dp[maxn][maxn];
    void trsolve(){
        if(xr[1]==yr[1]){putchar('0');return ;}
        bool f=0;
        if(xr[1]>yr[1])swap(xr,yr),swap(n,m),f=1;
        for(int i=1;i<=n;i++)
            for(int j=1;j<=m;j++)dp[i][j]=0;

        // printf("xy:\n");
        // for(int i=1;i<=n;i++)printf("%d ",xr[i]);
        // putchar('\n');
        // for(int i=1;i<=m;i++)printf("%d ",yr[i]);
        // putchar('\n');
        dp[1][1]=1;
        for(int i=1;i<=n;i++){
            for(int j=1;j<=m;j++){
                if(i<n&&j<m)dp[i+1][j+1]|=(dp[i][j]&(xr[i+1]<yr[j+1]));
                if(i<n)dp[i+1][j]|=(dp[i][j]&(xr[i+1]<yr[j]));
                if(j<m)dp[i][j+1]|=(dp[i][j]&(xr[i]<yr[j+1]));
            }
        }
        putchar(dp[n][m]+'0');
        if(f)swap(xr,yr),swap(n,m);
        return ;
    }
    void solve(){
        n=read(),m=read(),Q=read();
        for(int i=1;i<=n;i++)xr[i]=read();
        for(int i=1;i<=m;i++)yr[i]=read();
        trsolve();
        for(int i=1;i<=Q;i++){
            int kx,ky,kp,kv;
            kx=read(),ky=read();
            for(int j=1;j<=kx;j++)kp=read(),kv=read(),rep.push_back((node){0,kp,xr[kp]}),xr[kp]=kv;
            for(int j=1;j<=ky;j++)kp=read(),kv=read(),rep.push_back((node){1,kp,yr[kp]}),yr[kp]=kv;
            trsolve();
            int siz=rep.size();
            while(siz){
                if(!rep[siz-1].ty)xr[rep[siz-1].x]=rep[siz-1].v;
                else yr[rep[siz-1].x]=rep[siz-1].v;
                rep.pop_back(),siz--;
            }
        }
    }
}
namespace brute2{
    mt19937 R(time(0));
    const int maxn=5e5+2;
    int xr[maxn],yr[maxn];
    struct node{
        int ty,x,v;
    };
    vector<node>rep;
    bool check(){
        int tp1=1,tp2=1;
        while(tp1<n||tp2<m){
            if(tp1==n){
                if(yr[tp2+1]<=xr[tp1])return 0;
                tp2++;
            }
            else if(tp2==m){
                if(yr[tp2]<=xr[tp1+1])return 0;
                tp1++;
            }
            else {
                bool f1=(xr[tp1+1]<yr[tp2]),f2=(xr[tp1]<yr[tp2+1]);
                if(!f1&&!f2)return 0;
                if(R()&1){
                    if(f1)tp1++;
                    else tp2++;
                }
                else {
                    if(f2)tp2++;
                    else tp1++;
                }
            }
        }
        if(xr[n]>=yr[m])return 0;
        return 1;
    }
    void trsolve(){
        if(xr[1]==yr[1]){putchar('0');return ;}
        bool f=0;
        if(xr[1]>yr[1])swap(xr,yr),swap(n,m),f=1;
        bool ret=0;
        for(int i=1;i<=100;i++)ret|=check();
        putchar(ret+'0');
        if(f)swap(xr,yr),swap(n,m);
    }
    void solve(){
        n=read(),m=read(),Q=read();
        for(int i=1;i<=n;i++)xr[i]=read();
        for(int i=1;i<=m;i++)yr[i]=read();
        trsolve();
        for(int i=1;i<=Q;i++){
            int kx,ky,kp,kv;
            kx=read(),ky=read();
            for(int j=1;j<=kx;j++)kp=read(),kv=read(),rep.push_back((node){0,kp,xr[kp]}),xr[kp]=kv;
            for(int j=1;j<=ky;j++)kp=read(),kv=read(),rep.push_back((node){1,kp,yr[kp]}),yr[kp]=kv;
            trsolve();
            int siz=rep.size();
            while(siz){
                if(!rep[siz-1].ty)xr[rep[siz-1].x]=rep[siz-1].v;
                else yr[rep[siz-1].x]=rep[siz-1].v;
                rep.pop_back(),siz--;
            }
        }
    }
}
int main(){
    freopen("expand.in","r",stdin);
    freopen("expand.out","w",stdout);
    Cid=read();
    // brute2::solve();
    if(Cid<=7)brute1::solve();
    else brute2::solve();
    return 0;
}