#include<bits/stdc++.h>
using namespace std;
int c,n,m,q,dp[2005][2005],op,p,v;
int a[2005],b[2005],aa[2005],bb[2005],kx,ky;
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	scanf("%d%d%d%d",&c,&n,&m,&q);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)scanf("%d",&b[i]);
//	dp[0][0]=1;
	if(a[1]>b[1])op=0;
	else op=1;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(i==1&&j==1){
				if((op&&a[i]<b[j])||(op==0&&a[i]>b[j]))dp[i][j]=1;
				else dp[i][j]=0;
			}
			else{
				if((dp[i-1][j]||dp[i][j-1])&&((op&&a[i]<b[j])||(op==0&&a[i]>b[j])))dp[i][j]=1;
				else dp[i][j]=0;
			}
		}
	}
	printf("%d",dp[n][m]);
	while(q--){
		scanf("%d%d",&kx,&ky);
		for(int i=1;i<=kx;i++)scanf("%d%d",&p,&v),aa[p]=v,swap(a[p],aa[p]);
		for(int i=1;i<=ky;i++)scanf("%d%d",&p,&v),bb[p]=v,swap(b[p],bb[p]);
		dp[0][0]=1;
		if(a[1]>b[1])op=0;
		else op=1;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				if(i==1&&j==1){
					if((op&&a[i]<b[j])||(op==0&&a[i]>b[j]))dp[i][j]=1;
					else dp[i][j]=0;
				}
				else{
					if((dp[i-1][j]||dp[i][j-1])&&((op&&a[i]<b[j])||(op==0&&a[i]>b[j])))dp[i][j]=1;
					else dp[i][j]=0;
				}
			}
		}
		printf("%d",dp[n][m]);
		for(int i=1;i<=kx;i++)swap(a[p],aa[p]);
		for(int i=1;i<=ky;i++)swap(b[p],bb[p]);
	}
}
