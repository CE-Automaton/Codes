#include<bits/stdc++.h>
using namespace std;
int c,t,n,m,fa[200010],now[100005],size[200010],vis[100005],last[100005];
int T_,F_,U_,N;
char s[5];
struct node{
	int op,x,y;
}a[100005];
int get_fa(int x){
	if(fa[x]==x)return x;
	return fa[x]=get_fa(fa[x]);
}
void make_fa(int x,int y){
	if(get_fa(x)!=get_fa(y)){
		size[fa[y]]+=size[fa[x]];
		fa[fa[x]]=fa[y];
	}
}
int ck(int x){
	if(x>2*n)return 4*n+4-x;
	return x>n?x-n:x+n;
}
int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	scanf("%d%d",&c,&t);
	while(t--){
		scanf("%d%d",&n,&m);
		T_=2*n+1;U_=2*n+2;F_=2*n+3;
		for(int i=1;i<=2*n+3;i++)fa[i]=i,size[i]=0;
		for(int i=1;i<=n;i++)size[i]=1,now[i]=i,vis[i]=0;
		for(int i=1;i<=m;i++){
			int x,y;
			scanf("%s",s+1);
			if(s[1]=='-'){
				scanf("%d%d",&x,&y);
				a[i].op=0;last[x]=i;
				a[i].x=x;a[i].y=y;
			}
			else if(s[1]=='+'){
				scanf("%d%d",&x,&y);
				a[i].op=1;last[x]=i;
				a[i].x=x;a[i].y=y;
			}
			else{
				scanf("%d",&x);
				a[i].x=x;last[x]=i;
				if(s[1]=='T')a[i].op=3;
				if(s[1]=='U')a[i].op=4;
				if(s[1]=='F')a[i].op=5;
			}
		}
		for(int i=1;i<=m;i++){
			if(a[i].op>=3){
				a[i].op+=2*n-2;
				if(i==last[a[i].x]){
					make_fa(a[i].x,a[i].op);
					make_fa(ck(a[i].x),ck(a[i].op));
					vis[a[i].x]=1;
				}
				now[a[i].x]=a[i].op;
			}
			else{
				a[i].y=a[i].op?now[a[i].y]:ck(now[a[i].y]);
				if(i==last[a[i].x]){
					if(get_fa(a[i].x)==get_fa(ck(a[i].y))){
						make_fa(a[i].x,U_);make_fa(ck(a[i].x),U_);
					}
					else{
						make_fa(a[i].x,a[i].y);
						make_fa(ck(a[i].x),ck(a[i].y));
					}
					
					vis[a[i].x]=1;
				}
				now[a[i].x]=a[i].y;
			}
		}
	//	cout<<1;
		printf("%d\n",size[get_fa(U_)]);
	}
}
