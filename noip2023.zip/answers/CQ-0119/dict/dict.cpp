#include<bits/stdc++.h>
using namespace std;
int n,m,len,maxn[3005],minn[3005];
char s[3005];
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("%s",s+1);
		len=strlen(s+1);
		minn[i]=30;
		for(int j=1;j<=len;j++){
			maxn[i]=max(maxn[i],s[j]-'a'+1);
			minn[i]=min(minn[i],s[j]-'a'+1);
		}
	}
	for(int i=1;i<=n;i++){
		int op=1;
//	cout<<minn[i]<<maxn[i]<<endl;
		for(int j=1;j<=n;j++){
			if(j==i)continue;
			
			if(minn[i]>=maxn[j]){
				op=0;
				break;
			}
		}
		printf("%d",op);
	}
} 
/*
4 7
abandon
bananaa
baannaa
notnotn
*/
