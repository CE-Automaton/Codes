#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll c,t,n,m,x,y,k,d,tree[100005],f[100005],ans;
struct node{
	ll l,r,v;
}a[100005];
bool cmp(node x,node y){
	return x.r==y.r?x.l<y.l:x.r>y.r;
}
int main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	scanf("%lld%lld",&c,&t);
	while(t--){
		ans=0;
		scanf("%lld%lld%lld%lld",&n,&m,&k,&d);
		for(ll i=1;i<=m;i++){
			scanf("%lld%lld%lld",&x,&y,&a[i].v);
			a[i].l=x-y+1;a[i].r=x;
		}
		sort(a+1,a+1+m,cmp);
		for(ll i=1,j=0;i<=n;i++){
			f[i]=-1e18;
			if(j<m&&a[j+1].r<=i){
				for(ll l=0;l<=a[j+1].l;l++)tree[l]+=a[j+1].v;
				j++;
			}
			for(ll l=max(0ll,i-k+1);l<i;l++){
				f[i]=max(f[i],f[max(0ll,l-1)]+tree[l]-(i-l+1));
			}
			ans=max(ans,f[i]);
		}
		printf("%lld\n",ans);
	}
}
