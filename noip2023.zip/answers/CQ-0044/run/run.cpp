#include<bits/stdc++.h>
#define ll long long
#define N 500005
using namespace std;
struct node{ll x,y,z;}p[N];
struct tree{ll x,tag;}tr[N<<2];
bool cmp(node a,node b){return a.y<b.y;}
ll c,T,n,m,k,d,l,i,j,dp[N],qzh[N],tot;
void build(ll s,ll t,ll p){
	tr[p].tag = 0;
	if(s==t){
		if(s==0) tr[p].x=0;
		else tr[p].x=-1e16;
		return ;
	}
	build(s,(s+t)/2,2*p),build((s+t)/2+1,t,2*p+1);
	tr[p].x = max(tr[2*p].x,tr[2*p+1].x);
}
inline void pushtag(ll p,ll c){tr[p].x += c,tr[p].tag += c;}
inline void pushdown(ll p){pushtag(2*p,tr[p].tag),pushtag(2*p+1,tr[p].tag),tr[p].tag=0;}
void modify(ll l,ll r,ll c,ll s,ll t,ll p){
	if(l<=s&&t<=r){
		pushtag(p,c);
		return ;
	}
	pushdown(p);
	if(l<=(s+t)/2) modify(l,r,c,s,(s+t)/2,2*p);
	if(r>(s+t)/2) modify(l,r,c,(s+t)/2+1,t,2*p+1);
	tr[p].x = max(tr[2*p].x,tr[2*p+1].x);
}
void add(ll x,ll c,ll s,ll t,ll p){
	if(s==t){
		tr[p].x = c;
		return ;
	}
	pushdown(p);
	if(x<=(s+t)/2) add(x,c,s,(s+t)/2,2*p);
	else add(x,c,(s+t)/2+1,t,2*p+1);
	tr[p].x = max(tr[2*p].x,tr[2*p+1].x); 
}
ll query(ll l,ll r,ll s,ll t,ll p){
	if(l<=s&&t<=r) return tr[p].x;
	pushdown(p);
	ll ans = -1e16;
	if(l<=(s+t)/2) ans=max(ans,query(l,r,s,(s+t)/2,2*p));
	if(r>(s+t)/2) ans=max(ans,query(l,r,(s+t)/2+1,t,2*p+1));
	return ans;
}
int main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>c>>T;
	while(T--){
		tot = 0;
		cin>>n>>m>>k>>d;
		qzh[++tot] = n;
		for(i=1;i<=m;i++){
			cin>>p[i].x>>p[i].y>>p[i].z;
			swap(p[i].x,p[i].y),p[i].x=p[i].y-p[i].x;
			if(p[i].x!=0) qzh[++tot] = p[i].x;
			if(p[i].y!=0) qzh[++tot] = p[i].y;
		}
		sort(qzh,qzh+tot+1),tot=unique(qzh,qzh+tot+1)-qzh-1;
		for(i=1;i<=m;i++){
			p[i].x = lower_bound(qzh,qzh+tot+1,p[i].x)-qzh+1;
			p[i].y = lower_bound(qzh,qzh+tot+1,p[i].y)-qzh;
		}
		sort(p+1,p+m+1,cmp);
		build(0,tot,1);
		dp[0] = 0;
		for(i=1,j=1,l=0;i<=tot;i++){
			while(j<=m&&p[j].y<=i){
				modify(0,p[j].x-1,p[j].z,0,tot,1);
				j++;
			}
			while(qzh[i]-qzh[l]>k){
				add(l,-1e16,0,tot,1);
				l++;
			}
			modify(0,i-1,-d*(qzh[i]-qzh[i-1]),0,tot,1);
			dp[i] = max(dp[i-1],query(0,i-1,0,tot,1));
			add(i,dp[i-1],0,tot,1);
		}
		cout<<dp[tot]<<endl;
	}
	return 0;
}
/*
Input:
1 1
3 2 2 1
2 2 4
3 2 3

Output:
2
*/
