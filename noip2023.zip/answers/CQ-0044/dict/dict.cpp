#include<bits/stdc++.h>
#define N 3005
using namespace std;
int n,m,i,ans,temp;
string s[N],p[N],t;
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n>>m;
	for(i=1;i<=n;i++){
		cin>>s[i];
		sort(s[i].begin(),s[i].end());
		p[i]=s[i];
		reverse(s[i].begin(),s[i].end());
	}
	sort(s+1,s+n+1);
	for(i=1;i<=n;i++){
		temp = 0;
		t = p[i],reverse(t.begin(),t.end());
		if(s[1]<=p[i]){
			if(s[1]==t){
				if(n==1) cout<<1,temp=1;
				else if(s[2]>p[i]) cout<<1,temp=1;
			}
		}
		else cout<<1,temp=1;
		if(!temp) cout<<0;
	}
	cout<<endl;
	return 0;
}
/*
Input:
4 7
abandon
bananaa
baannaa
notnotn

Output:
1110
*/
