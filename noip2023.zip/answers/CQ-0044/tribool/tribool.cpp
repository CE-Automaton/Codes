#include<bits/stdc++.h>
#define ll long long
#define N 500005
using namespace std;
vector<ll> op[N],w[N];
struct node{ll x,y;char z;}p[N];
ll c,T,n,m,x,y,i,fath[N],si[N],vis[N],sum,temp;
ll gf(ll x){return x==fath[x]?x:fath[x]=gf(fath[x]);}
char ch,ans[N];
void dfs(ll x){
	for(ll i=0;i<op[x].size();i++){
		if(ans[op[x][i]]==0){
			if(w[x][i]==1){
				if(ans[x]=='T') ans[op[x][i]]='F';
				else if(ans[x]=='U') ans[op[x][i]]='U';
				else ans[op[x][i]]='T';
			}
			else{
				ans[op[x][i]] = ans[x];
			}
			dfs(op[x][i]);
		}
	}
}
ll dfss(ll x){
	ll son = 1;
	ans[x] = '@';
	for(ll i=0;i<op[x].size();i++){
		if(ans[op[x][i]]) continue;
		son += dfss(op[x][i]);
	}
	return son;
}
inline void merge_my(ll x,ll y){
	if(gf(x)==gf(y)) return ;
	si[gf(y)] += si[gf(x)],fath[gf(x)] = gf(y);
	return ;
}
int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>c>>T;
	while(T--){
		sum = 0;
		cin>>n>>m;
		for(i=1;i<=n;i++) p[i].x=i,p[i].y=0,p[i].z=0,ans[i]=0,op[i].clear(),w[i].clear();
		for(i=1;i<=2*n;i++) fath[i]=i,si[i]=1,vis[i]=0;
		while(m--){
			cin>>ch>>x;
			if(ch=='+') cin>>y,p[x]=p[y];
			else if(ch=='-'){
				cin>>y;
				if(p[y].z=='T') p[x].z='F';
				else if(p[y].z=='F') p[x].z='T';
				else if(p[y].z=='U') p[x].z='U';
				else p[x]=p[y],p[x].y^=1;
			}
			else p[x].z = ch;
		}
		for(i=1;i<=n;i++){
			if(!p[i].z){
				op[p[i].x].push_back(i),w[p[i].x].push_back(p[i].y);
				op[i].push_back(p[i].x),w[i].push_back(p[i].y);
			}
		}
		for(i=1;i<=n;i++) if(p[i].z) ans[i]=p[i].z,dfs(i);
		for(i=1;i<=n;i++){
			if(ans[i]==0){
				if(p[i].y) merge_my(i,p[i].x+n),merge_my(i+n,p[i].x);
				else merge_my(i,p[i].x),merge_my(i+n,p[i].x+n);
			}
		}
		for(i=1;i<=n;i++){
			if(ans[i]==0){
				if(!vis[i]){
					temp = dfss(i);
					if(gf(i)==gf(i+n)) sum += temp;
				}
			}
		}
		for(i=1;i<=n;i++) if(ans[i]=='U') sum++;
		cout<<sum<<endl;
	}
	return 0;
}
/*
Input:
1 3
3 3
- 2 1
- 3 2
+ 1 3
3 3
- 2 1
- 3 2
- 1 3
2 2
T 2
U 2

Output:
0
3
1
*/
