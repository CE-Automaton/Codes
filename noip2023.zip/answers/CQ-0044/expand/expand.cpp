#include<bits/stdc++.h>
#define N 2000005
using namespace std;
vector<pair<int,int> > op1[65],op2[65];
int C,n,m,nn,mm,q,i,j,a[N],b[N],aa[N],bb[N],aaa[N],bbb[N],temp[N],cnt1[N],cnt2[N],qzh[N],ttt,tot,x,y,z,c;
int ans1[N],ans2[N];
inline bool check(){
	aaa[1] = aa[1];
	for(i=2;i<=nn;i++) aaa[i]=max(aaa[i-1],aa[i]);
	bbb[1] = bb[1];
	for(i=2;i<=mm;i++) bbb[i]=min(bbb[i-1],bb[i]);
	for(i=1;i<=nn;i++) cnt1[aaa[i]]=i;
	for(i=1;i<=tot;i++) cnt1[i]=max(cnt1[i],cnt1[i-1]);
	for(i=1;i<=mm;i++) cnt2[bbb[i]]=i;
	for(i=tot;i>=1;i--) cnt2[i]=max(cnt2[i],cnt2[i+1]);
	for(i=1;i<nn;i++) ans1[i]=cnt2[min(aa[i],aa[i+1])];
	for(i=1;i<mm;i++) ans2[i]=cnt1[max(bb[i],bb[i+1])];
	int temp = 1;
	for(i=1;i<nn;i++) if(ans1[i]==mm) temp=0;
	for(i=1;i<mm;i++) if(ans2[i]==nn) temp=0;
	for(i=2;i<mm;i++) ans2[i]=max(ans2[i],ans2[i-1]);
	for(i=1;i<nn;i++){
		if(ans2[ans1[i]]>=i){
			temp=0;
			break;
		}
	}
	for(i=1;i<=nn;i++) ans1[i]=aaa[i]=0;
	for(i=1;i<=mm;i++) ans2[i]=bbb[i]=0;
	for(i=1;i<=tot;i++) cnt1[i]=cnt2[i]=0;
	return temp;
}
inline void solve(){
	nn = n,mm = m;
	if(!((aa[1]<bb[1]&&aa[n]<bb[m])||(aa[1]>bb[1]&&aa[n]>bb[m]))){
		cout<<0;
		return ;
	}
	if(aa[1]<bb[1]){
		for(i=1;i<=nn;i++) temp[i]=aa[i];
		for(i=1;i<=mm;i++) aa[i]=bb[i];
		for(i=1;i<=nn;i++) bb[i]=temp[i];
		swap(nn,mm);
	}
	int temp = check();
	if(temp){
		reverse(aa+1,aa+nn+1),reverse(bb+1,bb+mm+1);
		temp = check();
		if(temp) cout<<1;
		else cout<<0;
	}
	else cout<<0;
}
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>C>>n>>m>>q;
	for(i=1;i<=n;i++) cin>>a[i],qzh[++tot]=a[i];
	for(i=1;i<=m;i++) cin>>b[i],qzh[++tot]=b[i];
	for(i=1;i<=q;i++){
		cin>>x>>y;
		while(x--) cin>>z>>c,op1[i].push_back(make_pair(z,c)),qzh[++tot] = c;
		while(y--) cin>>z>>c,op2[i].push_back(make_pair(z,c)),qzh[++tot] = c;
	}
	sort(qzh+1,qzh+tot+1),tot=unique(qzh+1,qzh+tot+1)-qzh-1;
	for(i=1;i<=n;i++){
		a[i]=lower_bound(qzh+1,qzh+tot+1,a[i])-qzh;
		aa[i]=a[i];
	}
	for(i=1;i<=m;i++){
		b[i]=lower_bound(qzh+1,qzh+tot+1,b[i])-qzh;
		bb[i]=b[i];
	} 
	solve();
	for(ttt=1;ttt<=q;ttt++){
		for(i=1;i<=n;i++) aa[i]=a[i],bb[i]=b[i];
		for(i=0;i<op1[ttt].size();i++) aa[op1[ttt][i].first] = lower_bound(qzh+1,qzh+tot+1,op1[ttt][i].second)-qzh;
		for(i=0;i<op2[ttt].size();i++) bb[op2[ttt][i].first] = lower_bound(qzh+1,qzh+tot+1,op2[ttt][i].second)-qzh;
		solve();
	}
	return 0;
}
/*
Input:
3 3 3 3
8 6 9
1 7 4
1 0
3 0
0 2
1 8
3 5
1 1
2 8
1 7

Output:
1001
*/
