#include <bits/stdc++.h>
#define rep(i, a, b) for (int i = (a); i <= (b); i ++)
#define dep(i, a, b) for (int i = (a); i >= (b); i --)
using namespace std;

char buf[1 << 23], *p1 = buf, *p2 = buf;
#define getchar() (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1 << 21, stdin), p1 == p2) ? EOF : *p1 ++)
int read() {
  int s(0), f(1); char ch(getchar());
  while (!isdigit(ch)) f = ch == '-' ? -1 : 1, ch = getchar();
  while (isdigit(ch)) s = (s << 3) + (s << 1) + (ch ^ 48), ch = getchar();
  return s * f;
}

const int N = 1e5 + 5;
int type, T, n, m, pos[N], ed[N], fl[N], a[N];
int vis[N], dad[N], sta[N], tp, du[N];
struct Edge {
  char opt;
  int x, y;
} q[N];
vector <int> G[N];

int head[N], to[N << 1], nxt[N << 1], ecnt = 1, cost[N << 1];
void add(int u, int v, int w) {
  to[++ ecnt] = v, nxt[ecnt] = head[u], head[u] = ecnt, cost[ecnt] = w;
}

void getcir(int u) {
  if (vis[u]) {
    int cnt(dad[u]);
    for (int j = tp; j > 0 && sta[j] != u; j --) cnt += dad[sta[j]];
    if (cnt & 1) {
      a[u] = 0;
      while (tp > 0 && sta[tp] ^ u) a[sta[tp]] = 0, tp --;
      tp --;
    }
    return;
  }
  vis[u] = 1, sta[++ tp] = u;
  for (int i = head[u], v; v = to[i], i; i = nxt[i]) {
    getcir(v);
  }
  -- tp;
}

void dfs(int u) {
  a[u] = 0, vis[u] = 1;
  for (int i = head[u], v; v = to[i], i; i = nxt[i])
    if (!vis[v]) dfs(v);
}

void solve() {
  scanf("%d%d", &n, &m), tp = 0, ecnt = 1;
  rep(i, 1, n) pos[i] = vis[i] = head[i] = du[i] = 0, a[i] = 1, G[i].clear();
  rep(i, 1, m) {
    scanf(" %c", &q[i].opt);
    if (q[i].opt == '+') {
      scanf("%d%d", &q[i].x, &q[i].y);
      int p1 = pos[q[i].y];
      if (!p1) ed[i] = i, fl[i] = 0;
      else ed[i] = ed[p1], fl[i] = fl[p1];
      pos[q[i].x] = i;
    }
    else if (q[i].opt == '-') {
      scanf("%d%d", &q[i].x, &q[i].y);
      int p1 = pos[q[i].y];
      if (!p1) ed[i] = i, fl[i] = 1;
      else ed[i] = ed[p1], fl[i] = fl[p1] ^ 1;
      pos[q[i].x] = i;
    }
    else {
      scanf("%d", &q[i].x);
      ed[i] = i, fl[i] = 0, pos[q[i].x] = i;
    }
  }
  int res(0);
  rep(i, 1, n) {
    int p1 = pos[i], fg = fl[p1];
    if (!p1) continue;
    p1 = ed[p1];
    char op = q[p1].opt;
    if (op != '+' && op != '-') {
      if (op == 'U') a[i] = 0;
      continue;
    }
    if (fg && q[p1].y == i) a[i] = 0;
  }
  rep(i, 1, n) if (a[i]) {
    int p1 = pos[i], fg = fl[p1];
    if (!p1) continue;
    p1 = ed[p1];
    if (q[p1].opt == '+' || q[p1].opt == '-') {
      add(q[p1].y, i, fg), du[q[p1].y] ++, dad[i] = fg;
      G[i].push_back(q[p1].y);
    }
  }
  queue <int> q;
  rep(i, 1, n) if (!du[i]) q.push(i);
  while (!q.empty()) {
    int u = q.front();
    q.pop();
    for (int v : G[u]) {
      if (-- du[v] == 0) q.push(v); 
    }
  }
  rep(i, 1, n) if (!vis[i] && du[i]) tp = 0, getcir(i);
  memset(vis, 0, sizeof vis);
  rep(i, 1, n) if (!vis[i] && !a[i]) dfs(i);
  rep(i, 1, n) res += a[i] == 0;
  printf("%d\n", res);
}

int main() {
  freopen("tribool.in", "r", stdin);
  freopen("tribool.out", "w", stdout);
  scanf("%d%d", &type, &T);
  while (T --) solve();
  return 0;
}

