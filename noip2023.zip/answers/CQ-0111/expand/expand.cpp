#include <bits/stdc++.h>
#define rep(i, a, b) for (int i = (a); i <= (b); i ++)
#define dep(i, a, b) for (int i = (a); i >= (b); i --)
using namespace std;

char buf[1 << 23], *p1 = buf, *p2 = buf;
#define getchar() (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1 << 21, stdin), p1 == p2) ? EOF : *p1 ++)
int read() {
  int s(0), f(1); char ch(getchar());
  while (!isdigit(ch)) f = ch == '-' ? -1 : 1, ch = getchar();
  while (isdigit(ch)) s = (s << 3) + (s << 1) + (ch ^ 48), ch = getchar();
  return s * f;
}

const int N = 5e5 + 5, inf = 1e9;
int type, n, m, q, a[N], b[N], f[N], g[N];
int mx1, mn1, mx2, mn2;

bool chk() {
  mx1 = mx2 = -inf, mn1 = mn2 = inf;
  if (1ll * (a[1] - b[1]) * (a[n] - b[m]) <= 0) return 0;
  int fg = a[1] > b[1] ? 1 : -1;
  sort(a + 1, a + 1 + n);
  sort(b + 1, b + 1 + m);
  if (fg == 1)
  rep(i, 1, min(n, m)) {
    if (a[i] < b[i]) return 0;
  }
  else
  rep(i, 1, min(n, m)) {
    if (a[i] > b[i]) return 0;
  }
  return 1;
}

int main() {
  freopen("expand.in", "r", stdin);
  freopen("expand.out", "w", stdout);
  type = read(), n = read(), m = read(), q = read();
  rep(i, 1, n) a[i] = read();
  rep(i, 1, m) b[i] = read();
  printf("%d", chk());
  while (q --) {
    int k1 = read(), k2 = read();
    rep(i, 1, n) f[i] = a[i];
    rep(i, 1, m) g[i] = b[i];
    while (k1 --) {
      int x = read(), y = read();
      a[x] = y;
    }
    while (k2 --) {
      int x = read(), y = read();
      b[x] = y;
    }
    printf("%d", chk());
    rep(i, 1, n) a[i] = f[i];
    rep(i, 1, m) b[i] = g[i];    
  }
  return 0;
}

