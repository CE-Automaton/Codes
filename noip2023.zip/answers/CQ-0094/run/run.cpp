#include<bits/stdc++.h>
#define file(fname) freopen(#fname".in","r",stdin),freopen(#fname".out","w",stdout);
using namespace std;
using ll=long long;
void Solve();
int SID;
const int N = 1e5+15;
int n,m,k,d;
struct query {
   int l,r,v;
};
vector<query> q;
ll ans=-0x3f3f3f3f3f3f3f3f;
int s[N];
void dfs(int pos,ll E,int step) {
   if(pos>n) {
      for(auto it:q)
         if(s[it.r]-s[it.l]==it.r-it.l) 
            E+=it.v;
      ans=max(ans,E);
      return ;
   }
   if(step<k) {
      s[pos]=s[pos-1]+1;
      dfs(pos+1,E-d,step+1);
   }
   s[pos]=s[pos-1];
   dfs(pos+1,E,0);
}
signed main() {
   cin.tie(nullptr)->sync_with_stdio(false);
   file(run);
   cin>>SID;
   int T; cin>>T; while(T--)
   Solve();
   return 0;
}
void Solve() {
   cin>>n>>m>>k>>d;
   q.resize(m);
   for(auto &it:q) {
      cin>>it.r>>it.l>>it.v;
      it.l=it.r-it.l;
   }
   dfs(1,0,0);
   printf("%lld\n",ans);
}