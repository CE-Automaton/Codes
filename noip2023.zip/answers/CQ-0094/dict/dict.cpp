#include<bits/stdc++.h>
#define file(fname) freopen(#fname".in","r",stdin),freopen(#fname".out","w",stdout);
using namespace std;
using ll=long long;
void Solve();
const int N = 3e3+33;
int n,m;
string s[N],t[N];
signed main() {
   cin.tie(nullptr)->sync_with_stdio(false);
   file(dict);
   Solve();
   return 0;
}
void Solve() {
   cin>>n>>m;
   if(n==1) return puts("1"),void();
   for(int i=1;i<=n;i++) {
      cin>>s[i]; sort(s[i].begin(),s[i].end());
      t[i]=s[i]; reverse(t[i].begin(),t[i].end());
   }
   int x=1,y=2;
   if(t[x]>t[y]) swap(x,y);
   for(int i=3;i<=n;i++) {
      if(t[i]<=t[x]) y=x,x=i;
      else if(t[i]<=t[y]) y=i;
   }
   for(int i=1;i<=n;i++) {
      putchar(s[i]<t[i==x?y:x]?'1':'0');
   } puts("");
}