#include<bits/stdc++.h>
#define file(fname) freopen(#fname".in","r",stdin),freopen(#fname".out","w",stdout);
using namespace std;
using ll=long long;
void Solve();
const int N = 1e5+15;
int SID;
int n,Q;
struct Query {
   char op;
   int x,y;
}; vector<Query> q;
char ex(char ch) { return ch=='T'?'F':ch=='F'?'T':'U'; }
Query upd[N];
char a[N];
namespace Sub1 {
int ans;
char b[N];
void dfs(int pos,int cnt) {
   if(cnt>=ans) return ;
   if(pos>n) {
      for(int i=1;i<=n;i++) b[i]=a[i];
      for(auto it:q) {
         if(it.op=='+') b[it.x]=b[it.y];
         else if(it.op=='-') b[it.x]=ex(b[it.y]);
         else b[it.x]=it.op;
      }
      for(int i=1;i<=n;i++) if(b[i]!=a[i]) return ;
      ans=cnt;
      return ;
   }
   if(a[pos]!='#') return dfs(pos+1,cnt);
   a[pos]='T'; dfs(pos+1,cnt);
   a[pos]='F'; dfs(pos+1,cnt);
   a[pos]='U'; dfs(pos+1,cnt+1);
   a[pos]='#';
}
void main() {
   int cnt=0; ans=n;
   for(int i=1;i<=n;i++) {
      auto it=upd[i];
      if(it.op!='+'&&it.op!='-') 
         a[i]=it.op,cnt+=a[i]=='U';
      else a[i]='#';
   }
   dfs(1,cnt);
   printf("%d\n",ans);
}
}
namespace Sub2 {
void main() {
   int ans=0;
   for(int i=1;i<=n;i++) ans+=upd[i].op=='U';
   printf("%d\n",ans);
}
}
namespace Sub3 {
vector<int> e[N];
bool vis[N];
vector<int> now;
void dfs(int u,char ch) {
   vis[u]=true;
   a[u]=ch;
   now.push_back(u);
   for(auto v:e[u]) if(!vis[v]) dfs(v,ch);
   e[u].clear();
}
void main() {
   for(int i=1;i<=n;i++) {
      a[i]='#';
      e[i].clear();
   }
   reverse(q.begin(),q.end());
   for(auto it:q) {
      if(it.op=='+') {
         e[it.y].push_back(it.x);
      } else {
         dfs(it.x,'U');
         for(auto it:now) vis[it]=false;
      }
   }
   int ans=0;
   for(int i=1;i<=n;i++) ans+=a[i]=='U';
   printf("%d\n",ans);
}
}
namespace Sub4 {
bool ifU[N],vis[N],vip[N];
struct edge { int v,w; };
vector<edge> e[N];
vector<int> now;
bool dfs(int u,int step) {
   if(vip[u]) return step&1;
   if(ifU[u]) return true;
   vis[u]=vip[u]=true; 
   now.push_back(u);
   for(auto E:e[u]) {
      if(dfs(E.v,step+E.w)) return true;
   }
   vip[u]=false; now.pop_back();
   return false;
}
void main() {
   for(int i=1;i<=n;i++) {
      ifU[i]=false;
      e[i].clear();
   }
   for(auto it:q) {
      e[it.x].push_back({it.y,(it.op=='-')});
   }
   int ans=0;
   for(int i=1;i<=n;i++) {
      if(!vis[i]&&dfs(i,0)) {
         for(auto it:now) ifU[it]=true;
         now.clear();
      }
      ans+=ifU[i];
   }
   printf("%d\n",ans);
}
}
signed main() {
   cin.tie(nullptr)->sync_with_stdio(false);
   file(tribool);
   int T; cin>>SID>>T; while(T--)
   Solve();
   return 0;
}
void Solve() {
   cin>>n>>Q; 
   q.resize(Q);
   for(int i=1;i<=n;i++) upd[i]={'#',0,0},a[i]='#';
   for(auto &it:q) {
      it={'#',0,0};
      cin>>it.op;
      if(it.op=='+'||it.op=='-') 
         cin>>it.x>>it.y;
      else cin>>it.x;
      upd[it.x]=it;
   }
   if(SID==1||SID==2) return Sub1::main();
   if(SID==3||SID==4) return Sub2::main();
   if(SID==5||SID==6) return Sub3::main();
   if(SID==7||SID==8) return Sub4::main();
   Sub1::main();
}