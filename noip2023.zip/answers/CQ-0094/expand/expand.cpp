#include<bits/stdc++.h>
#define file(fname) freopen(#fname".in","r",stdin),freopen(#fname".out","w",stdout);
using namespace std;
using ll=long long;
void Solve();
const int N = 5e5+55;
int SID;
int n,m,Q;
ll a[N],b[N],pa[N],pb[N];
namespace Sub1 {
bool check() {
   return (a[1]-b[1])*(a[n]-b[m])>0;
}
void main() {
   for(int i=1;i<=n;i++) a[i]=pa[i];
   for(int i=1;i<=m;i++) b[i]=pb[i];
   putchar(check()?'1':'0');
   while(Q--) {
      for(int i=1;i<=n;i++) a[i]=pa[i];
      for(int i=1;i<=m;i++) b[i]=pb[i];
      int x,y,p,v;
      cin>>x>>y;
      while(x--) cin>>p>>v,a[p]=v;
      while(y--) cin>>p>>v,b[p]=v;
      putchar(check()?'1':'0');
   }
}
}
namespace Sub3 {
bool check() {
   return (a[1]-b[1])*(a[n]-b[m])>0 && 
      (max_element(a+1,a+n+1)-max_element(b+1,b+m+1))
      *(min_element(a+1,a+n+1)-min_element(b+1,b+m+1))>0;
}
void main() {
   for(int i=1;i<=n;i++) a[i]=pa[i];
   for(int i=1;i<=m;i++) b[i]=pb[i];
   putchar(check()?'1':'0');
   while(Q--) {
      for(int i=1;i<=n;i++) a[i]=pa[i];
      for(int i=1;i<=m;i++) b[i]=pb[i];
      int x,y,p,v;
      cin>>x>>y;
      while(x--) cin>>p>>v,a[p]=v;
      while(y--) cin>>p>>v,b[p]=v;
      putchar(check()?'1':'0');
   }
}
}
signed main() {
   cin.tie(nullptr)->sync_with_stdio(false);
   file(expand);
   cin>>SID;
   Solve();
   return 0;
}
void Solve() {
   cin>>n>>m>>Q;
   for(int i=1;i<=n;i++) cin>>pa[i];
   for(int i=1;i<=m;i++) cin>>pb[i];
   if(SID==1||SID==2) return Sub1::main();
   if(SID==3||SID==4) return Sub3::main();
   Sub3::main();
}