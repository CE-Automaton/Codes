//Linkwish's code
#include<bits/stdc++.h>
#define endl '\n'
#define si static inline
#define fi first
#define se second
using namespace std;typedef long long ll;typedef __int128 li;
typedef pair<int,int> pii;typedef pair<ll,ll> pll;typedef const int ci;
typedef const ll cl;const int iinf=INT_MAX;const ll linf=LLONG_MAX;
//template<typename T>si bool gmax(T &x,const T y){if(x<y)return x=y,1;return 0;}
//template<typename T>si bool gmin(T &x,const T y){if(y<x)return x=y,1;return 0;}

namespace LinkWish{
	ci N=200010;
	int TestCase;
	int n,m,T,F,U;
	int fa[N],sz[N],cur[N];
	int getf(int x){return x==fa[x]?x:fa[x]=getf(fa[x]);}
	si void merge(int x,int y){
		x=getf(x),y=getf(y);if(x==y)return ;
		if(sz[x]<sz[y])swap(x,y);
		fa[y]=x,sz[x]+=sz[y];
	}
	si void solve(){
		cin>>n>>m;T=2*n+1,F=2*n+2,U=2*n+3;
		for(int i=1;i<=U;i++){
			fa[i]=i;
			if(i<=n)sz[i]=1;
			else sz[i]=0;
		}
		for(int i=1;i<=2*n;i++)cur[i]=i;
		char op;
		for(int i=1,x,y,t1,t2;i<=m;i++){
			cin>>op>>x;
			if(op=='+'){
				cin>>y;
				t1=cur[y],t2=cur[y+n];
				cur[x]=t1;
				cur[x+n]=t2;
			}
			else if(op=='-'){
				cin>>y;
				t1=cur[y],t2=cur[y+n];
				cur[x]=t2;
				cur[x+n]=t1;
			}
			else{
				if(op=='T')cur[x]=T,cur[x+n]=F;
				else if(op=='F')cur[x]=F,cur[x+n]=T;
				else cur[x]=cur[x+n]=U;
			}
		}
		for(int i=1;i<=n;i++){
			merge(cur[i],i);
			merge(cur[i+n],i+n);
		}
		for(int i=1;i<=n;i++){
			if(getf(i)==getf(i+n)){
				merge(U,i);
			}
		}
		cout<<sz[getf(U)]<<endl;
	}
	void mian(){int TT;cin>>TestCase>>TT;while(TT--)solve();}
}

signed main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	LinkWish::mian();
	return 0;
}
