//Linkwish's code
#include<bits/stdc++.h>
#define endl '\n'
#define si static inline
#define fi first
#define se second
using namespace std;typedef long long ll;typedef __int128 li;
typedef pair<int,int> pii;typedef pair<ll,ll> pll;typedef const int ci;
typedef const ll cl;const int iinf=INT_MAX;const ll linf=1e18;
template<typename T>si bool gmax(T &x,const T y){if(x<y)return x=y,1;return 0;}
//template<typename T>si bool gmin(T &x,const T y){if(y<x)return x=y,1;return 0;}

namespace LinkWish{
	
	ci N=400005;
	int TestCase;
	int n,m,K,D;
	ll f[N],Mx[N];
	int b[N],num;
	
	struct T{
		int x,l,r,v;
	}op[N];
	
	vector<int> tag[N];
	
	struct Z1987{
		ll mx,tag;
	}t[N<<2];
	si int ls(int x){return x<<1;}
	si int rs(int x){return x<<1|1;}
	si void push_up(int x){t[x].mx=max(t[ls(x)].mx,t[rs(x)].mx);}
	si void update(int x,ll v){t[x].mx+=v,t[x].tag+=v;}
	si void push_down(int x){if(t[x].tag)update(ls(x),t[x].tag),update(rs(x),t[x].tag),t[x].tag=0;}
	void build(int x,int l,int r){
		t[x].tag=0;
		if(l==r){
			t[x].mx=0;
			return ;
		}
		int mid=(l+r)>>1;
		build(ls(x),l,mid);
		build(rs(x),mid+1,r);
		push_up(x);
	}
	void modify(int x,int l,int r,int L,int R,ll v){
//		if(!l&&r==n)cout<<"MODIFY "<<L<<' '<<R<<' '<<v<<endl;
		if(l>=L&&r<=R)return update(x,v),void();
		push_down(x);int mid=(l+r)>>1;
		if(L<=mid)modify(ls(x),l,mid,L,R,v);
		if(R>mid)modify(rs(x),mid+1,r,L,R,v);
		push_up(x);
	}
	ll ask(int x,int l,int r,int L,int R){
		if(l>=L&&r<=R)return t[x].mx;
		push_down(x);int mid=(l+r)>>1;ll res=-linf;
		if(L<=mid)res=ask(ls(x),l,mid,L,R);
		if(R>mid)gmax(res,ask(rs(x),mid+1,r,L,R));
		return res;
	}
	
	si int gv(int x){return lower_bound(b+1,b+1+num,x)-b;}
	si void init(){
		for(int i=0;i<=n;i++)tag[i].clear(),f[i]=Mx[i]=0;
		for(int i=1;i<=m;i++)tag[op[i].x].push_back(i);
		build(1,0,n);
	}
	
	si void dp(){
		for(int i=1;i<=n;i++){
			modify(1,0,n,1,i,-D);
			for(int j:tag[i])modify(1,0,n,op[j].l,op[j].r,op[j].v);
			modify(1,0,n,i,i,Mx[max(0,i-2)]);
			ll res=ask(1,0,n,max(0,i-K+1),i);
			Mx[i]=max(Mx[i-1],res);
		}
		cout<<Mx[n]<<endl;
	}
	
	si void solve(){
		cin>>n>>m>>K>>D;
		int tmp=0;
		for(int i=1,x,y,z;i<=m;i++){
			cin>>x>>y>>z;
			if(y<=K&&x-y+1>0){
				op[++tmp].x=x;
				op[tmp].l=max(1,x-K+1);
				op[tmp].r=x-y+1;
				op[tmp].v=z;
			}
		}
		m=tmp;
		init();
		dp();
	}
	
	void mian(){int TT;cin>>TestCase>>TT;while(TT--)solve();}
}

signed main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	LinkWish::mian();
	return 0;
}
