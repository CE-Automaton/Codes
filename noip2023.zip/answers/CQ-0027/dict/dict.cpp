//Linkwish's code
#include<bits/stdc++.h>
#define endl '\n'
#define si static inline
#define fi first
#define se second
using namespace std;typedef long long ll;typedef __int128 li;
typedef pair<int,int> pii;typedef pair<ll,ll> pll;typedef const int ci;
typedef const ll cl;const int iinf=INT_MAX;const ll linf=LLONG_MAX;
//template<typename T>si bool gmax(T &x,const T y){if(x<y)return x=y,1;return 0;}
//template<typename T>si bool gmin(T &x,const T y){if(y<x)return x=y,1;return 0;}

namespace LinkWish{
	ci N=3005;
	int n,m;
	string s[N],c[N];
	int mn,sn;
	void mian(){
		cin>>n>>m;
		if(n==1){
			cout<<"1\n";
			return ;
		}
		for(int i=1;i<=n;i++){
			cin>>s[i];
			c[i]=s[i];
			sort(c[i].begin(),c[i].end());
			reverse(c[i].begin(),c[i].end());
			if(!mn||c[i]<c[mn])sn=mn,mn=i;
			else if(!sn||c[i]<c[sn])sn=i;
		}
		for(int i=1;i<=n;i++){
			string tmp=s[i];
			sort(tmp.begin(),tmp.end());
			if(i==mn){
				if(tmp<c[sn])cout<<"1";
				else cout<<"0";
			}
			else{
				if(tmp<c[mn])cout<<"1";
				else cout<<"0";
			}
		}
	}
}

signed main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	LinkWish::mian();
	return 0;
}

