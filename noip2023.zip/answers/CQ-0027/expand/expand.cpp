//Linkwish's code
#include<bits/stdc++.h>
#define endl '\n'
#define si static inline
#define fi first
#define se second
using namespace std;typedef long long ll;typedef __int128 li;
typedef pair<int,int> pii;typedef pair<ll,ll> pll;typedef const int ci;
typedef const ll cl;const int iinf=INT_MAX;const ll linf=LLONG_MAX;
template<typename T>si bool gmax(T &x,const T y){if(x<y)return x=y,1;return 0;}
template<typename T>si bool gmin(T &x,const T y){if(y<x)return x=y,1;return 0;}

namespace LinkWish{
	
	si void read(int &x){
		char ch=getchar();for(;ch<'0'||ch>'9';ch=getchar());
		for(x=0;ch>='0'&&ch<='9';ch=getchar())x=x*10+(ch^48);
	}
	
	ci N=500005;
	int TestCase;
	int n,m,Q,a[N],b[N],Orga[N],Orgb[N];
	si bool check1(){
//		if(TestCase>=8&&TestCase<=14){
//			int mn=iinf;for(int i=1;i<=m;i++)gmin(mn,b[i]);
//			if(mn<=a[n])return 0;
//			int mx=0;for(int i=1;i<=n;i++)gmax(mx,a[i]);
//			if(mx>=b[m])return 0;
//			for(int i=1,cur=0;i<n;i++){
//				if(a[i+1]>=a[i])while(cur<m&&a[i]<b[cur+1]&&b[cur+1]<=a[i+1])cur++;
//				else while(cur<m&&a[i]<b[cur+1])cur++;
//				
//			}
//			return 1;
//		}
		vector<int> f;
		int now=1;while(now<=m&&b[now]>a[1])f.push_back(now++);
		for(int i=2;i<=n;i++){
			vector<int> tmp;
			int mx=0;
			for(int j:f){
				if(j<mx)continue;
				if(b[j]>a[i])tmp.push_back(j);
				mx=j+1;while(mx<=m&&b[mx]>a[i])tmp.push_back(mx++);
			}
			tmp.erase(unique(tmp.begin(),tmp.end()),tmp.end());
			f=tmp;
			if(TestCase>=8&&TestCase<=14&&!f.empty()&&f.back()==m)return 1;
		}
		if(f.empty())return 0;
		now=f.back();while(now<m&&a[n]<b[now+1])now++;
		return now==m;
	}
	si bool check2(){
		if(TestCase>=8&&TestCase<=14)return 0;
		vector<int> f;
		int now=1;while(now<=m&&b[now]<a[1])f.push_back(now++);
//		cout<<"F "<<1<<endl;for(int i:f)cout<<i<<' ';
//		cout<<endl;
		for(int i=2;i<=n;i++){
			vector<int> tmp;
			int mx=0;
			for(int j:f){
				if(j<mx)continue;
				if(b[j]<a[i])tmp.push_back(j);
				mx=j+1;while(mx<=m&&b[mx]<a[i])tmp.push_back(mx++);
			}
			tmp.erase(unique(tmp.begin(),tmp.end()),tmp.end());
			f=tmp;
//			cout<<"F "<<i<<endl;
//			for(int j:f)cout<<j<<' ';
//			cout<<endl;
		}
		if(f.empty())return 0;
		now=f.back();while(now<m&&a[n]>b[now+1])now++;
		return now==m;
	}
	void mian(){
		read(TestCase),read(n),read(m),read(Q);
		for(int i=1;i<=n;i++)read(a[i]),Orga[i]=a[i];
		for(int i=1;i<=m;i++)read(b[i]),Orgb[i]=b[i];
		cout<<(check1()||check2());
		for(int i=1,Kx,Ky;i<=Q;i++){
			read(Kx),read(Ky);
			for(int j=1,pos,v;j<=Kx;j++){
				read(pos),read(v);
				a[pos]=v;
			}
			for(int j=1,pos,v;j<=Ky;j++){
				read(pos),read(v);
				b[pos]=v;
			}
//			cout<<"NOW "<<i<<endl;
//			for(int j=1;j<=n;j++)cout<<a[j]<<' ';
//			cout<<endl;
//			for(int j=1;j<=m;j++)cout<<b[j]<<' ';
//			cout<<endl;
			cout<<(check1()||check2());
//			cout<<check1()<<' '<<check2()<<endl;
			memcpy(a,Orga,sizeof a);
			memcpy(b,Orgb,sizeof b);
		}
	}
}

signed main(){
//	freopen("expand4.in","r",stdin);
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	LinkWish::mian();
	return 0;
}

