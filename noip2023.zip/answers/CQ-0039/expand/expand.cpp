// pls, open in utf-8 mode

#include <bits/stdc++.h>
using namespace std;
const int MAXN = 500005;
int x[MAXN], y[MAXN];
int nxtmin[MAXN], nxtmax[MAXN];
int midmax[MAXN], midmin[MAXN];
bool solveminmax(int *x, int *y, int n, int m) {
    stack<int> stk; stk.push(n - 1);
    // printf("sv %d %d\n", n, m);
    for (int i = n - 2; ~i; i--) {
        // puts("??????[");
        while (x[stk.top()] > x[i]) stk.pop();
        nxtmin[i] = stk.top(); stk.push(i);
        // printf("nxtmin %d = %d\n", i, nxtmin[i]);
    }
    for (int i = 0; i != n - 1; ) {
        int nxti = nxtmin[i]; midmax[i] = 0;
        for (int j = i; j < nxti; j++) midmax[i] = max(midmax[i], x[j]);
        i = nxti;
    }
    while (stk.empty() == 0) stk.pop();
    stk.push(m - 1);
    for (int i = m - 2; ~i; i--) {
        // puts("?????????????dfdfd");
        while (y[stk.top()] < y[i]) stk.pop();
        nxtmax[i] = stk.top(); stk.push(i);
        // printf("nxtmax %d = %d\n", i, nxtmax[i]);
    }
    for (int i = 0; i != m - 1; ) {
        int nxti = nxtmax[i]; midmin[i] = 0x3f3f3f3f;
        for (int j = i; j < nxti; j++) midmin[i] = min(midmin[i], y[j]);
        i = nxti;
    }
    for (int i = 0, j = 0; i != n - 1 || j != m - 1; ) {
        if (i != n - 1 && midmax[i] < y[j]) i = nxtmin[i];
        else if (j != m - 1 && midmin[j] > x[i]) j = nxtmax[j];
        else return 0;
    }
    return 1;
}
bool solve(int *x, int *y, int n, int m) {
    // x[0] < y[0], x[n - 1] < y[m - 1]
    if (x[0] >= y[0] || x[n - 1] >= y[m - 1]) return 0;
    int minx = 0, maxy = 0; // puts("??????");
    for (int i = 1; i < n; i++) if (x[i] < x[minx]) minx = i;
    for (int i = 1; i < m; i++) if (y[i] > y[maxy]) maxy = i;
    bool ans = solveminmax(x, y, minx + 1, maxy + 1);
    reverse(x, x + n); reverse(y, y + m);
    ans &= solveminmax(x, y, n - minx, m - maxy);
    reverse(x, x + n); reverse(y, y + m);
    return ans;
}
pair<int, int> opform[2][MAXN];
int read() {
    char ch; while ((ch = getchar()) <= ' '); int x = ch - '0'; while ((ch = getchar()) > ' ') x = 10 * x + ch - '0'; return x;
}
int main() {
    freopen("expand.in", "r", stdin);
    freopen("expand.out", "w", stdout);
    int c, n, m, q; c = read(); n = read(); m = read(); q = read();
    for (int i = 1; i <= n; i++) x[i] = read();
    for (int i = 1; i <= m; i++) y[i] = read();
    putchar('0' + (solve(x + 1, y + 1, n, m) || solve(y + 1, x + 1, m, n)));
    while (q--) {
        int a, b; a = read(); b = read();
        for (int i = 1; i <= a; i++) {
            int C; opform[0][i].first = read(), C = read();
            opform[0][i].second = x[opform[0][i].first];
            x[opform[0][i].first] = C;
        }
        for (int i = 1; i <= b; i++) {
            int C; opform[1][i].first = read(); C = read();
            opform[1][i].second = y[opform[1][i].first];
            y[opform[1][i].first] = C;
        }
        putchar('0' + (solve(x + 1, y + 1, n, m) || solve(y + 1, x + 1, m, n)));
        for (int i = 1; i <= a; i++) x[opform[0][i].first] = opform[0][i].second;
        for (int i = 1; i <= b; i++) y[opform[1][i].first] = opform[1][i].second;
    }
    puts("");
}
/*
这是 t3？这是 t3？这是 t3？这是 t3？这是 t3？这是 t3？这是 t3？这是 t3？这是 t3？这是 t3？这是 t3？这是 t3？这是 t3？这是 t3？这是 t3？这是 t3？这是 t3？这是 t3？这是 t3？这是 t3？这是 t3？这是 t3？
uid=109114
3 3 3 3
8 6 9
1 7 4
1 0
3 0
0 2
1 8
3 5
1 1
2 8
1 7
*/