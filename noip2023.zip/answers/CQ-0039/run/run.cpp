// pls, open in utf-8 mode

#include <bits/stdc++.h>
using namespace std;
const int MAXN = 100005;
struct node {int t, x, w; bool operator < (const node &sec) const {return t < sec.t;}} wtf[MAXN];
int n, m, k; long long d;
namespace sgt {
    long long val[MAXN * 128], tag[MAXN * 128];
    int ntot, ls[MAXN * 128], rs[MAXN * 128];
    int newnode(int l, int r) {ntot++; ls[ntot] = rs[ntot] = 0; val[ntot] = r * d; tag[ntot] = 0; return ntot;}
    void addtag(int rt, long long w) {tag[rt] += w; val[rt] += w;}
    void pushdown(int rt, int l, int r) {if (tag[rt]) {
            int mid = (l + r) >> 1; if (ls[rt] == 0) ls[rt] = newnode(l, mid); if (rs[rt] == 0) rs[rt] = newnode(mid + 1, r);
            addtag(ls[rt], tag[rt]); addtag(rs[rt], tag[rt]); tag[rt] = 0;
    }}
    void build(int &rt, int l, int r) {ntot = 0; val[0] = -0x3f3f3f3f3f3f3f; rt = newnode(l, r);}
    void pushup(int rt) {val[rt] = max(val[ls[rt]], val[rs[rt]]);}
    void modify(int &rt, int l, int r, int x, int y, long long w) {
        if (rt == 0) rt = newnode(l, r); if (x <= l && r <= y) return addtag(rt, w); int mid = (l + r) >> 1; pushdown(rt, l, r);
        if (x <= mid) modify(ls[rt], l, mid, x, y, w); if (y > mid) modify(rs[rt], mid + 1, r, x, y, w); pushup(rt);
    }
    long long query(int rt, int l, int r, int x, int y) {
        if (x <= l && r <= y) return val[rt]; int mid = (l + r) >> 1; long long ans = -0x3f3f3f3f3f3f3f3f; pushdown(rt, l, r);
        if (x <= mid) ans = query(ls[rt], l, mid, x, y); if (y > mid) ans = max(ans, query(rs[rt], mid + 1, r, x, y)); return ans;
    }
}
int read() {
    char ch; while ((ch = getchar()) <= ' '); int x = ch - '0'; while ((ch = getchar()) > ' ') x = 10 * x + ch - '0'; return x;
}
int main() {
    freopen("run.in", "r", stdin);
    freopen("run.out", "w", stdout);
    int c, t; c = read(); t = read(); while (t--) {
        n = read(); m = read(); k = read(); d = read();
        int rt; sgt::build(rt, 0, 1e9);
        for (int i = 1; i <= m; i++) {
            int a, b, c; a = read(); b = read(); c = read();
            wtf[i] = {a, b, c};
        }
        sort(wtf + 1, wtf + 1 + m);
        long long hismax = 0;
        for (int i = 1; i <= m; i++) {
            sgt::modify(rt, 0, 1e9, 0, wtf[i].t - wtf[i].x, wtf[i].w);
            long long newval = sgt::query(rt, 0, 1e9, max(0, wtf[i].t - k), wtf[i].t) - wtf[i].t * d;
            if (newval > hismax) {
                if (wtf[i].t + 1 <= 1e9) sgt::modify(rt, 0, 1e9, wtf[i].t + 1, 1e9, newval - hismax);
                hismax = newval;
            }
            // printf("%d : %lld\n", i, newval);
        }
        printf("%lld\n", hismax);
    }
}
/*
这是 t4？这是 t4？这是 t4？这是 t4？这是 t4？这是 t4？这是 t4？这是 t4？这是 t4？这是 t4？这是 t4？这是 t4？这是 t4？这是 t4？这是 t4？这是 t4？这是 t4？这是 t4？这是 t4？这是 t4？这是 t4？这是 t4？
还有两个小时，冲 t3 绰绰有余
uid = 109114
1 1
3 2 2 1
2 2 4
3 2 3



stu@cqyz:/mnt/share/CQ-0039$ g++ -O2 -Wall -Wextra -Wno-unused-result -std=c++11 -fsanitize=undefined -o dict dict.cpp
all -Wextra -Wno-unused-result -std=c++11 -fsanitize=undefined -o tribool tribool.cpp
g++ -O2 -Wall -Wextra -Wno-unused-result -std=c++11 -fsanitize=undefined -o expand expand.cpp
g++ -O2 -Wall -Wextra -Wno-unused-result -std=c++11 -fsanitize=undefined -o run run.cpp
./dict < dict.in > dict.out
./dict < dict1.in > dict1.out
./dict < dict2.in > dict2.out
./dict < dict3.in > dict3.out
./tribool < tribool.in > tribool.out
./tribool < tribool1.in > tribool1.out
./tribool < tribool2.in > tribool2.out
./tribool < tribool3.in > tribool3.out
./expand < expand.in > expand.out
./expand < expand1.in > expand1.out
./expand < expand2.in > expand2.out
./expand < expand3.in > expand3.out
./expand < expand4.in > expand4.out
./run < run.in > run.out
./run < run1.in > run1.out
./run < run2.in > run2.out
./run < run3.in > run3.out
./run < run4.in > run4.out
./run < run5.in > run5.out
diff dict.out dict.ans
diff dict1.out dict1.ans
diff dict2.out dict2.ans
diff dict3.out dict3.ans
diff tribool.out tribool.ans
diff tribool1.out tribool1.ans
diff tribool2.out tribool2.ans
diff tribool3.out tribool3.ans
diff expand.out expand.ans
diff expand1.out expand1.ans
diff expand2.out expand2.ans
diff expand3.out expand3.ans
diff expand4.out expand4.ans
diff run.out run.ans
diff run1.out run1.ans
diff run2.out run2.ans
diff run3.out run3.ans
diff run4.out run4.ans
diff run5.out run5.ans
stu@cqyz:/mnt/share/CQ-0039$ g++ -O2 -Wall -Wextra -Wno-unused-result -std=c++11 -fsanitize=undefined -o tribool tribool.cpp
stu@cqyz:/mnt/share/CQ-0039$ g++ -O2 -Wall -Wextra -Wno-unused-result -std=c++11 -fsanitize=undefined -o expand expand.cpp
expand.cpp: In function ‘int main()’:
expand.cpp:60:9: warning: variable ‘c’ set but not used [-Wunused-but-set-variable]
   60 |     int c, n, m, q; c = read(); n = read(); m = read(); q = read();
      |         ^
stu@cqyz:/mnt/share/CQ-0039$ g++ -O2 -Wall -Wextra -Wno-unused-result -std=c++11 -fsanitize=undefined -o run run.cpp
run.cpp: In function ‘int sgt::newnode(int, int)’:
run.cpp:9:21: warning: unused parameter ‘l’ [-Wunused-parameter]
    9 |     int newnode(int l, int r) {ntot++; ls[ntot] = rs[ntot] = 0; val[ntot] = r * d; tag[ntot] = 0; return ntot;}
      |                 ~~~~^
run.cpp: In function ‘void sgt::modify(int&, int, int, int, int, long long int)’:
run.cpp:18:9: warning: this ‘if’ clause does not guard... [-Wmisleading-indentation]
   18 |         if (rt == 0) rt = newnode(l, r); if (x <= l && r <= y) return addtag(rt, w); int mid = (l + r) >> 1; pushdown(rt, l, r);
      |         ^~
run.cpp:18:42: note: ...this statement, but the latter is misleadingly indented as if it were guarded by the ‘if’
   18 |         if (rt == 0) rt = newnode(l, r); if (x <= l && r <= y) return addtag(rt, w); int mid = (l + r) >> 1; pushdown(rt, l, r);
      |                                          ^~
run.cpp:19:9: warning: this ‘if’ clause does not guard... [-Wmisleading-indentation]
   19 |         if (x <= mid) modify(ls[rt], l, mid, x, y, w); if (y > mid) modify(rs[rt], mid + 1, r, x, y, w); pushup(rt);
      |         ^~
run.cpp:19:56: note: ...this statement, but the latter is misleadingly indented as if it were guarded by the ‘if’
   19 |         if (x <= mid) modify(ls[rt], l, mid, x, y, w); if (y > mid) modify(rs[rt], mid + 1, r, x, y, w); pushup(rt);
      |                                                        ^~
run.cpp: In function ‘long long int sgt::query(int, int, int, int, int)’:
run.cpp:22:9: warning: this ‘if’ clause does not guard... [-Wmisleading-indentation]
   22 |         if (x <= l && r <= y) return val[rt]; int mid = (l + r) >> 1; long long ans = -0x3f3f3f3f3f3f3f3f; pushdown(rt, l, r);
      |         ^~
run.cpp:22:47: note: ...this statement, but the latter is misleadingly indented as if it were guarded by the ‘if’
   22 |         if (x <= l && r <= y) return val[rt]; int mid = (l + r) >> 1; long long ans = -0x3f3f3f3f3f3f3f3f; pushdown(rt, l, r);
      |                                               ^~~
run.cpp:23:9: warning: this ‘if’ clause does not guard... [-Wmisleading-indentation]
   23 |         if (x <= mid) ans = query(ls[rt], l, mid, x, y); if (y > mid) ans = max(ans, query(rs[rt], mid + 1, r, x, y)); return ans;
      |         ^~
run.cpp:23:58: note: ...this statement, but the latter is misleadingly indented as if it were guarded by the ‘if’
   23 |         if (x <= mid) ans = query(ls[rt], l, mid, x, y); if (y > mid) ans = max(ans, query(rs[rt], mid + 1, r, x, y)); return ans;
      |                                                          ^~
run.cpp: In function ‘int main()’:
run.cpp:32:9: warning: variable ‘c’ set but not used [-Wunused-but-set-variable]
   32 |     int c, t; c = read(); t = read(); while (t--) {
      |         ^
stu@cqyz:/mnt/share/CQ-0039$ ./dict < dict.in > dict.out
stu@cqyz:/mnt/share/CQ-0039$ ./dict < dict1.in > dict1.out
stu@cqyz:/mnt/share/CQ-0039$ ./dict < dict2.in > dict2.out
stu@cqyz:/mnt/share/CQ-0039$ ./dict < dict3.in > dict3.out
stu@cqyz:/mnt/share/CQ-0039$ ./tribool < tribool.in > tribool.out
stu@cqyz:/mnt/share/CQ-0039$ ./tribool < tribool1.in > tribool1.out
stu@cqyz:/mnt/share/CQ-0039$ ./tribool < tribool2.in > tribool2.out
stu@cqyz:/mnt/share/CQ-0039$ ./tribool < tribool3.in > tribool3.out
stu@cqyz:/mnt/share/CQ-0039$ ./expand < expand.in > expand.out
stu@cqyz:/mnt/share/CQ-0039$ ./expand < expand1.in > expand1.out
stu@cqyz:/mnt/share/CQ-0039$ ./expand < expand2.in > expand2.out
stu@cqyz:/mnt/share/CQ-0039$ ./expand < expand3.in > expand3.out
stu@cqyz:/mnt/share/CQ-0039$ ./expand < expand4.in > expand4.out
stu@cqyz:/mnt/share/CQ-0039$ ./run < run.in > run.out
stu@cqyz:/mnt/share/CQ-0039$ ./run < run1.in > run1.out
stu@cqyz:/mnt/share/CQ-0039$ ./run < run2.in > run2.out
stu@cqyz:/mnt/share/CQ-0039$ ./run < run3.in > run3.out
stu@cqyz:/mnt/share/CQ-0039$ ./run < run4.in > run4.out
stu@cqyz:/mnt/share/CQ-0039$ ./run < run5.in > run5.out
stu@cqyz:/mnt/share/CQ-0039$ diff dict.out dict.ans
stu@cqyz:/mnt/share/CQ-0039$ diff dict1.out dict1.ans
stu@cqyz:/mnt/share/CQ-0039$ diff dict2.out dict2.ans
stu@cqyz:/mnt/share/CQ-0039$ diff dict3.out dict3.ans
stu@cqyz:/mnt/share/CQ-0039$ diff tribool.out tribool.ans
stu@cqyz:/mnt/share/CQ-0039$ diff tribool1.out tribool1.ans
stu@cqyz:/mnt/share/CQ-0039$ diff tribool2.out tribool2.ans
stu@cqyz:/mnt/share/CQ-0039$ diff tribool3.out tribool3.ans
stu@cqyz:/mnt/share/CQ-0039$ diff expand.out expand.ans
stu@cqyz:/mnt/share/CQ-0039$ diff expand1.out expand1.ans
stu@cqyz:/mnt/share/CQ-0039$ diff expand2.out expand2.ans
stu@cqyz:/mnt/share/CQ-0039$ diff expand3.out expand3.ans
stu@cqyz:/mnt/share/CQ-0039$ diff expand4.out expand4.ans
stu@cqyz:/mnt/share/CQ-0039$ diff run.out run.ans
stu@cqyz:/mnt/share/CQ-0039$ diff run1.out run1.ans
stu@cqyz:/mnt/share/CQ-0039$ diff run2.out run2.ans
stu@cqyz:/mnt/share/CQ-0039$ diff run3.out run3.ans
stu@cqyz:/mnt/share/CQ-0039$ diff run4.out run4.ans
stu@cqyz:/mnt/share/CQ-0039$ diff run5.out run5.ans
stu@cqyz:/mnt/share/CQ-0039$ 

看样子 rp 被前天的 rk-4 垫上力
关注 109114 写写喵
general red /bx
Felix72 /bx
cqdzwh /bx
15 /bx
tuxuanming2024 /bx
priority /bx
(p-1)! mod p /bx
this->CE /bx
3 /bx
oxford /bx
chicken /bx
missel /bx
2e9 /bx
ytbetter /bx

太激动了第一次 ak noip



不吹不捧，ccf 的出题质量确实越来越高，但是难度是怎么一会是呢？
*/