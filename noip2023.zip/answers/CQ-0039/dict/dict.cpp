#include <bits/stdc++.h>
using namespace std;
const int MAXN = 3005;
char str[MAXN][MAXN];
int buc[MAXN][26];
int lchar[MAXN], fchar[MAXN];
int main() {
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);
	int n, m; scanf("%d %d", &n, &m);
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= m; j++) {
			while ((str[i][j] = getchar()) <= ' ');
			buc[i][str[i][j] - 'a']++;
		}
	}
	for (int i = 1; i <= n; i++) {
		for (int j = 0; j < 26; j++) if (buc[i][j]) lchar[i] = j;
		for (int j = 25; ~j; j--) if (buc[i][j]) fchar[i] = j;
	}
	for (int i = 1; i <= n; i++) {
		bool tag = 1;
		for (int j = 1; j <= n; j++) {
			if (j == i) continue;
		//	printf("%d %d\n", lchar[j], fchar[i]);
			if (lchar[j] < fchar[i]) tag = 0;
			else if (lchar[j] == fchar[i]) {
				tag = 0;
			}
		}
		putchar(tag + '0');
	} puts("");
}
/*
4 7
abandon
bananaa
baannaa
notnotn
*/
