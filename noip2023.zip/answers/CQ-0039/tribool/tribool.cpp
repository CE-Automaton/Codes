#include <bits/stdc++.h>
using namespace std;
const int MAXN = 100005;
int rf[MAXN]; bool tg[MAXN];
int ind[MAXN], siz[MAXN];
bool vis[MAXN];
pair<int, int> lnkto[MAXN];queue<int> q; 
int main() {
    freopen("tribool.in", "r", stdin);
    freopen("tribool.out", "w", stdout);
    int t; scanf("%*d %d", &t); while (t--) {
        // puts("??????");
        int n, m; scanf("%d %d", &n, &m);
        for (int i = 1; i <= n; i++) rf[i] = i, tg[i] = 0;
        while (m--) {
            // printf("m = %d\n", m);
            char str[6]; int x, y; scanf("%s %d", str, &x);
            if (str[0] == '+') {
                scanf("%d" ,&y); rf[x] = rf[y]; tg[x] = tg[y];
            }
            if (str[0] == '-') {
                scanf("%d", &y); rf[x] = rf[y]; tg[x] = !tg[y];
            }
            if (str[0] == 'T') rf[x] = -1, tg[x] = 0;
            if (str[0] == 'F') rf[x] = -2, tg[x] = 0;
            if (str[0] == 'U') rf[x] = -3, tg[x] = 0;
        }
        for (int i = 1; i <= n + 3; i++) ind[i] = 0, siz[i] = 1, vis[i] = 0;
        for (int i = 1; i <= n; i++) {
            if (rf[i] < 0) {
                if (rf[i] >= -2 && tg[i]) rf[i] = -3 - rf[i], tg[i] = 0;
                ind[n - rf[i]]++; lnkto[i] = {n - rf[i], tg[i]};
            }
            else ind[rf[i]]++, lnkto[i] = {rf[i], tg[i]};
        }
        ind[n + 1]++; lnkto[n + 2] = {n + 1, 1};
        ind[n + 2]++; lnkto[n + 1] = {n + 2, 1};
        ind[n + 3]++; lnkto[n + 3] = {n + 3, 1};
        for (int i = 1; i <= n + 3; i++) {
            if (ind[i] == 0) q.push(i);
        }
        while (q.empty() == 0) {
            int u = q.front(); q.pop();
            vis[u] = 1;
            ind[lnkto[u].first]--; siz[lnkto[u].first] += siz[u];
            if (ind[lnkto[u].first] == 0) q.push(lnkto[u].first);
        }
        int ans = 0;
        for (int i = 1; i <= n + 3; i++) {
            if (vis[i] == 0) {
                int u = i, p = 0, sizsum = 0; do {
                    sizsum += siz[u]; vis[u] = 1;
                    p ^= lnkto[u].second; u = lnkto[u].first; 
                } while (u != i);
                if (p) ans += sizsum;
            }
        }
        printf("%d\n", ans - 1);
    }
}
/*
1 3
3 3
‐ 2 1
‐ 3 2
+ 1 3
3 3
‐ 2 1
‐ 3 2
‐ 1 3
2 2
T 2
U 2
*/