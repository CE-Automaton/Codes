#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define pii pair<int,int>
#define fi first
#define dl double
#define se second
#define pk push_back
#define N 3010
using namespace std;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int f__[40];
il void write(int x){
	int cnt=0;
	if(!x) putchar('0');
	if(x<0){
		x=-x;putchar('-');
	}
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int n,m,pre[N],suf[N];
char S[N][N];
il bool cmp(char u,char v){
    return u>v;
}
il bool check(int i,int j){
    for(int k=0;k<m;++k){
        if(S[i][k]<S[j][k]) return 1;
        if(S[i][k]>S[j][k]) return 0;
    }
    return 0;
}
signed main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
    n=read();m=read();
    for(int i=1;i<=n;++i){
        scanf(" %s",S[i]);sort(S[i],S[i]+m,cmp);
        // printf("%s\n",S[i]);
    }
    // cerr<<(dl)clock()/CLOCKS_PER_SEC<<"\n";
    pre[1]=1;
    for(int i=2;i<=n;++i){
        pre[i]=pre[i-1];
        if(check(i,pre[i])) pre[i]=i;
    }
    suf[n]=n;
    for(int i=n-1;i;--i){
        suf[i]=suf[i+1];
        if(check(i,suf[i])) suf[i]=i;
        // cerr<<suf[i]<<" ";
    }
    for(int i=1;i<=n;++i){
        sort(S[i],S[i]+m);
        if((i==1||check(i,pre[i-1]))&&(i==n||check(i,suf[i+1]))) putchar('1');
        else putchar('0');
        sort(S[i],S[i]+m,cmp);
    }
	return 0;
}
