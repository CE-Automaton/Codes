#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define pii pair<int,int>
#define fi first
#define dl double
#define se second
#define pk push_back
#define N 400010
using namespace std;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int f__[40];
il void write(int x){
	int cnt=0;
	if(!x) putchar('0');
	if(x<0){
		x=-x;putchar('-');
	}
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int T,n,m,now[N],id,f[N];
bool chk[N];
char op[3];
il int find(int x){
    return f[x]==x?x:f[x]=find(f[x]);
}
il void merge(int u,int v){
    f[find(u)]=find(v);
}
signed main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
    read();T=read();
    while(T--){
        for(int i=0;i<N;++i){
            f[i]=i;
            chk[i]=0;
        }
        n=read();m=read();
        id=5;
        for(int i=1;i<=n;++i){
            now[i]=++id;++id;
            // cerr<<now[i]<<" ";
        }
        merge(0,3);merge(1,2);merge(4,5);
        // cerr<<find(0)<<" "<<find(3)<<"\n";
        while(m--){
            scanf(" %s",op);
            if(op[0]=='+'){
                int i=read(),j=read();
                int tmp=++id;++id;
                merge(tmp,now[j]);merge(tmp+1,now[j]+1);
                now[i]=tmp;
            }
            else if(op[0]=='-'){
                int i=read(),j=read();
                int tmp=++id;++id;
                merge(tmp,now[j]+1);merge(tmp+1,now[j]);
                now[i]=tmp;
                // cerr<<now[i]<<" "<<now[j]+1<<"\n";
                // cerr<<now[i]+1<<" "<<now[j]<<"\n";
            }
            else{
                // cerr<<"ERROR";
                int i=read();
                int tmp=++id;++id;
                if(op[0]=='T'){
                    merge(tmp,0);merge(tmp+1,1);
                }
                else if(op[0]=='F'){
                    merge(tmp,2);merge(tmp+1,3);
                }
                else{
                    merge(tmp,3);merge(tmp+1,4);
                }
                now[i]=tmp;
            }
        }
        for(int i=1;i<=n;++i){
            merge(now[i],5+(i-1)*2+1);merge(now[i]+1,5+(i-1)*2+2);
            // cerr<<now[i]<<" "<<5+(i-1)*2+1<<"\n";
        }
        for(int i=0;i<=id;i+=2) if(find(i)==find(i^1)) chk[find(i)]=1;
        int ans=0;
        for(int i=1;i<=n;++i){
            // cerr<<chk[find(5+(i-1)*2+1)]<<" "<<find(5+(i-1)*2+2)<<"\n";
            if(chk[find(5+(i-1)*2+1)]||chk[find(5+(i-1)*2+2)]){
                ++ans;
                // cerr<<i<<" ";
            }
        }
        write(ans);putchar('\n');
    }
	return 0;
}
