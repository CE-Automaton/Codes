#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define pii pair<int,int>
#define fi first
#define dl double
#define se second
#define pk push_back
#define N 200010
#define inf (int)(1000000000000000000)
using namespace std;
bool ppp;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int f__[40];
il void write(int x){
	int cnt=0;
	if(!x) putchar('0');
	if(x<0){
		x=-x;putchar('-');
	}
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int T,n,m,K,d,z[N<<1],tot,ans,dp[N],type,ss[N];
struct node{
    int l,r,v;
    il bool operator<(ct node &x)ct{
        return r<x.r;
    }
} op[N];
struct BIT1{
    int sum[N];
    il int lowbit(int x){
        return x&-x;
    }
    il void init(){
        for(int i=0;i<=tot;++i) sum[i]=0;
    }
    il void add(int x,int k){
        for(;x<=tot;x+=lowbit(x)) sum[x]+=k;
    }
    il int query(int x){
        int res=0;
        for(;x;x-=lowbit(x)) res+=sum[x];
        return res;
    }
} BT1;
struct BIT2{
    int mx[N];
    il int lowbit(int x){
        return x&-x;
    }
    il void init(){
        for(int i=0;i<=tot;++i) mx[i]=-inf;
    }
    il void add(int x,int k){
        for(;x<=tot;x+=lowbit(x)) mx[x]=max(mx[x],k);
    }
    il int query(int x){
        int res=0;
        for(;x;x-=lowbit(x)) res=max(res,mx[x]);
        return res;
    }
} BT2;
il void solve1(){
    for(int i=1;i<=m;++i) ss[i]=ss[i-1]+op[i].v;
    for(int i=1;i<=m;++i){
        dp[i]=op[i].v-(op[i].r-op[i].l+1)*d;
        for(int j=max(0ll,i-10);j<i;++j){
            if(op[j].r+1<op[j+1].l) dp[i]=max(dp[i],dp[j]+ss[i]-ss[j]-(op[i].r-op[j+1].l+1)*d);
            else if(j+2<i) dp[i]=max(dp[i],dp[j]+ss[i]-ss[j+1]-(op[i].r-op[j+2].l+1)*d);
        }
        dp[i]=max(dp[i],dp[i-1]);
    }
    write(dp[m]);putchar('\n');
}
il int find(int x){
    return lower_bound(z+1,z+1+tot,x)-z;
}
il void solve2(){
    BT1.init();BT2.init();
    for(int i=1,now=1;i<=tot;++i){
        while(now<=m&&op[now].r<=z[i]){
            if(op[now].l>0) BT1.add(tot-find(op[now].l)+1,op[now].v);
            ++now;
        }
        dp[i]=0;
        for(int j=lower_bound(z+1,z+1+tot,z[i]-K+1)-z;j<=i;++j){
            int tmp=j-1;
            if(tmp&&z[tmp]+1==z[j]) --tmp;
            dp[i]=max(dp[i],BT1.query(tot-j+1)+BT2.query(tmp)-d*(z[i]-z[j]+1));
        }
        ans=max(ans,dp[i]);BT2.add(i,dp[i]);
    }
    write(ans);putchar('\n');
}
bool pppp;
signed main(){
    cerr<<(&ppp-&pppp)/1024.0/1024.0<<"\n";
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
    type=read();T=read();
    while(T--){
        n=read();m=read();K=read();d=read();tot=ans=0;
        for(int i=1;i<=m;++i){
            op[i].l=read();op[i].r=read();op[i].v=read();
            op[i].l=op[i].l-op[i].r+1;op[i].r=op[i].l+op[i].r-1;
            z[++tot]=op[i].l;z[++tot]=op[i].r;
        }
        sort(z+1,z+1+tot);
        tot=unique(z+1,z+1+tot)-z-1;
        sort(op+1,op+1+m);
        if(type==17||type==18) solve1();
        else solve2();
    }
	return 0;
}
