#include<bits/stdc++.h>
#define int long long
#define il inline
#define ct const
#define pii pair<int,int>
#define fi first
#define dl double
#define se second
#define pk push_back
#define N 500010
using namespace std;
il int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int f__[40];
il void write(int x){
	int cnt=0;
	if(!x) putchar('0');
	if(x<0){
		x=-x;putchar('-');
	}
	while(x){
		f__[cnt++]=x%10+'0';x/=10;
	}
	while(cnt) putchar(f__[--cnt]);
}
int type,n,m,Q,x_[N],y_[N],x[N],y[N];
bool dp[2010][2010];
il void init(){
    for(int i=0;i<=n;++i) for(int j=0;j<=m;++j) dp[i][j]=0;
}
il void solve(){
    init();
    if(x[n]<y[m]){
        dp[1][1]=1;
        for(int i=1;i<=n;++i){
            for(int j=1;j<=m;++j) if(dp[i][j]&&x[i]<y[j]){
                dp[i+1][j]=dp[i][j+1]=dp[i+1][j+1]=1;
            }
        }
    }
    if(x[n]>y[m]){
        dp[1][1]=1;
        for(int i=1;i<=n;++i){
            for(int j=1;j<=m;++j) if(dp[i][j]&&x[i]>y[j]){
                dp[i+1][j]=dp[i][j+1]=dp[i+1][j+1]=1;
            }
        }
    }
    if(dp[n][m]) putchar('1');
    else putchar('0');
}
signed main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
    type=read();n=read();m=read();Q=read();
    for(int i=1;i<=n;++i) x[i]=x_[i]=read();
    for(int i=1;i<=m;++i) y[i]=y_[i]=read();
    solve();
    while(Q--){
        int kx=read(),ky=read();
        for(int i=1;i<=n;++i) x[i]=x_[i];
        for(int i=1;i<=m;++i) y[i]=y_[i];
        while(kx--){
            int p=read(),v=read();
            x[p]=v;
        }
        while(ky--){
            int p=read(),v=read();
            y[p]=v;
        }
        solve();
    }
	return 0;
}
