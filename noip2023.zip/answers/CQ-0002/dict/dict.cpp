#include<bits/stdc++.h>
using namespace std;
#define int long long
#define rep(i,j,k) for(int i=(j);i<=(k);i++)
#define per(i,j,k) for(int i=(j);i>=(k);i--)
#define pb push_back
#define mp make_pair
#define fi first
#define se second
typedef vector<int> vi;
typedef pair<int,int> pi;

const int N=3005,b0=131,b1=193,mod=1e9+7;
struct Hash{
	int a,b;
}e{b0,b1},O{0,0};
Hash operator+(const Hash &A,const Hash &B){
	Hash res={A.a+B.a,A.b+B.b};
	if(res.a>=mod){
		res.a-=mod;
	}
	if(res.b>=mod){
		res.b-=mod;
	}
	return res;
};
Hash operator-(const Hash &A,const Hash &B){
	Hash res={A.a-B.a,A.b-B.b};
	if(res.a<0){
		res.a+=mod;
	}
	if(res.b<0){
		res.b+=mod;
	}
	return res;
}
Hash operator*(const Hash &A,const Hash &B){
	return {A.a*B.a%mod,A.b*B.b%mod};
}
bool operator==(const Hash &A,const Hash &B){
	return A.a==B.a && A.b==B.b;
}
Hash P[N];
int n,m;
string s[N],t[N];
Hash val[N][N];
signed main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	cin>>n>>m;
	rep(i,1,n){
		cin>>s[i];
		sort(s[i].begin(),s[i].end());
		t[i]=s[i];
		reverse(s[i].begin(),s[i].end());
		
		rep(j,0,m-1){
			val[i][j]=(i==0?O:val[i][j-1]*e)+(Hash){s[i][j],s[i][j]};
		}
	}
	rep(i,1,n){
		Hash cur[N]{};
		rep(j,0,m-1){
			cur[j]=(j==0?O:cur[j-1]*e)+(Hash){t[i][j],t[i][j]};
		}
		bool flag=1;
		rep(j,1,n){
			if(i==j){
				continue;
			}
			int l=-1,r=m-1;
			while(l<r){
				int mid=(l+r+1)/2;
				Hash val0=cur[mid],val1=val[j][mid];
				if(!(val0==val1)){
					r=mid-1;
				}
				else{
					l=mid;
				}
			}
			if(l==m-1 || t[i][l+1]>s[j][l+1]){
				flag=0;
				break;
			}
		}
		cout<<flag;
	}
	return 0;
}
