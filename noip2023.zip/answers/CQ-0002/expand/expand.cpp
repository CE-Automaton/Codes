#include<bits/stdc++.h>
using namespace std;
//#define int long long
#define rep(i,j,k) for(int i=(j);i<=(k);i++)
#define per(i,j,k) for(int i=(j);i>=(k);i--)
#define pb push_back
#define mp make_pair
#define fi first
#define se second
typedef vector<int> vi;
typedef pair<int,int> pi;

const int N=5e5+5,lim=1e9;
int n,m;
int A[N],B[N];
int rA[N],rB[N];
void solve(){
	vi a(A,A+n+1),b(B,B+m+1),c(m+1),d(m+1);
	if(a[1]>b[1]){
		rep(i,1,n){
			a[i]=lim-a[i];
		}
		rep(i,1,m){
			b[i]=lim-b[i];
		}
	}
	per(i,m,0){
		c[i]=(i==m?b[i]:max(b[i],c[i+1]));
		d[i]=(i==m?b[i]:min(b[i],d[i+1]));
	}
	int l=1,r=1,mx=m+1;
	rep(i,1,n){
		while(l<=r && b[l]<=a[i]){
			l++;
		}
		if(l>r){
			cout<<0;
			return;
		}
		while(r<m && b[r+1]>a[i]){
			r++;
		}
		mx=min(mx,(int)( lower_bound(c.begin(),c.end(),a[i],greater<int>())-c.begin() ));
		if(mx<=m && a[i]<d[mx]){
			mx=m+1;
		}
	}
	cout<<(r==m && mx==m+1);
}
signed main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int c,q;
	cin>>c>>n>>m>>q;
	rep(i,1,n){
		cin>>A[i];
		rA[i]=A[i];
	}
	rep(i,1,m){
		cin>>B[i];
		rB[i]=B[i];
	}
	solve();
	rep(i,1,q){
		rep(j,1,n){
			A[j]=rA[j];
		}
		rep(j,1,m){
			B[j]=rB[j];
		}
		int kx,ky;cin>>kx>>ky;
		rep(j,1,kx){
			int p,v;cin>>p>>v;
			A[p]=v;
		}
		rep(j,1,ky){
			int p,v;cin>>p>>v;
			B[p]=v;
		}
		solve();
	}
	return 0;
}
