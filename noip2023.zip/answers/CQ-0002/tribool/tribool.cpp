#include<bits/stdc++.h>
using namespace std;
//#define int long long
#define rep(i,j,k) for(int i=(j);i<=(k);i++)
#define per(i,j,k) for(int i=(j);i>=(k);i--)
#define pb push_back
#define mp make_pair
#define fi first
#define se second
typedef vector<int> vi;
typedef pair<int,int> pi;

const int N=1e5+5;
void solve(){
	int n,m;cin>>n>>m;
	vector<pi> val(n+1);
	rep(i,1,n){
		val[i]=mp(i,0);
	}
	rep(i,1,m){
		char op;cin>>op;
		if(op=='+'){
			int x,y;cin>>x>>y;
			val[x]=val[y];
		}
		else if(op=='-'){
			int x,y;cin>>x>>y;
			if(val[y].fi==-1){
				val[x]=mp(-1, (val[y].se==2?2:1-val[y].se) );
			}
			else{
				val[x]=mp(val[y].fi,val[y].se^1);
			}
		}
		else{
			int x;cin>>x;
			if(op=='F'){
				val[x]=mp(-1,0);
			}
			else if(op=='T'){
				val[x]=mp(-1,1);
			}
			else{
				val[x]=mp(-1,2);
			}
		}
	}
	vector<char> vis(n+1,0);
	vi cur(n+1,-1);
	function<void(int,int)> dfs=[&](int u,int cval)->void{
		if(vis[u]==2){
			return;
		}
		if(vis[u]==1){
			if(cur[u]!=cval){
				cur[u]=2;
			}
			else{
				cur[u]=cval;
			}
			return;
		}
		vis[u]=1;
		cur[u]=cval;
		if(val[u].fi==-1){
			cur[u]=val[u].se;
			vis[u]=2;
			return;
		}
		int v=val[u].fi,w=val[u].se;
		dfs(v, (w==1?1-cval:cval) );
		if(cur[v]==2){
			cur[u]=2;
		}
		vis[u]=2;
	};
	rep(i,1,n){
		if(!vis[i]){
			dfs(i,0);
		}
	}
	int ans=0;
	rep(i,1,n){
		ans+=(cur[i]==2);
	}
	cout<<ans<<'\n';
}
signed main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int c,t;cin>>c>>t;
	while(t--){
		solve();
	}
	return 0;
}
