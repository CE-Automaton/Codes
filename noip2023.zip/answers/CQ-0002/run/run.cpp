#include<bits/stdc++.h>
using namespace std;
#define int long long
#define rep(i,j,k) for(int i=(j);i<=(k);i++)
#define per(i,j,k) for(int i=(j);i>=(k);i--)
#define pb push_back
#define mp make_pair
#define fi first
#define se second
typedef vector<int> vi;
typedef pair<int,int> pi;
 
mt19937 rnd(3663);
const int N=1e5+5,M=N*5,inf=1e18;

// ƽ����һ����ά��һ����Ϣ
// split ֮ǰ ���ҵ��ֽ���Ӧ��� ����ɾ��Ȼ�����²��� ʹ�ÿ����������
// һ�� split ��ഴ�� 2 ����� 
struct info{
	int len,k,b;
	int mx(){return k<0?b:k*(len-1)+b;}
};
struct FHQ{
	int s[M][2],w[M],sz[M],mx[M],add[M],rt,tot;
	info v[M];
	int Newnode(info val){
		tot++;
		w[tot]=rnd();
		v[tot]=val;
		sz[tot]=val.len;
		mx[tot]=val.mx();
		return tot;
	}
	void pushup(int d){
		sz[d]=sz[s[d][0]]+sz[s[d][1]]+v[d].len;
		mx[d]=max(v[d].mx(),max(s[d][0]?mx[s[d][0]]:-inf,s[d][1]?mx[s[d][1]]:-inf));
	}
	void f(int d,int nw){
		mx[d]+=nw;
		v[d].b+=nw;
		add[d]+=nw;
	}
	void pushdown(int d){
		if(add[d]){
			if(s[d][0]){
				f(s[d][0],add[d]);
			}
			if(s[d][1]){
				f(s[d][1],add[d]);
			}
			add[d]=0;
		}
	}
	void split(int d,int rk,int &l,int &r){
		if(!d){
			l=r=0;
			return;
		}
		pushdown(d);
		if(rk<sz[s[d][0]]+v[d].len){
			r=d;
			split(s[d][0],rk,l,s[r][0]);
		}
		else{
			l=d;
			split(s[d][1],rk-sz[s[d][0]]-v[d].len,s[l][1],r);
		}
		pushup(d);
	}
	int Merge(int x,int y){
		if(!x || !y){
			return x+y;
		}
		if(w[x]<w[y]){
			pushdown(x);
			s[x][1]=Merge(s[x][1],y);
			pushup(x);
			return x;
		}
		pushdown(y);
		s[y][0]=Merge(x,s[y][0]);
		pushup(y);
		return y;
	}
	pi erase(int &d,int rk){
		pushdown(d);
		pi res;
		if(rk<=sz[s[d][0]]){
			res=erase(s[d][0],rk);
		}
		else{
			rk-=sz[s[d][0]];
			if(rk<=v[d].len){
				int u=d;
				d=Merge(s[d][0],s[d][1]);
				return mp(u,rk);
			}
			else{
				res=erase(s[d][1],rk-v[d].len);
			}
		}
		pushup(d);
		return res;
	}
	void dfs(int d){
		if(!d){
			return;
		}
		pushdown(d);
		dfs(s[d][0]);
		cout<<d<<' '<<v[d].len<<' '<<v[d].k<<' '<<v[d].b<<' '<<mx[d]<<endl;
		dfs(s[d][1]);
	}
	void Split(int rk,int &rt0,int &rt1){
		pi Get=erase(rt,rk);
		int u=Get.fi,le=Get.se,ri=v[u].len-le;
		split(rt,rk-le,rt0,rt1);
		
		if(le){
			rt0=Merge(rt0,Newnode( {le,v[u].k,v[u].b} ));
		}
		if(ri){
			rt1=Merge(Newnode( {ri,v[u].k,v[u].b+v[u].k*le} ),rt1);
		}
	}
};
void solve(){
	FHQ T;
	memset(&T,0,sizeof(T));
	int n,m,k,d;cin>>n>>m>>k>>d;
	T.rt=T.Merge(T.Newnode({1,0,0}),T.Newnode({k,0,-inf}));
	vector<array<int,3>> Q(m);
	for(auto &x:Q){
		rep(i,0,2){
			cin>>x[i];
		}
	}
	sort(Q.begin(),Q.end());
	int lst=0;
	for(const auto &x:Q){
		int Gap=x[0]-lst;
		lst=x[0];
		if(Gap){
			int mx=T.mx[T.rt];
			if(Gap<=k){
				int rt0,rt1;
				T.Split(k+1-Gap,rt0,rt1);
				T.f(rt0,-Gap*d);
				T.rt=T.Merge(T.Newnode({Gap,-d,mx}),rt0);
			}
			else{
				T.rt=T.Newnode({k+1,-d,mx});
			}
		}
		if(x[1]<=k){
			int rt0,rt1;
			T.Split(x[1],rt0,rt1);
			T.f(rt1,x[2]);
			T.rt=T.Merge(rt0,rt1);
		}
	}
	cout<<T.mx[T.rt]<<endl;
}
signed main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int c,t;cin>>c>>t;
	while(t--){
		solve();
	}
	return 0;
}
