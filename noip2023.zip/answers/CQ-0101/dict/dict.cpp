#include<bits/stdc++.h> 
using namespace std;
int n,m,b[3011],f;
char a[3011][3011];
bool cmp(char x,char y){
	return x>y;
}
bool cmmp(int x,int y){
	for(int j=0;j<m;j++)
		if(a[x][j]!=a[y][j])
			return a[x][j]<a[y][j];
	return 1;
}
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("%s",a[i]);
		sort(a[i],a[i]+m,cmp);
		b[i]=i;
	}
	sort(b+1,b+n+1,cmmp);
	for(int i=1;i<=n;i++){
		f=0;
		if(i!=b[1]){
			for(int j=0;j<m;j++)
				if(a[b[1]][j]!=a[i][m-j-1]){
					if(a[b[1]][j]>a[i][m-j-1]){
						f=1;
						break;
					}
				}
			if(f==1)
				printf("1");
			else
				printf("0");
		}
		else{
			for(int j=0;j<m;j++)
				if(a[b[2]][j]!=a[i][m-j-1]){
					if(a[b[2]][j]>a[i][m-j-1]){
						f=1;
						break;
					}
				}
			if(f==1)
				printf("1");
			else
				printf("0");
		}
	}
	return 0;
}
