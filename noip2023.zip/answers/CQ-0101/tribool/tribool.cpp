#include<bits/stdc++.h> 
using namespace std;
int C,T,n,m,a[101001],f[101001],si[101001],ans=0,fa[21][101001],h[101001],fs[101001],vv[101001];
vector<int>son[101001],ss[101001],sou[101001];
bool v[101001],vvv[101001];
int zbb(int x){
	if(f[x]==x)
		return x;
	f[x]=zbb(f[x]);
	return f[x];
}
void dfs(int x,int y){
	vvv[x]=1;
	h[x]=h[y]+1;
	fa[0][x]=y;
	for(int i=1;i<=17;i++)
		fa[i][x]=fa[i-1][fa[i-1][x]];
	for(int i=0;i<son[x].size();i++)
		if(vvv[son[x][i]]==0){
			v[ss[x][i]]=1;
			fs[son[x][i]]=fs[x]+sou[x][i];
			dfs(son[x][i],x);
		}
}
int lca(int x,int y){
	if(h[x]>h[y])
		swap(x,y);
	for(int i=17;i>=0;i--)
		if(h[fa[i][y]]>=h[x])
			y=fa[i][y];
	if(x==y)
		return x;
	for(int i=17;i>=0;i--)
		if(fa[i][x]!=fa[i][y]){
			x=fa[i][x];
			y=fa[i][y];
		}
	return fa[0][x];
}
int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	scanf("%d%d",&C,&T);
	while(T--){
		scanf("%d%d",&n,&m);
		memset(vv,0,sizeof(vv));
		memset(vvv,0,sizeof(vvv));
		memset(v,0,sizeof(v));
		memset(h,0,sizeof(h));
		memset(a,0,sizeof(a));
		memset(si,0,sizeof(si));
		memset(f,0,sizeof(f));
		memset(fs,0,sizeof(fs));
		for(int i=0;i<=n+10;i++)
			son[i].clear(),sou[i].clear(),ss[i].clear();
		for(int i=1;i<=n;i++)
			a[i]=i+1;
		for(int i=1;i<=m;i++){
			char c[3];
			int x,y;
			scanf("%s",c);
			if(c[0]=='-'){
				scanf("%d%d",&x,&y);
				a[x]=-a[y];
			}
			if(c[0]=='+'){
				scanf("%d%d",&x,&y);
				a[x]=a[y];
			}
			if(c[0]=='F'){
				scanf("%d",&x);
				a[x]=-1;
			}
			if(c[0]=='T'){
				scanf("%d",&x);
				a[x]=1;
			}
			if(c[0]=='U'){
				scanf("%d",&x);
				a[x]=0;
			}
		}
		for(int i=0;i<=n+10;i++)
			f[i]=i,si[i]=1;
		si[0]=si[1]=0;
		for(int i=2;i<=n+1;i++){
			if(zbb(i)!=zbb(max(a[i-1],-a[i-1]))){
				si[zbb(max(a[i-1],-a[i-1]))]+=si[zbb(i)];
				f[zbb(i)]=zbb(max(a[i-1],-a[i-1]));
			}
			son[max(a[i-1],-a[i-1])].push_back(i);
			ss[max(a[i-1],-a[i-1])].push_back(i);
			if(a[i-1]<0)
				sou[max(a[i-1],-a[i-1])].push_back(-1),sou[i].push_back(-1),vv[i]=-1;
			else
				sou[max(a[i-1],-a[i-1])].push_back(0),sou[i].push_back(0),vv[i]=0;
			son[i].push_back(max(a[i-1],-a[i-1]));
			ss[i].push_back(i);
		}
		for(int i=2;i<=n+1;i++)
			if(zbb(i)==i)
				dfs(i,n+10);
//		for(int i=2;i<=n+1;i++)
//			printf("         %d\n",fa[0][i]);
		ans=0;
		memset(vvv,0,sizeof(vvv)) ;
		vvv[zbb(0)]=1;
		for(int i=2;i<=n+1;i++)
			if(v[i]==0&&zbb(i)!=zbb(1)&&zbb(i)!=zbb(0)){
//				printf("  %d %d\n",i,fs[i]+fs[max(a[i-1],-a[i-1])]-fs[lca(max(a[i-1],-a[i-1]),i)]+vv[i]);
				if((fs[i]+fs[max(a[i-1],-a[i-1])]-fs[lca(max(a[i-1],-a[i-1]),i)]+vv[i])%2==-1&&vvv[zbb(i)]==0){
					ans+=si[zbb(i)],vvv[zbb(i)]=1;
				}
			}
		printf("%d\n",si[zbb(0)]+ans);
	}
	return 0;
}
