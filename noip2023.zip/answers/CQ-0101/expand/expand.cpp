#include<bits/stdc++.h> 
using namespace std;
int C,n,m,q,a[500001],b[500001],c[500001],d[500001],ans;
void dfs(int x,int y){
	if((c[1]>=d[1]&&c[n]<=d[m])||(c[1]<=d[1]&&c[n]>=d[m]))
		return;
	if(ans==1)
		return;
	if(x==n&&y==m){
		ans=1;
		return;
	}
	if(x!=n&&((c[x+1]>d[y]&&c[1]>d[1])||(c[x+1]<d[y]&&c[1]<d[1])))
		dfs(x+1,y);
	if(y!=m&&((c[x]>d[y+1]&&c[1]>d[1])||(c[x]<d[y+1]&&c[1]<d[1])))
		dfs(x,y+1);
	if(x!=n&&y!=m&&((c[x+1]>d[y+1]&&c[1]>d[1])||(c[x+1]<d[y+1]&&c[1]<d[1])))
		dfs(x+1,y+1);
}
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	scanf("%d%d%d%d",&C,&n,&m,&q);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]),c[i]=a[i];
	for(int i=1;i<=m;i++)
		scanf("%d",&b[i]),d[i]=b[i];
	dfs(1,1);
	printf("%d",ans);
	while(q--){
		int x,y,xx,yy;
		scanf("%d%d",&x,&y);
		for(int i=1;i<=n;i++)
			c[i]=a[i];
		for(int i=1;i<=m;i++)
			d[i]=b[i];
		for(int i=1;i<=x;i++){
			scanf("%d%d",&xx,&yy);
			c[xx]=yy;
		}
		for(int i=1;i<=y;i++){
			scanf("%d%d",&xx,&yy);
			d[xx]=yy;
		}
		ans=0;
		dfs(1,1);
		printf("%d",ans);
	}
	return 0;
}
