#include<bits/stdc++.h>
using namespace std;
const int N=5e5+5;
int c,tn,Tm,q,n,m;
int ta[N],tb[N],a[N],b[N],h[N],id[N];
bitset<40005> s[40005];
int main(){
    freopen("expand.in","r",stdin);
    freopen("expand.out","w",stdout);
    int kx,ky,p,v;
    scanf("%d%d%d%d",&c,&tn,&Tm,&q);
    for(int i=1;i<=tn;i++)   scanf("%d",&ta[i]);
    for(int i=1;i<=Tm;i++)   scanf("%d",&tb[i]);
    n=tn;m=Tm;
    for(int i=1;i<=n;i++)   a[i]=ta[i];
    for(int i=1;i<=m;i++)   b[i]=tb[i];
    if(a[1]>b[1]&&a[n]>b[m]){
    }
    else if(a[1]<b[1]&&a[n]<b[m]){
        swap(n,m);
        swap(a,b);
    }
    else
        printf("0");
    if(a[1]>b[1]&&a[n]>b[m]){
        for(int i=0;i<=n+1;i++)
            s[i].reset();
        s[1][1]=1;
        for(int i=1;i<=n;i++)
            for(int j=1;j<=m;j++)
                if(a[i]>b[j])
                    s[i][j]=s[i][j]|s[i-1][j]|s[i][j-1]|s[i-1][j-1];
        if(s[n][m]) printf("1");
        else    printf("0");
    }
    while(q--){
        n=tn;m=Tm;
        for(int i=1;i<=n;i++)   a[i]=ta[i];
        for(int i=1;i<=m;i++)   b[i]=tb[i];
        scanf("%d%d",&kx,&ky);
        for(int i=1;i<=kx;i++){
            scanf("%d%d",&p,&v);
            a[p]=v;
        }
        for(int i=1;i<=ky;i++){
            scanf("%d%d",&p,&v);
            b[p]=v;
        }
        if(a[1]>b[1]&&a[n]>b[m]){

        }
        else if(a[1]<b[1]&&a[n]<b[m]){
            swap(n,m);
            swap(a,b);
        }
        else{
            printf("0");
            continue;
        }
        for(int i=0;i<=n+1;i++)
            s[i].reset();
        s[1][1]=1;
        for(int i=1;i<=n;i++)
            for(int j=1;j<=m;j++)
                if(a[i]>b[j])
                    s[i][j]=s[i][j]|s[i-1][j]|s[i][j-1]|s[i-1][j-1];
        if(s[n][m]) printf("1");
        else    printf("0");
    }
}