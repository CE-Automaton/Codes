#include<bits/stdc++.h>
using namespace std;
const int N=2e5+5;
int c,t,n,m;
int fa[N],d[N],f[N],tot,ty[N],ans,bk[N];
int faa[N],dd[N];
int find(int x){
    if(fa[x]==x)    return x;
    fa[x]=find(fa[x]);
    d[x]^=d[fa[x]];
    return fa[x];
}
int ffind(int x){
    if(faa[x]==x)    return x;
    faa[x]=ffind(faa[x]);
    dd[x]^=dd[faa[x]];
    return faa[x];
}
void merge(int x,int y,int dis){
    int rtx=ffind(x);
    int rty=ffind(y);
    if(rtx==rty){
        if((dd[y]^dis)!=dd[x])
            ty[rtx]=2;
        return ;
    }
    else{
        ty[rty]|=ty[rtx];
        faa[rtx]=rty;
        dd[rtx]=dd[x]^dis^dd[y];
    }
}
int main(){
    freopen("tribool.in","r",stdin);
    freopen("tribool.out","w",stdout);
    char op[3];int x,y;
    scanf("%d%d",&c,&t);
    while(t--){
        scanf("%d%d",&n,&m);
        tot=n;
        for(int i=1;i<=n;i++){
            fa[i]=i;
            f[i]=i;
            d[i]=0;
            ty[i]=0;
        }
        ans=0;
        while(m--){
            scanf("%s",op);
            if(op[0]=='-'||op[0]=='+'){
                scanf("%d%d",&x,&y);
                f[x]=++tot;
                d[tot]=(op[0]=='-')^d[f[y]];
                fa[tot]=fa[f[y]];
                // if(x==1){
                //     printf("%d %d %d ??SD",f[x],d[f[x]],y);
                // }
                // if(x==10){
                //     printf("%d %d %d %d fdbgdf?/\n",x,y,f[y],d[f[y]]);
                // }
            }
            else{
                scanf("%d",&x);
                f[x]=++tot;
                fa[tot]=tot;d[tot]=0;
                if(op[0]=='U') ty[tot]=2;
                else    ty[tot]=1;
            }
        }
        for(int i=1;i<=n;i++){
            ty[i]=ty[f[i]];
            bk[f[i]]=i;
            bk[i]=i;
        }
        for(int i=1;i<=n;i++)
            faa[i]=i,dd[i]=0;
        for(int i=1;i<=n;i++){
            y=bk[find(f[i])];
            x=i;
            // printf("%d %d %d %d\n",x,y,f[i],d[f[i]]);
            merge(x,y,d[f[i]]);
        }
        for(int i=1;i<=n;i++)
            if(ty[ffind(i)]==2)
                ans++;
        printf("%d\n",ans);
    }
}