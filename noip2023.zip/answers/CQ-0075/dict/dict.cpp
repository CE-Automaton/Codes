#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=3005;
const int mod=1e9+7;
const int b1=998244353;
const int b2=998244853;
int n,m;
char s[N][N],mx[N][N],mi[N][N];
int hsx[3][N][N],hsi[3][N][N];
bool cmp(char x,char y){
    return x>y;
}
int cp(int i,int j){
    if(hsi[1][i][m]==hsx[1][j][m]&&hsi[2][i][m]==hsx[2][j][m])
        return 0;
    int l=1,r=m;
    while(l<r){
        int mid=(l+r)/2;
        if(hsi[1][i][mid]!=hsx[1][j][mid]||hsi[2][i][mid]!=hsx[2][j][mid])
            r=mid;
        else
            l=mid+1;
    }
    return mi[i][l]<mx[j][l];
}
int main(){
    freopen("dict.in","r",stdin);
    freopen("dict.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++){
        scanf("%s",s[i]+1);
        for(int j=1;j<=m;j++)
            mx[i][j]=mi[i][j]=s[i][j];
        sort(mx[i]+1,mx[i]+1+m,cmp);
        sort(mi[i]+1,mi[i]+1+m);
        for(int j=1;j<=m;j++){
            hsx[1][i][j]=((ll)hsx[1][i][j-1]*b1+mx[i][j]-'a')%mod;
            hsx[2][i][j]=((ll)hsx[2][i][j-1]*b2+mx[i][j]-'a')%mod;
            hsi[1][i][j]=((ll)hsi[1][i][j-1]*b1+mi[i][j]-'a')%mod;
            hsi[2][i][j]=((ll)hsi[2][i][j-1]*b2+mi[i][j]-'a')%mod;
        }
    }
    for(int i=1;i<=n;i++){
        int flag=1;
        for(int j=1;j<=n&&flag;j++)
            if(j!=i)
                flag=cp(i,j);
        printf("%d",flag);
    }
}