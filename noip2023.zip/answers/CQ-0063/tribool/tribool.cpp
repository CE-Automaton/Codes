#include <bits/stdc++.h>

using namespace std;

const int N = 1e5 + 10;

int c, t, n, m, u, x, timestamp, Top;
int Last[N << 1], Pre[N << 1], val[N << 1], ch[N << 1];
int h[N << 1], e[N << 1], w[N << 1], ne[N << 1], idx;
int R[N << 1], S[N << 1], cnt[N << 1];
bool st[N << 1];
char v;

int read() {
	int x = 0; char ch = getchar();
	while (ch < '0' || '9' < ch) ch = getchar();
	while ('0' <= ch && ch <= '9') x = x * 10 + (ch - '0'), ch = getchar();
	return x;
}

void write(int x) {
	if (x > 9) write(x / 10);
	putchar('0' + x % 10);
}

void add(int a, int b, int c) {
	e[idx] = b, w[idx] = c, ne[idx] = h[a], h[a] = idx ++;
}

int trib(int V, int W) {
	if (!W) return V;
	else {
		if (V == 1) return 3;
		if (V == 2) return 2;
		if (V == 3) return 1;
	}
	return 114514;
}

int dfs(int x) {
	if (ch[x] == 1) return R[x];
	if (ch[x] == 2) {
		int G = 0;
		for (int i = Top; i >= 1; i --) {
			G ^= cnt[i];
			if (S[i] == x) break;
		}
		if (G == 0) return 1;
		else return 2;
	}
	S[++ Top] = x;
	ch[x] = 2;
	for (int i = h[x]; ~i; i = ne[i]) {
		int j = e[i];
		cnt[Top] = w[i];
		R[x] = trib(dfs(j), w[i]);
	}
	Top --;
	return R[x];
}

void chg(int x) {
	if (ch[x] == 1) return;
	ch[x] = 1;
	for (int i = h[x]; ~i; i = ne[i]) chg(e[i]);
}

int main() {
	freopen("tribool.in", "r", stdin);
	freopen("tribool.out", "w", stdout);
	
	c = read(), t = read();
	
	while (t --) {
		idx = 0;
		memset(h, -1, sizeof h);
		memset(st, 0, sizeof st);
		memset(ch, 0, sizeof ch);
		
		n = read(), m = read();
		
		timestamp = 3;
		for (int i = 1; i <= n; i ++) Last[i] = ++ timestamp, Pre[Last[i]] = Last[i], val[Last[i]] = 0;
		for (int i = 1; i <= m; i ++) {
			v = getchar();
			while (v != 'T' && v != 'U' && v != 'F' && v != '+' && v != '-') v = getchar();
			if (v == 'T') {
				u = read();
				Pre[++ timestamp] = 1;
				val[timestamp] = 0;
				Last[u] = timestamp;
			}
			if (v == 'U') {
				u = read();
				Pre[++ timestamp] = 2;
				val[timestamp] = 0;
				Last[u] = timestamp;
			}
			if (v == 'F') {
				u = read();
				Pre[++ timestamp] = 3;
				val[timestamp] = 0;
				Last[u] = timestamp;
			}
			if (v == '+') {
				u = read(), x = read();
				Pre[++ timestamp] = Pre[Last[x]];
				val[timestamp] = val[Last[x]];
				Last[u] = timestamp;
			}
			if (v == '-') {
				u = read(), x = read();
				Pre[++ timestamp] = Pre[Last[x]];
				val[timestamp] = (val[Last[x]] ^ 1);
				Last[u] = timestamp;
			}
		}
		
		for (int i = 1; i <= n; i ++) add(Pre[Last[i]], i + 3, val[Last[i]]);
		
		R[1] = 1, R[2] = 2, R[3] = 3;
		queue<int> q;
		q.push(1);
		q.push(2);
		q.push(3);
		st[1] = st[2] = st[3] = true;
		while (q.size()) {
			int T = q.front();
			q.pop();
			for (int i = h[T]; ~i; i = ne[i]) {
				int j = e[i];
				R[j] = trib(R[T], w[i]);
				st[j] = true;
				q.push(j);
			}
		}
		
		idx = 0;
		memset(h, -1, sizeof h);
		for (int i = 1; i <= n; i ++) add(i + 3, Pre[Last[i]], val[Last[i]]);
		
		for (int i = 1; i <= n; i ++) {
			if (!st[i + 3] && !ch[i + 3]) {
				dfs(i + 3);
				chg(i + 3);
			}
		}
		
		int ans = 0;
		for (int i = 1; i <= n; i ++) {
			if (R[i + 3] == 2) ans ++;
		}
		
		write(ans), putchar('\n');
	}
	
	return 0;
}
