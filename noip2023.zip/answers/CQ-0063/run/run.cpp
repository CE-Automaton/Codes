#include <bits/stdc++.h>

using namespace std;

const int N = 1e5 + 10;
const int M = 1010;

int c, t, n, m, k, d;
long long dp[M][M], Get[M][M];
struct node {
	int x, y, v;
}p[N];

bool cmp(node a, node b) {
	return a.x < b.x;
}

int main() {
	freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);
	
	scanf("%d%d", &c, &t);
	
	while (t --) {
		scanf("%d%d%d%d", &n, &m, &k, &d);
		for (int i = 1; i <= m; i ++) scanf("%d%d%d", &p[i].x, &p[i].y, &p[i].v);
		sort(p + 1, p + 1 + m, cmp);
		
		bool st = true;
		for (int i = 1; i < m; i ++)
			if (p[i].x >= p[i + 1].x - p[i + 1].y + 1) st = false;
		if (st) {
			long long ans = 0;
			for (int i = 1; i <= m; i ++) {
				if (p[i].y <= k) {
					ans += max(p[i].v - 1ll * p[i].y * d, 0ll);
				}
			}
			printf("%lld\n", ans);
			continue;
		}
		
		memset(Get, 0, sizeof Get);
		for (int i = 1; i <= m; i ++) Get[p[i].x][p[i].y] += p[i].v;
		for (int i = 1; i <= n; i ++) {
			for (int j = 1; j <= k; j ++) {
				Get[i][j] += Get[i][j - 1];
			}
		}
		
		memset(dp, -0x3f, sizeof dp);
		dp[0][0] = 0;
		for (int i = 1; i <= n; i ++) {
			for (int j = 0; j <= k; j ++) dp[i][0] = max(dp[i][0], dp[i - 1][j]);
			for (int j = 1; j <= k; j ++) {
				dp[i][j] = dp[i - 1][j - 1] - d;
				dp[i][j] += Get[i][j];
			}
		}
		long long Max = 0;
		for (int i = 0; i <= k; i ++) Max = max(Max, dp[n][i]);
		
		printf("%lld\n", Max);
	}
	
	return 0;
}
