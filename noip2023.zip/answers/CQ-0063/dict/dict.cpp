#include <bits/stdc++.h>

using namespace std;

const int N = 3010;

int n, m;
int cnt[N][26], Min[N], Max[N];
char a[N][N];

int main() {
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; i ++) scanf("%s", a[i] + 1);
	
	for (int i = 1; i <= n; i ++) Min[i] = 25, Max[i] = 0;
	for (int i = 1; i <= n; i ++)
		for (int j = 1; j <= m; j ++) {
			cnt[i][a[i][j] - 'a'] ++;
			Min[i] = min(Min[i], a[i][j] - 'a');
			Max[i] = max(Max[i], a[i][j] - 'a');
		}
	
	for (int i = 1; i <= n; i ++) {
		bool st = true;
		for (int j = 1; j <= n; j ++) {
			if (i == j) continue;
			if (Max[j] < Min[i]) {
				st = false;
				break;
			}
			else if (Max[j] == Min[i]) {
				st = false;
				break;
			}
		}
		if (st) putchar('1');
		else putchar('0');
	}
	
	return 0;
}
