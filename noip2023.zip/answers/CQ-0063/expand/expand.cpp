#include <bits/stdc++.h>

using namespace std;

const int N = 5e5 + 10;
const int M = 2010;

int c, n, m, q, kx, ky, p, v;
int x[N], y[N], X[N], Y[N], dp[M][M];
char a[N];

int read() {
	int x = 0; char ch = getchar();
	while (ch < '0' || '9' < ch) ch = getchar();
	while ('0' <= ch && ch <= '9') x = x * 10 + (ch - '0'), ch = getchar();
	return x;
}

char D() {
	dp[1][0] = dp[0][1] = 1;
	for (int i = 1; i <= n; i ++) {
		for (int j = 1; j <= m; j ++) {
			dp[i][j] = 0;
			if (x[i] > y[j]) dp[i][j] |= dp[i][j - 1], dp[i][j] |= dp[i - 1][j];
		}
	}
	if (dp[n][m]) return '1';
	dp[1][0] = dp[0][1] = 1;
	for (int i = 1; i <= n; i ++) {
		for (int j = 1; j <= m; j ++) {
			dp[i][j] = 0;
			if (x[i] < y[j]) dp[i][j] |= dp[i][j - 1], dp[i][j] |= dp[i - 1][j];
		}
	}
	if (dp[n][m]) return '1';
	return '0';
}

int main() {
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);
	
	c = read(), n = read(), m = read(), q = read();
	for (int i = 1; i <= n; i ++) x[i] = read();
	for (int i = 1; i <= m; i ++) y[i] = read();
	
	if (n <= 200 && m <= 200) {
		a[0] = D();
		for (int id = 1; id <= q; id ++) {
			kx = read(), ky = read();
			for (int i = 1; i <= n; i ++) X[i] = x[i];
			for (int i = 1; i <= m; i ++) Y[i] = y[i];
			for (int i = 1; i <= kx; i ++) p = read(), v = read(), x[p] = v;
			for (int i = 1; i <= ky; i ++) p = read(), v = read(), y[p] = v;
			a[id] = D();
			for (int i = 1; i <= n; i ++) x[i] = X[i];
			for (int i = 1; i <= m; i ++) y[i] = Y[i];
		}
		printf("%s", a);
		return 0;
	}
	
	return 0;
}
