#include <bits/stdc++.h>
#define ll long long 
#define int long long 
using namespace std;
const int N=200005;

template<typename z>
void read(z &x) {
    x=0;bool f=0;char c=getchar();
    while(!isdigit(c)) f|=c=='-',c=getchar();
    while(isdigit(c)) x=(x<<3)+(x<<1)+(c^48),c=getchar();
    x=f?-x:x;
    return ;
}
struct Others {
    struct node {
        int tag,Max;
    }tr[N<<2];
    void pushup(int p) {
        tr[p].Max=max(tr[p<<1].Max,tr[p<<1|1].Max);
        return ;
    }
    void update(int p,int t) {
        tr[p].tag+=t,tr[p].Max+=t;
        return ;
    }
    void pushdown(int p) {
        if(!tr[p].tag) return ;
        update(p<<1,tr[p].tag);
        update(p<<1|1,tr[p].tag);
        tr[p].tag=0;
        return ;
    }
    void build(int l,int r,int p) {
        tr[p].tag=tr[p].Max=0;
        if(l==r) return ;
        int mid=l+r>>1;
        build(l,mid,p<<1),build(mid+1,r,p<<1|1);
        return ;
    }
    void add(int s,int t,int l,int r,int p,int d) {
        if(s>t) return ;
        if(s<=l&&r<=t) return update(p,d);
        pushdown(p);
        int mid=l+r>>1;
        if(s<=mid) add(s,t,l,mid,p<<1,d);
        if(t>mid) add(s,t,mid+1,r,p<<1|1,d);
        pushup(p);
        return ; 
    }
    int getmax(int s,int t,int l,int r,int p) {
        if(s>t) return 0;
        if(s<=l&&r<=t) return tr[p].Max;
        int mid=l+r>>1,ans=0;
        pushdown(p);
        if(s<=mid) ans=max(ans,getmax(s,t,l,mid,p<<1));
        if(t>mid) ans=max(ans,getmax(s,t,mid+1,r,p<<1|1));
        return ans;
    }
}T;
int C,TT,n,m,k,d,x,y,l[N],r[N],flag[N],top,v[N],dp[N][2];
vector<int> vec[N];
signed main() {
    // freopen("run6.in","r",stdin);
    // freopen("run.out","w",stdout);
    freopen("run.in","r",stdin);
    freopen("run.out","w",stdout);
    read(C),read(TT);
    while(TT--) {
        //待会来写初始化
        read(n),read(m),read(k),read(d);
        top=0;
        flag[++top]=n+1;
        for(int i=1;i<=m;i++) {
            read(x),read(y),read(v[i]);
            l[i]=x-y,r[i]=x;
            flag[++top]=l[i],flag[++top]=r[i];
        }
        sort(flag+1,flag+top+1),top=unique(flag+1,flag+top+1)-flag-1;
        for(int i=1;i<=m;i++) {
            l[i]=lower_bound(flag+1,flag+top+1,l[i])-flag,r[i]=lower_bound(flag+1,flag+top+1,r[i])-flag;
            vec[r[i]].push_back(i);
        }
        T.build(1,top,1);
        // puts("Cyy");
        for(int i=1;i<=top;i++) {
            dp[i][0]=max(dp[i-1][0],dp[i-1][1]);
            if(i==top) break;
            if(flag[i]-flag[i-1]<=k&&vec[i].size()) {
                int L=lower_bound(flag+1,flag+top+1,flag[i]-k)-flag;
                for(const auto &lxl:vec[i]) T.add(1,l[lxl],1,top,1,v[lxl]);
                vec[i].clear();
                dp[i][1]=T.getmax(L,i-1,1,top,1)-flag[i]*d;
            }else dp[i][1]=0;
            T.add(i,i,1,top,1,dp[i][0]+flag[i]*d);
//            if(i<=10) printf("%lld %lld\n",dp[i][0],dp[i][1]);
        }
        printf("%lld\n",dp[top][0]);
    }
    cerr << clock()*1.0/CLOCKS_PER_SEC << '\n';
    return 0;
}
