#include <bits/stdc++.h>
#define ll long long 
using namespace std;

template<typename z>
void read(z &x) {
    x=0;bool f=0;char c=getchar();
    while(!isdigit(c)) f|=c=='-',c=getchar();
    while(isdigit(c)) x=(x<<3)+(x<<1)+(c^48),c=getchar();
    x=f?-x:x;
    return ;
}
const int N=500005,M=2005;
bool dp[M][M];
int a[N],b[N],c[N],d[N],C,n,m,q,x,y,p,s,Max,Maxx,Min,Minn;
void solve(int *a,int *b) {
    dp[0][0]=1;
    for(int i=1;i<=n;i++) 
        for(int j=1;j<=m;j++) 
            if(a[i]!=b[j]&&(a[i]>b[j])==(a[1]>b[1])) 
                dp[i][j]=(dp[i-1][j]|dp[i][j-1]|dp[i-1][j-1]);
            else dp[i][j]=0;
    return ;
}
int main() {
    // freopen("expand5.in","r",stdin);
    // freopen("expand.out","w",stdout);
    freopen("expand.in","r",stdin);
    freopen("expand.out","w",stdout);
    read(C),read(n),read(m),read(q);
    for(int i=1;i<=n;i++) read(a[i]);
    for(int i=1;i<=m;i++) read(b[i]);
    if(1ll*n*m*q<=3e8) {
        solve(a,b);
        printf("%d",dp[n][m]);
        for(int z=1;z<=q;z++) {
            read(x),read(y);
            for(int i=1;i<=n;i++) c[i]=a[i];
            for(int i=1;i<=m;i++) d[i]=b[i];
            while(x--) read(p),read(s),c[p]=s;
            while(y--) read(p),read(s),d[p]=s;
            solve(c,d);
            printf("%d",dp[n][m]);
        }
    }else {
        //快脚造数据！！！
        Max=Maxx=0,Min=Minn=INT_MAX;
        for(int i=1;i<=n;i++) Max=max(Max,a[i]),Min=min(Min,a[i]);
        for(int i=1;i<=m;i++) Maxx=max(Maxx,b[i]),Minn=min(Minn,b[i]);
        int op=a[1]>b[1];
        if((a[1]>b[1])==op&&(a[n]>b[m])==op&&(Max>Maxx)==op&&(Min>Minn)==op&&a[1]!=b[1]&&a[n]!=b[n]&&Max!=Maxx&&Min!=Minn) putchar('1');
        else putchar('0');
        for(int z=1;z<=q;z++) {
            read(x),read(y);
            for(int i=1;i<=n;i++) c[i]=a[i];
            for(int i=1;i<=m;i++) d[i]=b[i];
            while(x--) read(p),read(s),c[p]=s;
            while(y--) read(p),read(s),d[p]=s;
            Max=Maxx=0,Min=Minn=INT_MAX;
            for(int i=1;i<=n;i++) Max=max(Max,c[i]),Min=min(Min,c[i]);
            for(int i=1;i<=m;i++) Maxx=max(Maxx,d[i]),Minn=min(Minn,d[i]);
            int op=c[1]>d[1];
            if((c[1]>d[1])==op&&(c[n]>d[m])==op&&(Max>Maxx)==op&&(Min>Minn)==op&&c[1]!=d[1]&&c[n]!=d[n]&&Max!=Maxx&&Min!=Minn) putchar('1');
            else putchar('0');
        }
    }
    return 0;
}