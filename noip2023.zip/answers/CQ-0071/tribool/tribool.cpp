#include <bits/stdc++.h>
#define ll long long 
using namespace std;
/*
内向基环树

样例过了虚空调试1h，麻了。
*/
const int N=100005;
int a[N],d[N],s[N],ans,vis[N],now,dis,c,T,n,m,x,y;
char op[105];
queue<int> qu;
void dfs(int p) {
    now+=s[p],dis+=(a[p]<0);
    vis[p]=1;
    if(!vis[abs(a[p])]) dfs(abs(a[p]));
    return ;
}
int f(int x) {
    if(x==n+1) return n+2;
    if(x==n+2) return n+1;
    return n+3;
}
int main() {
    // freopen("tribool4.in","r",stdin);
    // freopen("tribool.out","w",stdout);
    // system("fc tribool.out tribool3.ans");
    // return 0;
    freopen("tribool.in","r",stdin);
    freopen("tribool.out","w",stdout);
    scanf("%d%d",&c,&T);
    for(int z=1;z<=T;z++) {
        scanf("%d%d",&n,&m);
        for(int i=1;i<=n;i++) a[i]=i,d[i]=0,s[i]=1,vis[i]=0;
        for(int i=1;i<=m;i++) {
            scanf("%s",op);
            if(op[0]=='+') scanf("%d%d",&x,&y),a[x]=a[y];
            if(op[0]=='-') scanf("%d%d",&x,&y),a[x]=(a[y]>n?f(a[y]):-a[y]);
            if(op[0]=='T') scanf("%d",&x),a[x]=n+1;
            if(op[0]=='F') scanf("%d",&x),a[x]=n+2;
            if(op[0]=='U') scanf("%d",&x),a[x]=n+3;
        }
        for(int i=1;i<=n;i++) if(a[i]<=n) 
            d[abs(a[i])]++;
        for(int i=1;i<=n;i++) if(!d[i]&&a[i]<=n) qu.push(i);
        while(qu.size()) {
            int top=qu.front();qu.pop();
            --d[abs(a[top])];
            s[abs(a[top])]+=s[top];
            if(!d[abs(a[top])]&&a[abs(a[top])]<=n) qu.push(abs(a[top]));
        }
        ans=0;
        for(int i=1;i<=n;i++) {
            if(a[i]>n) ans+=(a[i]==n+3)*s[i];
            if(d[i]&&!vis[i]) {
                now=dis=0;
                dfs(i);
                if(dis&1) ans+=now;
            }
        }
        printf("%d\n",ans);
    }
    return 0;
}