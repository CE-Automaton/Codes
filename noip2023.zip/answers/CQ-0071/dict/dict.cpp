#include <bits/stdc++.h>
/*
桶排，最大字典序和最小字典序。O(n^2)
找到最大字典序中最小的和次小的词典序，然后枚举并比较 O(n^2)
*/
#define ll long long 
using namespace std;
const int N=3005;
char a[N][N],b[N][N];
int c[105],d[105],n,m,Min;
bool ck(char *x,char *y) {
    for(int i=1;i<=m;i++) 
        if(x[i]!=y[i]) 
            return x[i]<y[i];
    return 1;
}
int main() {
    // freopen("dict4.in","r",stdin);
    // freopen("dict.out","w",stdout);
    // system("fc dict.out dict4.ans");
    // return 0;
    freopen("dict.in","r",stdin);
    freopen("dict.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++) b[0][i]='z';
    for(int i=1;i<=n;i++) {
        scanf("%s",a[i]+1);
        for(int j=1;j<=m;j++) c[a[i][j]-'a']++,d[a[i][j]-'a']++;
        int t=0;
        for(int j=0;j<26;j++) //min
            while(c[j]) 
                a[i][++t]=j+'a',c[j]--;
        t=0;
        for(int j=25;j>=0;j--) //max
            while(d[j]) 
                b[i][++t]=j+'a',d[j]--;
        if(ck(b[i],b[Min])) Min=i;
    }
    for(int i=1;i<=n;i++) {
        if(ck(a[i],b[Min])) putchar('1');
        else putchar('0');
    }
    return 0;
}