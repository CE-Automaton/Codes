#include <bits/stdc++.h>
using namespace std;
int main() {
    freopen("tribool.in", "r", stdin);
    freopen("tribool.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    int c, t;
    cin >> c >> t;
    while (t--) {
        int n, m;
        cin >> n >> m;
        vector<int> father(n + n + m + m + 3);
        int T = n + n + m + m,
            F = n + n + m + m + 1,
            U = n + n + m + m + 2;
        iota(father.begin(), father.end(), 0);
        function<int(int)> find_set = [&](int x) -> int {
            return x == father[x] ? x : father[x] = find_set(father[x]);
        };
        vector<int> lst(n, -1);
        for (int i = 0; i < m; i++) {
            char x;
            cin >> x;
            if (x == 'T') {
                int y;
                cin >> y;
                y--;
                father[find_set(n + n + i)] = find_set(T);
                father[find_set(n + n + m + i)] = find_set(F);
                lst[y] = i;
            }
            else if (x == 'F') {
                int y;
                cin >> y;
                y--;
                father[find_set(n + n + i)] = find_set(F);
                father[find_set(n + n + m + i)] = find_set(T);
                lst[y] = i;
            }
            else if (x == 'U') {
                int y;
                cin >> y;
                y--;
                father[find_set(n + n + i)] = find_set(U);
                father[find_set(n + n + m + i)] = find_set(U);
                lst[y] = i;
            }
            else if (x == '+') {
                int y, z;
                cin >> y >> z;
                y--, z--;
                father[find_set(n + n + i)] = find_set(~lst[z] ? n + n + lst[z] : z);
                father[find_set(n + n + m + i)] = find_set(~lst[z] ? n + n + m + lst[z] : n + z);
                lst[y] = i;
            }
            else if (x == '-') {
                int y, z;
                cin >> y >> z;
                y--, z--;
                father[find_set(n + n + i)] = find_set(~lst[z] ? n + n + m + lst[z] : n + z);
                father[find_set(n + n + m + i)] = find_set(~lst[z] ? n + n + lst[z] : z);
                lst[y] = i;
            }
        }
        for (int i = 0; i < n; i++) {
            if (~lst[i]) {
                father[find_set(i)] = find_set(n + n + lst[i]);
                father[find_set(n + i)] = find_set(n + n + m + lst[i]);
            }
        }
        int ans = 0;
        for (int i = 0; i < n; i++)
            if (find_set(i) == find_set(U) ||
                find_set(n + i) == find_set(U) ||
                find_set(i) == find_set(n + i))
                ans += 1;
        cout << ans << '\n';
    }
    return 0;
}