#include <bits/stdc++.h>
using namespace std;
int main() {
    freopen("dict.in", "r", stdin);
    freopen("dict.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    int n, m;
    cin >> n >> m;
    vector<string> a(n);
    for (int i = 0; i < n; i++)
        cin >> a[i];
    vector<string> b(a), c(a);
    for (int i = 0; i < n; i++)
        sort(b[i].begin(), b[i].end());
    for (int i = 0; i < n; i++)
        sort(c[i].begin(), c[i].end(), greater<char>());
    vector<string> pf(c), pb(c), p(n);
    for (int i = 1; i < n; i++)
        pf[i] = min(pf[i - 1], pf[i]);
    for (int i = n - 2; i >= 0; i--)
        pb[i] = min(pb[i + 1], pb[i]);
    p[0] = pb[1];
    for (int i = 1; i < n - 1; i++)
        p[i] = min(pf[i - 1], pb[i + 1]);
    p[n - 1] = pf[n - 2];
    for (int i = 0; i < n; i++)
        cout << (p[i] > b[i] ? '1' : '0');
    cout << '\n';
    return 0;
}