#include <bits/stdc++.h>
using namespace std;
const long long inf = 0x3f3f3f3f3f3f3f3f;
int main() {
    freopen("run.in", "r", stdin);
    freopen("run.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    int c, t;
    cin >> c >> t;
    while (t--) {
        int n, m, k, d;
        cin >> n >> m >> k >> d;
        unordered_map<int, vector<pair<int, int>>> mp;
        for (int i = 0; i < m; i++) {
            int x, y, z;
            cin >> x >> y >> z;
            if (y <= k)
                mp[x].emplace_back(y, z);
        }
        vector<vector<long long>> f(n + 1, vector<long long>(k + 1, -inf));
        f[0][0] = 0;
        for (int i = 1; i <= n; i++) {
            f[i][0] = *max_element(f[i - 1].begin(), f[i - 1].end());
            for (int j = 1; j <= k; j++)
                f[i][j] = f[i - 1][j - 1] - d;
            if (mp.count(i)) {
                for (pair<int, int> j : mp[i])
                    for (int l = j.first; l <= k; l++)
                        f[i][l] += j.second;
            }
        }
        cout << *max_element(f[n].begin(), f[n].end()) << '\n';
    }
    return 0;
}