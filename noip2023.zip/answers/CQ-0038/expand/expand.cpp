#include <bits/stdc++.h>
using namespace std;
int c, n, m, q;
vector<int> a, b, X, Y;
int l;
bool solve(int lx, int rx, int ly, int ry, bool le, bool ri, bool top, bool bottom, bool left, bool right) {
    if (le && ri)
        return true;
    if (left && bottom)
        return true;
    if (right && top)
        return true;
    if (lx > rx || ly > ry)
        return true;
    int xl = max_element(X.begin() + lx, X.begin() + rx + 1) - X.begin();
    int yl = max_element(Y.begin() + ly, Y.begin() + ry + 1) - Y.begin();
    int xs = min_element(X.begin() + lx, X.begin() + rx + 1) - X.begin();
    int ys = min_element(Y.begin() + ly, Y.begin() + ry + 1) - Y.begin();
    if (le) {
        for (int i = lx; i <= rx; i++)
            if (X[i] >= X[xl])
                xl = i;
        for (int i = lx; i <= rx; i++)
            if (X[i] <= X[xs])
                xs = i;
        for (int i = ly; i <= ry; i++)
            if (Y[i] >= Y[yl])
                yl = i;
        for (int i = ly; i <= ry; i++)
            if (Y[i] <= Y[ys])
                ys = i;
    }
    if (X[xl] > Y[yl] && X[xs] > Y[ys]) {
        return false;
    }
    if (X[xl] > Y[yl] && X[xs] < Y[ys]) {
        if (ri) {
            if (xl < xs && !right)
                return false;
            return solve(lx, xl - 1, ly, ry, le, ri, top, false, left, right);
        }
        if (le) {
            if (xs < xl && !left)
                return false;
            return solve(xl + 1, rx, ly, ry, le, ri, false, bottom, left, right);
        }
        return false;
    }
    if (X[xl] < Y[yl] && X[xs] > Y[ys]) {
        if (ri) {
            if (ys < yl && !bottom)
                return false;
            return solve(lx, rx, ly, ys - 1, le, ri, top, bottom, left, false);
        }
        if (le) {
            if (yl < ys && !top)
                return false;
            return solve(lx, rx, ys + 1, ry, le, ri, top, bottom, false, right);
        }
        return false;
    }
    if (X[xl] < Y[yl] && X[xs] < Y[ys]) {
        return solve(lx, xs - 1, ly, yl - 1, le, true, top, true, left, true) && solve(xs + 1, rx, yl + 1, ry, true, ri, true, bottom, true, right);
    }
    return false;
}
unordered_map<int, unordered_map<int, bool>> vis;
bool dfs1(int x, int y) {
    if (x == 0 && y == 0)
        return true;
    if (x == 0 || y == 0)
        return false;
    if (!(X[x - 1] < Y[y - 1]))
        return false;
    if (vis[x].count(y))
        return vis[x][y];
    return vis[x][y] = dfs1(x - 1, y - 1) || dfs1(x, y - 1) || dfs1(x - 1, y);
}
bool dfs2(int x, int y) {
    if (x == 0 && y == 0)
        return true;
    if (x == 0 || y == 0)
        return false;
    if (!(X[x - 1] > Y[y - 1]))
        return false;
    if (vis[x].count(y))
        return vis[x][y];
    return vis[x][y] = dfs2(x - 1, y - 1) | dfs2(x, y - 1) | dfs2(x - 1, y);
}
int main() {
    freopen("expand.in", "r", stdin);
    freopen("expand.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    cin >> c >> n >> m >> q;
    a = vector<int>(n), b = vector<int>(m);
    for (int i = 0; i < n; i++)
        cin >> a[i];
    for (int i = 0; i < m; i++)
        cin >> b[i];
    X = a, Y = b;
    if (c >= 21) {
        if (X[0] > Y[0])
            swap(X, Y);
        cout << solve(0, X.size() - 1, 0, Y.size() - 1, false, false, false, false, false, false);
        for (int i = 0; i < q; i++) {
            l = i == 3;
            X = a, Y = b;
            int x, y;
            cin >> x >> y;
            for (int j = 0; j < x; j++) {
                int z, w;
                cin >> z >> w;
                z--;
                X[z] = w;
            }
            for (int j = 0; j < y; j++) {
                int z, w;
                cin >> z >> w;
                z--;
                Y[z] = w;
            }
            if (X[0] > Y[0])
                swap(X, Y);
            cout << solve(0, X.size() - 1, 0, Y.size() - 1, false, false, false, false, false, false);
        }
    }
    else { // 相信 CCF 的数据
        if (X[0] > Y[0])
            swap(X, Y);
        vis.clear();
        if (X[0] < Y[0])
            cout << (dfs1(X.size(), Y.size()) ? '1' : '0');
        else if (X[0] > Y[0])
            cout << (dfs2(X.size(), Y.size()) ? '1' : '0');
        else
            cout << '0';
        for (int i = 0; i < q; i++) {
            l = i == 3;
            X = a, Y = b;
            int x, y;
            cin >> x >> y;
            for (int j = 0; j < x; j++) {
                int z, w;
                cin >> z >> w;
                z--;
                X[z] = w;
            }
            for (int j = 0; j < y; j++) {
                int z, w;
                cin >> z >> w;
                z--;
                Y[z] = w;
            }
            if (X[0] > Y[0])
                swap(X, Y);
            vis.clear();
            if (X[0] < Y[0])
                cout << (dfs1(X.size(), Y.size()) ? '1' : '0');
            else if (X[0] > Y[0])
                cout << (dfs2(X.size(), Y.size()) ? '1' : '0');
            else
                cout << '0';
        }
    }
    return 0;
}