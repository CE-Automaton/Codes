#include<bits/stdc++.h>
typedef long long ll;
using namespace std;
int c,T;
const ll inf=-1e18;
namespace Brute1{
	struct Seg{
		int l,r;
		ll mx,lazy;
	}Tree[400005];
	struct node{
		int p;
		ll val;
		node(int p_,ll val_){
			p=p_,val=val_;
		}
	};
	void ztree(int p,int l,int r){
		Tree[p].l=l,Tree[p].r=r,Tree[p].lazy=0;
		if(l==r){
			if(l==0)Tree[p].mx=0;
			else Tree[p].mx=inf;
			return;
		}
		int mid=l+r>>1;
		ztree(p*2,l,mid);
		ztree(p*2+1,mid+1,r);
		Tree[p].mx=max(Tree[p*2].mx,Tree[p*2+1].mx);
	}
	void pushdown(int p){
		if(Tree[p].lazy==0)return;
		Tree[p*2].mx=max(Tree[p*2].mx+Tree[p].lazy,inf);
		Tree[p*2].lazy=max(Tree[p*2].lazy+Tree[p].lazy,inf);
		Tree[p*2+1].mx=max(Tree[p*2+1].mx+Tree[p].lazy,inf);
		Tree[p*2+1].lazy=max(Tree[p*2+1].lazy+Tree[p].lazy,inf);
		Tree[p].lazy=0;
	}
	void upd(int p,int l,int r,ll val){
		if(l>r)return;
		if(l<=Tree[p].l&&Tree[p].r<=r){
			Tree[p].mx=max(Tree[p].mx+val,inf);
			Tree[p].lazy=max(Tree[p].lazy+val,inf);
			return;
		}
		pushdown(p);
		int mid=Tree[p].l+Tree[p].r>>1;
		if(l<=mid)upd(p*2,l,r,val);
		if(r>mid)upd(p*2+1,l,r,val);
		Tree[p].mx=max(Tree[p*2].mx,Tree[p*2+1].mx);
	}
	void change(int p,int l,ll val){
		if(Tree[p].l==Tree[p].r){
			Tree[p].mx=val;
			return;
		}
		pushdown(p);
		int mid=Tree[p].l+Tree[p].r>>1;
		if(l<=mid)change(p*2,l,val);
		else change(p*2+1,l,val);
		Tree[p].mx=max(Tree[p*2].mx,Tree[p*2+1].mx);
	}
	ll Getmax(int p,int l,int r){
		if(l<=Tree[p].l&&Tree[p].r<=r)return Tree[p].mx;
		pushdown(p);
		int mid=Tree[p].l+Tree[p].r>>1;
		ll res=inf;
		if(l<=mid)res=max(res,Getmax(p*2,l,r));
		if(r>mid)res=max(res,Getmax(p*2+1,l,r));
		return res;
	}
	vector<node>vec[100005];
	void solve(){
		while(T--){
			int n,m,k;
			ll d;
			scanf("%d%d%d%lld",&n,&m,&k,&d);
			for(int i=1;i<=n;i++)vec[i].clear();
			for(int i=1;i<=m;i++){
				int x,y;
				ll val;
				scanf("%d%d%lld",&x,&y,&val);
				vec[x].push_back(node(x-y+1,val));
			}
			ztree(1,0,n);
			for(int i=1;i<=n;i++){
				ll val=Getmax(1,0,0),val1=Tree[1].mx;
				change(1,i,val);
				change(1,0,val1);
				upd(1,1,i,-d);
				for(auto to:vec[i])upd(1,1,to.p,to.val);
				upd(1,1,i-k,inf);
//				out(1,0,n,i);
//				cout<<endl;
			}
			printf("%lld\n",Tree[1].mx);
		}
	}
}
namespace Brute2{
	ll dp[100005][105];
	struct node{
		int l,r;
		ll val;
	}a[100005];
	bool cmp(node x,node y){
		return x.r<y.r;
	}
	void solve(){
		while(T--){
			int n,m,k;
			ll d;
			scanf("%d%d%d%lld",&n,&m,&k,&d);
			for(int i=1;i<=m;i++){
				scanf("%d%d%lld",&a[i].r,&a[i].l,&a[i].val);
			}
			sort(a+1,a+1+m,cmp);
			dp[0][0]=0;
			for(int j=1;j<=k;j++)dp[0][j]=inf;
			for(int i=1;i<=m;i++){
				dp[i][0]=inf;
				for(int j=0;j<=k;j++)dp[i][0]=max(dp[i][0],dp[i-1][j]);
				for(int j=1;j<=k;j++){
					if(a[i].r-a[i-1].r<=j)dp[i][j]=dp[i-1][j-a[i].r+a[i-1].r]-1ll*(a[i].r-a[i-1].r)*d;
					else dp[i][j]=dp[i][0]-d*j;
				}
				for(int j=a[i].l;j<=k;j++)dp[i][j]+=a[i].val; 
				for(int j=0;j<=k;j++)dp[i][j]=max(dp[i][j],inf);
			}
			ll ans=0;
			for(int i=0;i<=k;i++)ans=max(ans,dp[m][i]);
			printf("%lld\n",ans);
		}
	}
}
namespace Brute3{
	ll dp[100005];
	struct node{
		int l,r;
		ll val;
	}a[100005];
	bool cmp(node x,node y){
		return x.r<y.r;
	}
	void solve(){
		while(T--){
			int n,m,k;
			ll d;
			scanf("%d%d%d%lld",&n,&m,&k,&d);
			for(int i=1;i<=m;i++){
				scanf("%d%d%lld",&a[i].r,&a[i].l,&a[i].val);
			}
			sort(a+1,a+1+m,cmp);
			dp[0]=0;
			for(int i=1;i<=m;i++){
				if(a[i].l>k){
					dp[i]=dp[i-1];
					continue;
				}
				dp[i]=max(dp[i-1],dp[i-1]-d*a[i].l+a[i].val);
			}
			printf("%lld\n",dp[m]);
		}
	}
}
int main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	scanf("%d%d",&c,&T);
	if(c<=14)Brute1::solve();
	else if(c<=16)Brute2::solve();
	else Brute3::solve();
	return 0;
}
//��Ȼnodgd�࿼��ǿ��debuff 
