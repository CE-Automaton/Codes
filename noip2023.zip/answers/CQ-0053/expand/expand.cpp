#include<bits/stdc++.h>
using namespace std;
int c,n,m,q;
namespace Brute1{
	int a[2005],b[2005],arr[2005],brr[2005];
	bool fl[2005][2005];
	bool ck(){
		fl[0][0]=1;
//		cout<<endl;
//		for(int i=1;i<=n;i++)cout<<a[i]<<" ";puts("");
//		for(int i=1;i<=m;i++)cout<<b[i]<<" ";puts("");
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				fl[i][j]=0;
				if(a[1]>b[1]&&a[i]>b[j]&&(fl[i][j-1]||fl[i-1][j]||fl[i-1][j-1]))fl[i][j]=1;
				if(a[1]<b[1]&&a[i]<b[j]&&(fl[i][j-1]||fl[i-1][j]||fl[i-1][j-1]))fl[i][j]=1;
			}
		}
		return fl[n][m];
	}
	void solve(){
		for(int i=1;i<=n;i++)scanf("%d",&a[i]),arr[i]=a[i];
		for(int i=1;i<=m;i++)scanf("%d",&b[i]),brr[i]=b[i];
		if(ck())putchar('1');
		else putchar('0');
		while(q--){
			int kx,ky;
			scanf("%d%d",&kx,&ky);
			for(int i=1;i<=n;i++)a[i]=arr[i];
			for(int i=1;i<=m;i++)b[i]=brr[i];
			for(int i=1;i<=kx;i++){
				int x,y;
				scanf("%d%d",&x,&y);
				a[x]=y;
			}
			for(int i=1;i<=ky;i++){
				int x,y;
				scanf("%d%d",&x,&y);
				b[x]=y;
			}
			if(ck())putchar('1');
			else putchar('0');
		}
	}
}
namespace Brute2{
	int a[500005],b[500005],arr[500005],brr[500005];
	bool ck(){
		if(a[1]<b[1]&&a[n]>b[m])return 0;
		if(a[1]>b[1]&&a[n]<b[m])return 0;
		int mxa=0,mxb=0,mna=1e9,mnb=1e9;
		for(int i=1;i<=n;i++){
			mxa=max(mxa,a[i]);
			mna=min(mna,a[i]);
		}
		for(int i=1;i<=m;i++){
			mxb=max(mxb,b[i]);
			mnb=min(mnb,b[i]);
		}
		if(a[1]>b[1]&&mna>mnb&&mxa>mxb)return 1;
		if(a[1]<b[1]&&mna<mnb&&mxa<mxb)return 1;
		return 0;
	}
	void solve(){
		for(int i=1;i<=n;i++)scanf("%d",&a[i]),arr[i]=a[i];
		for(int i=1;i<=m;i++)scanf("%d",&b[i]),brr[i]=b[i];
		if(ck())putchar('1');
		else putchar('0');
		while(q--){
			int kx,ky;
			scanf("%d%d",&kx,&ky);
			for(int i=1;i<=n;i++)a[i]=arr[i];
			for(int i=1;i<=m;i++)b[i]=brr[i];
			for(int i=1;i<=kx;i++){
				int x,y;
				scanf("%d%d",&x,&y);
				a[x]=y;
			}
			for(int i=1;i<=ky;i++){
				int x,y;
				scanf("%d%d",&x,&y);
				b[x]=y;
			}
			if(ck())putchar('1');
			else putchar('0');
		}
	}
}
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	scanf("%d%d%d%d",&c,&n,&m,&q);
	if(c<=7){
		Brute1::solve();
	}
	else{
		Brute2::solve();
	}
	return 0;
}
