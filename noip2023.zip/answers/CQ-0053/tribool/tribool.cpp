#include<bits/stdc++.h>
using namespace std;
int c,T;
int n,m;
namespace Brute1{
	int val[15],b[15];
	struct ope{
		int op,x,y;
	}a[15];
	int ans;
	void dfs(int now){
		if(now==n+1){
			for(int i=1;i<=n;i++)val[i]=b[i];
			for(int i=1;i<=m;i++){
				if(a[i].op==1)val[a[i].x]=val[a[i].y];
				if(a[i].op==2){
					if(val[a[i].y]==2)val[a[i].x]=2;
					else val[a[i].x]=val[a[i].y]^1;
				}
				if(a[i].op==3)val[a[i].x]=1;
				if(a[i].op==4)val[a[i].x]=0;
				if(a[i].op==5)val[a[i].x]=2; 
			}
			int cnt2=0;
			int fl=1;
			for(int i=1;i<=n;i++){
				if(val[i]!=b[i])fl=0;
				cnt2+=(b[i]==2);
			}
			if(fl)ans=min(ans,cnt2);
			return;
		}
		b[now]=0;
		dfs(now+1);
		b[now]=1;
		dfs(now+1);
		b[now]=2;
		dfs(now+1);
		b[now]=0;
	}
	void solve(){
		while(T--){
			scanf("%d%d",&n,&m);
			for(int i=1;i<=m;i++){
				char c;
				scanf(" %c ",&c);
				if(c=='-'){
					a[i].op=2;
					scanf("%d%d",&a[i].x,&a[i].y);
				}
				if(c=='+'){
					a[i].op=1;
					scanf("%d%d",&a[i].x,&a[i].y);
				}
				if(c=='T'){
					a[i].op=3;
					scanf("%d",&a[i].x);
				}
				if(c=='F'){
					a[i].op=4;
					scanf("%d",&a[i].x);
				}
				if(c=='U'){
					a[i].op=5;
					scanf("%d",&a[i].x);
				}
			}
			ans=1e9;
			dfs(1);
			printf("%d\n",ans);
		}
	}
}
namespace Brute2{
	int val[100005];
	struct ope{
		int op,x,y;
	}a[100005];
	void solve(){
		while(T--){
			scanf("%d%d",&n,&m);
			for(int i=1;i<=n;i++)val[i]=0;
			for(int i=1;i<=m;i++){
				char c;
				scanf(" %c ",&c);
				if(c=='+'){
					a[i].op=1;
					scanf("%d%d",&a[i].x,&a[i].y);
				}
				if(c=='U'){
					a[i].op=2;
					scanf("%d",&a[i].x);
				}
			}
			int ans=0;
			for(int i=1;i<=n;i++){
				if(val[i]==2)ans++;
			}
			printf("%d\n",ans);
		}
	}
}
namespace Brute3{
	int val[100005],cnt;
	struct ope{
		int op,x,y;
	}a[100005];
	void solve(){
		while(T--){
			scanf("%d%d",&n,&m);
			for(int i=1;i<=n;i++)val[i]=0;
			for(int i=1;i<=m;i++){
				char c;
				scanf(" %c ",&c);
				if(c=='+'){
					a[i].op=1;
					scanf("%d%d",&a[i].x,&a[i].y);
				}
				if(c=='U'){
					a[i].op=2;
					scanf("%d",&a[i].x);
				}
			}
			int lst=0,cnt=0;
			while(1){
				for(int i=1;i<=m;i++){
					if(a[i].op==1)val[a[i].x]=val[a[i].y];
					else val[a[i].x]=2;
				}
				cnt=0;
				for(int i=1;i<=n;i++)cnt+=(val[i]==2);
				if(cnt==lst)break;
				lst=cnt;
			}
			printf("%d\n",cnt);
		}
	}
}
int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	scanf("%d%d",&c,&T);
	if(c<=2)Brute1::solve();
	else if(c<=4)Brute2::solve();
	else Brute3::solve();
	return 0;
}
