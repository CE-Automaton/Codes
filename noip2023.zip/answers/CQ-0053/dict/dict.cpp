#include<bits/stdc++.h>
using namespace std;
int n,m;
char str[3005][3005],s[3005];
int cnt[27];
int mn,scmn;
bool ck(int x,int y){ 
	if(x==0)return 1;
	if(y==0)return 0;
	for(int i=1;i<=m;i++){
		if(str[x][i]<str[y][i])return 0;
		if(str[y][i]<str[x][i])return 1;
	}
	return 1;
}
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n==1){
		putchar('1');
		return 0;
	}
	for(int i=1;i<=n;i++){
		scanf("%s",str[i]+1);
		for(int j=1;j<=m;j++)cnt[str[i][j]-'a']++;
		int tot=0;
		for(int j=25;j>=0;j--){
			while(cnt[j])str[i][++tot]=j+'a',cnt[j]--;
		}
		if(ck(scmn,i))scmn=i;
		if(ck(mn,scmn))swap(scmn,mn);
	}
//	cout<<mn<<" "<<scmn<<endl;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++)cnt[str[i][j]-'a']++;
		int tot=0;
		for(int j=0;j<26;j++){
			while(cnt[j])s[++tot]=j+'a',cnt[j]--;
		}
		bool fl=0;
		if(i!=mn){
			for(int j=1;j<=m;j++){
				if(s[j]<str[mn][j]){
					fl=1;
					break;
				}
				if(s[j]>str[mn][j])break;
			}
		}
		else{
			for(int j=1;j<=m;j++){
				if(s[j]<str[scmn][j]){
					fl=1;
					break;
				}
				if(s[j]>str[scmn][j])break;
			}
		}
		if(!fl)putchar('0');
		else putchar('1');
	}
	return 0;
}
