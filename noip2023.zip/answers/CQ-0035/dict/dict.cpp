#include <cstdio>
#include <algorithm>
using namespace std;

#define MAXN 3000

char s[MAXN + 5];
bool sn[MAXN + 5][26 + 5];
pair<int, int> sq[MAXN + 5];

int main () {
	freopen ("dict.in", "r", stdin);
	freopen ("dict.out", "w", stdout);
	
	int n, m;
	
	scanf ("%d %d", &n, &m);
	for (int i = 1; i <= n; i ++) {
		scanf ("%s", s + 1);
		for (int j = 1; j <= m; j ++) {
			sn[i][s[j] - 'a'] = 1;
		}
		for (int j = 0; j < 26; j ++) {
			if (sn[i][j]) {
				sq[i].first = j;
				
				break;
			}
		}
		for (int j = 25; j >= 0; j --) {
			if (sn[i][j]) {
				sq[i].second = j;
				
				break;
			}
		}
	}
	for (int i = 1; i <= n; i ++) {
		bool flag = 1;
		
		for (int j = 1; j <= n; j ++) {
			if (i == j) {
				continue;
			}
			if (sq[i].first >= sq[j].second) {
				flag = 0;
				
				break;
			}
		}
		if (flag) {
			putchar ('1');
		}
		else {
			putchar ('0');
		}
	}
}
