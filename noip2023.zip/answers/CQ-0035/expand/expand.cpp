#include <cstdio>
#include <algorithm>
using namespace std;

#define MAXN 500000
#define MAXM 19

int sa[MAXN + 5], sb[MAXN + 5];
vector<int> sn, sm;
int sq[MAXN + 5];
int st1[MAXN + 5][MAXM + 5], st2[MAXN + 5][MAXM + 5];
int Log[MAXN + 5];

int find1 (int l, int r) {
	int u = Log[r - l + 1];
	
	return min (st1[l][u], st1[r - (1 << u) + 1][u]);
}
int find2 (int l, int r) {
	int u = Log[r - l + 1];
	
	return max (st2[l][u], st2[r - (1 << u) + 1][u]);
}

bool f (int *s1, int *s2, int n, int m) {
	if (s1[1] == s2[1] || s1[n] == s2[m] || (s1[1] < s2[1]) != (s1[n] < s2[m])) {
		return 0;
	}
	if (s1[1] < s2[1]) {
		swap (s1, s2);
		swap (n, m);
	}
	if (n == 1) {
		for (int i = 1; i <= m; i ++) {
			if (s1[1] <= s2[i]) {
				return 0;
			}
		}
		
		return 1;
	}
	else if (m == 1) {
		for (int i = 1; i <= n; i ++) {
			if (s2[1] >= s1[i]) {
				return 0;
			}
		}
		
		return 1;
	}
	sn.clear();
	sm.clear();
	for (int i = 1; i < n; i ++) {
		if (i == 1) {
			if (s1[1] > s1[i + 1]) {
				sn.push_back(s1[1]);
			}
			
			continue;
		}
		if (s1[i] >= s1[i - 1] && s1[i] > s1[i + 1]) {
			sn.push_back(s1[i]);
		}
		else if (s1[i] <= s1[i - 1] && s1[i] < s1[i + 1]) {
			sn.push_back(s1[i]);
		}
	}
	sn.push_back(s1[n]);
	sm.push_back(s2[1]);
	for (int i = 2; i < m; i ++) {
		if (s2[i] >= s2[i - 1] && s2[i] > s2[i + 1]) {
			sm.push_back(s2[i]);
		}
		else if (s2[i] <= s2[i - 1] && s2[i] < s2[i + 1]) {
			sm.push_back(s2[i]);
		}
	}
	sm.push_back(s2[m]);
	for (int i = 0; i < int(sm.size()); i ++) {
		st1[i][0] = sm[i];
		st2[i][0] = sm[i];
	}
	for (int i = 1; i <= Log[int(sm.size())]; i ++) {
		for (int j = 0; j < int(sm.size()) - (1 << i) + 1; j ++) {
			st1[j][i] = min (st1[j][i - 1], st1[j + (1 << (i - 1))][i - 1]);
			st2[j][i] = max (st2[j][i - 1], st2[j + (1 << (i - 1))][i - 1]);
		}
	}
	
	int h = -1;
	
	for (auto i : sn) {
		if (h < int(sm.size()) - 1 && sm[h + 1] < i) {
			int len = 1;
			int d = 0;
			
			while (h + (len << 1) < int(sm.size())) {
				d ++;
				len <<= 1;
				if (find2 (h + 1, h + len) >= i) {
					len >>= 1;
					d --;
					
					break;
				}
			}
			for (int j = d - 1; j >= 0; j --) {
				if (h + len + (1 << j) >= int(sm.size())) {
					continue;
				}
				if (find2 (h + 1, h + len + (1 << j)) < i) {
					len += (1 << j);
				}
			}
			h += len;
		}
		else {
			if (find1 (0, h) >= i) {
				return 0;
			}
			if (sm[h] < i) {
				continue;
			}
			
			int len = 1;
			int d = 0;
			
			while (h + 1 - (len << 1) >= 0) {
				d ++;
				len <<= 1;
				if (find1 (h + 1 - len, h) < i) {
					len >>= 1;
					d --;
					
					break;
				}
			}
			for (int j = d - 1; j >= 0; j --) {
				if (h + 1 - len - (1 << j) < 0) {
					continue;
				}
				if (find1 (h + 1 - len - (1 << j), h) >= i) {
					len += (1 << j);
				}
			}
			h -= len;
		}
	}
	if (h == int(sm.size() - 1)) {
		return 1;
	}
	
	return 0;
}
void read (int &n) {
	n = 0;
	
	char c = getchar ();
	bool flag = 0;
	
	while (c < '0' || c > '9') {
		if (c == '-') {
			flag = 1;
		}
		c = getchar ();
	}
	while (c >= '0' && c <= '9') {
		n = (n << 1) + (n << 3) + (c ^ 48);
		c = getchar ();
	}
	n = flag ? -n : n;
}

int main () {
	freopen ("expand.in", "r", stdin);
	freopen ("expand.out", "w", stdout);
	
	int n, m;
	int q;
	
	scanf ("%*d %d %d %d", &n, &m, &q);
	for (int i = 2; i <= n; i ++) {
		Log[i] = Log[i >> 1] + 1;
	}
	for (int i = 1; i <= n; i ++) {
		read (sa[i]);
	}
	for (int i = 1; i <= m; i ++) {
		read (sb[i]);
	}
	putchar (48 ^ f (sa, sb, n, m));
	
	vector<pair<int, int> > sk1, sk2;
	
	for (int i = 1; i <= q; i ++) {
		int k1, k2;
		
		read (k1), read (k2);
		sk1.clear();
		sk2.clear();
		for (int j = 1; j <= k1; j ++) {
			int loc;
			int v;
			
			read (loc), read (v);
			sk1.push_back(make_pair (loc, sa[loc]));
			sa[loc] = v;
		}
		for (int j = 1; j <= k2; j ++) {
			int loc;
			int v;
			
			read (loc), read (v);
			sk2.push_back(make_pair (loc, sb[loc]));
			sb[loc] = v;
		}
		putchar (48 ^ f (sa, sb, n, m));
		for (auto j : sk1) {
			sa[j.first] = j.second;
		}
		for (auto j : sk2) {
			sb[j.first] = j.second;
		}
	}
}
