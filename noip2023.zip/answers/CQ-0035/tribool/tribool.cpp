#include <cstdio>
#include <algorithm>
#include <vector>
#include <stack>
using namespace std;

#define MAXN 200000

vector<pair<int, bool> > s[MAXN + 5];
int sn[MAXN + 5];
int sv[MAXN + 5];
int slast[MAXN + 5];
int sd[MAXN + 5];

int f (int c, bool e) {
	if (c == 3) {
		return 3;
	}
	else if (e == 0){
		return 3 - c;
	}
	else {
		return c;
	}
}

bool dfs (int u) {
	for (auto i : s[u]) {
		if (sv[i.first]) {
			if (sv[i.first] != f (sv[u], i.second)) {
				return 0;
			}
		}
		else {
			sv[i.first] = f (sv[u], i.second);
			if (!dfs (i.first)) {
				return 0;
			}
		}
	}
	
	return 1;
}
void inite (int u) {
	sv[u] = 3;
	for (auto i : s[u]) {
		if (sv[i.first] == 3) {
			continue;
		}
		else {
			inite (i.first);
		}
	}
}

int main () {
	freopen ("tribool.in", "r", stdin);
	freopen ("tribool.out", "w", stdout);
	
	int t;
	
	scanf ("%*d %d", &t);
	while (t --) {
		int n, m;
		
		scanf ("%d %d", &n, &m);
		for (int i = 0; i <= n + m; i ++) {
			s[i].clear();
			sv[i] = 0;
			slast[i] = 0;
			sd[i] = 0;
		}
		for (int i = 1; i <= n; i ++) {
			sn[i] = i;
		}
		
		int num = n;
		
		for (int i = 1; i <= m; i ++) {
			char opt[2];
			
			scanf ("%s", opt);
			if (opt[0] == 'T') {
				int u;
				
				scanf ("%d", &u);
				sn[u] = ++num;
				sv[num] = 1;
			}
			else if (opt[0] == 'F') {
				int u;
				
				scanf ("%d", &u);
				sn[u] = ++num;
				sv[num] = 2;
			}
			else if (opt[0] == 'U') {
				int u;
				
				scanf ("%d", &u);
				sn[u] = ++num;
				sv[num] = 3;
			}
			else if (opt[0] == '+') {
				int u, v;
				
				scanf ("%d %d", &v, &u);
				u = sn[u];
				sn[v] = ++num;
				v = sn[v];
				s[u].push_back(make_pair (v, 1));
				sd[u] ++;
				slast[v] = u;
			}
			else if (opt[0] == '-') {
				int u, v;
				
				scanf ("%d %d", &v, &u);
				u = sn[u];
				sn[v] = ++num;
				v = sn[v];
				s[u].push_back(make_pair (v, 0));
				sd[u] ++;
				slast[v] = u;
			}
		}
		for (int i = 1; i <= n; i ++) {
			s[sn[i]].push_back(make_pair (i, 1));
			sd[sn[i]] ++;
			slast[i] = sn[i];
		}
		for (int i = 1; i <= num; i ++) {
			if (sv[i]) {
				dfs(i);
			}
		}
		
		stack <int> S;
		
		for (int i = 1; i <= num; i ++) {
			if (!sd[i]) {
				S.push (i);
			}
		}
		while (!S.empty ()) {
			int p = S.top();
			
			S.pop();
			if (slast[p]) {
				sd[slast[p]] --;
				if (!sd[slast[p]]) {
					S.push(slast[p]);
				}
			}
		}
		for (int i = 1; i <= n; i ++) {
			if (!sd[i]) {
				continue;
			}
			if (!sv[i]) {
				sv[i] = 1;
				if (dfs (i)) {
					continue;
				}
				else {
					sv[i] = 3;
					inite (i);
				}
			}
		}
		
		int ans = 0;
		
		for (int i = 1; i <= n; i ++) {
			if (sv[i] == 3) {
				ans ++;
			}
		}
		printf ("%d\n", ans);
	}
}
