#include <cstdio>
#include <algorithm>
#include <random>
using namespace std;

#define MAXN 100000
#define INF 0x3f3f3f3f3f3f3f3f

int s[MAXN + 5];
vector<pair<int, long long> > sm[MAXN + 5];
mt19937 rnd(348757);
struct fhq  {
	int son[2] = {};
	int num = 0;
	int Lazy = 0;
	long long smax = -INF;
	long long v = -INF;
	int key = rnd();
}sf[MAXN + 5];
int rt;
int num = 0;

void download (int p) {
	if (sf[p].son[0]) {
		sf[sf[p].son[0]].smax += sf[p].Lazy;
		sf[sf[p].son[0]].Lazy += sf[p].Lazy;
		sf[sf[p].son[0]].v += sf[p].Lazy;
	}
	if (sf[p].son[1]) {
		sf[sf[p].son[1]].smax += sf[p].Lazy;
		sf[sf[p].son[1]].Lazy += sf[p].Lazy;
		sf[sf[p].son[1]].v += sf[p].Lazy;
	}
	sf[p].Lazy = 0;
}
void upload (int p) {
	sf[p].smax = max (sf[p].v, max (sf[sf[p].son[0]].smax, sf[sf[p].son[1]].smax));
	sf[p].num = 1 + sf[sf[p].son[0]].num + sf[sf[p].son[1]].num;
}
void split (int p, int &l, int &r, int k) {
	if (!p) {
		l = r = 0;
		
		return ;
	}
	if (sf[sf[p].son[0]].num + 1 <= k) {
		download (p);
		l = p;
		split (sf[p].son[1], sf[l].son[1], r, k - sf[sf[p].son[0]].num - 1);
		upload (l);
	}
	else {
		download (p);
		r = p;
		split (sf[p].son[0], l, sf[r].son[0], k);
		upload (r);
	}
}
int merge (int l, int r) {
	if (l == 0 || r == 0) {
		return (l | r);
	}
	else if (sf[l].key > sf[r].key) {
		download (l);
		sf[l].son[1] = merge (sf[l].son[1], r);
		upload (l);
		
		return l;
	}
	else {
		download (r);
		sf[r].son[0] = merge (l, sf[r].son[0]);
		upload (r);
		
		return r;
	}
}
int newfhq (long long v) {
	++num;
	sf[num].v = v;
	sf[num].smax = v;
	sf[num].num = 1;
	sf[num].Lazy = 0;
	sf[num].son[0] = sf[num].son[1] = 0;
	
	return num;
}

int main () {
	freopen ("run.in", "r", stdin);
	freopen ("run.out", "w", stdout);
	
	int t;
	
	scanf ("%*d %d", &t);
	while (t --) {
		int n, m, k, d;
		
		scanf ("%d %d %d %d", &n, &m, &k, &d);
		for (int i = 1; i <= n; i ++) {
			sm[i].clear();
		}
		for (int i = 1; i <= m; i ++) {
			int x, y;
			long long v;
			
			scanf ("%d %d %lld", &x, &y, &v);
			sm[x].push_back(make_pair (y, v));
		}
		num = 0;
		rt = newfhq (0);
		
		for (int i = 1; i <= n; i ++) {
			int loc = newfhq (sf[rt].smax);
			
			sf[rt].v -= d;
			sf[rt].smax -= d;
			sf[rt].Lazy -= d;
			rt = merge (loc, rt);
			for (auto j : sm[i]) {
				int l, r;
				
				split (rt, l, r, j.first);
				if (r) {
					sf[r].v += j.second;
					sf[r].smax += j.second;
					sf[r].Lazy += j.second;
					rt = merge (l, r);
				}
				else {
					rt = l;
				}
			}
			int l;
			
			split (rt, rt, l, k + 1);
		}
		printf ("%lld\n", sf[rt].smax);
	}
}
