#include<bits/stdc++.h>
using namespace std;

namespace Solve{
	typedef long long ll;
	
	const int N=500010;
	int check(vector<int>&a,vector<int>&b){
		int n=a.size(),m=b.size();
		if(a[0]<=b[0])return 0;
//		for(int i:b)cerr<<i<<' ';cerr<<"b\n";
		queue<pair<int,int>>A,B;
		int mx=a[0],mi=a[0];
		for(int i=1;i<n;i++){
			if(a[i]>=mx){
				A.push({a[i],mi});
//				cerr<<"A "<<a[i]<<' '<<mi<<'\n';
				mx=mi=a[i];
			}
			else{
				mi=min(mi,a[i]);
			}
		}
		mx=mi=b[0];
		for(int i=1;i<m;i++){
			if(b[i]<=mi){
				B.push({b[i],mx});
//				cerr<<"B "<<b[i]<<' '<<mx<<'\n';
				mi=mx=b[i];
			}
			else{
				mx=max(mx,b[i]);
			}
		}
		mx=a[0],mi=b[0];
		while(A.size()&&B.size()){
			if(A.front().second>mi){
				mx=A.front().first;
				A.pop();
			}
			else if(B.front().second<mx){
				mi=B.front().first;
				B.pop();
			}
			else{
				return 0;
			}
		}
		while(A.size()){
			if(A.front().second>mi){
				A.pop();
			}
			else{
				return 0;
			}
		}
		while(B.size()){
			if(B.front().second<mx){
				B.pop();
			}
			else{
				return 0;
			}
		}
		return 1;
	}
	int id,n,m,q;
	int a[N],b[N];
	int ta[N],tb[N];
	
	int calc(){
		if(a[1]==b[1]||a[n]==b[m])return 0;
		if((a[1]>b[1])^(a[n]>b[m]))return 0;
		
		if(a[1]>b[1]){
			int mx=1,mi=1;
			for(int i=2;i<=n;i++)
				if(a[i]>a[mx]){
					mx=i;
				}
			for(int i=2;i<=m;i++)
				if(b[i]<b[mi]){
					mi=i;
				}
			vector<int>A,B;
			for(int i=1;i<=mx;i++)A.push_back(a[i]);
			for(int i=1;i<=mi;i++)B.push_back(b[i]);
			if(!check(A,B))return 0;
			A.clear(),B.clear();
			for(int i=n;i>=mx;i--)A.push_back(a[i]);
			for(int i=m;i>=mi;i--)B.push_back(b[i]);
			if(!check(A,B))return 0;
			return 1;
		}
		else{
			swap(a,b),swap(n,m);
			int res=calc();
			swap(a,b),swap(n,m);
			return res;
		}
	}
	void main(){
		cin>>id>>n>>m>>q;
		for(int i=1;i<=n;i++)cin>>a[i];
		for(int i=1;i<=m;i++)cin>>b[i];
		
		memcpy(ta,a,sizeof ta);
		memcpy(tb,b,sizeof tb);
		cout<<calc();
		while(q--){
			memcpy(a,ta,sizeof a);
			memcpy(b,tb,sizeof b);
			
			int x,y;cin>>x>>y;
			while(x--){
				int p,q;cin>>p>>q;
				a[p]=q;
			}
			while(y--){
				int p,q;cin>>p>>q;
				b[p]=q;
			}
//			for(int i=1;i<=n;i++)cerr<<a[i]<<' ';cerr<<'\n';
//			for(int i=1;i<=m;i++)cerr<<b[i]<<' ';cerr<<'\n';
			cout<<calc();
		}
		cout<<'\n';
	}
}
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	
	Solve::main();
	
	return 0;
}


