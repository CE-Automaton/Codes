#include<bits/stdc++.h>
using namespace std;

namespace Solve{
	typedef long long ll;
	
	const int N=100010<<1;
	int id,T;
	int n,m;
	
	int v[N],s[N],tot;
	char op[N];
	
	int fa[N],d[N],siz[N];
	int get(int x){
		if(!fa[x])return x;
		int r=get(fa[x]);
		d[x]^=d[fa[x]];
		return fa[x]=r;
	}
	bool o[N];
	void merge(int x,int y,int z){
		get(x);z^=d[x];x=get(x);
		get(y);z^=d[y];y=get(y);
		if(x==y){
			if(z){
				o[x]=1;
			}
			return;
		}
		if(x>y)swap(x,y);
		fa[x]=y,d[x]=z,o[y]|=o[x],siz[y]+=siz[x];
	}
	void main(){
		cin>>id>>T;
		while(T--){
			cin>>n>>m;
			for(int i=1;i<=n;i++)v[i]=i,s[i]=0;
			tot=n;
			for(int i=1;i<=m;i++){
				char c;cin>>c;
				if(c=='+'){
					int x,y;cin>>x>>y;
					v[x]=v[y],s[x]=s[y];
				}
				else if(c=='-'){
					int x,y;cin>>x>>y;
					v[x]=v[y],s[x]=s[y]^1;
				}
				else{
					op[++tot]=c;
					int x;cin>>x;
					v[x]=tot,s[x]=0;
				}
			}
			
			for(int i=1;i<=tot;i++)fa[i]=d[i]=0,o[i]=0,siz[i]=(i<=n);
			
			for(int i=1;i<=n;i++){
//				cerr<<"Merge "<<i<<' '<<v[i]<<' '<<s[i]<<'\n';
				merge(i,v[i],s[i]);
			}
			
			int cnt=0;
			for(int i=1;i<=tot;i++)
				if(get(i)==i){
//					cerr<<"I "<<i<<' '<<siz[i]<<'\n';
					if(o[i]||(i>n&&op[i]=='U')){
						cnt+=siz[i];
					}
				}
			
			cout<<cnt<<'\n';
		}
	}
}
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	
	Solve::main();
	
	return 0;
}


