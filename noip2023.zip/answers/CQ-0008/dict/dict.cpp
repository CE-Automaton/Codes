#include<bits/stdc++.h>
using namespace std;

namespace Solve{
	typedef long long ll;
	
	const int N=3010;
	int n,m;string s[N];
	
	int ans[N];
	void main(){
		cin>>n>>m;
		for(int i=1;i<=n;i++)cin>>s[i],sort(s[i].begin(),s[i].end());
		
		for(int i=1;i<=n;i++)ans[i]=1;
		string mi=s[1];reverse(mi.begin(),mi.end());
		for(int i=2;i<=n;i++){
			if(s[i]>=mi){
				ans[i]=0;
			}
			string tmp=s[i];reverse(tmp.begin(),tmp.end());
			if(tmp<mi){
				mi=tmp;
			}
		}
		mi=s[n];reverse(mi.begin(),mi.end());
		for(int i=n-1;i;i--){
			if(s[i]>=mi){
				ans[i]=0;
			}
			string tmp=s[i];reverse(tmp.begin(),tmp.end());
			if(tmp<mi){
				mi=tmp;
			}
		}
		for(int i=1;i<=n;i++)cout<<ans[i];
	}
}
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	
	Solve::main();
	
	return 0;
}


