#include<bits/stdc++.h>
#define int long long
using namespace std;

namespace Solve{
	typedef long long ll;
	
	const int N=200010;
	const int INF=1e18;
	int id,T;
	int n,m,k,d;
	int l[N],r[N],v[N];
	
	int lis[N],sz;
	void lisan(){
		sz=0;
		for(int i=1;i<=m;i++){
			lis[++sz]=l[i];
			lis[++sz]=r[i];
		}
		sort(lis+1,lis+1+sz);
		sz=unique(lis+1,lis+1+sz)-lis-1;
		for(int i=1;i<=m;i++){
			l[i]=lower_bound(lis+1,lis+1+sz,l[i])-lis;
			r[i]=lower_bound(lis+1,lis+1+sz,r[i])-lis;
		}
	}
	
	inline void Max(int&x,int y){
		x=(x>y?x:y);
	}
	int b[N];
	struct SegmentTree{
		struct Node{
			int dlt,ad;
		}tr[N<<2];
		void build(int p,int l,int r){
			tr[p].dlt=0,tr[p].ad=-INF;
			if(l==r){
				tr[p].dlt=-lis[l]*d+b[l];
				return;
			}
			int mid=(l+r)>>1;
			build(p<<1,l,mid),build(p<<1|1,mid+1,r);
		}
		void cover_dlt(int p,int d){
			tr[p].dlt+=d;
		}
		void cover_ad(int p,int a){
			Max(tr[p].ad,a+tr[p].dlt);
		}
		void pushdown(int p){
			if(tr[p].ad!=-INF){
				cover_ad(p<<1,tr[p].ad);
				cover_ad(p<<1|1,tr[p].ad);
				tr[p].ad=-INF;
			}
			if(tr[p].dlt){
				cover_dlt(p<<1,tr[p].dlt);
				cover_dlt(p<<1|1,tr[p].dlt);
				tr[p].dlt=0;
			}
		}
		void Dlt(int p,int L,int R,int l,int r,int x){
			if(l<=L&&R<=r){
				cover_dlt(p,x);
				return;
			}
			int mid=(L+R)>>1;
			pushdown(p);
			if(l<=mid)Dlt(p<<1,L,mid,l,r,x);
			if(r>mid)Dlt(p<<1|1,mid+1,R,l,r,x);
		}
		void Ad(int p,int L,int R,int l,int r,int x){
			if(l<=L&&R<=r){
				cover_ad(p,x);
				return;
			}
			int mid=(L+R)>>1;
			pushdown(p);
			if(l<=mid)Ad(p<<1,L,mid,l,r,x);
			if(r>mid)Ad(p<<1|1,mid+1,R,l,r,x);
		}
		int Query(int p,int L,int R,int x){
			if(L==R)return tr[p].ad;
			int mid=(L+R)>>1;
			pushdown(p);
			if(x<=mid)return Query(p<<1,L,mid,x);
			return Query(p<<1|1,mid+1,R,x);
		}
	}seg;
	int f[N];
	
	vector<int>vv[N];
	
	int get(int x){
		if(x==1)return 0;
		if(lis[x-1]==lis[x]-1)return max(0ll,f[x-2]);
		return max(0ll,f[x-1]);
	}
	char buf[1<<23],*p1=buf,*p2=buf;
	#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2)?EOF:*p1++)
	inline int rd(){
		int x=0,f=1;char ch=getchar();
		while(!isdigit(ch)){if(ch=='-')f=-1;ch=getchar();};
		while(isdigit(ch))x=(x*10)+(ch^48),ch=getchar();
		return x*f;
	}
	void main(){
//		cin>>id>>T;
		id=rd(),T=rd();
		while(T--){
//			cin>>n>>m>>k>>d;
			n=rd(),m=rd(),k=rd(),d=rd();
			for(int i=1;i<=m;i++){
//				int x,y;cin>>x>>y>>v[i];
				int x=rd(),y=rd();v[i]=rd();
				l[i]=x-y+1,r[i]=x;
			}
//			cerr<<"AAA\n";
			lisan();
			for(int i=1;i<=sz;i++)vv[i].clear();
			for(int i=1;i<=m;i++){
				vv[l[i]].push_back(i);
			}
			
			memset(b,0,sizeof b);
			for(int i=1;i<=m;i++)b[r[i]]+=v[i];
			for(int i=1;i<=sz;i++)b[i]+=b[i-1];
			seg.build(1,1,sz);
			
			int cur=1;
			memset(f,0,sizeof f);
			for(int i=1;i<=sz;i++){
				if(i>1){
					int res=seg.Query(1,1,sz,i-1);
					Max(f[i-1],res);
					Max(f[i-1],f[i-2]);
				}
				while(cur<sz&&lis[cur+1]-lis[i]+1<=k)cur++;
				
				seg.Ad(1,1,sz,i,cur,get(i)+(lis[i]-1)*d);
				
				for(int j:vv[i]){
					seg.Dlt(1,1,sz,r[j],sz,-v[j]);
				}
			}
//			for(int i=1;i<=sz;i++){
//				cerr<<seg.Query(1,i)<<' ';
//			}
//			cerr<<"S\n";
			int res=seg.Query(1,1,sz,sz);
			Max(f[sz],res);
			Max(f[sz],f[sz-1]);
			
			cout<<f[sz]<<'\n';
		}
	}
}
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	
	Solve::main();
	
	return 0;
}


