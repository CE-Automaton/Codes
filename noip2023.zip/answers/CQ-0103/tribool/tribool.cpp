#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
const int N=200005;
int C,T,n,m,s[N],fa[N],sz[N],ans,sum[N],st[N],tp;
char op[2];
bool vis[N];
vector<int>e[N];
int gf(int x){return fa[x]==x?x:fa[x]=gf(fa[x]);}
void dfs(int rt,int x,int prt,bool &fl){
	sum[rt]+=sz[x],vis[x]=1,st[++tp]=x;
	if(s[x]==2*n+3)fl=1;
	for(auto y:e[x])
		if(y!=prt){
			if(vis[y]){
				int cnt=1,k=tp;
				while(st[k]!=y)k--,cnt++;
				if(cnt&1)fl=1;
				continue;
			}
			dfs(rt,y,x,fl);
		}
	tp--;
}
int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	scanf("%d%d",&C,&T);
	while(T--){
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;i++){
			s[i]=fa[i]=i,sz[i]=1,sum[i]=0,vis[i]=0;
			e[i].clear();
		}
		while(m--){
			scanf("%s",op);
			int x,y;
			if(op[0]=='+')scanf("%d%d",&x,&y),s[x]=s[y];
			if(op[0]=='-'){
				scanf("%d%d",&x,&y);
				if(s[y]==2*n+1)s[x]=2*n+2;
				else if(s[y]==2*n+2)s[x]=2*n+1;
				else if(s[y]==2*n+3)s[x]=2*n+3;
				else if(s[y]<=n)s[x]=s[y]+n;
				else if(s[y]>n&&s[y]<=2*n)s[x]=s[y]-n;
			}
			if(op[0]=='T')scanf("%d",&x),s[x]=2*n+1;
			if(op[0]=='F')scanf("%d",&x),s[x]=2*n+2;
			if(op[0]=='U')scanf("%d",&x),s[x]=2*n+3;
		}
		ans=0;
		for(int i=1;i<=n;i++)
			if(s[i]<=n){
				int x=gf(i),y=gf(s[i]);
				if(x!=y)sz[y]+=sz[x],fa[x]=y;
			}
		for(int i=1;i<=n;i++)
			if(gf(i)==i&&s[i]<=2*n&&s[i]>n){
				int to=gf(s[i]-n);
				e[i].push_back(to);
				e[to].push_back(i);
			}
		for(int i=1;i<=n;i++)
			if(gf(i)==i&&!vis[i]){
				bool res=0;
				dfs(i,i,0,res);
				ans+=res*sum[i];
			}
		printf("%d\n",ans);
	}
	return 0;
}
