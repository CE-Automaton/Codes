#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
const int N=3005;
char c[N];
int n,m,l[N],r[N];
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("%s",c+1);
		l[i]=130;
		for(int j=1;j<=m;j++)
			l[i]=min(l[i],(int)c[j]),r[i]=max(r[i],(int)c[j]);
	}
	for(int i=1;i<=n;i++){
		char fl='1';
		for(int j=1;j<=n;j++)
			if(j!=i&&r[j]<=l[i]){fl='0';break;}
		putchar(fl);
	}
	return 0;
}
