#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
const int N=200005;
int C,n,m,Q,a[N],b[N],A[N],B[N],kx,ky,px[N],vx[N],py[N],vy[N];
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	scanf("%d%d%d%d",&C,&n,&m,&Q);
	for(int i=1;i<=n;i++)scanf("%d",a+i),A[i]=a[i];
	for(int i=1;i<=m;i++)scanf("%d",b+i),B[i]=b[i];
	if(a[1]==b[1]||a[n]==b[m])putchar('0');
	else if((a[1]>b[1])^(a[n]>b[m]))putchar('0');
	else putchar('1');
	while(Q--){
		scanf("%d%d",&kx,&ky);
		for(int i=1;i<=kx;i++)scanf("%d%d",px+i,vx+i),a[px[i]]=vx[i];
		for(int i=1;i<=ky;i++)scanf("%d%d",py+i,vy+i),b[py[i]]=vy[i];
		if(a[1]==b[1]||a[n]==b[m])putchar('0');
		else if((a[1]>b[1])^(a[n]>b[m]))putchar('0');
		else putchar('1');
		for(int i=1;i<=kx;i++)a[px[i]]=A[px[i]];
		for(int i=1;i<=ky;i++)b[py[i]]=B[py[i]];
	}
	return 0;
}
