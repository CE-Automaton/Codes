#include<bits/stdc++.h>
#define rep1(i, a, b) for(int i = a; i <= b; ++i)
#define rep2(i, a, b) for(int i = a; i >= b; --i)
#define pii pair <int, int>
#define ll long long
#define ft first
#define sd second
#define pb push_back
#define debug puts("---------------------")
const int N = 1.1e5 + 10;
using namespace std;
int c, T, a[N], vis[N]; pii to[N];
void dfs(int u) {
	int nxt = to[u].ft, tp = to[u].sd;
//	cout << u << ' ' << nxt << '\n';
	if(!nxt) return a[u] = 0, void();
	if(~a[nxt]) a[u] = a[nxt] < 2 ? tp ^ a[nxt] : 2;
	else {
		int nxtp = ((vis[u] - 1) ^ tp) + 1;
		if(vis[nxt]) {
			if(vis[nxt] ^ nxtp) return a[u] = 2, void();
			return a[u] = 0, void();
		} vis[nxt] = nxtp;
		dfs(nxt); a[u] = (a[nxt] < 2 ? tp ^ a[nxt] : 2);
//		cout << u << ' ' << a[u] << ' ' << nxt << ' ' << a[nxt] << ' ' << (tp ^ a[nxt]) << '\n';
	}
}
int main() {
	freopen("tribool.in", "r", stdin);
	freopen("tribool.out", "w", stdout);
	scanf("%d%d", &c, &T);
	while(T--) {
		int n, m, ans = 0; scanf("%d%d", &n, &m);
		rep1(i, 1, n + 3) a[i] = -1, vis[i] = 0, to[i] = {i, 0};
		rep1(i, 1, m) {
			char op; int u, v;
			scanf("\n%c%d", &op, &u);
			if(op == '-' || op == '+') {
				scanf("%d", &v);
				to[u].ft = to[v].ft;
				to[u].sd = to[v].sd ^ (op == '-');
			}
			else {
				if(op == 'U') to[u] = {n + 3, 0};
				else to[u] = {n + 1 + (op == 'T'), 0};
			}
		} a[n + 1] = 0; a[n + 2] = 1; a[n + 3] = 2;
		rep1(i, 1, n) {
			if(~a[i]) continue;
//			cout << i << ' ' << to[i].ft << ' ' << to[i].sd << '\n';
			vis[i] = 1; dfs(i);
		}
		rep1(i, 1, n) ans += a[i] == 2;
		printf("%d\n", ans);
	}
	return 0;
}
/*
ע�⣺
������̬��������̬��������̬��

Ҫ��飡Ҫ��飡Ҫ��飡

�����Ѽ��
ll�Ѽ��
�������Ѽ��
freopen�Ѽ��
�����Ѽ�� 

begin: 9:32

end: 10:58

test :
1 1
10 10
- 7 6
+ 4 1
+ 6 4
T 1
+ 2 9
- 9 10
U 10
+ 5 5
U 8
T 3

*/

