#include<bits/stdc++.h>
#define rep1(i, a, b) for(int i = a; i <= b; ++i)
#define rep2(i, a, b) for(int i = a; i >= b; --i)
#define pii pair <int, int>
#define ll long long
#define ft first
#define sd second
#define pb push_back
#define debug puts("---------------------")
const int N = 2e3 + 10;
using namespace std;
int c, n, m, q, a[N], b[N], va[N], vb[N], dp[N][N];
int main() {
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);
	scanf("%d%d%d%d", &c, &n, &m, &q);
	rep1(i, 1, n) scanf("%d", a + i);
	rep1(i, 1, m) scanf("%d", b + i);
	rep1(i, 0, q) {
		rep1(j, 1, n) va[j] = a[j];
		rep1(j, 1, m) vb[j] = b[j];
		if(i) {
			int kx, ky, p, v; scanf("%d%d", &kx, &ky);
			rep1(j, 1, kx) scanf("%d%d", &p, &v), va[p] = v;
			rep1(j, 1, ky) scanf("%d%d", &p, &v), vb[p] = v;
		} int tp = va[1] < vb[1], flg = (va[1] == vb[1]) | (va[n] == vb[m]);
//		rep1(j, 1, n) cout << va[j] << ' '; puts("");
//		rep1(j, 1, m) cout << vb[j] << ' '; puts("");
		if((va[n] < vb[m]) != tp || flg) {printf("0"); continue;}
		rep1(j, 0, n) rep1(k, 0, m) dp[j][k] = 0; dp[0][0] = 1;
		rep1(j, 1, n) rep1(k, 1, m) {
			dp[j][k] = 0;
			if((va[j] < vb[k]) != tp) continue;
			dp[j][k] = dp[j - 1][k - 1] | dp[j][k - 1] | dp[j - 1][k];
		}
//		rep1(j, 1, n) rep1(k, 1, m) cout << j << ' ' << k << ' ' << dp[j][k] << '\n';
		printf("%d", dp[n][m]);
	}
	return 0;
}
/*
ע�⣺
������̬��������̬��������̬��

Ҫ��飡Ҫ��飡Ҫ��飡

�����Ѽ��
ll�Ѽ��
freopen�Ѽ��
�����Ѽ�� 

begin: 11:29

end: 11:48

*/

