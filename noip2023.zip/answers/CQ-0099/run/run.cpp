#include<bits/stdc++.h>
#define rep1(i, a, b) for(int i = a; i <= b; ++i)
#define rep2(i, a, b) for(int i = a; i >= b; --i)
#define pii pair <int, int>
#define ll long long
#define ft first
#define sd second
#define pb push_back
#define debug puts("---------------------")
const int N = 2e3 + 10;
const ll inf = -1e18;
using namespace std;
int c, T; ll dp[N][N];
vector <pii> e[N];
int main() {
	freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);
	scanf("%d%d", &c, &T);
	while(T--) {
		int n, m, k, d; scanf("%d%d%d%d", &n, &m, &k, &d);
		if(c <= 9) {
			rep1(i, 1, n) e[i].clear();
			rep1(i, 1, m) {
				int x, y, w;
				scanf("%d%d%d", &x, &y, &w);
				if(y > k) continue;
				e[x].pb({y, w});
			}
			rep1(i, 1, n) sort(e[i].begin(), e[i].end());
			ll ans = 0;
			rep1(i, 0, n) rep1(j, 0, min(i, k)) dp[i][j] = inf;
			dp[0][0] = 0;
			rep1(i, 1, n) {
				rep1(j, 0, min(i, k)) dp[i][0] = max(dp[i][0], dp[i - 1][j]);
				rep1(j, 1, min(i, k)) dp[i][j] = max(dp[i][j], dp[i - 1][j - 1] - d);
				ll sum = 0, id = -1; if(!e[i].size()) continue;
				rep1(j, 1, min(i, k)) {
					while((int)e[i].size() > id + 1 && j >= e[i][id + 1].ft) ++id, sum += e[i][id].sd;
					dp[i][j] += sum;
				}
			}
			rep1(i, 0, min(n, k)) ans = max(ans, dp[n][i]);
			printf("%lld\n", ans);
		}
		if(17 <= c && c <= 18) {
			ll ans = 0;
			rep1(i, 1, m) {
				int x, y, w;
				scanf("%d%d%d", &x, &y, &w);
				if(y > k) continue;
				if(w > 1ll * y * d) ans += w - 1ll * y * d;
			} printf("%lld\n", ans);
		}
	}
	return 0;
}
/*
ע�⣺
������̬��������̬��������̬��

Ҫ��飡Ҫ��飡Ҫ��飡

�����Ѽ��
ll�Ѽ�� 
�����Ѽ��
freopen�Ѽ�� 

begin: 12:12

end: 12:40

*/

