#include <iostream>

#define DEBUG 0
#if !DEBUG
#define fre(file) freopen(#file ".in", "r", stdin), freopen(#file ".out", "w", stdout)
#else
#define fre(...)
#endif

int cnt[3005][26];
int g[3005];
int n, m, p1 = 25, np;
char ch;
bool flag;
int p2 = 25, p3 = 25;

int main() {
	fre(dict);
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	std::cout.tie(nullptr);
	std::cin >> n >> m;
	if (n == 1) { return std::cout << '1', 0; }
	for (int i = 0; i != n; ++i) {
		for (int j = 0; j != m; ++j)
			std::cin >> ch, ++cnt[i][ch -= 'a'], g[i] |= 1 << ch;
		np = __builtin_ctz(g[i]);
		if (np < p1)
			p1 = np, flag = false;
		if (cnt[i][p1] == m)
			flag = true;
		np = __builtin_clz(g[i]) ^ 31;
		if (np <= p2)
			p3 = p2, p2 = np;
		else if (np < p3)
			p3 = np;
	}
	for (int i = 0; i != n; ++i) {
		int p = __builtin_ctz(g[i]);
		if (p == p1)
			if (cnt[i][p] == m || !flag)
				std::cout << '1';
			else
				std::cout << '0';
		else
			if (p2 > p || p2 == p && p3 > p)
				std::cout << '1';
			else
				std::cout << '0';
	}
	return 0;
}
