#include <iostream>

#define DEBUG 0
#if !DEBUG
#define fre(file) freopen(#file ".in", "r", stdin), freopen(#file ".out", "w", stdout)
#else
#define fre(...)
#endif

constexpr int MAXN = 2e5 + 5;
int c, t, n, m;
int fr, to;
char op;
int fa[MAXN], oth[MAXN];
bool flag[MAXN];
bool vis[MAXN];
int ans;
unsigned char colors[MAXN];

inline void setval(int a, int b, int op) {
	if (op)
		fa[a] = fa[b] ^ 1 << 31;
	else
		fa[a] = fa[b];
}
int getfa(int idx) { return fa[idx] != idx ? fa[idx] = getfa(fa[idx]) : idx; }
void mge(int a, int tmp) {
	int& b = oth[tmp];
	if (a ==  0) { fa[tmp] = 0; return; }
	if (b == -1) { b = getfa(a); return; }
	a = getfa(a), b = getfa(b);
	if (a == b) return;
	if (a == 0 || b == 0) { fa[a] = fa[b] = 0; return; }
	
	if (~oth[a]) if ((oth[a] = getfa(oth[a])) == b) { fa[a] = fa[b] = 0; return; }
	if (~oth[b]) if ((oth[b] = getfa(oth[b])) == a) { fa[b] = fa[a] = 0; return; }
	fa[a] = b;
	if (~oth[a] && ~oth[b])
		fa[oth[a]] = oth[b];
	else if (~oth[a])
		oth[b] = oth[a];
}
void mge1(int a, int& b) {
	a = getfa(a), b = getfa(b);
	if (a == b) return;
	if (a == 0 || b == 0) { fa[a] = fa[b] = 0; return; }
	if (~oth[a] && ~oth[b]) {
		if ((oth[a] = getfa(oth[a])) == b) { fa[a] = fa[b] = 0; return; }
		if ((oth[b] = getfa(oth[b])) == a) { fa[b] = fa[a] = 0; return; }
	}
	fa[a] = b;
	if (~oth[a] && ~oth[b]) fa[oth[a]] = oth[b];
	else if (~oth[a]) oth[b] = oth[a];
}
bool dfs(int idx, int col = 1) {
	if (idx == -1) return true;
	if (!flag[idx = getfa(idx)]) return false;
	if (!vis[idx]) return true;
	if (colors[idx]) return flag[idx] = colors[idx] == col;
	colors[idx] = col;
	return flag[idx] = dfs(oth[idx], col ^ 3);
}

int main() {
	fre(tribool);
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	std::cout.tie(nullptr);
	std::cin >> c >> t;
	while (t--) {
		ans = 0;
		std::cin >> n >> m;
		for (int i = 1; i <= n; ++i) fa[i] = fa[i + n] = i, oth[i] = oth[i + n] = -1;
		fa[(n << 1) | 1] = (n << 1) + 1, fa[(n << 1) + 2] = (n << 1) + 2, fa[(n << 1) + 3] = 0;
		oth[(n << 1) | 1] = oth[(n << 1) + 2] = oth[(n << 1) + 3] = -1;
		for (int i = 0; i != m; ++i) {
			std::cin >> op >> fr, to = 0;
			switch (op) {
			case 'T':
				to = n + 1;
				break;
			case 'F':
				to = n + 2;
				break;
			case 'U':
				to = n + 3;
				break;
			default:
				std::cin >> to;
				break;
			}
			setval(fr + n, to + n, op == '-');
		}

		for (int i = 1, j; i <= n; ++i) {
			j = getfa(i);
			if (fa[i + n] >> 31) continue;
			if (j != getfa(i + n))
				if (j && getfa(i + n))
					mge1(fa[i + n], fa[j]);
				else
					fa[j] = fa[getfa(i + n)] = 0;
		}
		__builtin_memset(colors + 1, 0x00, n);
		__builtin_memset(vis    + 1, 0x00, n);
		__builtin_memset(flag   + 1, 0x01, n);
		flag[(n << 1) + 1] = 1;
		flag[(n << 1) + 2] = 1;
		flag[(n << 1) + 3] = 1;
		for (int i = 1, j; i <= n; ++i) {
			j = getfa(i);
			if (fa[i + n] >> 31)
				mge(getfa(fa[i + n] ^ 1 << 31), j);
		}
		for (int i = 1; i <= n; ++i)
			vis[getfa(i)] = true;
		for (int i = 1; i <= n; ++i)
			if (vis[i] && flag[i]) {
				dfs(i);
				if (flag[i])
					for (int j = i; vis[j] && ~j; j = oth[j])
						vis[j] = false;
			}

		for (int i = 1; i <= n; ++i)
			if (!flag[getfa(i)]) ++ans;
		std::cout << ans << '\n';
	}
	return 0;
}
