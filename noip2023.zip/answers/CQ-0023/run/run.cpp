#include <bits/stdc++.h>
using namespace std;
#define ll long long
const int MAXM = 1e5;
int c, t, n, m, k, d, tot;
ll dp[1005][1005], calc[1005][1005], a[MAXM+5];
vector<pair<int, int> > v[1005];
/*
struct e{
    int l, r, u;
}a[MAXM+5];
bool cmp(e x, e y) {
    return x.l<y.l;
}
*/
ll dfs(int i, int u) {
    if (i==n+1) return 0;
    if (u>k) return 0;
    if (dp[i][u]!=-1) return dp[i][u];
    return dp[i][u]=max(dfs(i+1, u+1)-d, dfs(i+1, 0))+calc[i][u];
}
int main() {
    freopen("run.in", "r", stdin);
    freopen("run.out", "w", stdout);
    scanf("%d %d", &c, &t);
    for (int zqw=1;zqw<=t;zqw++) {
        tot = 0;
        scanf("%d %d %d %d", &n, &m, &k, &d);
        if (n<=1000) {
            for (int p=1;p<=n;p++) {
                v[p].clear();
            }
        }
        for (int p=1;p<=m;p++) {
            int x, y, u;
            scanf("%d %d %d", &x, &y, &u);
            if (y<=k) a[++tot] = u-1ll*y*d;
            if (n<=1000) v[x].push_back({y, u});
        }
        if (n<=1000) {
            for (int p=1;p<=n;p++) {
                stable_sort(v[p].begin(), v[p].end());
            }
            for (int p=1;p<=n;p++) {
                int i = 0;
                ll u = 0;
                for (int j=0;j<=n;j++) {
                    while (i<v[p].size()&&j>=v[p][i].first) {
                        u+=v[p][i].second;
                        i++;
                    }
                    calc[p][j] = u;
                }
            }
            memset(dp, -1, sizeof(dp));
            printf("%lld\n", max(dfs(1, 0), dfs(1, 1)-d));
        }
        else {
            ll ans = 0;
            for (int p=1;p<=tot;p++) {
                if (a[p]>0) ans+=a[p];
            }
            printf("%lld\n", ans);
        }
    }
    return 0;
}