#include <bits/stdc++.h>
using namespace std;
int n, m, keg[35];
char a[3005][3005], b[3005][3005];
int main() {
    freopen("dict.in", "r", stdin);
    freopen("dict.out", "w", stdout);
    scanf("%d %d", &n, &m);
    for (int p=1;p<=n;p++) {
        for (int k=0;k<=30;k++) {
            keg[k] = 0;
        }
        for (int k=1;k<=m;k++) {
            char i;
            cin>>i;
            keg[i-'a']++;
        }
        int tot = 0;
        for (int i=0;i<=30;i++) {
            for (int j=1;j<=keg[i];j++) {
                a[p][++tot] = i+'a';
            }
        }
        tot = 0;
        for (int i=30;i>=1;i--) {
            for (int j=1;j<=keg[i];j++) {
                b[p][++tot] = i+'a';
            }
        }
    }
    int MIN = 1;
    for (int p=2;p<=n;p++) {
        for (int k=1;k<=m;k++) {
            if (b[MIN][k]>b[p][k]) {
                MIN = p;
                break;
            }
            if (b[MIN][k]<b[p][k]) break;
        }
    }
    for (int p=1;p<=n;p++) {
        bool flag = 1;
        for (int k=1;k<=m;k++) {
            if (b[MIN][k]>a[p][k]) break;
            if (b[MIN][k]<a[p][k]) {
                flag = 0;
                break;
            }
        }
        if (!flag) putchar('0');
        else putchar('1');
    }
    return 0;
}
