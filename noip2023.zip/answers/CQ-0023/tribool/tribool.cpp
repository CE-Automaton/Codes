#include <bits/stdc++.h>
using namespace std;
const int MAXN = 1e5+5;
int c, t, n, m, T = 100001, F = 100002, U = 100003;
int from[MAXN+5];
bool flag[MAXN+5], vis[MAXN+5];
multiset<int> s[MAXN+5];
int dfs(int i) {
    if (vis[i]) return 0;
    vis[i] = 1;
    int ans = 1;
    for (auto p:s[i]) {
        ans+=dfs(p);
    }
    return ans;
}
int num;
bool f, col[MAXN+5];
void df(int i, bool u, int last) {
    if (vis[i]) {
        if (u!=col[i]) f = 1;
        return ;
    }
    vis[i] = 1;
    num++;
    col[i] = u;
    if (from[i]!=last) df(from[i], u^flag[i], i);
    for (auto p:s[i]) {
        if (p!=last) df(p, u^flag[p], i);
    }
    return ;
}
int main() {
    freopen("tribool.in", "r", stdin);
    freopen("tribool.out", "w", stdout);
    scanf("%d %d", &c, &t);
    for (int zqw=1;zqw<=t;zqw++) {
        scanf("%d %d", &n, &m);
        for (int p=1;p<=n;p++) {
            s[p].clear();
            s[p].insert(p);
            from[p] = p;
            flag[p] = vis[p] = col[p] = 0;
        }
        s[T].clear();
        s[T].insert(T);
        from[T] = T;
        flag[T] = vis[T] = col[T] = 0;
        s[F].clear();
        s[F].insert(F);
        from[F] = F;
        flag[F] = vis[F] = col[F] = 0;
        s[U].clear();
        s[U].insert(U);
        from[U] = U;
        flag[U] = vis[U] = col[U] = 0;
        for (int p=1;p<=m;p++) {
            char op;
            cin>>op;
            if (op=='T') {
                int i;
                scanf("%d", &i);
                s[from[i]].erase(i);
                from[i] = T;
                flag[i] = 0;
                s[T].insert(i);
            }
            else if (op=='F') {
                int i;
                scanf("%d", &i);
                s[from[i]].erase(i);
                from[i] = F;
                flag[i] = 0;
                s[F].insert(i);
            }
            else if (op=='U') {
                int i;
                scanf("%d", &i);
                s[from[i]].erase(i);
                from[i] = U;
                flag[i] = 0;
                s[U].insert(i);
            }
            else if (op=='+') {
                int i, j;
                scanf("%d %d", &i, &j);
                s[from[i]].erase(i);
                from[i] = from[j];
                flag[i] = flag[j];
                s[from[j]].insert(i);
            }
            else {
                int i, j;
                scanf("%d %d", &i, &j);
                s[from[i]].erase(i);
                from[i] = from[j];
                flag[i] = !flag[j];
                s[from[j]].insert(i);
            }
        }
        int ans = dfs(U);
        for (int p=1;p<=n;p++) {
            if (from[p]==p) {
                if (flag[p]) ans+=dfs(p);
            }
        }
        for (int p=1;p<=n;p++) {
            if (!vis[p]) {
                num = 0;
                f = 0;
                df(p, 0, 0);
                if (f) ans+=num;
            }
        }
        printf("%d\n", ans-1);
    }
    return 0;
}