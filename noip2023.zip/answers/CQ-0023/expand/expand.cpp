#include <bits/stdc++.h>
using namespace std;
inline int read() {
    char i;
    int ans;
    while (i=getchar(), i<'0'||i>'9');
    ans = i-'0';
    while (i=getchar(), i>='0'&&i<='9') {
        ans*=10;
        ans+=i-'0';
    }
    return ans;
}
const int MAXN = 5e5;
int c, n, m, q, a[MAXN+5], b[MAXN+5], A[MAXN+5], B[MAXN+5], dp[2005][2005], lsh[4*MAXN+5], len;
int MINA[MAXN+5], MAXA[MAXN+5], MINB[MAXN+5], MAXB[MAXN+5], f[4*MAXN+5], g[4*MAXN+5];
/*
int f(int l, int r, int x) {
    if (l==r) return l;
    int mid = (l+r)/2;
    if (MAXB[mid]>x) return f(l, mid, x);
    else return f(mid+1, r, x);
}
int g(int l, int r, int x) {
    if (l==r) return l;
    int mid = (l+r)/2;
    if (MINA[mid]<x) return g(l, mid, x);
    else return g(mid+1, r, x);
}
*/
bool dfs(int i, int j, bool flag) {
    if (!flag) {
        if (i==1) return 1;
        int u = f[MAXA[i-1]];
        if (u>=j) return 0;
        return dfs(i, u, 1);
    }
    else {
        if (j==1) return 1;
        int u = g[MINB[j-1]];
        if (u>=i) return 0;
        return dfs(u, j, 0);
    }
}
vector<pair<int, int> > TA[MAXN+5], TB[MAXN+5];
int main() {
    freopen("expand.in", "r", stdin);
    freopen("expand.out", "w", stdout);
    scanf("%d %d %d %d", &c, &n, &m, &q);
    for (int p=1;p<=n;p++) {
        A[p] = read();
        lsh[++len] = A[p];
    }
    for (int p=1;p<=m;p++) {
        B[p] = read();
        lsh[++len] = B[p];
    }
    if (c<=7) {
        for (int p=1;p<=n;p++) {
            a[p] = A[p];
        }
        for (int p=1;p<=m;p++) {
            b[p] = B[p];
        }
        if (a[1]<b[1]) {
            dp[1][1] = 1;
            for (int i=1;i<=n;i++) {
                for (int j=1;j<=m;j++) {
                    if (i==1&&j==1) continue;
                    if (a[i]<b[j]) dp[i][j] = ((dp[i-1][j]|dp[i-1][j-1])|dp[i][j-1]);
                    else dp[i][j] = 0;
                }
            }
            if (dp[n][m]) putchar('1');
            else putchar('0');
        }
        else if (a[1]>b[1]) {
            dp[1][1] = 1;
            for (int i=1;i<=n;i++) {
                for (int j=1;j<=m;j++) {
                    if (i==1&&j==1) continue;
                    if (a[i]>b[j]) dp[i][j] = ((dp[i-1][j]|dp[i-1][j-1])|dp[i][j-1]);
                    else dp[i][j] = 0;
                }
            }
            if (dp[n][m]) putchar('1');
            else putchar('0');
        }
        else putchar('0');
        for (int zqw=1;zqw<=q;zqw++) {
            for (int p=1;p<=n;p++) {
                a[p] = A[p];
            }
            for (int p=1;p<=m;p++) {
                b[p] = B[p];
            }
            int len1, len2;
            len1 = read(), len2 = read();
            for (int p=1;p<=len1;p++) {
                int i, x;
                i = read(), x = read();
                a[i] = x;
            }
            for (int p=1;p<=len2;p++) {
                int i, x;
                i = read(), x = read();
                b[i] = x;
            }
            if (a[1]<b[1]) {
                dp[1][1] = 1;
                for (int i=1;i<=n;i++) {
                    for (int j=1;j<=m;j++) {
                        if (i==1&&j==1) continue;
                        if (a[i]<b[j]) dp[i][j] = ((dp[i-1][j]|dp[i-1][j-1])|dp[i][j-1]);
                        else dp[i][j] = 0;
                    }
                }
                if (dp[n][m]) putchar('1');
                else putchar('0');
            }
            else if (a[1]>b[1]) {
                dp[1][1] = 1;
                for (int i=1;i<=n;i++) {
                    for (int j=1;j<=m;j++) {
                        if (i==1&&j==1) continue;
                        if (a[i]>b[j]) dp[i][j] = ((dp[i-1][j]|dp[i-1][j-1])|dp[i][j-1]);
                        else dp[i][j] = 0;
                    }
                }
                if (dp[n][m]) putchar('1');
                else putchar('0');
            }
            else putchar('0');
        }
    }
    else {
        for (int zqw=1;zqw<=q;zqw++) {
            int len1, len2;
            len1 = read(), len2 = read();
            for (int p=1;p<=len1;p++) {
                int i, x;
                i = read(), x = read();
                TA[zqw].push_back({i, x});
                lsh[++len] = x;
            }
            for (int p=1;p<=len2;p++) {
                int i, x;
                i = read(), x = read();
                TB[zqw].push_back({i, x});
                lsh[++len] = x;
            }
        }
        stable_sort(lsh+1, lsh+len+1);
        len = unique(lsh+1, lsh+len+1)-lsh-1;
        for (int p=1;p<=n;p++) {
            A[p] = lower_bound(lsh+1, lsh+len+1, A[p])-lsh;
        }
        for (int p=1;p<=m;p++) {
            B[p] = lower_bound(lsh+1, lsh+len+1, B[p])-lsh;
        }
        for (int p=1;p<=n;p++) {
            a[p] = A[p];
        }
        for (int p=1;p<=m;p++) {
            b[p] = B[p];
        }
        MINA[0] = MINB[0] = len+1;
        MAXA[n+1] = MAXB[m+1] = len+1;
        for (int p=1;p<=n;p++) {
            MINA[p] = min(MINA[p-1], a[p]);
            MAXA[p] = max(MAXA[p-1], a[p]);
        }
        for (int p=1;p<=m;p++) {
            MINB[p] = min(MINB[p-1], b[p]);
            MAXB[p] = max(MAXB[p-1], b[p]);
        }
        for (int p=1;p<=n+1;p++) {
            for (int i=MINA[p-1]-1;i>=MINA[p];i--) {
                g[i] = p;
            }
        }
        for (int p=1;p<=m+1;p++) {
            for (int i=MAXB[p-1]+1;i<=MAXB[p];i++) {
                f[i] = p;
            }
        }
        if (dfs(n, m, 0)||dfs(n, m, 1)) putchar('1');
        else putchar('0');
        for (int zqw=1;zqw<=q;zqw++) {
            for (int p=1;p<=n;p++) {
                a[p] = A[p];
            }
            for (int p=1;p<=m;p++) {
                b[p] = B[p];
            }
            for (int p=0;p<TA[zqw].size();p++) {
                a[TA[zqw][p].first] = lower_bound(lsh+1, lsh+len+1, TA[zqw][p].second)-lsh;
            }
            for (int p=0;p<TB[zqw].size();p++) {
                b[TB[zqw][p].first] = lower_bound(lsh+1, lsh+len+1, TB[zqw][p].second)-lsh;
            }
            MINA[0] = MINB[0] = len+1;
            MAXA[n+1] = MAXB[m+1] = len+1;
            for (int p=1;p<=n;p++) {
                MINA[p] = min(MINA[p-1], a[p]);
                MAXA[p] = max(MAXA[p-1], a[p]);
            }
            for (int p=1;p<=m;p++) {
                MINB[p] = min(MINB[p-1], b[p]);
                MAXB[p] = max(MAXB[p-1], b[p]);
            }
            for (int p=1;p<=n+1;p++) {
                for (int i=MINA[p-1]-1;i>=MINA[p];i--) {
                    g[i] = p;
                }
            }
            for (int p=1;p<=m+1;p++) {
                for (int i=MAXB[p-1]+1;i<=MAXB[p];i++) {
                    f[i] = p;
                }
            }
            if (dfs(n, m, 0)||dfs(n, m, 1)) putchar('1');
            else putchar('0');
        }
    }
    return 0;
}