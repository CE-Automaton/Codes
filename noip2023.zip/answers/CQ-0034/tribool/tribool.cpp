#include<bits/stdc++.h>
using namespace std;
int fa[200011];
int find(int x) {return fa[x] == x ? x : fa[x] = find(fa[x]);}
void Merge(int x,int y)
{
	x = find(x),y = find(y);
	fa[y] = x;
}
int op[200011];
int c,T,n,m,cnt;
char opt;
int x,y;
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	cin >> c >> T;
	while(T--)
	{
		cin >> n >> m;
		cnt = n + 2;
		for(int i = 1;i <= 2 * cnt;i++) fa[i] = i;
		Merge(cnt,cnt + cnt);
		for(int i = 1;i <= cnt;i++) op[i] = i;
		while(m--)
		{
			cin >> opt >> x;
			if(opt == 'T')
			{
				op[x] = n + 1;
			}else if(opt == 'F')
			{
				op[x] = cnt + n + 1;
			}else if(opt == 'U')
			{
				op[x] = cnt;
			}else if(opt == '+')
			{
				cin >> y;
				op[x] = op[y];
			}else if(opt == '-')
			{
				cin >> y;
				op[x] = op[y] + (op[y] > cnt ? -cnt : cnt);
			}
		}
		for(int i = 1;i <= n;i++) Merge(i,op[i]),Merge(i + cnt,op[i] + (op[i] > cnt ? -cnt : cnt));
		int ans = 0;
		for(int i = 1;i <= n;i++) if(find(i) == find(cnt + i)) ans++;
		cout << ans << "\n";
	}
	return 0;
}
//��չ�򲢲鼯������ôд�ˣ�����Ī�������ܹ������������ˣ������ˣ������������ˣ���˵�԰�
