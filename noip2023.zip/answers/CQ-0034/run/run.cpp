#include<bits/stdc++.h>
using namespace std;
typedef struct{
	long long mx,tag;
}Tree;
Tree t[800011];
inline void Add(int p,long long k)
{
	t[p].mx += k,t[p].tag += k;
}
inline void push_down(int p)
{
	Add(p<<1,t[p].tag),Add(p<<1|1,t[p].tag),t[p].tag = 0;
}
inline void push_up(int p)
{
	t[p].mx = max(t[p<<1].mx,t[p<<1|1].mx);
}
int h[200011],a[200011],cnt;
void add(int p,int ll,int rr,int l,int r,long long k)
{
	if(l <= ll && rr <= r) return Add(p,k);
	int mid = ll + rr >> 1;
	push_down(p);
	if(l <= mid) add(p<<1,ll,mid,l,r,k);
	if(mid < r) add(p<<1|1,mid+1,rr,l,r,k);
	push_up(p);
}
int findl(int x)
{
	int l = 1,r = cnt,mid,res;
	while(l <= r)
	{
		mid = l + r >> 1;
		if(a[mid] >= x) res = mid,r = mid - 1;
		else l = mid + 1;
	}
	return res;
}
int tid,T,n,m,k;
long long d;
int l[100011],r[100011],w[100011];
vector<pair<int,int> > v[200011];
long long pre[200011];
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	cin >> tid >> T;
	while(T--)
	{
		memset(t,0,sizeof(t));
		cin >> n >> m >> k >> d;
		for(int i = 1;i <= m;i++)
		{
			int x,y;
			cin >> x >> y >> w[i];
			l[i] = x - y + 1,r[i] = x;
			h[2 * i - 1] = l[i],h[2 * i] = r[i];
		}
		sort(h + 1,h + 2 * m + 1);
		cnt = 0;
		for(int i = 1;i <= 2 * m;i++)
			if(h[i] > h[i - 1]) a[++cnt] = h[i];
		for(int i = 1;i <= cnt;i++)
			v[i].clear();
		for(int i = 1;i <= m;i++)
		{
			if(r[i] - l[i] + 1 <= k)
				v[findl(r[i])].push_back({findl(l[i]),w[i]});
		}
		a[0] = -10;
		for(int i = 1;i <= cnt;i++)
		{
			if(a[i - 1] < a[i] - 1)
				add(1,1,cnt,i,i,pre[i - 1]);
			else
				add(1,1,cnt,i,i,pre[i - 2]);
			if(i > 1)
				add(1,1,cnt,1,i - 1,-(d * (a[i] - a[i - 1])));
			add(1,1,cnt,i,i,-d);
			for(auto x:v[i])
				add(1,1,cnt,findl(a[i] - k + 1),x.first,x.second);
			pre[i] = max(pre[i - 1],t[1].mx);
		}
		cout << pre[cnt] << "\n";
	}
	return 0;
}
//û��long long�����죬��д�˸�8pts���� 
