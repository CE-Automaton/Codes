#include<bits/stdc++.h>
using namespace std;
char c[3011];
int suf[3011],pre[3011],mx[3011],mn[3011];
int a[3011];
int n,m;
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	cin >> n >> m;
	for(int i = 1;i <= n;i++)
	{
		cin >> (c + 1);
		for(int j = 1;j <= m;j++) a[j] = (c[j] - 'a' + 1);
		mx[i] = 0,mn[i] = 27;
		for(int j = 1;j <= m;j++)
			mx[i] = max(mx[i],a[j]),mn[i] = min(mn[i],a[j]);
	}
	pre[0] = 27;
	for(int i = 1;i <= n;i++) pre[i] = min(pre[i - 1],mx[i]);
	suf[n + 1] = 27;
	for(int i = n;i;i--) suf[i] = min(suf[i + 1],mx[i]);
	for(int i = 1;i <= n;i++)
		cout << (min(pre[i - 1],suf[i + 1]) > mn[i] ? 1 : 0);
	return 0;
}
//����Ҫ����ַ��������ı�����ַ�����С�Ĵ����
