#include<bits/stdc++.h>
using namespace std;
int tid,n,m,q;
int a[500011],b[500011];
int x[500011],y[500011];
bool f[2011][2011];
inline void BF()
{
	if(x[1] > y[1])
	{
		memset(f,0,sizeof(f));
		f[1][1] = 1;
		for(int i = 1;i <= n;i++)
		{
			for(int j = 1;j <= m;j++)
			{
				if(!f[i][j]) continue;
				if(j < m && x[i] > y[j + 1]) f[i][j + 1] = 1;
				if(i < n && x[i + 1] > y[j]) f[i + 1][j] = 1;
			}
		}
		if(f[n][m])
		{
			cout << 1;
			return;
		}
	}
	if(x[1] < y[1])
	{
		memset(f,0,sizeof(f));
		f[1][1] = 1;
		for(int i = 1;i <= n;i++)
		{
			for(int j = 1;j <= m;j++)
			{
				if(!f[i][j]) continue;
				if(j < m && x[i] < y[j + 1]) f[i][j + 1] = 1;
				if(i < n && x[i + 1] < y[j]) f[i + 1][j] = 1;
			}
		}
		if(f[n][m])
		{
			cout << 1;
			return;
		}
	}
	cout << 0;
	return;
}
inline void Solve()
{
	if(tid <= 7) return BF();
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	cin >> tid >> n >> m >> q;
	for(int i = 1;i <= n;i++) cin >> a[i];
	for(int i = 1;i <= m;i++) cin >> b[i];
	memcpy(x,a,sizeof(x)),memcpy(y,b,sizeof(y));
	Solve();
	while(q--)
	{
		memcpy(x,a,sizeof(x)),memcpy(y,b,sizeof(y));
		int mx,my,pl,val;
		cin >> mx >> my;
		while(mx--)
		{
			cin >> pl >> val;
			x[pl] = val;
		}
		while(my--)
		{
			cin >> pl >> val;
			y[pl] = val;
		}
		Solve();
	}
	return 0;
}
//ƴ��35pts���о���Сʱд�������ˣ����Ǽ���
