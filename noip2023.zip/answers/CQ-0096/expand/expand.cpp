#include<bits/stdc++.h>
using namespace std;
const int N=5e5+5;
int Case,n,m,q;
int x[N],y[N],a[N],b[N];
namespace Sub1{
	bool f[2005][2005];
	inline bool Solve(){
		memset(f,0,sizeof(f));
		f[1][1]=1;
		bool tag=a[1]<b[1];
		if(a[1]==b[1])return false;
		for(int i=1;i<=n;++i){
			for(int j=1;j<=m;++j){
				if(f[i][j]){
					if(a[i+1]!=b[j]&&(a[i+1]<b[j])==tag)f[i+1][j]=1;
					if(a[i]!=b[j+1]&&(a[i]<b[j+1])==tag)f[i][j+1]=1;
					if(a[i+1]!=b[j+1]&&(a[i+1]<b[j+1])==tag)f[i+1][j+1]=1;
				}
			}
		}return f[n][m];
	}
	inline void main(){
		for(int i=1;i<=n;++i)a[i]=x[i];
		for(int i=1;i<=m;++i)b[i]=y[i];
		cout<<Solve();
		while(q--){
			for(int i=1;i<=n;++i)a[i]=x[i];
			for(int i=1;i<=m;++i)b[i]=y[i];
			int k1,k2;
			cin>>k1>>k2;
			for(int i=1,p,v;i<=k1;++i)cin>>p>>v,a[p]=v;
			for(int i=1,p,v;i<=k2;++i)cin>>p>>v,b[p]=v;
			cout<<Solve();
		}
	}
} 
signed main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	std::ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	cin>>Case>>n>>m>>q;
	for(int i=1;i<=n;++i)cin>>x[i];
	for(int i=1;i<=m;++i)cin>>y[i];
	if(n<=2000&&m<=2000)Sub1::main(),exit(0);
	else{
		for(int i=1;i<=n;++i)a[i]=x[i];
		for(int i=1;i<=m;++i)b[i]=y[i];
		int Mn1=2e9,Mn2=2e9,Mx1=0,Mx2=0;
		for(int i=1;i<=n;++i)Mx1=max(Mx1,a[i]),Mn1=min(Mn1,a[i]);
		for(int i=1;i<=m;++i)Mx2=max(Mx2,b[i]),Mn2=min(Mn2,b[i]);
		if(a[1]==b[1]||a[n]==b[m])cout<<0;
		else if(a[1]<b[1])cout<<(Mx2>Mx1&&Mn2>Mn1);
		else cout<<(Mx2<Mx1&&Mn2<Mn1);
		while(q--){
			for(int i=1;i<=n;++i)a[i]=x[i];
			for(int i=1;i<=m;++i)b[i]=y[i];
			int k1,k2;
			cin>>k1>>k2;
			for(int i=1,p,v;i<=k1;++i)cin>>p>>v,a[p]=v;
			for(int i=1,p,v;i<=k2;++i)cin>>p>>v,b[p]=v;
			int Mn1=2e9,Mn2=2e9,Mx1=0,Mx2=0;
			for(int i=1;i<=n;++i)Mx1=max(Mx1,a[i]),Mn1=min(Mn1,a[i]);
			for(int i=1;i<=m;++i)Mx2=max(Mx2,b[i]),Mn2=min(Mn2,b[i]);
			if(a[1]==b[1]||a[n]==b[m])cout<<0;
			else if(a[1]<b[1])cout<<(Mx2>Mx1&&Mn2>Mn1);
			else cout<<(Mx2<Mx1&&Mn2<Mn1);
		}
	}
	return 0;
}
/*
�������ѯ��һ�ۼٵģ�����ֱ��ÿ����һ�ξ��У�������Ϊ�˿�˫log 
������������һ������ fi=gi�Ŀ���ֱ������һ��������ֻ��n+m�ĳ��� 
Ϊ����ֻ��nm�������������� 
*/
