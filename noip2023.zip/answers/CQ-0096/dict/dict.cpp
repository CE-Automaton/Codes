#include<bits/stdc++.h>
using namespace std;
const int N=3005;
int n,m;
int Cnt[N][26],Ans[N],l[N],r[N];
signed main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	std::ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	cin>>n>>m;
	for(int i=1;i<=n;++i){
		for(int j=1;j<=m;++j){
			char ch;
			cin>>ch;
			++Cnt[i][ch-'a'];
		}
	}
	for(int i=1;i<=n;++i){
		for(int j=0;j<26;++j)if(Cnt[i][j]){l[i]=j;break;}
		for(int j=25;j>=0;--j)if(Cnt[i][j]){r[i]=j;break;}
	}
	for(int i=1;i<=n;++i){
		bool fl=true;
		for(int j=1;j<=n;++j){
			if(i==j)continue;
			if(l[i]>=r[j]){fl=false;break;}			
		}
		Ans[i]=fl;
	}
	for(int i=1;i<=n;++i)cout<<Ans[i];
	return 0;
}
