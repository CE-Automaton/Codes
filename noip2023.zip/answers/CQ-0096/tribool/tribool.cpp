#include<bits/stdc++.h>
using namespace std;
const int N=4e5+5;
int n,m;
int fro[N],tag[N],a[N],prt[N];
int gf(int x){return prt[x]==x?x:prt[x]=gf(prt[x]);}
inline void merge(int x,int y){x=gf(x),y=gf(y),prt[y]=x,tag[x]|=tag[y];}
signed main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	std::ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	int Case,t;
	cin>>Case>>t;
	while(t--){
		memset(fro,0,sizeof(fro)),memset(tag,0,sizeof(tag)),memset(a,0,sizeof(a)),memset(prt,0,sizeof(prt));
		cin>>n>>m;
		for(int i=1;i<=n;++i)fro[i*2-1]=i*2-1,fro[i*2]=i*2,a[i]=i;
		int tot=n;
		for(int op=1;op<=m;++op){
			char ch;int x,y;
			cin>>ch;
			if(ch=='T'||ch=='F'||ch=='U'){
				cin>>x;
				a[x]=++tot,fro[tot*2-1]=tot*2-1,fro[tot*2]=tot*2;
				if(ch=='T')tag[tot*2-1]=1,tag[tot*2]=2;
				else if(ch=='F')tag[tot*2-1]=2,tag[tot*2]=1;
				else if(ch=='U')tag[tot*2-1]=tag[tot*2]=3;
			}else if(ch=='+'){
				cin>>x>>y;
				++tot;
				fro[tot*2-1]=fro[a[y]*2-1],fro[tot*2]=fro[a[y]*2];
				tag[tot*2-1]=tag[a[y]*2-1],tag[tot*2]=tag[a[y]*2];
				a[x]=tot;
			}else{
				cin>>x>>y;
				++tot;
				fro[tot*2-1]=fro[a[y]*2],fro[tot*2]=fro[a[y]*2-1];
				tag[tot*2-1]=tag[a[y]*2],tag[tot*2]=tag[a[y]*2-1];
				a[x]=tot;
			}
		}
		for(int i=1;i<=tot;++i)prt[i*2-1]=i*2-1,prt[i*2]=i*2;
		for(int i=1;i<=n;++i){
			merge(i*2-1,a[i]*2-1);
			merge(i*2,a[i]*2);
			merge(a[i]*2-1,fro[a[i]*2-1]);
			merge(a[i]*2,fro[a[i]*2]);
		}
		int Ans=0;
		for(int i=1;i<=n;++i)if(gf(i*2-1)==gf(i*2)||tag[gf(i*2-1)]==3||tag[gf(i*2)]==3)++Ans;
		cout<<Ans<<"\n";
	}	
	return 0;
}

