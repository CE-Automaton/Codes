#include<bits/stdc++.h>
#define fi first
#define se second
using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
const int N=2e5+5;
const ll Inf=2e18;
int n,m,k,d;
ll Mx[N];
vector<pii>v[N];
int Case,T;
namespace Sub1{
	struct tree{int l,r;ll Mx,tag;}t[N*4];
	#define lt p<<1
	#define rt p<<1|1
	inline void pushup(int p){t[p].Mx=max(t[lt].Mx,t[rt].Mx);}
	inline void updata(int p,ll d){t[p].tag+=d,t[p].Mx+=d;}
	inline void pushdown(int p){if(t[p].tag)updata(lt,t[p].tag),updata(rt,t[p].tag),t[p].tag=0;}
	void build(int p,int l,int r){
		t[p]=(tree){l,r,-Inf,0};
		if(l==r)return;
		int mid=(l+r)>>1;
		build(lt,l,mid),build(rt,mid+1,r);
	}
	void Add(int p,int l,int r,ll d){
		if(l>r)return;
		if(l<=t[p].l&&t[p].r<=r)return updata(p,d),void();
		int mid=(t[p].l+t[p].r)>>1;pushdown(p);
		if(l<=mid)Add(lt,l,r,d);
		if(r>mid)Add(rt,l,r,d);
		pushup(p);
	}
	void insert(int p,int x,ll d){
		if(t[p].l==t[p].r)return t[p].Mx=max(t[p].Mx,d),void();
		int mid=(t[p].l+t[p].r)>>1;pushdown(p);
		if(x<=mid)insert(lt,x,d);
		else insert(rt,x,d);
		pushup(p);
	}
	ll ask(int p,int l,int r){
		if(l<=t[p].l&&t[p].r<=r)return t[p].Mx;
		int mid=(t[p].l+t[p].r)>>1;ll Mx=-Inf;pushdown(p);
		if(l<=mid)Mx=max(Mx,ask(lt,l,r));
		if(r>mid)Mx=max(Mx,ask(rt,l,r));
		return Mx;
	}
	inline void main(){
		while(T--){
			cin>>n>>m>>k>>d;
			memset(Mx,0,sizeof(Mx));
			for(int i=1;i<=n;++i)v[i].clear();
			for(int i=1,x,y,z;i<=m;++i){
				cin>>x>>y>>z;
				if(y<=k)v[x].push_back(pii(y,z));
			}
			build(1,1,n*2);
			int L=1,R=1;
			ll S=0;
			sort(v[1].begin(),v[1].end()),insert(1,1,-d),Mx[1]=max(Mx[1],S-d);
			for(pii i:v[1]){
				S+=i.se;
				if(i.fi==1)insert(1,1,S-d),Mx[1]=max(Mx[1],S-d);
			}
			for(int i=2;i<=n;++i){
				int nl,nr;
				if(R-L+1==k)nl=L+1,nr=R+1;
				else nl=L,nr=R+1;
				sort(v[i].begin(),v[i].end());
				Add(1,nl,nr,-d);
				for(pii j:v[i]){
					if(i-j.fi+1<=0)break;
					Add(1,nl,nr-j.fi+1,j.se);
				}
				ll Res=0;
				insert(1,nr,Mx[i-2]-d);
				for(pii j:v[i]){
					if(i-j.fi+1<=0)break;
					Res+=j.se,insert(1,nr-j.fi+1,Mx[i-j.fi-1]-1ll*d*j.fi+Res);
				}
				L=nl,R=nr,Mx[i]=max(Mx[i-1],max(Mx[i],ask(1,L,R)));
			}
			cout<<Mx[n]<<"\n";
		}
	}
}
signed main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	std::ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	cin>>Case>>T;
	if(Case<=14)Sub1::main();
	return 0;
}
