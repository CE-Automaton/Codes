#include<bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; ++i)
#define Rof(i, j, k) for (int i = j; i >= k; --i)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define pb push_back
#define SZ(x) int(x.size())

using namespace std;
using pii = pair<int, int>;
using ull = unsigned long long;
using i64 = long long;

inline int read() {
    int x = 0, f = 0; char ch = getchar();
    while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
    while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
    return f ? -x : x;
}

const int N = 4e5 + 100;

int type, T, n, m, now[N], num;
int head[N], nxt[N << 1], to[N << 1], w[N << 1], cnt;
void add(int u, int v, int c) {
    to[++cnt] = v, w[cnt] = c, nxt[cnt] = head[u], head[u] = cnt;
    to[++cnt] = u, w[cnt] = c, nxt[cnt] = head[v], head[v] = cnt; 
}

int op[N]; vector<int> ve;

pii merge(pii x, pii y) { return {x.first & y.first, x.second + y.second}; }
pii dfs(int u) {
    pii ans = pii(1, u <= n && op[u] == 0);
    ve.push_back(u);
    Eor(u) if (op[to[i]] == -2) {
        op[to[i]] = op[u] * w[i];
        ans = merge(ans, dfs(to[i]));
    } else if (op[u] * w[i] != op[to[i]]) ans.first = 0;
    return ans;
}
void solve() {
    n = read(), m = read();

    For(i, 1, n + m + 3) head[i] = 0;
    For(i, 1, n) now[i] = i;
    cnt = 0, num = n + 3;

    For(i, 1, m) { char c; cin >> c;
        if (c == 'T') add(n + 1, now[read()] = ++num, 1);
        if (c == 'F') add(n + 2, now[read()] = ++num, 1);
        if (c == 'U') add(n + 3, now[read()] = ++num, 1);
        if (c == '+' || c == '-') {
            int x = read(), y = read();
            add(now[y], ++num, c == '+' ? 1 : -1), now[x] = num;
        }
    }
    For(i, 1, n) add(now[i], i, 1);

    For(i, 1, num) op[i] = -2; int ans = 0;
    op[n + 1] = 1, op[n + 2] = -1, op[n + 3] = 0;
    ans += dfs(n + 1).second;
    ans += dfs(n + 2).second;
    ans += dfs(n + 3).second;

    For(i, 1, n) if (op[i] == -2) {
        int mi = n + 1, p = 0;
        For(k, -1, 1) {
            ve.clear(), op[i] = k;auto tmp = dfs(i);
            if (tmp.first && tmp.second < mi)
                mi = tmp.second, p = k;
            for (auto x : ve) op[x] = -2;
        }
        op[i] = p; auto tmp = dfs(i);
        ans += tmp.second, ve.clear();
    }
    cout << ans << '\n';
}
signed main() {
    freopen("tribool.in", "r", stdin);
    freopen("tribool.out", "w", stdout);
    type = read(), T = read(); while (T--) solve();
    return 0;
}