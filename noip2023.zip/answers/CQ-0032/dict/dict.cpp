#include<bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; ++i)
#define Rof(i, j, k) for (int i = j; i >= k; --i)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define pb push_back
#define SZ(x) int(x.size())

using namespace std;
using pii = pair<int, int>;
using ull = unsigned long long;
using i64 = long long;

inline int read() {
    int x = 0, f = 0; char ch = getchar();
    while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
    while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
    return f ? -x : x;
}

const int N = 3010;
int n, m; char s[N];
int cnt[N][26];
signed main() {
    freopen("dict.in", "r", stdin);
    freopen("dict.out", "w", stdout);
    n = read(), m = read();
    For(i, 1, n) { scanf("%s", s + 1); For(j, 1, m) ++cnt[i][s[j] - 'a']; }
    For(i, 1, n) { bool flag = 1;
        For(j, 1, n) if (j != i) {
            int p1 = 0, p2 = 25, t1 = 0, t2 = 0; bool ok = 1;
            while (p1 < 26) {
                if (p1 < 26 && t1 == cnt[i][p1]){ ++p1, t1 = 0; continue; }
                if (p2 >= 0 && t2 == cnt[j][p2]){ --p2, t2 = 0; continue; }
                if (p1 < p2) break; if (p1 > p2) { ok = 0;break;}
                int k = min(cnt[i][p1] - t1, cnt[j][p2] - t2); t1 += k, t2 += k;
            }
            if (ok == 0) { flag = 0; break; }
        } putchar(flag + '0');
    }  
    return 0;
}