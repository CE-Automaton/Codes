#include<bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; ++i)
#define Rof(i, j, k) for (int i = j; i >= k; --i)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define pb push_back
#define SZ(x) int(x.size())

using namespace std;
using pii = pair<int, int>;
using ull = unsigned long long;
using i64 = long long;

inline int read() {
    int x = 0, f = 0; char ch = getchar();
    while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
    while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
    return f ? -x : x;
}

const int N = 1e5 + 100;

int type, T, n, m, k, d; 

struct Node {
    int x, d, v;
    bool operator <(const Node &b) const {
        return x < b.x;
    }
}a[N];


namespace BL {
    i64 f[N], g[N];
    void change(int x) {  i64 ma = 0;
        For(i, 0, k) ma = max(ma, f[i]), g[i] = f[i];
        For(i, 0, k) if (x > i) f[i] = ma - i * d;
        else f[i] = g[i - x] - d * x;
    }
    void solve() {
        n = read(), m = read(), k = read(), d = read();
        For(i, 1, m) a[i] = {read(), read(), read()};
        a[++m] = {n, 0, 0}, memset(f, -0x3f, sizeof f);
        f[0] = 0, sort(a + 1, a + m + 1);

        // For(i, 0, k) cout << f[i] <<" "; cout << '\n';
        int p = 0; For(i, 1, m) {
            if (p < a[i].x) change(a[i].x - p), p = a[i].x;
            // For(j, 0, k) cout << f[j] <<" ";cout << '\n';
            For(j, a[i].d, k) f[j] += a[i].v;
            // For(j, 0, k) cout << f[j] <<" ";cout << '\n';
        }
        i64 ans = 0; For(i, 0, k) ans = max(ans, f[i]);
        cout << ans << '\n';
    }
}

// const i64 inf = 1e18 + 10;

// namespace FHQ {
//     #define ls(x) (t[x].ls)
//     #define rs(x) (t[x].rs)
//     struct node {
//         int ls, rs, rnd, l, r;
//         i64 ma, k, b, tag1, tag2;
//     }t[N << 2];
//     mt19937 R(time(0));
//     int root, num;

//     void update(int x, int d, i64 k) { 
//         if (!x) return;;t[x].b += k, t[x].tag2 += k; 
//         t[x].l += d, t[x].r += d, t[x].tag1 += d;
//     } 
//     void pushdown(int x) { 
//         update(ls(x), t[x].tag1, t[x].tag2);
//         update(rs(x), t[x].tag1, t[x].tag2);
//         t[x].tag1 = t[x].tag2 = 0; 
//     }
//     void pushup(int x) { t[x].ma = max({t[ls(x)].ma, t[rs(x)].ma, t[x].b}); }
//     int merge(int x, int y) {
//         if (!x || !y) return x | y; ; pushdown(x), pushdown(y);
//         if (t[x].rnd < t[y].rnd) return rs(x) = merge(rs(x), y), pushup(x), x;
//         return ls(y) = merge(x, ls(y)), pushup(y), y;
//     }
//     void split(int x, int k, int &a, int &b, int &c) {
//         if (!x) return a = b = c = 0, void(); ; pushdown(x);
//         if (t[x].r <= k) a = x, split(rs(x), k, rs(a), b, c);
//         else if (t[x].l <= k) b = x, split(rs(x), k, a, b, c); 
//         else c = x, split(ls(x), k, a, b, ls(c)); ;pushdown(x);
//     }
//     void Split(int x, int k, int &a, int &c, int b = 0) {
//         split(x, k, a, b, c); 
//         if (b) {
//             t[++num] = {0, 0, (int)R(), t[b].l, k, t[b].b, k, t[b].b, 0, 0};
//             a = merge(a, num);
           
//             i64 val = t[b].b + (k + 1ll - t[b].l) * t[b].k;
            
//             t[++num] = {0, 0, (int)R(), k + 1, t[b].r, val, t[b].k, val, 0, 0};
            
//             c = merge(num, c);
//         }

//     }
//     void insert(int &rt, int l, int r, i64 k, i64 bb) {
//         int a, b, c; Split(rt, l - 1, a, c, b);
//         t[++num] = {0, 0, (int)R(), l, r, bb, k, bb, 0, 0};
//         rt = merge(merge(a, num), b);
//     }
//     void change(int x) {
//         i64 ma = t[root].ma, p = k;
//         if (x <= k) { int a; p = x - 1;
//             Split(root, k - x, root, a);
//             update(root, x, -1ll * x * d);
//         }
//         t[++num] = {0, 0, (int)R(), 0, (int)p, ma, -d, ma, 0, 0};
//         root = merge(num, root);
//     }

//     void modify(int L, int R, i64 v) { int a, b, c;
//         Split(root, R, a, c), Split(a, L - 1, a, b);
//         update(b, 0, v), root = merge(merge(a, b), c);
//     }
//     void out(int x) {
//         if (!x) return;
//         out(ls(x)), pushdown(x);
//         // For(i, t[x].l, t[x].r) 
//             // cout << t[x].b + (t[x].k * (i - t[x].l)) <<" ";
//         cout << t[x].l<<" "<<t[x].r<<" "<<t[x].k<<" "<<t[x].b<<'\n';
//         out(rs(x));
//     }
// }

// void solve() {
//     n = read(), m = read(), k = read(), d = read();
//     For(i, 1, m) a[i] = {read(), read(), read()};
//     a[++m] = {n, 0, 0}, sort(a + 1, a + m + 1);
    
//     FHQ::root = 0, FHQ::num = 0;
//     FHQ::insert(FHQ::root, 0, 0, 0, 0);
//     FHQ::insert(FHQ::root, 1, k, 0, -inf);

 
//     FHQ::out(FHQ::root),         cout << "??:"<<root <<'\n';
//         cout << "Error:1\n", FHQ::out(FHQ::root), cout << '\n';

//         FHQ::modify(a[i].d, k, a[i].v);

//         cout << "Error:2\n", FHQ::out(FHQ::root), cout << '\n';

//     } cout << FHQ::t[FHQ::root].ma << '\n';
// }

signed main() {
    freopen("run.in", "r", stdin);
    freopen("run.out", "w", stdout);
    type = read(), T = read(); while (T--) BL::solve();
    return 0;
}