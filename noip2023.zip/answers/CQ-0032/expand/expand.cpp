#include<bits/stdc++.h>

#define For(i, j, k) for (int i = j; i <= k; ++i)
#define Rof(i, j, k) for (int i = j; i >= k; --i)
#define Eor(u) for (int i = head[u]; i; i = nxt[i])
#define pb push_back
#define SZ(x) int(x.size())

using namespace std;
using pii = pair<int, int>;
using ull = unsigned long long;
using i64 = long long;

inline int read() {
    int x = 0, f = 0; char ch = getchar();
    while (!isdigit(ch)) f |= (ch == '-'), ch = getchar();
    while (isdigit(ch)) x = x * 10 + ch - '0', ch = getchar();
    return f ? -x : x;
}

const int N = 5e5 + 1000;

int type, n, m, q, a[N], b[N];
int posa[N], vala[N], posb[N], valb[N];

int f[N], g[N], R[N]; bool flag = 0;

void solve() {
    if (a[1] < b[1]) swap(a, b), swap(n, m), flag = 1;
    if (a[1] <= b[1]) return putchar('0'), void();
    For(i, 1, m) f[i] = 0; f[1] = 1;
    
    For(i, 1, n) {
        R[m + 1] = m; Rof(j, m, 1) 
            R[j] = a[i] > b[j] ? R[j + 1] : j - 1;
        For(j, 0, m) g[j] = 0;
        For(j, 1, m) if (f[j]) {
            if (a[i] > b[j]) ++g[j], --g[R[j + 1] + 1];
            else ++g[j + 1], --g[R[j + 1] + 1];
        }
        For(j, 1, m) f[j] = (g[j] += g[j - 1]) > 0;
    } 
    putchar(f[m] ? '1' : '0');    
}
signed main() {
    freopen("expand.in", "r", stdin);
    freopen("expand.out", "w", stdout);
    type = read(), n = read(), m = read(), q = read();
    For(i, 1, n) a[i] = read(); For(i, 1, m) b[i] = read();
    solve(); while (q--) {
        int t1 = read(), t2 = read();
        For(i, 1, t1) posa[i] = read(), vala[i] = read();
        For(i, 1, t2) posb[i] = read(), valb[i] = read();
        For(i, 1, t1) swap(a[posa[i]], vala[i]);
        For(i, 1, t2) swap(b[posb[i]], valb[i]);
        solve();if (flag) swap(a, b), swap(n, m), flag ^= 1;
        For(i, 1, t1) swap(a[posa[i]], vala[i]);
        For(i, 1, t2) swap(b[posb[i]], valb[i]);
    }
    return 0;
}