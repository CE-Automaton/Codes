#include<bits/stdc++.h>
using namespace std;
const int N=5e5+5,inf=2e9;
bool st;
int c,n,m,q,a[N],b[N],sa[N],sb[N],p[2][21][N],lg[N];
inline int ask(int fl,int l,int r)
{
	int k=lg[r-l+1];
	if(!fl)return min(p[0][k][l],p[0][k][r-(1<<k)+1]);
	return max(p[1][k][l],p[1][k][r-(1<<k)+1]);
}
void init(int *a,int n)
{
	for(int i=1;i<=n;i++)p[0][0][i]=p[1][0][i]=a[i];
	for(int i=1;(1<<i)<=n;i++)for(int j=1;j<=n-(1<<i)+1;j++)
	{
		p[0][i][j]=min(p[0][i-1][j],p[0][i-1][j+(1<<i-1)]);
		p[1][i][j]=max(p[1][i-1][j],p[1][i-1][j+(1<<i-1)]);
	}
}
bool solve()
{
	if(a[1]>b[1] && a[n]>b[m])
	{
		init(b,m);
		int minn=inf;
		for(int i=1;i<=m;i++)minn=min(minn,b[i]);
		int j=1,fl=0;
		for(int i=1;i<=n;i++)if(a[i]<=minn)fl=1;
		if(!fl)for(int i=1;i<=n;i++)
		{
			bool flag=1;
			if(a[i]<=b[j])
			{
				flag=0;
			}
			else
			{
				int l=j,r=m,res=m;
				while(l<=r)
				{
					int mid=l+r>>1;
					if(ask(1,j,mid)>=a[i])r=mid-1,res=mid;
					else l=mid+1;
				}
				if(res==j)flag=0;
				j=res;
			}
			if(!flag && a[i]<=b[j])
			{
				int l=1,r=j,res=0;
				while(l<=r)
				{
					int mid=l+r>>1;
					if(ask(0,mid,j)<a[i])l=mid+1,res=mid;
					else r=mid-1;
				}
				if(!res){fl=1;break;}
				j=res+1;
			}
		}
		if(!fl && j==m)return 1;
	}
	if(b[1]>a[1] && b[m]>a[n])
	{
		init(a,n);
		int minn=inf;
		for(int i=1;i<=n;i++)minn=min(minn,a[i]);
		int j=1,fl=0;
		for(int i=1;i<=m;i++)if(b[i]<=minn)fl=1;
		if(!fl)for(int i=1;i<=m;i++)
		{
			bool flag=1;
			if(b[i]<=a[j])
			{
				flag=0;
			}
			else
			{
				int l=j,r=n,res=n;
				while(l<=r)
				{
					int mid=l+r>>1;
					if(ask(1,j,mid)>=b[i])r=mid-1,res=mid;
					else l=mid+1;
				}
				if(res==j)flag=0;
				j=res;
			}
			if(!flag && b[i]<=a[j])
			{
				int l=1,r=j,res=0;
				while(l<=r)
				{
					int mid=l+r>>1;
					if(ask(0,mid,j)<b[i])l=mid+1,res=mid;
					else r=mid-1;
				}
				if(!res){fl=1;break;}
				j=res+1;
			}
		}
		if(!fl && j==n)return 1;
	}
	return 0;
}
inline int rd()
{
	int res=0;
	char ch=getchar();
	while(ch<'0' || ch>'9')ch=getchar();
	while(ch>='0' && ch<='9')res=res*10+(ch&15),ch=getchar();
	return res;
}
bool ed;
int main()
{
	for(int i=2;i<N;i++)lg[i]=lg[i>>1]+1;
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	c=rd(),n=rd(),m=rd(),q=rd();
	for(int i=1;i<=n;i++)a[i]=rd(),sa[i]=a[i];
	for(int i=1;i<=m;i++)b[i]=rd(),sb[i]=b[i];
	printf("%d",solve());
	while(q--)
	{
		for(int i=1;i<=n;i++)a[i]=sa[i];
		for(int i=1;i<=m;i++)b[i]=sb[i];
		int kx=rd(),ky=rd();
		while(kx--)
		{
			int x=rd(),y=rd();
			a[x]=y;
		}
		while(ky--)
		{
			int x=rd(),y=rd();
			b[x]=y;
		}
		printf("%d",solve());
	}
	return 0;
}
