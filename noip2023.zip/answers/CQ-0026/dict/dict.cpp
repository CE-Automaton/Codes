#include<bits/stdc++.h>
using namespace std;
const int N=3e3+5,p1=19491001,mod1=998244353;
int n,m,cnt[26],minn[N],maxn[N],mncnt[N],mxcnt[N];
char getc(){char ch=getchar();while(ch<'a' || ch>'z')ch=getchar();return ch;}
int main()
{
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		char ch;
		maxn[i]=0,minn[i]=25;
		for(int j=0;j<26;j++)cnt[j]=0;
		for(int j=1;j<=m;j++)ch=getc(),cnt[ch-'a']++,maxn[i]=max(maxn[i],ch-'a'),minn[i]=min(minn[i],ch-'a');
		mncnt[i]=cnt[minn[i]],mxcnt[i]=cnt[maxn[i]];
	}
	for(int i=1;i<=n;i++)
	{
		bool flag=0;
		for(int j=1;j<=n;j++)if(j!=i)
		{
			if(minn[i]>maxn[j] || (minn[i]==maxn[j] && (cnt[i]!=m || cnt[j]!=m))){flag=1;break;}
		}
		if(!flag)printf("1");else printf("0");
	}
	return 0;
}
