#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e5+5,inf=4e18;
int c,T,f[N],n,m,k,d,x[N],y[N],d1[N];
vector<pair<int,int> >que[N];
inline int rd()
{
	int res=0;
	char ch=getchar();
	while(ch<'0' || ch>'9')ch=getchar();
	while(ch>='0' && ch<='9')res=res*10+(ch&15),ch=getchar();
	return res;
}
struct Seg_tree
{
	struct STree{int l,r,maxn,add;}t[N*4];
	void pushup(int p){t[p].maxn=max(t[p*2].maxn,t[p*2+1].maxn);}
	void update(int p,int v){t[p].maxn+=v,t[p].add+=v;}
	void pushdown(int p){if(t[p].add)update(p*2,t[p].add),update(p*2+1,t[p].add),t[p].add=0;}
	void build(int p,int l,int r)
	{
		t[p].l=l,t[p].r=r,t[p].add=0,t[p].maxn=0;
		if(l==r)return ;
		int mid=l+r>>1;
		build(p*2,l,mid),build(p*2+1,mid+1,r);
	}
	void change(int p,int l,int r,int v)
	{
		if(l>r)return ;
		if(l<=t[p].l && t[p].r<=r)return update(p,v);
		pushdown(p);int mid=t[p].l+t[p].r>>1;
		if(l<=mid)change(p*2,l,r,v);if(mid<r)change(p*2+1,l,r,v);pushup(p);
	}
	int ask(int p,int l,int r)
	{
		if(l<=t[p].l && t[p].r<=r)return t[p].maxn;
		pushdown(p);int mid=t[p].l+t[p].r>>1,res=-inf;
		if(l<=mid)res=max(res,ask(p*2,l,r));if(mid<r)res=max(res,ask(p*2+1,l,r));return res;
	}
}t;
void solve()
{
	n=rd(),m=rd(),k=rd(),d=rd();
	for(int i=1;i<=n;i++)que[i].clear(),f[i]=0;
	for(int i=1;i<=m;i++)x[i]=rd(),y[i]=rd(),d1[i]=rd(),que[x[i]].push_back({x[i]-y[i]+1,d1[i]});
	t.build(1,1,n);
	for(int i=1;i<=n;i++)
	{
		t.change(1,1,i,-d);
		f[i]=f[i-1];
		if(que[i].size())
		{
			for(auto j:que[i])t.change(1,1,j.first,j.second);
			f[i]=max(f[i],t.ask(1,max(1ll,i-k+1),i));
		}
		if(i+2<=n)t.change(1,i+2,i+2,f[i]);
	}
	printf("%lld\n",f[n]);
}
namespace work1
{
	int n,m,k,d,x[N],y[N],v[N];
	void solve()
	{
		n=rd(),m=rd(),k=rd(),d=rd();
		for(int i=1;i<=m;i++)x[i]=rd(),y[i]=rd(),v[i]=rd();
		int ans=0;
		for(int i=1;i<=m;i++)if(y[i]<=k && v[i]>y[i]*d)ans+=v[i]-y[i]*d;
		printf("%lld\n",ans);
	}
}
signed main()
{
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	c=rd(),T=rd();
	if(17<=c && c<=18){while(T--)work1::solve();return 0;}
//	if(15<=c && c<=16){while(T--)work2::solve();return 0;}
	while(T--)solve();
	return 0;
}
