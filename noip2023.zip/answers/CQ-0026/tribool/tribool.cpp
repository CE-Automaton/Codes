#include<bits/stdc++.h>
using namespace std;
const int N=3e5+5,inf=2e9;
int c,t,n,m,lst[N],tot,prt[N],val[N],vis[N],nval[N];
char getc(){char ch=getchar();while(ch!='T' && ch!='F' && ch!='U' && ch!='+' && ch!='-')ch=getchar();return ch;}
int gf(int x){if(x==prt[x])return x;return prt[x]=gf(prt[x]);}
int calc(int x,int y){if(x<=1)return (x^y);return 2;}
int get(char ch){if(ch=='T')return 0;if(ch=='F')return 1;return 2;}
bool v1[N],v2[N];
vector<int>temp;
bool iscor=1;
vector<pair<int,int> >son[N];
void dfs(int x,int now)
{
	v1[x]=1,v2[x]=1,nval[x]=now,temp.push_back(x);
	for(auto y:son[x])if(!v1[y.first])dfs(y.first,calc(now,y.second));else if(nval[y.first]!=calc(now,y.second))iscor=0;
}
void clr()
{
	memset(val,-1,sizeof(val)),memset(v1,0,sizeof(v1)),memset(v2,0,sizeof(v2)),memset(lst,0,sizeof(lst));
	memset(vis,0,sizeof(vis)),memset(nval,0,sizeof(nval));
}
void solve()
{
	memset(val,-1,sizeof(val));
	scanf("%d %d",&n,&m),tot=n;
	for(int i=1;i<N;i++)prt[i]=i,son[i].clear();
	for(int i=1;i<=n;i++)lst[i]=i;
	for(int i=1;i<=m;i++)
	{
		char ch;
		int x,y;
		ch=getc();
		if(ch=='+' || ch=='-')
		{
			scanf("%d %d",&y,&x);
			int now=lst[x];
			tot++,lst[y]=tot,son[now].push_back({lst[y],(ch=='-')}),son[lst[y]].push_back({now,(ch=='-')});
			int fx=gf(now),fy=gf(lst[y]);
			if(fx!=fy)prt[fx]=fy,vis[fy]=((!vis[fy])?vis[fx]:vis[fy]);
		}
		else
		{
			scanf("%d",&x);
			tot++,lst[x]=tot,val[lst[x]]=get(ch),vis[tot]=tot;
		}
	}
	for(int i=1;i<=n;i++)
	{
		son[i].push_back({lst[i],0}),son[lst[i]].push_back({i,0});
		int fx=gf(i),fy=gf(lst[i]);
		if(fx!=fy)prt[fx]=fy,vis[fy]=((!vis[fy])?vis[fx]:vis[fy]);
	}
	int ans=0,alls=0;
	for(int i=1;i<=n;i++)if(!v2[i])
	{
		int fx=gf(i);
		if(vis[fx])
		{
			int now=vis[fx];
			temp.clear(),iscor=1,dfs(now,val[now]);
			for(auto j:temp)if(j<=n && nval[j]==2)ans++;
			for(auto j:temp)v1[j]=0;
		}
		else
		{
			int res0=inf,res1=inf,res2=inf;
			
			temp.clear(),iscor=1,dfs(i,0);
			if(iscor)
			{
				res0=0;
				for(auto j:temp)if(j<=n && nval[j]==2)res0++;
			}
			for(auto j:temp)v1[j]=0;
			
			temp.clear(),iscor=1,dfs(i,1);
			if(iscor)
			{
				res1=0;
				for(auto j:temp)if(j<=n && nval[j]==2)res1++;
			}
			for(auto j:temp)v1[j]=0;
			
			temp.clear(),iscor=1,dfs(i,2);
			if(iscor)
			{
				res2=0;
				for(auto j:temp)if(j<=n && nval[j]==2)res2++;
			}
			for(auto j:temp)v1[j]=0;
			alls+=res2;
			ans+=min(res0,min(res1,res2));
		}
	}
	printf("%d\n",ans);
}
int main()
{
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	scanf("%d %d",&c,&t);
	for(int i=1;i<=t;i++)
	{
		clr(),solve();
	}
	return 0;
}
