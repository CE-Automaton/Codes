#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAXN=1e5+5;
int read(){
    int x=0;char c=getchar();bool f=0;
    while(c>'9'||c<'0'){f|=(c=='-');c=getchar();}
    while(c<='9'&&c>='0'){x=(x<<1)+(x<<3)+c-'0';c=getchar();}
    return f?-x:x;
}
ll write(ll x){
    if(x<0) putchar('-'),x=-x;
    if(x>9) write(x/10);
    putchar(x%10+'0');
}
struct node{
    int ti;
    ll v;
};
vector<node> a[MAXN],Emp;
ll w[2005][2005],dp[MAXN];
int T;
int n,m,k;
ll d;
void solve1(){
    while(T--){
        n=read(),m=read(),k=read(),d=1ll*read();
        for(int i=1;i<=n;i++)   a[i]=Emp;
        for(int i=1;i<=m;i++){
            int x=read(),y=read(),z=read();
            a[x].push_back(node{y,1ll*z});
        }
        for(int i=1;i<=n;i++){
            w[i][i-1]=0;
            for(int j=i;(j<=n)&&(j-i+1<=k);j++){
//                w[i][j]=0;
//                for(int o=i;o<=j;o++){
//                	for(node t:a[o]){
//                		if(o-t.ti+1>=i)	w[i][j]+=t.v;
//					}
//				}
				w[i][j]=w[i][j-1];
                for(node t:a[j])
                    if(j-i+1>=t.ti) w[i][j]+=t.v;
            }
        }
        dp[0]=0;
        for(int i=1;i<=n;i++){
            dp[i]=dp[i-1];
            for(int j=max(i-k+1,1);j<=i;j++){
                dp[i]=max(dp[i],(j>=2?dp[j-2]:0)+w[j][i]-d*1ll*(i-j+1));
			}
        }
        write(dp[n]),putchar('\n');
    }
}
void solveA(){
    while(T--){
        ll ans=0;
        n=read(),m=read(),k=read(),d=1ll*read();
        for(int i=1;i<=m;i++){
            int x=read(),y=read(),z=read();
            if(y>k) continue;
            ll now=1ll*z-d*1ll*y;
            if(now>0)   ans+=now;  
        }
        write(ans),putchar('\n');
    }
}
int main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
    int C=read();T=read();
    if(C==17||C==18)    solveA();
    else    solve1();
    return 0;
}