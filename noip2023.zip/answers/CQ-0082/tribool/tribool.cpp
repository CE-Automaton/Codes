#include<bits/stdc++.h>
using namespace std;
const int MAXN=2e5+5;
int n,m;
struct node{
    int op;
    int val;
}a[MAXN];
int fa[MAXN],v[MAXN];
void Init(){
    for(int i=1;i<=n;i++)   a[i].op=1,a[i].val=i;
    for(int i=1;i<=2*n;i++) fa[i]=i,v[i]=0;
}
int find(int x){return fa[x]==x?x:fa[x]=find(fa[x]);}
void merge(int x,int y){
    int p=find(x),q=find(y);
    if(p==q)    return;
    fa[p]=q;
    if(v[p])    v[q]=v[p];
}
void solve(){
    scanf("%d%d",&n,&m);
    Init();
    while(m--){
        char c;int x,y;
        scanf("\n%c %d",&c,&x);
        if(c=='-'||c=='+')  scanf("%d",&y);
        if(c=='+'){
            a[x]=a[y];
        }else if(c=='-'){
            a[x]=a[y];
            if(a[x].op==2){
                if(a[x].val==1) a[x].val=2;
                else if(a[x].val==2)    a[x].val=1;
            }else   a[x].op=(a[x].op^1);
        }else if(c=='T')    a[x].val=1,a[x].op=2;
        else if(c=='F') a[x].val=2,a[x].op=2;
        else    a[x].val=3,a[x].op=2;
    }
    for(int i=1;i<=n;i++){
//    	printf("%d: %d %d\n",i,a[i].op,a[i].val);
        if(a[i].op==2){
        	if(a[i].val==3){
        		merge(i,i+n);
        		v[find(i)]=a[i].val;
			}else{
				v[find(i)]=a[i].val;
				if(a[i].val==1)	v[find(i+n)]=2;
				else	v[find(i+n)]=1;
			} 
		}  
        else{
            int j=a[i].val;
            if(a[i].op==1)  merge(i,j),merge(i+n,j+n);
            else    merge(i,j+n),merge(i+n,j);
        }
    }
    int ans=0;
    for(int i=1;i<=n;i++){
        if(find(i)==find(i+n))  ans++;
        else if(v[find(i)]==3)  ans++;
    }
    printf("%d\n",ans);
}
int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
    int C,T;scanf("%d%d",&C,&T);
    while(T--){
        solve();
    }
    return 0;
}