#include<bits/stdc++.h>
using namespace std;
const int MAXN=3005;
char mi[MAXN],mx[MAXN];
char s[MAXN][MAXN];
int n,m;
bool ans[MAXN];
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++){
        scanf("\n%s",s[i]+1);
        mi[i]=s[i][1],mx[i]=s[i][1];
        for(int j=2;j<=m;j++){
            mi[i]=min(mi[i],s[i][j]);
            mx[i]=max(mx[i],s[i][j]);
        }
    }
    for(int i=1;i<=n;i++){
        bool flag=1;
        for(int j=1;j<=n;j++){
            if(i==j)  continue;
            if(mi[i]<mx[j]) continue;
            else if(mi[i]>mx[j]){
                flag=0;
                break;
            }else{
                if(mi[i]==mx[i]&&mi[j]==mx[j])  continue;
                else{
                    flag=0;
                    break;
                }
            }
        }
        ans[i]=flag;
    }
    for(int i=1;i<=n;i++){
        putchar(ans[i]+'0');
    }
    return 0;
}
