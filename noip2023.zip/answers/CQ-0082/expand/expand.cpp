#include<bits/stdc++.h>
using namespace std;
const int MAXN=5e5+5;
int read(){
    int x=0;char c=getchar();bool f=0;
    while(c>'9'||c<'0'){f|=(c=='-');c=getchar();}
    while(c<='9'&&c>='0'){x=(x<<1)+(x<<3)+c-'0';c=getchar();}
    return f?-x:x;
}
int A[MAXN],B[MAXN];
int a[MAXN],b[MAXN],c[MAXN];
int n,m;
bool dp[2005][2005];
int sum[2005],l[MAXN];
void solve1(){
	if((a[1]==b[1])||(a[n]==b[m])){
		putchar('0');
		return;
	}
	if(a[1]<b[1]){
		for(int i=1;i<=n;i++)	c[i]=a[i];
		int t=n;
		n=m;
		for(int i=1;i<=m;i++)	a[i]=b[i];
		m=t;
		for(int i=1;i<=n;i++)	b[i]=c[i];
	}
    dp[0][0]=1;sum[0]=1;
    for(int j=1;j<=m;j++)   sum[j]=1;
    for(int i=1;i<=n;i++){
        l[0]=1;dp[i][0]=0;
        for(int j=1;j<=m;j++){
            if(a[i]>b[j]){
                l[j]=l[j-1];
                int cnt=sum[j]-(l[j]-1>0?sum[l[j]-2]:0);
                if(cnt) dp[i][j]=1;
                else    dp[i][j]=0;
//            	printf("%d %d %d [%d %d]\n",i,j,dp[i][j],l[j]-1,j);
            }
            else    l[j]=j+1,dp[i][j]=0;
        }
        sum[0]=0;
        for(int j=1;j<=m;j++)   sum[j]=sum[j-1]+dp[i][j];
    }
    putchar(dp[n][m]+'0');
}
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
    int C=read();
	n=read(),m=read();
	int N=n,M=m;
	int Q=read();
    for(int i=1;i<=n;i++){
    	A[i]=read();
    	a[i]=A[i];
	}
    for(int i=1;i<=m;i++){
    	B[i]=read();
    	b[i]=B[i];
	}
    solve1();
    for(int wwh=1;wwh<=Q;wwh++){
        int kx=read(),ky=read();
        n=N,m=M;
        for(int i=1;i<=n;i++)	a[i]=A[i];
        for(int i=1;i<=m;i++)	b[i]=B[i];
        for(int i=1;i<=kx;i++){
            int p=read(),v=read();
            a[p]=v;
        }
        for(int i=1;i<=ky;i++){
            int p=read(),v=read();
            b[p]=v;
        }
        solve1();
    }
    return 0;
}