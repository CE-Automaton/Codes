#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define mid ((l+r)>>1)
#define ls (id<<1)
#define rs ((id<<1)|1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int __[30],_=0;
    while(x) __[++_]=x%10,x/=10;
    while(_) pc('0'+__[_--]);
}

const int Maxn=1e5+10,INF=1e18;
int op,T,N,M,K,D,X[Maxn],Y[Maxn],V[Maxn],f[5010][5010],Ans,A[Maxn],B[Maxn];

void DFS(int x){
    if(x>N){
        For(i,1,N){
            if(!A[i]) B[i]=0;
            else B[i]=B[i-1]+1;
            if(B[i]>K) return;
        }
        int ret=0;
        For(i,1,M){
            if(B[X[i]]>=Y[i]) ret+=V[i];
        }
        For(i,1,N) if(A[i]) ret-=D;
        Ans=max(Ans,ret);
        return;
    }
    A[x]=1; DFS(x+1); A[x]=0; DFS(x+1);
}

void Solve1(){ DFS(1),write(Ans); }

void Solve(){
    N=read(),M=read(),K=read(),D=read(),Ans=-INF;
    For(i,1,M) X[i]=read(),Y[i]=read(),V[i]=read();
    if(N<=18) return Solve1(),void();
    memset(f,0,sizeof f);
    For(i,1,M){
        int len=X[i]-X[i-1];
        For(j,0,min(K,X[i])){
            if(len>j){
                For(k,0,min(K,X[i-1]))
                    f[i][j]=max(f[i][j],f[i-1][k]-j*D+(j>=Y[i]?V[i]:0));
            }else{
                f[i][j]=max(f[i][j],f[i-1][j-len]-len*D+(j>=Y[i]?V[i]:0));
            }
        }
    }
    For(i,0,min(K,N)) Ans=max(Ans,f[M][i]);
    write(Ans),pc('\n');
}

signed main(){
    freopen("run.in","r",stdin);
    freopen("run.out","w",stdout);
    op=read(),T=read(); while(T--) Solve();
    return 0;
}
/*
g++ run.cpp -o run -O2 -Wall
./run
*/