#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define int long long
#define mid ((l+r)>>1)
#define ls (id<<1)
#define rs ((id<<1)|1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int __[30],_=0;
    while(x) __[++_]=x%10,x/=10;
    while(_) pc('0'+__[_--]);
}

const int Maxn=5e5+10;
int op,N,M,Q,A[Maxn],B[Maxn],f[3010][3010];
int C[Maxn],D[Maxn];

void Solve(){
    For(i,0,N) For(j,0,M) f[i][j]=0;
    f[0][0]=1;
    if(A[1]>B[1]){
        For(i,1,N){
            For(j,1,M) if(f[i-1][j-1]||f[i][j-1]||f[i-1][j]){
                if(A[i]>B[j]) f[i][j]=1;
            }
        }
        write(f[N][M]);
    }else{
        For(i,1,N){
            For(j,1,M) if(f[i-1][j-1]||f[i][j-1]||f[i-1][j]){
                if(A[i]<B[j]) f[i][j]=1;
            }
        }
        write(f[N][M]);
    }
}

signed main(){
    freopen("expand.in","r",stdin);
    freopen("expand.out","w",stdout);
    op=read(),N=read(),M=read(),Q=read();
    For(i,1,N) A[i]=C[i]=read(); For(i,1,M) B[i]=D[i]=read();
    Solve();
    For(i,1,Q){
        int kx=read(),ky=read(),p,v;
        For(j,1,kx) p=read(),v=read(),A[p]=v;
        For(j,1,ky) p=read(),v=read(),B[p]=v;
        Solve();
        For(j,1,N) A[j]=C[j],B[j]=D[j];
    }
    return 0;
}
/*
g++ expand.cpp -o expand -O2 -Wall
./expand
*/