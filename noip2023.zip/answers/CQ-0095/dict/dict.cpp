#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define mid ((l+r)>>1)
#define ls (id<<1)
#define rs ((id<<1)|1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int __[30],_=0;
    while(x) __[++_]=x%10,x/=10;
    while(_) pc('0'+__[_--]);
}

int N,M,A[3010][30];
char S[5010],Mx[3010],Mn[3010];

int main(){
    freopen("dict.in","r",stdin);
    freopen("dict.out","w",stdout);
    N=read(),M=read();
    For(i,1,N){
        scanf("%s",S+1);
        Mx[i]=Mn[i]=S[1];
        For(j,2,M) Mx[i]=max(Mx[i],S[j]),Mn[i]=min(Mn[i],S[j]);
    }
    if(N==1) pc('1'),exit(0);
    For(i,1,N){
        bool ff=0;
        For(j,1,N) if(j^i){
            if(Mn[i]<Mx[j]) continue;
            else{ ff=1; break;}
        }
        if(!ff) pc('1');
        else pc('0');
    }
    return 0;
}
/*
g++ dict.cpp -o dict -O2 -Wall
./dict
*/