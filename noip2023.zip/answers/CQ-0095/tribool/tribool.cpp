#include<bits/stdc++.h>
using namespace std;
#define gc getchar
#define pc putchar
#define pb push_back
#define mp make_pair
#define mid ((l+r)>>1)
#define ls (id<<1)
#define rs ((id<<1)|1)
#define For(i,a,b) for(int i=(a);i<=(b);++i)
#define Rof(i,a,b) for(int i=(a);i>=(b);--i)

int read(){
    int ret=0,f=0; char ch=gc();
    while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gc();
    while(ch>='0'&&ch<='9') ret=(ret<<1)+(ret<<3)+(ch^48),ch=gc();
    return f?-ret:ret;
}

void write(int x){
    if(!x) return pc('0'),void();
    if(x<0) pc('-'),x=-x;
    int __[30],_=0;
    while(x) __[++_]=x%10,x/=10;
    while(_) pc('0'+__[_--]);
}

const int Maxn=2e5+10,INF=1e9+7;
int op,T,N,M,Ans,X[Maxn],Y[Maxn],fa[Maxn],C[Maxn];
char A[Maxn],V[Maxn],B[Maxn];
vector<int> E[Maxn];
queue<int> Q;
bool Vis[Maxn];

char Rev(char x){
    if(x=='T') return 'F';
    if(x=='F') return 'T';
    return 'U';
}

bool check(){
    For(i,1,N) B[i]=A[i];
    For(i,1,M){
        if(V[i]=='+') B[X[i]]=B[Y[i]];
        else if(V[i]=='-') B[X[i]]=Rev(B[Y[i]]);
        else B[X[i]]=V[i];
    }
    For(i,1,N) if(B[i]!=A[i]) return 0;
    return 1;
}

void DFS(int x,int t){
    if(t>=Ans) return;
    if(x>N){
        if(check()) Ans=t;
        return;
    }
    A[x]='T'; DFS(x+1,t);
    A[x]='F'; DFS(x+1,t);
    A[x]='U'; DFS(x+1,t+1);
}

void Solve1(){ Ans=INF,DFS(1,0),write(Ans),pc('\n'); }

int find(int x){return fa[x]=(fa[x]==x?x:find(fa[x]));}

void Solve(){
    N=read(),M=read();
    if(op<=2){
        For(i,1,M){
            cin>>V[i];
            if(V[i]=='U'||V[i]=='T'||V[i]=='F') X[i]=read();
            else X[i]=read(),Y[i]=read();
        }
        return Solve1(),void();
    }
    if(op<=4){
        For(i,1,N) A[i]='T';
        For(i,1,M){
            char ch; cin>>ch; int x=read();
            A[x]=ch;
        }
        Ans=0; For(i,1,M) if(A[i]=='U') ++Ans;
        write(Ans),pc('\n');
        return;
    }
    if(op<=6){
        For(i,1,N) B[i]='T',E[i].clear(),Vis[i]=0,fa[i]=i;
        For(i,1,M){
            char ch; cin>>ch; int x,y;
            if(ch=='+'){
                x=read(),y=read();
                if(B[y]=='U') B[x]='U';
                else B[x]=ch,E[fa[y]].pb(x),fa[x]=fa[y];
            }
            else x=read(),B[x]=ch;
        }
        For(i,1,N) if(B[i]=='U') Q.push(i),Vis[i]=1;
        while(1){
            while(!Q.empty()){
                int x=Q.front(); Q.pop();
                for(int y:E[x]){
                    if(Vis[y]||fa[y]!=x) continue;
                    Vis[y]=1; Q.push(y);
                }
            }
            bool flag=0;
            For(i,1,N) if(Vis[i]&&B[i]=='+'&&!Vis[fa[i]]) Vis[fa[i]]=1,Q.push(fa[i]),flag=1;
            if(!flag) break;
        }
        Ans=0; For(i,1,N) if(Vis[i]) ++Ans;
        write(Ans),pc('\n');
        return;
    }
    if(op<=8){
        For(i,1,N) fa[i]=i,fa[N+i]=N+i,Vis[i]=Vis[i+N]=0,C[i]=i,C[i+N]=0;
        For(i,1,M){
            char ch; cin>>ch;
            int x=read(),y=read();
            if(ch=='+') C[x]=C[y];
            else C[x]=(C[y]>N?C[y]-N:C[y]+N);
        }
        For(i,1,N){
            int x=C[i],y=i,fx=find(x),fy=find(y);
            if(fx!=fy) fa[fx]=fy;
            x=C[i]>N?C[i]-N:C[i]+N,y=y+N;
            fx=find(x),fy=find(y);
            if(fx!=fy) fa[fx]=fy;
        }
        For(i,1,N) if(find(i)==find(i+N)) Vis[i]=Vis[i+N]=1;
        Ans=0; For(i,1,N) if(Vis[find(C[i])]) ++Ans;
        write(Ans),pc('\n');
        return;
    }
}

int main(){
    freopen("tribool.in","r",stdin);
    freopen("tribool.out","w",stdout);
    op=read(),T=read(); while(T--) Solve();
    return 0;
}
/*
g++ tribool.cpp -o tribool -O2 -Wall
./tribool
*/