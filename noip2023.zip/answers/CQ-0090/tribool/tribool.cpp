#include<bits/stdc++.h> 
using namespace std;
inline int read(){int x=0,f=1;char ch=getchar();while(ch<'0'||ch>'9')f=ch=='-'?-f:f,ch=getchar();while('0'<=ch&&ch<='9')x=(x<<1)+(x<<3)+(ch^48),ch=getchar();return x*f;}
int type,t;
int n,m;
int a[100005],nxt[200005],vis[200005];//�Ƿ񱻴���U�� 
int find(int x){return nxt[x]==x?x:nxt[x]=find(nxt[x]);}
void merge(int x,int y){x=find(x),y=find(y);if(x!=y)nxt[x]=y;}
//i ���� x_i,i+n ���� !x_i��2*n+1����T ��2*n+2���� F��2*n+3 ���� U 
void Freopen(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
}
void work(){
	int ans=0;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=2*n;i++)nxt[i]=i,vis[i]=0;
	for(int i=1;i<=n;i++)a[i]=i;
	for(int i=1;i<=m;i++){
		char op;
		scanf(" %s",&op);
		if(op=='T')a[read()]=2*n+1;
		else if(op=='F')a[read()]=2*n+2;
		else if(op=='U')a[read()]=2*n+3;
		else if(op=='+')a[read()]=a[read()];
		else{
			int x,y;
			scanf("%d%d",&x,&y);
			a[x]=
			a[y]==2*n+1?2*n+2:
			a[y]==2*n+2?2*n+1:
			a[y]==2*n+3?2*n+3:
			a[y]>n?a[y]-n:
			a[y]+n;
		}
	}
	for(int i=1;i<=n;i++){
		if(a[i]<=2*n){
			if(a[i]<=n)merge(i,a[i]),merge(i+n,a[i]+n);
			else merge(i,a[i]),merge(i+n,a[i]-n);
		}
	}
	for(int i=1;i<=n;i++)if(a[i]==2*n+3){
		vis[find(i+n)]=vis[find(i)]=1;
		++ans;
	}
	for(int i=1;i<=n;i++)if(a[i]!=2*n+3){
		int x=find(i),y=find(i+n);
		if(vis[x]||vis[y])++ans;
		else if(x==y){vis[x]=1;++ans;}
	}
	printf("%d\n",ans);
}
int main(){
	Freopen();
	scanf("%d%d",&type,&t);
	while(t--)work();
}
