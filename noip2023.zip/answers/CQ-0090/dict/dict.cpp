#include<bits/stdc++.h> 
using namespace std;
int n,m;
char a[3005][3005];
string b[3005];
string mn,nxt;int mni,nxti;
void Freopen(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
}
int main(){
	Freopen();
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)mn+='z',nxt+='z';
	for(int i=1;i<=n;i++){
		string x;
		scanf("%s",a[i]+1);
		for(int j=1;j<=m;j++)x+=a[i][j];
		sort(x.begin(),x.end());
		reverse(x.begin(),x.end());
		if(x<mn)nxti=mni,nxt=mn,mni=i,mn=x;
		else if(x<nxt)nxti=i,nxt=x;
		reverse(x.begin(),x.end());
		b[i]=x;
	}
	if(n==1){
		for(int i=1;i<=n;i++)putchar('1');
		return 0;
	}
	for(int i=1;i<=n;i++){
		if(mni==i)printf("%d",b[i]<nxt);
		else printf("%d",b[i]<mn);
	}
	
}
/*
inline int read(){int x=0,f=1;char ch=getchar();while(ch<'0'||ch>'9')f=ch=='-'?-f:f,ch=getchar();while('0'<=ch&&ch<='9')x=(x<<1)+(x<<3)+(ch^48),ch=getchar();return x*f;}
void wt(int x){if(x>9)wt(x/10);putchar(x%10^48);}
inline void write(int x){if(x<0)putchar('-'),x=-x;wt(x);}
*/
/*
4 7
abandon
bananaa
baannaa
notnotn

*/
