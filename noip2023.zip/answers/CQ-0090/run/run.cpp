#include<bits/stdc++.h>
using namespace std;
#define ll long long

int type,t,n,m,p,d;

struct Node{int y;ll d;};
vector<Node> add[100005];

ll dp[1005][1005];
void sub1(){
	for(int i=1;i<=n;i++)add[i].clear();
	for(int i=1,x,y,d;i<=m;i++){
		scanf("%d%d%d",&x,&y,&d);
		add[x].push_back(Node{y,d});
	}
	memset(dp,-0x3f,sizeof(dp));
	dp[0][0]=0; 
	for(int i=1;i<=n;i++){
		for(int j=1;j<=p;j++)
			dp[i][j]=dp[i-1][j-1]-d,
			dp[i][0]=max(dp[i][0],dp[i-1][j]);
		dp[i][0]=max(dp[i-1][0],dp[i][0]);
		sort(add[i].begin(),add[i].end(),[](const Node &a,const Node &b){return a.y<b.y;});
		for(int j=1;j<(int)add[i].size();j++)add[i][j].d+=add[i][j-1].d;
		for(int j=0;j+1<(int)add[i].size();j++)
			for(int k=add[i][j].y;k<add[i][j+1].y;k++)
				dp[i][k]+=add[i][j].d;
		if(add[i].size()) 
		for(int k=add[i].back().y;k<=p;k++)dp[i][k]+=add[i].back().d;
	}
	ll ans=-0x7fffffffffffffff;
	for(int i=0;i<=p;i++)ans=max(ans,dp[n][i]);
	printf("%lld\n",ans);
}


void sub3(){
	ll ans=0;
	for(int i=1,x,y,v;i<=m;i++){
		scanf("%d%d%d",&x,&y,&v);
		ans+=max(0ll,v-1ll*y*d);
	}
	printf("%lld\n",ans);
}
void work(){
	scanf("%d%d%d%d",&n,&m,&p,&d);
	if(n<=1000&&m<=100000)sub1();
	else sub3();
}
void Freopen(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
}
int main(){
	Freopen();
	scanf("%d%d",&type,&t);
	while(t--)work();
}
/*
1 1
3 2 2 1
2 2 4
3 2 3
*/ 
