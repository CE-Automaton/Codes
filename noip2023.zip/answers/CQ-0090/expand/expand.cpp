#include<bits/stdc++.h> 
using namespace std;
int type,n,m,q;
int a[2005],b[2005];
int x[2005],y[2005];

bitset<2005> dp[2005];
void sub1(){
	if(x[1]<y[1]){
		for(int i=1;i<=n;i++)x[i]=-x[i];
		for(int i=1;i<=m;i++)y[i]=-y[i];
	}
	if(x[1]==y[1])return putchar('0'),void();
	for(int i=1;i<=n;i++)dp[i].reset();
	dp[1][1]=1;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++)if(i!=1||j!=1){
			dp[i][j]=((dp[i-1][j]&(x[i]>y[j]))|(dp[i][j-1]&(x[i]>y[j])));
		}
	}
	printf("%d",(int)dp[n][m]);
}
void work(){
	sub1();
}
void Freopen(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
}
int main(){
	Freopen();
	scanf("%d%d%d%d",&type,&n,&m,&q);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)scanf("%d",&b[i]);
	for(int i=1;i<=n;i++)x[i]=a[i];
	for(int i=1;i<=m;i++)y[i]=b[i];
	work();
	while(q--){
		int kx,ky;
		for(int i=1;i<=n;i++)x[i]=a[i];
		for(int i=1;i<=m;i++)y[i]=b[i];
		scanf("%d%d",&kx,&ky);
		for(int i=1,a,b;i<=kx;i++)scanf("%d%d",&a,&b),x[a]=b;
		for(int i=1,a,b;i<=ky;i++)scanf("%d%d",&a,&b),y[a]=b;
		work();
	}
}
