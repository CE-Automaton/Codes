#include<bits/stdc++.h>
using namespace std;
#define md(a) a=(a%mod+mod)%mod
#define file(a) freopen(#a".in","r",stdin);freopen(#a".out","w",stdout)

bool ST;

const int N=100005;
int Tid,bl[N],n,Q,prt[N],U[N],inc[N];
vector<int>son[N];int col[N],sz;bool flag=1;
inline void add(int x,int y){son[x].push_back(y);}
inline void Link(int x,int y){add(x,y),add(y,x);}

bool ED;

inline int rd()
{
	char ch=getchar();int s=0;
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9')s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
	return s;
}
inline int F(int x)
{
	if(x>=-n&&x<=n)return -x;
	if(x==n+1)return n+2;if(x==n+2)return n+1;return n+3;
}
int fa(int x){if(x==prt[x])return x;return prt[x]=fa(prt[x]);}
inline void Mer(int x,int y){x=fa(x),y=fa(y),prt[x]=y,inc[y]+=inc[x];}
void dfs(int x,int c)
{
	col[x]=c;if(U[x])flag=0;sz+=inc[x];
	for(int y:son[x]){if(!col[y])dfs(y,c^1);else flag&=(col[y]==(c^1));}
}
inline void Get()
{
	for(int i=1;i<=n;i++)son[i].clear(),col[i]=0,prt[i]=i,U[i]=(bl[i]==n+3),inc[i]=1;
	for(int i=1;i<=n;i++)if(bl[i]>=1&&bl[i]<=n)Mer(i,bl[i]);
	for(int i=1;i<=n;i++)if(bl[i]<0){int p=fa(i),q=fa(-bl[i]);Link(p,q);}int ans=0;
	for(int i=1;i<=n;i++)if(fa(i)==i&&col[i]==0){flag=1,sz=0,dfs(i,2);if(!flag)ans+=sz;}
	printf("%d\n",ans);
}
inline void solve()
{
	scanf("%d%d",&n,&Q);
	for(int i=1;i<=n;i++)bl[i]=i;
	while(Q--)
	{
		char op[2];int x,y;scanf("%s",op),x=rd();
		if(op[0]=='+')y=rd(),bl[x]=bl[y];else if(op[0]=='-')y=rd(),bl[x]=F(bl[y]);
		else {if(op[0]=='T')bl[x]=n+1;else if(op[0]=='F')bl[x]=n+2;else bl[x]=n+3;}
	}
	Get();
}
signed main()
{
//	cerr<<(&ST-&ED)/1024.0/1024<<endl;
	file(tribool);
	int T;cin>>Tid>>T;
	while(T--)solve();
	return 0;
}
