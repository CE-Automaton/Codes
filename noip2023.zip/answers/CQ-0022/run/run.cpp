#include<bits/stdc++.h>
using namespace std;
#define int long long
#define md(a) a=(a%mod+mod)%mod
#define file(a) freopen(#a".in","r",stdin);freopen(#a".out","w",stdout)
inline int rd()
{
	char ch=getchar();int s=0;
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9')s=(s*10)+(ch&15),ch=getchar();
	return s;
}

bool ST;

const int N=200005,inf=1e16;
int Tid,n,Q,m,ned,del,p[N],Sam[N],st[N];
struct num{int l,r,val;}q[N];vector<int>inc[N];
inline bool cmp(int x,int y){return q[x].l>q[y].l;}
struct Seg{int add,dat;}tree[N*4];int Zeo;
inline void ADD(int v,int d){tree[v].add+=d,tree[v].dat+=d;}
inline void pushup(int v){tree[v].dat=max(tree[v*2].dat,tree[v*2+1].dat);}
inline void pushdown(int v){if(tree[v].add!=0)ADD(v*2,tree[v].add),ADD(v*2+1,tree[v].add),tree[v].add=0;}
void build(int v,int l,int r)
{
	tree[v]={0,0};if(l==r){if(l>0)tree[v].dat=-inf;else Zeo=v;return ;}
	int mid=(l+r)>>1;build(v*2,l,mid),build(v*2+1,mid+1,r),pushup(v);
}
void add(int v,int l,int r,int d,int L=0,int R=m)
{
	if(l<=L&&R<=r)return void(ADD(v,d));int mid=(L+R)>>1;
	pushdown(v);if(l<=mid)add(v*2,l,r,d,L,mid);if(r>mid)add(v*2+1,l,r,d,mid+1,R);pushup(v);
}
void chg(int v,int x,int d,int L=0,int R=m)
{
	if(L==R)return void(tree[v].dat=max(tree[v].dat,d));int mid=(L+R)>>1;
	pushdown(v);if(x<=mid)chg(v*2,x,d,L,mid);else chg(v*2+1,x,d,mid+1,R);pushup(v);
}

bool ED;

inline void Clear(){for(int i=1;i<=m;i++)inc[i].clear(),Sam[i]=0;m=0;}
inline int Binary(int i)
{
	int l=1,r=i,mid,ans=i;
	while(l<=r){mid=(l+r)>>1;if(p[i]-p[mid]+1<=ned)ans=mid,r=mid-1;else l=mid+1;}
	return ans;
}
inline void DP()
{
	build(1,0,m);
	for(int i=2;i<=m;i++)
	{
		int las=tree[Zeo].dat,mx=tree[1].dat;if(p[i]-1>p[i-1])las=max(las,mx);
		chg(1,0,mx);chg(1,i,las+Sam[i]-del);int pos=i-1,sum=Sam[i];
		for(int id:inc[i])
		{
			int now=q[id].l;int L=now+1,R=pos;L=max(L,st[i]);
			if(L<=R)add(1,L,R,sum-del*(p[i]-p[i-1]));pos=now,sum+=q[id].val;
		}
		if(st[i]<=pos)add(1,st[i],pos,sum-del*(p[i]-p[i-1]));
	}
	int ans=tree[1].dat;cout<<ans<<endl;
}
inline void solve()
{
	Clear();n=rd(),Q=rd(),ned=rd(),del=rd();
	for(int i=1;i<=Q;i++)
	{
		int r,len,val;r=rd(),len=rd(),val=rd();
		int l=r-len+1;p[++m]=l,p[++m]=r,q[i]={l,r,val};
	}
	p[++m]=0,sort(p+1,p+m+1),m=unique(p+1,p+m+1)-p-1;
	for(int i=1;i<=Q;i++)q[i].l=lower_bound(p+1,p+m+1,q[i].l)-p;
	for(int i=1;i<=Q;i++)q[i].r=lower_bound(p+1,p+m+1,q[i].r)-p;
	for(int i=1;i<=Q;i++)
	{
		if(q[i].l==q[i].r)Sam[q[i].r]+=q[i].val;
		else inc[q[i].r].push_back(i);
	}
	for(int i=1;i<=m;i++)sort(inc[i].begin(),inc[i].end(),cmp);
	for(int i=1;i<=m;i++)st[i]=Binary(i);DP();
}
signed main()
{
//	cerr<<(&ST-&ED)/1024.0/1024<<endl;
	file(run);
	int T;cin>>Tid>>T;
	while(T--)solve();
	return 0;
}
