#include<bits/stdc++.h>
using namespace std;
#define md(a) a=(a%mod+mod)%mod
#define file(a) freopen(#a".in","r",stdin);freopen(#a".out","w",stdout)

bool ST;

const int N=3001;
int n,m;char s[N];
int mn[N],mx[N];

bool ED;

signed main()
{
//	cerr<<(&ST-&ED)/1024.0/1024<<endl;
	file(dict);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%s",s+1);sort(s+1,s+m+1);
		mn[i]=s[1]-'a',mx[i]=s[m]-'a';
	}
	for(int i=1;i<=n;i++)
	{
		bool flag=1;
		for(int j=1;j<=n;j++)
		{
			if(i==j)continue;
			if(mn[i]>=mx[j]){flag=0;break;}
		}
		if(flag)putchar('1');else putchar('0');
	}
	return 0;
}
