/*
���û�ҷ֣�����Ӧ���� 335 ��
�������ɡ������� 
�о� T3 �ñ���+α��,0.5h�������� 
�����׼�ֶ���� 400,�Ѹ㡣�� 
*/
#include<bits/stdc++.h>
using namespace std;
#define md(a) a=(a%mod+mod)%mod
#define file(a) freopen(#a".in","r",stdin);freopen(#a".out","w",stdout)
inline int rd()
{
	char ch=getchar();int s=0;
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9')s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
	return s;
}

bool ST;

const int N=500005;
int Tid,n,m,Q,a[N],b[N],A[N],B[N];

namespace Force
{
	int f[2001][2001];
	inline bool check()
	{
		if(a[1]<=b[1]||a[n]<=b[m])return 0;
		for(int i=1;i<=n;i++)for(int j=1;j<=m;j++)f[i][j]=0;
		f[1][1]=1;
		for(int i=1;i<=n;i++)for(int j=1;j<=m;j++)
		{
			if(!f[i][j])continue;
			if(i+1<=n&&a[i+1]>b[j])f[i+1][j]=1;
			if(j+1<=m&&a[i]>b[j+1])f[i][j+1]=1;
			if(i+1<=n&&j+1<=m&&a[i+1]>b[j+1])f[i+1][j+1]=1;
		}
		return f[n][m];
	}
	inline void solve()
	{
		if(check()){putchar('1');return ;}
		for(int i=1;i<=max(n,m);i++)swap(a[i],b[i]);swap(n,m);
		if(check())putchar('1');else putchar('0');swap(n,m);
	}
};
namespace I_want_more_points
{
	inline bool check()
	{
		if(a[1]<=b[1]||a[n]<=b[m])return 0;
		int j=0;
		for(int i=1;i<=n;i++)
		{
			while(j+1<=m&&a[i]>b[j+1])j++;
			if(j==0||a[i]<=b[j])return 0;
		}
		return 1;
	}
	inline void solve()
	{
		if(check()){putchar('1');return ;}
		reverse(a+1,a+n+1),reverse(b+1,b+m+1);
		if(check()){putchar('1');return ;}
		for(int i=1;i<=max(n,m);i++)swap(a[i],b[i]);swap(n,m);
		if(check()){putchar('1');swap(n,m);return ;}
		reverse(a+1,a+n+1),reverse(b+1,b+m+1);
		if(check())putchar('1');else putchar('0');swap(n,m);
	}
};

bool ED;


inline void solve()
{
	if(Tid<=7){Force::solve();return ;}
	else {I_want_more_points::solve();return ;}
}
signed main()
{
//	cerr<<(&ST-&ED)/1024.0/1024<<endl;
	file(expand);
	Tid=rd(),n=rd(),m=rd(),Q=rd();
	for(int i=1;i<=n;i++)A[i]=rd();
	for(int i=1;i<=m;i++)B[i]=rd();
	for(int i=1;i<=n;i++)a[i]=A[i];
	for(int i=1;i<=m;i++)b[i]=B[i];
	solve();
	while(Q--)
	{
		for(int i=1;i<=n;i++)a[i]=A[i];
		for(int i=1;i<=m;i++)b[i]=B[i];
		int kx,ky,x,d;kx=rd(),ky=rd();
		while(kx--)x=rd(),d=rd(),a[x]=d;
		while(ky--)x=rd(),d=rd(),b[x]=d;
		solve();
	}
	return 0;
}
