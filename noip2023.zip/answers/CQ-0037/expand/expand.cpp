#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=2005,Q=65;
int Z,n,m,q,A[N],B[N],x[2][N],y[2][N],dp[N][N],ans[Q];
bool solve()
{
	memset(dp,0,sizeof(dp));
	if(A[1]>B[1])
	{
		dp[1][1]=1;
		for(int a=1;a<=n;a++)
		{
			for(int b=1;b<=m;b++)
			{
				if(a+1<=n&&A[a+1]>B[b]) dp[a+1][b]|=dp[a][b];
				if(b+1<=m&&A[a]>B[b+1]) dp[a][b+1]|=dp[a][b];
				if(a+1<=n&&b+1<=m&&A[a+1]>B[b+1]) dp[a+1][b+1]|=dp[a][b];
			}
		}
	}
	else if(A[1]<B[1])
	{
		dp[1][1]=1;
		for(int a=1;a<=n;a++)
		{
			for(int b=1;b<=m;b++)
			{
				if(a+1<=n&&A[a+1]<B[b]) dp[a+1][b]|=dp[a][b];
				if(b+1<=m&&A[a]<B[b+1]) dp[a][b+1]|=dp[a][b];
				if(a+1<=n&&b+1<=m&&A[a+1]<B[b+1]) dp[a+1][b+1]|=dp[a][b];
			}
		}
	}
	return dp[n][m];
}
int main()
{
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
    scanf("%d%d%d%d",&Z,&n,&m,&q);
    for(int a=1;a<=n;a++) scanf("%d",&A[a]);
    for(int a=1;a<=m;a++) scanf("%d",&B[a]);
    ans[0]=solve();
    for(int i=1;i<=q;i++)
    {
    	int k1,k2;
    	scanf("%d%d",&k1,&k2);
    	for(int a=1;a<=k1;a++)
    	{
    		scanf("%d%d",&x[0][a],&y[0][a]);
    		swap(y[0][a],A[x[0][a]]);
		}
		for(int a=1;a<=k2;a++)
    	{
    		scanf("%d%d",&x[1][a],&y[1][a]);
    		swap(y[1][a],B[x[1][a]]);
		}
		ans[i]=solve();
		for(int a=1;a<=k1;a++)
    	{
    		swap(y[0][a],A[x[0][a]]);
		}
		for(int a=1;a<=k2;a++)
    	{
    		swap(y[1][a],B[x[1][a]]);
		}
	}
	for(int a=0;a<=q;a++) printf("%d",ans[a]);
}
