#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=1e5+5;
int Z,T,n,m,d,k,lsh[N],len,lsh2[N],len2;
ll ans[N],premx[N];
bool u[N];
struct X
{
	int x,y,z;
}j[N];
bool cmpy(X a,X b)
{
	return a.y<b.y;
}
struct Tree
{
	int l,r;
	ll mx,lazy;
}t[4*N+1];
void update(int p)
{
	t[p].mx=max(t[p*2].mx,t[p*2+1].mx);
}
void maketree(int p,int l,int r)
{
	t[p].l=l,t[p].r=r;
	t[p].mx=t[p].lazy=0;
	if(l==r)
	{
		t[p].mx=(ll)d*(lsh[l]-1);
		return;
	}
	int mid=(l+r)/2;
	maketree(p*2,l,mid);
	maketree(p*2+1,mid+1,r);
	update(p);
}
void spread(int p)
{
	if(t[p].lazy!=0)
	{
		t[p*2].mx+=t[p].lazy;
		t[p*2+1].mx+=t[p].lazy;
		t[p*2].lazy+=t[p].lazy;
		t[p*2+1].lazy+=t[p].lazy;
		t[p].lazy=0;
	}
}
void add(int p,int l,int r,ll x)
{
	if(l<=t[p].l&&r>=t[p].r)
	{
		t[p].mx+=x;
		t[p].lazy+=x;
		return;
	}
	spread(p);
	int mid=(t[p].l+t[p].r)/2;
	if(l<=mid) add(p*2,l,r,x);
	if(r>mid) add(p*2+1,l,r,x);
	update(p);
}
ll get_mx(int p,int l,int r)
{
	if(t[p].l>=l&&t[p].r<=r) return t[p].mx;
	spread(p);
	int mid=(t[p].l+t[p].r)/2;
	ll mx=-2e18;
	if(l<=mid) mx=max(mx,get_mx(p*2,l,r));
	if(r>mid) mx=max(mx,get_mx(p*2+1,l,r));
	return mx;
}
int main()
{
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
    scanf("%d%d",&Z,&T);
    while(T--)
    {
    	scanf("%d%d%d%d",&n,&m,&k,&d);
    	for(int a=1;a<=m;a++)
		{
    		scanf("%d%d%d",&j[a].x,&j[a].y,&j[a].z);
    		int l=j[a].x-j[a].y+1,r=j[a].x;
    		j[a].x=l,j[a].y=r;
    	//	cout<<l<<" "<<r<<endl;
    		lsh[a]=j[a].x;
    		lsh2[a]=j[a].y;
		}
		sort(lsh+1,lsh+1+m);
		len=unique(lsh+1,lsh+1+m)-(lsh+1);
		sort(lsh2+1,lsh2+1+m);
		len2=unique(lsh2+1,lsh2+1+m)-(lsh2+1);
		sort(j+1,j+1+m,cmpy);
		maketree(1,1,len);
		memset(u,0,sizeof(u));
		memset(ans,0,sizeof(ans));
		memset(premx,0,sizeof(premx));
		for(int a=1;a<=m;a++)
		{
			int p=lower_bound(lsh+1,lsh+1+len,j[a].x)-lsh;
			//cout<<get)mx
			add(1,1,p,j[a].z);
			if(u[p]==0)
			{
				u[p]=1;
				int p2=lower_bound(lsh2+1,lsh2+1+len2,j[a].x-1)-lsh2-1;
				add(1,p,p,premx[p2]);
			}
			int p2=lower_bound(lsh2+1,lsh2+1+len2,j[a].y)-lsh2;
			int h=lower_bound(lsh+1,lsh+1+len,j[a].y-k+1)-lsh;
			int h2=upper_bound(lsh+1,lsh+1+len,j[a].y)-lsh-1;
			if(h<=h2) ans[p2]=max(ans[p2],get_mx(1,h,h2)-(ll)d*j[a].y);
			premx[p2]=max(premx[p2-1],ans[p2]);
		//	cout<<j[a].y<<" "<<get_mx(1,1,1)<<endl;
		}
		printf("%lld\n",premx[len2]);
	}
}
