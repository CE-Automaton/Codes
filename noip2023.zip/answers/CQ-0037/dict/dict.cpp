#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=3005;
int n,m;
char S[N];
string s[N],s2[N];
int main()
{
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
    scanf("%d%d",&n,&m);
    if(n==1)
    {
    	printf("1");
    	return 0;
	}
    for(int a=1;a<=n;a++)
	{
		scanf("%s",S);
		sort(S,S+strlen(S));
		s[a]=S;
		s2[a]=s[a];
		for(int b=0;b<s[a].size();b++) s2[a][b]=s[a][s[a].size()-b-1];
	//	cout<<s2[a]<<endl;
	}
    string mn1="",mn2="";
    int p1=-1,p2=-1;
    for(int a=1;a<=n;a++)
    {
    	if(s2[a]<mn1||p1==-1)
    	{
    		mn2=mn1,mn1=s2[a];
    		p2=p1,p1=a;
		}
		else if(s2[a]<mn2||p2==-1)
		{
			mn2=s2[a];
    		p2=a;
		}
	}
//	cout<<mx1<<" "<<mx2<<endl;
	for(int a=1;a<=n;a++)
	{
		if(p1==a)
		{
			if(mn2>s[a])
			{
				printf("1");
			}
			else printf("0");
		}
		else
		{
			if(mn1>s[a])
			{
				printf("1");
			}
			else printf("0");
		}
	}
}
