#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=1e5+5;
int Z,T,n,m,fa[N],q,Size[N],d[N],ans;
queue<int> que;
int main()
{
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
    scanf("%d%d",&Z,&T);
    while(T--)
    {
    	scanf("%d%d",&n,&q);
    	for(int a=1;a<=n;a++) fa[a]=a;
    	while(q--)
    	{
    		char S;
    		int x,y;
    		scanf(" %c%d",&S,&x);
    		if(S=='+')
    		{
    			scanf("%d",&y);
    			fa[x]=fa[y];
			}
			else if(S=='-')
    		{
    			scanf("%d",&y);
    			fa[x]=-fa[y];
			}
			else if(S=='T')
			{
				fa[x]=1e9;
			}
			else if(S=='F') fa[x]=-1e9;
			else fa[x]=0;
		}
		for(int a=1;a<=n;a++) Size[a]=1,d[a]=0;
		for(int a=1;a<=n;a++)
		{
			if(abs(fa[a])>0&&abs(fa[a])<=n) d[abs(fa[a])]++;
		}
		while(!que.empty()) que.pop();
		for(int a=1;a<=n;a++)
		{
			if(d[a]==0) que.push(a);
		}
		while(!que.empty())
		{
			int t=que.front();
			que.pop();
			if(abs(fa[t])>0&&abs(fa[t])<=n)
			{
				d[abs(fa[t])]--;
				if(abs(fa[t])!=t)
				{
		       		Size[abs(fa[t])]+=Size[t];
			        if(d[abs(fa[t])]==0) que.push(abs(fa[t]));
				}
			}
		}
		ans=0;
		for(int a=1;a<=n;a++)
		{
			if(fa[a]==0||fa[a]==-a) ans+=Size[a];
		}
		for(int a=1;a<=n;a++)
		{
			if(d[a]==0||abs(fa[a])==a) continue;
			bool ck=0;
			int tot=0;
			for(int b=a;d[b]>0;b=abs(fa[b]))
			{
			//	cout<<"h";
				if(fa[b]<0) ck^=1;
				d[b]=0;
				tot+=Size[b];
			}
		//	cout<<endl;
			if(ck==1) ans+=tot;
		}
		printf("%d\n",ans);
	}
}
