#include <bits/stdc++.h>

namespace IO {
	std::ostream& fmtout(const char* out) {
		while (*out) {
			if (*out == '{' && *(out + 1) == '}') {
				throw std::invalid_argument("???");
			}
			std::cout << *out;
			out++;
		}
		return std::cout;
	} 
	
	template <class Fst, class... Nxt>
	std::ostream& fmtout(const char* out, const Fst& fst, const Nxt&... nxt) {
		while (*out) {
			if (*out == '{' && *(out + 1) == '}') {
				std::cout << fst;
				return fmtout(out + 2, nxt...);
			}
			std::cout << *out;
			out++;
		}
		throw std::invalid_argument("???");	
	}
	
	std::ostream& fmterr(const char* out) {
		while (*out) {
			if (*out == '{' && *(out + 1) == '}') {
				throw std::invalid_argument("???");
			}
			std::cerr << *out;
			out++;
		}
		return std::cerr;
	} 
	
	template <class Fst, class... Nxt>
	std::ostream& fmterr(const char* out, const Fst& fst, const Nxt&... nxt) {
		while (*out) {
			if (*out == '{' && *(out + 1) == '}') {
				std::cerr << fst;
				return fmterr(out + 2, nxt...);
			}
			std::cerr << *out;
			out++;
		}
		throw std::invalid_argument("???");	
	}
}

namespace Solve {
	using namespace IO;
	
	using ll = long long;
	using ul = unsigned long long;
	using ui = unsigned int;
	
	int const INF = std::numeric_limits<int>::max();
	int const NINF = std::numeric_limits<int>::min();
	
	std::mt19937 mt(std::chrono::high_resolution_clock::now().time_since_epoch().count());
	
	ll rnd(ll l, ll r) {
		return std::uniform_int_distribution<ll>(l, r)(mt);
	}
	
	template <class T>
	inline int isz(const T& t) {
		return t.size();
	}
	
	template <class T>
	inline T& ckmx(T& a, const T& b) {
		return a < b ? (a = b) : a;
	}
	
	template <class T>
	inline T& ckmi(T& a, const T& b) {
		return b < a ? (a = b) : a;
	}
	
	int const N = 5e5 + 10;
	int const LG = 19;

	struct ST {
		int mx[LG + 1][N + 1];
		int mi[LG + 1][N + 1];
		int lg[N + 1];

		void init(int* a, int n) {
			for (int i = 1; i <= n; i++) {
				mx[0][i] = a[i];
				mi[0][i] = a[i];
			}

			for (int i = 2; i <= n; i++) {
				lg[i] = lg[i / 2] + 1;
			}

			for (int i = 1; (1 << i) <= n; i++) {
				for (int j = 1; j + (1 << i) - 1 <= n; j++) {
					mx[i][j] = std::max(mx[i - 1][j], mx[i - 1][j + (1 << (i - 1))]);
					mi[i][j] = std::min(mi[i - 1][j], mi[i - 1][j + (1 << (i - 1))]);
				}
			}
		}

		int gmx(int l, int r) {
			int k = lg[r - l + 1];
			return std::max(mx[k][l], mx[k][r - (1 << k) + 1]);
		}

		int gmi(int l, int r) {
			int k = lg[r - l + 1];
			return std::min(mi[k][l], mi[k][r - (1 << k) + 1]);
		}
	};

	int testid;
	int n, m, q;
	int a[N + 1];
	int b[N + 1];
	int oa[N + 1];
	int ob[N + 1];
	ST st;

	int solve(int a[N + 1], int n, int b[N + 1], int m) {
		if (*std::max_element(a + 1, a + n + 1) < *std::max_element(b + 1, b + m + 1)) {
			return solve(b, m, a, n);
		}

		st.init(b, m);
		int L = 0, R = 0;
		b[0] = b[m + 1] = INF;
		for (int i = 1; i <= n; i++) {
			int nL = L;
			while (nL <= R + 1 && a[i] <= b[nL]) {
				nL++;
			}
			if (nL > R + 1) {
				return 0;
			}

			if (a[i] > b[R + 1]) {
				bool is = false;
				for (int j = 1; j <= 4 && R + j <= m; j++) {
					if (a[i] <= b[R + j]) {
						is = true;
						R = R + j - 1;
						break;
					}
				}

				if (!is) {
					int l = R + 1;
					int r = m;
					int res = R + 1;
					while (l <= r) {
						int mid = (l + r) >> 1;

						if (a[i] > st.gmx(R + 1, mid)) {
							res = mid;
							l = mid + 1;
						}
						else {
							r = mid - 1;
						}
					}
					R = res;
				}
			}
			else {
				bool is = false;
				for (int j = 0; j < 4 && R - j >= L; j++) {
					if (a[i] > b[R - j]) {
						is = true;
						R = R - j;
						break;
					}
				}

				if (!is) {
					int l = L;
					int r = R;
					int res = -1;
					while (l <= r) {
						int mid = (l + r) >> 1;

						if (a[i] > st.gmi(mid, R)) {
							res = mid;
							l = mid + 1;
						}
						else {
							r = mid - 1;
						}
					}

					if (res == -1) {
						return 0;
					}

					R = res;
				}
			}

			L = nL;
			if (L > R) {
				return 0;
			}
		}

		return R >= m;
	}

	void main() {
		std::cin >> testid;
		std::cin >> n >> m >> q;
		for (int i = 1; i <= n; i++) {
			std::cin >> a[i];
			oa[i] = a[i];
		}
		for (int i = 1; i <= m; i++) {
			std::cin >> b[i];
			ob[i] = b[i];
		}

		fmtout("{}", solve(a, n, b, m));
		for (int i = 1; i <= q; i++) {
			int kx, ky;
			std::cin >> kx >> ky;
		
			for (int j = 1; j <= n; j++) {
				a[j] = oa[j];
			}
			for (int j = 1; j <= m; j++) {
				b[j] = ob[j];
			}

			for (int j = 1; j <= kx; j++) {
				int p, v;
				std::cin >> p >> v;
				a[p] = v;
			}
			for (int j = 1; j <= ky; j++) {
				int p, v;
				std::cin >> p >> v;
				b[p] = v;
			}

			// for (int j = 1; j <= n; j++) {
			// 	fmterr("{} ", a[j]);
			// }
			// fmterr("\n");
			// for (int j = 1; j <= m; j++) {
			// 	fmterr("{} ", b[j]);
			// }
			// fmterr("\n\n");

			fmtout("{}", solve(a, n, b, m));
		}
		fmtout("\n");
	}
	
	void clear() {
		
	}
	
	void init() {
		
	}
}

signed main() {
	auto inf = freopen("expand.in", "r", stdin);
	auto ouf = freopen("expand.out", "w", stdout);
	
	std::ios::sync_with_stdio(false);
	std::cin.tie(0);
	std::cout.tie(0);
	
	int t = 1;
//	std::cin >> t;
	
	Solve::init();
	for (; t; t--) {
		Solve::main();
		Solve::clear();
	}
	
	std::cout.flush();
	fclose(inf);
	fclose(ouf);
}
