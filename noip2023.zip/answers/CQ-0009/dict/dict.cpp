#include <bits/stdc++.h>

namespace IO {
	std::ostream& fmtout(const char* out) {
		while (*out) {
			if (*out == '{' && *(out + 1) == '}') {
				throw std::invalid_argument("???");
			}
			std::cout << *out;
			out++;
		}
		return std::cout;
	} 
	
	template <class Fst, class... Nxt>
	std::ostream& fmtout(const char* out, const Fst& fst, const Nxt&... nxt) {
		while (*out) {
			if (*out == '{' && *(out + 1) == '}') {
				std::cout << fst;
				return fmtout(out + 2, nxt...);
			}
			std::cout << *out;
			out++;
		}
		throw std::invalid_argument("???");	
	}
	
	std::ostream& fmterr(const char* out) {
		while (*out) {
			if (*out == '{' && *(out + 1) == '}') {
				throw std::invalid_argument("???");
			}
			std::cerr << *out;
			out++;
		}
		return std::cerr;
	} 
	
	template <class Fst, class... Nxt>
	std::ostream& fmterr(const char* out, const Fst& fst, const Nxt&... nxt) {
		while (*out) {
			if (*out == '{' && *(out + 1) == '}') {
				std::cerr << fst;
				return fmterr(out + 2, nxt...);
			}
			std::cerr << *out;
			out++;
		}
		throw std::invalid_argument("???");	
	}
}

namespace Solve {
	using namespace IO;
	
	using ll = long long;
	using ul = unsigned long long;
	using ui = unsigned int;
	
	int const INF = std::numeric_limits<int>::max();
	int const NINF = std::numeric_limits<int>::min();
	
	std::mt19937 mt(std::chrono::high_resolution_clock::now().time_since_epoch().count());
	
	ll rnd(ll l, ll r) {
		return std::uniform_int_distribution<ll>(l, r)(mt);
	}
	
	template <class T>
	inline int isz(const T& t) {
		return t.size();
	}
	
	template <class T>
	inline T& ckmx(T& a, const T& b) {
		return a < b ? (a = b) : a;
	}
	
	template <class T>
	inline T& ckmi(T& a, const T& b) {
		return b < a ? (a = b) : a;
	}

	int const N = 3010;

	struct Val {
		std::string fst, snd;

		void insert(const std::string& s) {
			if (s < fst) {
				snd = fst;
				fst = s;
			}
			else if (s < snd) {
				snd = s;
			}
		}
	};

	int n, m;
	std::string s[N + 1];
	std::string mx[N + 1];

	void main() {
		std::cin >> n >> m;
		if (n == 1) {
			fmtout("1\n");
			return;
		}

		for (int i = 1; i <= n; i++) {
			std::cin >> s[i];
			mx[i] = s[i];
			std::sort(mx[i].begin(), mx[i].end(), std::greater<char>());
		}

		Val v { std::min(mx[1], mx[2]), std::max(mx[1], mx[2]) };
		for (int i = 3; i <= n; i++) {
			v.insert(mx[i]);
		}

		for (int i = 1; i <= n; i++) {
			auto t = mx[i] == v.fst ? v.snd : v.fst;
			std::sort(s[i].begin(), s[i].end());
			if (s[i] < t) {
				fmtout("1");
			}
			else {
				fmtout("0");
			}
		}
		fmtout("\n");
	}
	
	void clear() {
		
	}
	
	void init() {
		
	}
}

signed main() {
	auto inf = freopen("dict.in", "r", stdin);
	auto ouf = freopen("dict.out", "w", stdout);
	
	std::ios::sync_with_stdio(false);
	std::cin.tie(0);
	std::cout.tie(0);
	
	int t = 1;
//	std::cin >> t;
	
	Solve::init();
	for (; t; t--) {
		Solve::main();
		Solve::clear();
	}
	
	std::cout.flush();
	fclose(inf);
	fclose(ouf);
}
