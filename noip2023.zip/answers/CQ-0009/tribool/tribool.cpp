#include <bits/stdc++.h>

namespace IO {
	std::ostream& fmtout(const char* out) {
		while (*out) {
			if (*out == '{' && *(out + 1) == '}') {
				throw std::invalid_argument("???");
			}
			std::cout << *out;
			out++;
		}
		return std::cout;
	} 
	
	template <class Fst, class... Nxt>
	std::ostream& fmtout(const char* out, const Fst& fst, const Nxt&... nxt) {
		while (*out) {
			if (*out == '{' && *(out + 1) == '}') {
				std::cout << fst;
				return fmtout(out + 2, nxt...);
			}
			std::cout << *out;
			out++;
		}
		throw std::invalid_argument("???");	
	}
	
	std::ostream& fmterr(const char* out) {
		while (*out) {
			if (*out == '{' && *(out + 1) == '}') {
				throw std::invalid_argument("???");
			}
			std::cerr << *out;
			out++;
		}
		return std::cerr;
	} 
	
	template <class Fst, class... Nxt>
	std::ostream& fmterr(const char* out, const Fst& fst, const Nxt&... nxt) {
		while (*out) {
			if (*out == '{' && *(out + 1) == '}') {
				std::cerr << fst;
				return fmterr(out + 2, nxt...);
			}
			std::cerr << *out;
			out++;
		}
		throw std::invalid_argument("???");	
	}
}

namespace Solve {
	using namespace IO;
	
	using ll = long long;
	using ul = unsigned long long;
	using ui = unsigned int;
	
	int const INF = std::numeric_limits<int>::max();
	int const NINF = std::numeric_limits<int>::min();
	
	std::mt19937 mt(std::chrono::high_resolution_clock::now().time_since_epoch().count());
	
	ll rnd(ll l, ll r) {
		return std::uniform_int_distribution<ll>(l, r)(mt);
	}
	
	template <class T>
	inline int isz(const T& t) {
		return t.size();
	}
	
	template <class T>
	inline T& ckmx(T& a, const T& b) {
		return a < b ? (a = b) : a;
	}
	
	template <class T>
	inline T& ckmi(T& a, const T& b) {
		return b < a ? (a = b) : a;
	}
	
	int const N = 1e5 + 10;

	struct Val {
		int v; // 0, 1, 2
		int op, x;
	};

	struct Node {
		int x, v;
	};

	int testid;
	int n, m;
	Val v[N + 1];
	std::vector<Node> gr[N + 1];
	int col[N + 1];
	int vis[N + 1];
	int cnt;
	bool fail;

	void dfs(int x) {
		vis[x] = 1;
		cnt++;
		if (v[x].v == 2) {
			fail = true;
		}

		for (auto& to : gr[x]) {
			if (vis[to.x]) {
				if (col[to.x] != (col[x] ^ to.v)) {
					fail = true;
				}
			}
			else {
				col[to.x] = col[x] ^ to.v;
				dfs(to.x);
			}
		}
	}

	void main() {
		std::cin >> n >> m;
		for (int i = 1; i <= n; i++) {
			v[i] = { -1, 0, i };
		}	

		for (int i = 1; i <= m; i++) {
			char op;
			std::cin >> op;

			if (op == '+') {
				int x, y;
				std::cin >> x >> y;
				v[x] = v[y];
			}
			else if (op == '-') {
				int x, y;
				std::cin >> x >> y;
				if (v[y].v != -1) {
					v[x] = { v[y].v == 2 ? 2 : !v[y].v, 0, 0 };
				}
				else {
					v[x] = v[y];
					v[x].op ^= 1;
				}
			}
			else {
				int x;
				std::cin >> x;
				v[x] = { op == 'T' ? 1 : op == 'F' ? 0 : 2, 0, 0 };
			}
		}

		for (int i = 1; i <= n; i++) {
			if (v[i].v == -1) {
				gr[i].push_back({ v[i].x, v[i].op });
				gr[v[i].x].push_back({ i, v[i].op });
			}
		}

		int ans = 0;
		// int cc = 0;
		for (int i = 1; i <= n; i++) {
			if (!vis[i]) {
				// cc++;
				cnt = 0;
				fail = false;
				dfs(i);
				if (fail) {
					ans += cnt;
				}
			}
		}

		// fmterr("? {}\n", cc);
		fmtout("{}\n", ans);
	}
	
	void clear() {
		for (int i = 1; i <= n; i++) {
			v[i] = {};
			gr[i].clear();
			col[i] = 0;
			vis[i] = 0;
		}
		cnt = 0;
		fail = false;
		n = m = 0;
	}
	
	void init() {
		
	}
}

signed main() {
	auto inf = freopen("tribool.in", "r", stdin);
	auto ouf = freopen("tribool.out", "w", stdout);
	
	std::ios::sync_with_stdio(false);
	std::cin.tie(0);
	std::cout.tie(0);
	
	int t = 1;
	std::cin >> Solve::testid >> t;
	
	Solve::init();
	for (; t; t--) {
		Solve::main();
		Solve::clear();
	}
	
	std::cout.flush();
	fclose(inf);
	fclose(ouf);
}
