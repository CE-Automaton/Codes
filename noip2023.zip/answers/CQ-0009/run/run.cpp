#include <bits/stdc++.h>

namespace IO {
	std::ostream& fmtout(const char* out) {
		while (*out) {
			if (*out == '{' && *(out + 1) == '}') {
				throw std::invalid_argument("???");
			}
			std::cout << *out;
			out++;
		}
		return std::cout;
	} 
	
	template <class Fst, class... Nxt>
	std::ostream& fmtout(const char* out, const Fst& fst, const Nxt&... nxt) {
		while (*out) {
			if (*out == '{' && *(out + 1) == '}') {
				std::cout << fst;
				return fmtout(out + 2, nxt...);
			}
			std::cout << *out;
			out++;
		}
		throw std::invalid_argument("???");	
	}
	
	std::ostream& fmterr(const char* out) {
		while (*out) {
			if (*out == '{' && *(out + 1) == '}') {
				throw std::invalid_argument("???");
			}
			std::cerr << *out;
			out++;
		}
		return std::cerr;
	} 
	
	template <class Fst, class... Nxt>
	std::ostream& fmterr(const char* out, const Fst& fst, const Nxt&... nxt) {
		while (*out) {
			if (*out == '{' && *(out + 1) == '}') {
				std::cerr << fst;
				return fmterr(out + 2, nxt...);
			}
			std::cerr << *out;
			out++;
		}
		throw std::invalid_argument("???");	
	}
}

namespace Solve {
	#define int long long

	using namespace IO;
	
	using ll = long long;
	using ul = unsigned long long;
	using ui = unsigned int;
	
	int const INF = std::numeric_limits<int>::max();
	int const NINF = std::numeric_limits<int>::min();
	
	std::mt19937 mt(std::chrono::high_resolution_clock::now().time_since_epoch().count());
	
	ll rnd(ll l, ll r) {
		return std::uniform_int_distribution<ll>(l, r)(mt);
	}
	
	template <class T>
	inline int isz(const T& t) {
		return t.size();
	}
	
	template <class T>
	inline T& ckmx(T& a, const T& b) {
		return a < b ? (a = b) : a;
	}
	
	template <class T>
	inline T& ckmi(T& a, const T& b) {
		return b < a ? (a = b) : a;
	}
	
	int const M = 1e5 + 10;

	struct Line {
		int l, r, v;
	};

	int testid;
	int n, m, K, D;
	Line ls[M + 1];

	// namespace SubB {
	// 	bool check_sub() {
	// 		for (int i = 1; i < m; i++) {
	// 			if (ls[i].r >= ls[i + 1].l) {
	// 				return false;
	// 			}
	// 		}
	// 		return true;
	// 	}

	// 	void main() {
	// 		int ans = 0;
	// 		for (int i = 1; i <= m; i++) {
	// 			int L = ls[i].r - ls[i].l + 1;
	// 			if (L > K) {
	// 				continue;
	// 			}

	// 			if (L * D <= ls[i].v) {
	// 				ans += ls[i].v - L * D;
	// 			}
	// 		}

	// 		fmtout("{}\n", ans);
	// 	}
		
	// 	void clear() {

	// 	}
	// }

	namespace SubN1e3 {
		int const N = 1e3 + 10;

		bool check_sub() {
			return n <= 1000;
		}

		int f[N + 1];
		int vv[N + 1];

		void main() {
			std::sort(ls + 1, ls + m + 1, [&](const Line& l, const Line& r) {
				return l.r == r.r ? l.l < r.l : l.r < r.r;
			});
			
			// fmterr("ls: ");
			// for (int i = 1; i <= m; i++) {
			// 	fmterr("({} {} {}) ", ls[i].l, ls[i].r, ls[i].v);
			// }
			// fmterr("\n");

			for (int i = 1; i <= m; i++) {
				int j = i;
				while (j + 1 <= m && ls[j + 1].r == ls[j].r) {
					j++;
				}

				int sum = 0;
				for (int k = i; k <= j; k++) {
					sum += ls[k].v;
				}

				for (int j = 1; j <= ls[i].r; j++) {
					ckmx(f[j], f[j - 1]);
				}

				for (int k = i; k <= j; k++) {
					int cur = sum;
					for (int p = ls[k].r; p >= 1 && ls[i].r - p + 1 <= K; p--) {
						cur += vv[p];
						if (p <= ls[k].l) {
							ckmx(f[ls[i].r], (p >= 2 ? f[p - 2] : 0) + cur - D * (ls[i].r - p + 1));
						}
					}

					vv[ls[k].l] += ls[k].v;
					sum -= ls[k].v;
				}

				i = j;
			}

			int ans = 0;
			for (int i = 1; i <= n; i++) {
				ckmx(ans, f[i]);
			}

			fmtout("{}\n", ans);
		}

		void clear() {
			for (int i = 0; i <= n; i++) {
				f[i] = vv[i] = 0;
			}
		}
	}

	namespace SubM1e3orA {
		int const M = 1e5 + 10;

		bool check_sub() {
			return m <= 1e3 || K <= 1e2;
		}

		int f[M + 1];
		int vv[M + 1];
		std::vector<int> vl, vr;
		int hl[M + 1];
		int hr[M + 1];

		void main() {
			std::sort(ls + 1, ls + m + 1, [&](const Line& l, const Line& r) {
				return l.r == r.r ? l.l < r.l : l.r < r.r;
			});

			for (int i = 1; i <= m; i++) {
				vl.push_back(ls[i].l);
				vr.push_back(ls[i].r);
			}

			std::sort(vl.begin(), vl.end());
			vl.erase(std::unique(vl.begin(), vl.end()), vl.end());
			for (int i = 1; i <= m; i++) {
				hl[i] = std::lower_bound(vl.begin(), vl.end(), ls[i].l) - vl.begin();
			}

			std::sort(vr.begin(), vr.end());
			vr.erase(std::unique(vr.begin(), vr.end()), vr.end());
			for (int i = 1; i <= m; i++) {
				hr[i] = std::lower_bound(vr.begin(), vr.end(), ls[i].r) - vr.begin();
			}

			for (int i = 1; i <= m; i++) {
				int j = i;
				while (j + 1 <= m && ls[j + 1].r == ls[j].r) {
					j++;
				}

				int sum = 0;
				for (int k = i; k <= j; k++) {
					sum += ls[k].v;
				}

				f[hr[i]] = f[hr[i - 1]];

				for (int k = i; k <= j; k++) {
					int cur = sum;
					auto it = std::upper_bound(vl.begin(), vl.end(), ls[k].r) - vl.begin() - 1;
					auto tr = std::lower_bound(vr.begin(), vr.end(), ls[k].r) - vr.begin() - 1;
					for (int p = it; p >= 0 && ls[i].r - vl[p] + 1 <= K; p--) {
						while (tr >= 0 && vr[tr] + 1 >= vl[p]) {
							tr--;
						}

						cur += vv[p];
						if (vl[p] <= ls[k].l) {
							ckmx(f[hr[i]], (tr >= 0 ? f[tr] : 0) + cur - D * (ls[i].r - vl[p] + 1));
						}
					}

					vv[hl[k]] += ls[k].v;
					sum -= ls[k].v;
				}

				i = j;
			}

			fmtout("{}\n", f[hr[m]]);
		}

		void clear() {
			for (int i = 0; i <= m; i++) {
				f[i] = hl[i] = hr[i] = vv[i] = 0;
			}
			vl.clear();
			vr.clear();
		}
	}

	namespace SubC {
		bool check_sub() {
			for (int i = 1; i < m; i++) {
				if (ls[i].l >= ls[i + 1].l || ls[i].r >= ls[i + 1].r) {
					return false;
				}
			}
			return true;
		}

		struct SegmentTree {
			struct Node {
				int l, r;
				int mx;
			};

			Node nd[4 * M + 1];

			void build(int x, int l, int r) {
				nd[x].l = l;
				nd[x].r = r;
				if (l != r) {
					int mid = (l + r) >> 1;
					build(2 * x, l, mid);
					build(2 * x + 1, mid + 1, r);
					pushup(x);
				}
				else {
					nd[x].mx = NINF;
				}
			}

			void pushup(int x) {
				nd[x].mx = std::max(nd[2 * x].mx, nd[2 * x + 1].mx);
			}

			void update(int x, int p, int v) {
				if (nd[x].l == nd[x].r) {
					ckmx(nd[x].mx, v);
				}
				else {
					int mid = (nd[x].l + nd[x].r) >> 1;
					if (p <= mid) {
						update(2 * x, p, v);
					}
					else {
						update(2 * x + 1, p, v);
					}
					pushup(x);
				}
			}

			int prod(int x, int l, int r) {
				if (nd[x].r < l || nd[x].l > r) {
					return NINF;
				}
				else if (nd[x].l >= l && nd[x].r <= r) {
					return nd[x].mx;
				}
				else {
					return std::max(prod(2 * x, l, r), prod(2 * x + 1, l, r));
				}
			}
		};

		int p[M + 1];
		int f[M + 1];
		SegmentTree seg;

		void main() {
			for (int i = 1; i <= m; i++) {
				p[i] = p[i - 1] + ls[i].v;
			}

			seg.build(1, 1, m);
			int q = 0;
			for (int i = 1; i <= m; i++) {
				f[i] = f[i - 1];

				int L = 1;
				int R = i;
				int res = i + 1;
				while (L <= R) {
					int mid = (L + R) >> 1;

					if (ls[i].r - ls[mid].l + 1 <= K) {
						res = mid;
						R = mid - 1;
					}
					else {
						L = mid + 1;
					}
				}

				while (ls[q + 1].r < ls[i].l - 1) {
					q++;
				}

				// fmterr("{}: {}\n", i, q);

				int v = f[q] - p[i - 1] + D * (ls[i].l - 1);
				// fmterr("? {}\n", v);
				seg.update(1, i, v);

				if (res <= i) {
					auto t = seg.prod(1, res, i);
					if (t != NINF) {
						ckmx(f[i], t - D * ls[i].r + p[i]);					
					}
				}
			}

			fmtout("{}\n", f[m]);
		}

		void clear() {
			for (int i = 0; i <= m; i++) {
				f[i] = p[i] = 0;
			}
		}
	}

	void main() {
		std::cin >> n >> m >> K >> D;
		for (int i = 1; i <= m; i++) {
			int x, y, v;
			std::cin >> x >> y >> v;
			ls[i] = { x - y + 1, x, v };
		}

		// if (SubB::check_sub()) {
		// 	SubB::main();
		// 	SubB::clear();
		// 	return;
		// }

		if (SubC::check_sub()) {
			SubC::main();
			SubC::clear();
			return;
		}
		
		if (SubN1e3::check_sub()) {
			SubN1e3::main();
			SubN1e3::clear();
			return;
		}

		if (SubM1e3orA::check_sub()) {
			SubM1e3orA::main();
			SubM1e3orA::clear();
			return;
		}
	}
	
	void clear() {
		for (int i = 1; i <= m; i++) {
			ls[i] = {};
		}
		n = m = K = D = 0;
	}
	
	void init() {
		
	}
}

signed main() {
	auto inf = freopen("run.in", "r", stdin);
	auto ouf = freopen("run.out", "w", stdout);
	
	std::ios::sync_with_stdio(false);
	std::cin.tie(0);
	std::cout.tie(0);
	
	int t = 1;
	std::cin >> Solve::testid >> t;
	
	Solve::init();
	for (; t; t--) {
		Solve::main();
		Solve::clear();
	}
	
	std::cout.flush();
	fclose(inf);
	fclose(ouf);
}
