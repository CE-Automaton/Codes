#include <cstdio>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>
#include <map>
#include <set>
#define LL long long
#define mr make_pair
#define pr pair <int, int>
using namespace std;
const int MAXN = 4e5 + 5, MAXM = 4e3 + 5;
const LL lof = 3e18;
struct sgt {
	int L, R;
	LL maxx, add;
}tree[MAXN << 2];
struct node {
	int L, R, val;
}arr[MAXN];
int C, T, n, m, k, d, lsh[MAXN], tot;
LL dp[MAXM][MAXM], del[MAXN];
vector <pr> v[MAXN];
void read(int &x) {
	x = 0; bool f = 1; char c = getchar();
	for(; c < '0' || c > '9'; c = getchar()) if(c == '-') f = 0;
	for(; c >= '0' && c <= '9'; c = getchar()) x = (x << 1) + (x << 3) + (c ^ 48);
	x = (f ? x : -x);
}
int cnta, cntc, cntm;
void build(int p, int l, int r) {
	tree[p].L = l; tree[p].R = r; tree[p].maxx = -lof; tree[p].add = 0;
	if(l == r) {
		if(l == 0) tree[p].maxx = 0;
		return;
	}
	int mid = (l + r) >> 1; build(p << 1, l, mid); build(p << 1 | 1, mid + 1, r);
	tree[p].maxx = max(tree[p << 1].maxx, tree[p << 1 | 1].maxx);
}
void getv(int p, LL val) {
	tree[p].maxx += val; tree[p].add += val;
}
void spread(int p) {
	if(tree[p].add) {
		getv(p << 1, tree[p].add); getv(p << 1 | 1, tree[p].add); tree[p].add = 0;
	}
}
void cng(int p, int ql, int qr, LL val) {
	cntc ++;
	if(ql > qr) return;
	if(tree[p].L >= ql && tree[p].R <= qr) {
		getv(p, val); return;
	}
	int mid = (tree[p].L + tree[p].R) >> 1; spread(p);
	if(mid >= ql) cng(p << 1, ql, qr, val);
	if(mid < qr) cng(p << 1 | 1, ql, qr, val);
	tree[p].maxx = max(tree[p << 1].maxx, tree[p << 1 | 1].maxx);
}
LL ask(int p, int ql, int qr) {
	cnta ++;
	if(tree[p].L >= ql && tree[p].R <= qr) return tree[p].maxx;
	int mid = (tree[p].L + tree[p].R) >> 1; spread(p);
	if(mid < ql) return ask(p << 1 | 1, ql, qr);
	if(mid >= qr) return ask(p << 1, ql, qr);
	return max(ask(p << 1, ql, qr), ask(p << 1 | 1, ql, qr));
}
void Modify(int p, int x, LL val) {
	cntm ++;
	if(tree[p].L == tree[p].R) {
		tree[p].maxx = val; return;
	}
	int mid = (tree[p].L + tree[p].R) >> 1; spread(p);
	if(x <= mid) Modify(p << 1, x, val);
	else Modify(p << 1 | 1, x, val);
	tree[p].maxx = max(tree[p << 1].maxx, tree[p << 1 | 1].maxx);
}
int main() {
//	freopen("A.txt", "r", stdin);
//	freopen("B.txt", "w", stdout);
	freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);
	read(C); read(T); int x, y;
	while(T --) {
		read(n); read(m); read(k); read(d); tot = 0;
		for(int i = 1; i <= m; i ++) {
			read(arr[i].L); read(arr[i].R); read(arr[i].val);
			arr[i].R = arr[i].L - arr[i].R + 1; swap(arr[i].L, arr[i].R);
			lsh[++ tot] = arr[i].L; lsh[++ tot] = arr[i].R;
			lsh[++ tot] = arr[i].L - 1; //lsh[++ tot] = arr[i].R - 1;
		}
		sort(lsh + 1, lsh + 1 + tot); tot = unique(lsh + 1, lsh + 1 + tot) - lsh - 1;
		for(int i = 1; i <= tot; i ++) v[i].clear();
		for(int i = 1; i <= m; i ++) {
			x = lower_bound(lsh + 1, lsh + 1 + tot, arr[i].L) - lsh;
			y = lower_bound(lsh + 1, lsh + 1 + tot, arr[i].R) - lsh;
			v[y].emplace_back(mr(arr[i].val, x));
		}
		lsh[tot + 1] = lsh[tot] + 1; lsh[0] = lsh[1] - 1;
		build(1, 0, tot);
//		for(int i = 1; i <= tot; i ++) dp[0][i] = -lof;
		int r = -1;
		for(int i = 1; i <= tot; i ++) {
			LL mn = tree[1].maxx; int lasr = r;
			while(r + 1 <= i && lsh[i] - lsh[r + 1] > k) r ++;
//			for(int j = lasr + 1; j <= r; j ++) Modify(1, j, -lof);
			cng(1, 0, tot, -1ll * (lsh[i] - lsh[i - 1]) * d);
			Modify(1, i, mn);
			for(auto j : v[i]) cng(1, max(0, r + 1), j.second - 1, j.first);
		}
		LL ans = ask(1, max(0, r + 1), tot);
		printf("%lld\n", ans);
	}
//	printf("|%d %d %d|\n", cnta, cntc, cntm);
	return 0;
}
/*
1 1
3 2 2 1
2 2 4
3 2 3
*/
