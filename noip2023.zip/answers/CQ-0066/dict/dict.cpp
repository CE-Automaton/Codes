#include <cstdio>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>
#include <map>
#include <set>
#define LL long long
#define mr make_pair
#define pr pair <int, int>
using namespace std;
const int MAXN = 3e3 + 5;
int n, m, lens, lent, res[MAXN], c[1000];
char s[MAXN][MAXN], P[MAXN][MAXN], Q[MAXN][MAXN], S[MAXN], T[MAXN];
void read(int &x) {
	x = 0; bool f = 1; char c = getchar();
	for(; c < '0' || c > '9'; c = getchar()) if(c == '-') f = 0;
	for(; c >= '0' && c <= '9'; c = getchar()) x = (x << 1) + (x << 3) + (c ^ 48);
	x = (f ? x : -x);
}
int calc(int x, int y, int p, int q) { // O(m)
	if(!x || !y) return x + y;
	lens = lent = 0;
	if(p == 0) {
		for(int i = 1; i <= m; i ++) S[i] = P[x][i];
	}
	else {
		for(int i = 1; i <= m; i ++) S[i] = Q[x][i];
	}
	if(q == 0) {
		for(int i = 1; i <= m; i ++) T[i] = P[y][i];
	}
	else {
		for(int i = 1; i <= m; i ++) T[i] = Q[y][i];
	}
	for(int i = 1; i <= m; i ++) {
		if(S[i] < T[i]) return 0;
		if(S[i] > T[i]) return 1;
	}
	return 0;
}
int main() {
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= n; i ++) scanf("%s", s[i] + 1);
	for(int i = 1; i <= n; i ++) {
		memset(c, 0, sizeof(c));
		for(int j = 1; j <= m; j ++) c[s[i][j] - 'a'] ++;
		int tot = 0;
		for(int j = 0; j <= 25; j ++) {
			for(int k = 1; k <= c[j]; k ++) P[i][++ tot] = j + 'a'; 
		}
		tot = 0;
		for(int j = 25; j >= 0; j --) {
			for(int k = 1; k <= c[j]; k ++) Q[i][++ tot] = j + 'a';
		}
	}
	for(int i = 1; i <= n; i ++) res[i] = 1;
	int noww = 0;
	for(int i = 1; i <= n; i ++) {
		if(i >= 2) res[i] &= calc(noww, i, 1, 0);
		if(calc(noww, i, 1, 1)) noww = i;
	}
	noww = 0;
	for(int i = n; i >= 1; i --) {
		if(i <= n - 1) res[i] &= calc(noww, i, 1, 0);
		if(calc(noww, i, 1, 1)) noww = i;
	}
	for(int i = 1; i <= n; i ++) printf("%d", res[i]);
	return 0;
}

