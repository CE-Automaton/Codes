#include <cstdio>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>
#include <map>
#include <set>
#define LL long long
#define mr make_pair
#define pr pair <int, int>
using namespace std;
const int MAXN = 3e5 + 5;
int C, T, n, m, fa[MAXN], vis[MAXN], a[MAXN];
char s[10];
void read(int &x) {
	x = 0; bool f = 1; char c = getchar();
	for(; c < '0' || c > '9'; c = getchar()) if(c == '-') f = 0;
	for(; c >= '0' && c <= '9'; c = getchar()) x = (x << 1) + (x << 3) + (c ^ 48);
	x = (f ? x : -x);
}
int findset(int x) {
	return fa[x] ^ x ? fa[x] = findset(fa[x]) : fa[x];
}
void merge(int x, int y) {
//	printf("?%d %d?\n", x, y);
	int u = findset(x), v = findset(y);
	if(u ^ v) fa[u] = v;
}
int main() {
	freopen("tribool.in", "r", stdin);
	freopen("tribool.out", "w", stdout);
	read(C); read(T); int x, y;
	while(T --) {
		read(n); read(m);
		for(int i = 1; i <= 2 * n + 5; i ++) fa[i] = i, vis[i] = 0;
		for(int i = 1; i <= n; i ++) a[i] = i;
		for(int i = 1; i <= m; i ++) {
			scanf("%s", s);
			if(s[0] == 'T' || s[0] == 'F' || s[0] == 'U') {
				read(x);
				if(s[0] == 'T') a[x] = 2 * n + 2;
				if(s[0] == 'F') a[x] = 2 * n + 3;
				if(s[0] == 'U') a[x] = 2 * n + 1;
			}
			else if(s[0] == '+') {
				read(x); read(y); a[x] = a[y];
			}
			else if(s[0] == '-') {
				read(x), read(y);
				if(a[y] == 2 * n + 2) a[x] = 2 * n + 3;
				else if(a[y] == 2 * n + 3) a[x] = 2 * n + 2;
				else if(a[y] == 2 * n + 1) a[x] = 2 * n + 1;
				else if(a[y] > n) a[x] = a[y] - n;
				else a[x] = a[y] + n;
			}
		}
		for(int i = 1; i <= n; i ++) {
			if(a[i] <= 2 * n + 1) {
				if(a[i] == 2 * n + 1) merge(i, a[i]), merge(i + n, a[i]);
				else if(a[i] <= n) merge(i, a[i]), merge(i + n, a[i] + n);
				else merge(i, a[i]), merge(i + n, a[i] - n);
			}
		}
		vis[findset(2 * n + 1)] = 1;
		for(int i = 1; i <= n; i ++) {
			if(findset(i) == findset(n + i)) vis[findset(i)] = 1;
//			printf("|%d %d\n", findset(i), findset(n + i));
		}
		int res = 0;
		for(int i = 1; i <= n; i ++) if(vis[findset(i)] || vis[findset(n + i)]) res ++;
		printf("%d\n", res);
	}
	return 0;
}

