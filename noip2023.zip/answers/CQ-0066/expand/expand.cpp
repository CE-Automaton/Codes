#include <cstdio>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>
#include <map>
#include <set>
#define LL long long
#define mr make_pair
#define pr pair <int, int>
using namespace std;
const int MAXN = 5e5 + 5, MAXM = 2e3 + 5;
int C, n, m, q, X[MAXN], Y[MAXN], a[MAXN], b[MAXN], dfna[MAXN], dfnb[MAXN], P, Q;
bool dp[MAXM][MAXM];
int cnt;
void read(int &x) {
	x = 0; bool f = 1; char c = getchar();
	for(; c < '0' || c > '9'; c = getchar()) if(c == '-') f = 0;
	for(; c >= '0' && c <= '9'; c = getchar()) x = (x << 1) + (x << 3) + (c ^ 48);
	x = (f ? x : -x);
}
int nowcnt;
int querya(int x) {
	return (dfna[x] == nowcnt ? a[x] : X[x]);
}
int queryb(int x) {
	return (dfnb[x] == nowcnt ? b[x] : Y[x]);
}
int calc(int l, int r, int nowl, int nowr, int f) {
	if(f == 0) {
		int noww = nowr, lasmin = 0x3f3f3f3f, lasid;
//		printf("|%d %d %d %d|\n", l, r, nowl, nowr);
		for(int i = r; i >= l; i --) {
			if(noww == nowl) {
				return 1;
			}
			int p = i, mx = querya(p);
			while(p - 1 >= l && querya(p - 1) >= querya(i)) p --, mx = max(mx, querya(p));
			lasmin = querya(i); lasid = i;
			int t = noww;
			if(queryb(t) <= querya(i)) {
				return 0;
			}
			while(t >= nowl && queryb(t) <= mx && queryb(t) > querya(i)) t --;
			
			if(queryb(t) <= querya(i) || queryb(t) <= mx) {
				return 0;
			}
			if(t == nowl - 1) {
				return 0;
			}
			noww = t; i = p;
		}
//		printf("?");
		for(int j = noww - 1; j >= nowl; j --) {
			if(queryb(j) <= lasmin) {
				return 0;
			}
		}
		return 1;
	}
	int noww = nowr, lasmin = 0x3f3f3f3f, lasid;
		for(int i = r; i >= l; i --) {
			if(noww == nowl) {
				return 1;
			}
			int p = i, mx = querya(p);
			while(p - 1 >= l && querya(p - 1) <= querya(i)) p --, mx = min(mx, querya(p));
			lasmin = querya(i); lasid = i;
			int t = noww;
			if(queryb(t) >= querya(i)) {
				return 0;
			}
			while(t >= nowl && queryb(t) >= mx && queryb(t) < querya(i)) t --;
			
			if(queryb(t) >= querya(i) || queryb(t) >= mx) {
				return 0;
			}
			if(t == nowl - 1) {
				return 0;
			}
			noww = t; i = p;
		}
		for(int j = noww - 1; j >= nowl; j --) {
			if(queryb(j) >= lasmin) {
				return 0;
			}
		}
		return 1;
}
void solve() {
	nowcnt ++; int x, y;
	if(nowcnt >= 2) {
		read(P); read(Q);
		for(int i = 1; i <= P; i ++) read(x), read(y), dfna[x] = nowcnt, a[x] = y;
		for(int i = 1; i <= Q; i ++) read(x), read(y), dfnb[x] = nowcnt, b[x] = y;	
	}
	if(querya(n) == queryb(m)) {
		printf("0"); return;
	}
	b[m + 1] = 0x3f3f3f3f;
	if(n <= 2000 && m <= 2000 && 0) {
		dp[0][0] = 1;
		for(int i = 1; i <= n; i ++) {
			x = (dfna[i] == nowcnt ? a[i] : X[i]);
			for(int j = 1; j <= m; j ++) {
				y = (dfnb[j] == nowcnt ? b[j] : Y[j]);
				if(querya(n) < queryb(m) && x >= y) {
					dp[i][j] = 0; continue;
				}
				if(querya(n) > queryb(m) && x <= y) {
					dp[i][j] = 0; continue;
				}
				dp[i][j] = dp[i - 1][j] | dp[i][j - 1] | dp[i - 1][j - 1];
			}
		}
		printf("%d", dp[n][m]); return;
	}
	if(querya(n) < queryb(m)) {
		int noww = 1, lasmin = 0x3f3f3f3f, lasid;
		for(int i = 1; i <= n; i ++) {
			if(noww == m) {
				printf("1"); return;
			}
			int p = i, mx = querya(p);
			while(p + 1 <= n && querya(p + 1) >= querya(i)) p ++, mx = max(mx, querya(p));
			if(p == n) {
				printf("%d", calc(i, p, noww, m, 0)); return;
			}
			lasmin = querya(i); lasid = i;
			int t = noww;// printf("|%d %d %d %d|\n", t, p, n, m);
			if(queryb(t) <= querya(i)) {
				printf("0"); return;
			}
			while(t <= m && queryb(t) <= mx && queryb(t) > querya(i)) t ++;
			
			if(queryb(t) <= querya(i) || queryb(t) <= mx) {
				printf("0"); return;
			}
			if(t == m + 1) {
				printf("0"); return;
			}
			noww = t; i = p;
//			if(nowcnt == 15) printf("|%d %d %d %d %d|\n", t, p, n, m, queryb(t));
		}
		if(lasmin == querya(n)) {
			for(int j = noww + 1; j <= m; j ++) {
				if(queryb(j) <= lasmin) {
	//				if(nowcnt == 15) {
	//					printf("|%d %d|\n", lasmin, queryb(j));
	//				}
					printf("0"); return;
				}
			}
		}
		else {
			printf("%d", calc(lasid, n, noww, m, 0)); return;
		}
	}
	else {
		int noww = 1, lasmin = 0x3f3f3f3f, lasid;
		for(int i = 1; i <= n; i ++) {
			if(noww == m) {
				for(int j = i; j <= n; j ++) {
					if(querya(j) <= queryb(m)) {
						printf("0"); return;
					}
				}
				printf("1"); return;
			}
			int p = i, mn = querya(p); lasid = i;
			while(p + 1 <= n && querya(p + 1) <= querya(i)) p ++, mn = min(mn, querya(p)); 
			if(p == n) {
				printf("%d", calc(i, p, noww, m, 1)); return;
			}
			int t = noww; lasmin = querya(i);
			if(queryb(t) >= querya(i)) {
				printf("0"); return;
			}
			while(t <= m && queryb(t) >= mn && queryb(t) < querya(i)) t ++;
			if(queryb(t) >= querya(i) || queryb(t) >= mn) {
				printf("0"); return;
			}
			if(t == m + 1) {
				printf("0"); return;
			}
			noww = t; i = p;
	//		printf("|%d %d|\n", t, p);
		}
		if(lasmin == querya(n)) {
			for(int j = noww + 1; j <= m; j ++) {
				if(queryb(j) >= lasmin) {
					printf("0"); return;
				}
			}
		}
		else {
			printf("%d", calc(lasid, n, noww, m, 0)); return;
		}
	}
	printf("1");
}
int main() {
//	freopen("A.txt", "r", stdin);
//	freopen("B.txt", "w", stdout);
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);
	read(C); read(n); read(m); read(q);
	for(int i = 1; i <= n; i ++) read(X[i]);
	for(int i = 1; i <= m; i ++) read(Y[i]);
	int x, y; solve();
	while(q --) {
		solve();// return 0;
	}
//	printf("|%d|", cnt);
	return 0;
}
/*
5 3 3 100
3 2 1
4 1 4
*/
