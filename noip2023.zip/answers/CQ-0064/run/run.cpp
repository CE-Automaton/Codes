#include<bits/stdc++.h>
using namespace std;
const int N=105;
int c,T,n,m,k,d;
long long dp[N],maxx[N];
struct nn{
	int l,r,v;
}a[N];
long long calc(int x,int y)
{
	long long res=0;
	for(int i=1;i<=m;i++)if(a[i].l>=x&&a[i].r<=y)res+=a[i].v;
	return res;
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	cin>>c>>T;
	while(T--)
	{
		cin>>n>>m>>k>>d;
		for(int i=1;i<=m;i++)
		{
			int x,y,v;
			cin>>x>>y>>v;
			a[i].l=x-y+1,a[i].r=x,a[i].v=v;
		}
		memset(dp,-0x3f,sizeof(dp));
		memset(maxx,0,sizeof(maxx));
		dp[0]=0;
		for(int i=1;i<=n;i++)
		{
			for(int j=0;j<k;j++)
			{
				int xx=i-j;
				if(xx<=0)break;
				long long val=calc(xx,i);
				dp[i]=max(dp[i],maxx[max(0,xx-2)]+val-(j+1)*d);
			}
			maxx[i]=max(maxx[i-1],dp[i]);
		}
		cout<<maxx[n]<<'\n';
	}
	return 0;
}
