#include<bits/stdc++.h>
using namespace std;
const int N=2e2+5;
int c,n,m,q,x[N],y[N],tmpx[N],tmpy[N],posx[N],posy[N],valx[N],valy[N];
bool dp[N][N],flag;
bool pd(int pos,int l,int r)
{
	for(int i=l;i<=r;i++)
	{
		if(x[pos]==y[i])return false;
		if((x[pos]>y[i])^(x[1]>y[1]))return false;
	}
	return true;
}
void solve()
{
	flag=x[1]>y[1];
	if(x[1]==y[1])
	{
		cout<<0;
		return;
	}
	memset(dp,0,sizeof(dp));
	dp[1][1]=1;
	for(int i=2;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			for(int k=1;k<j;k++)
			{
				if(pd(i,k+1,j))dp[i][j]=max(dp[i][j],dp[i-1][k]);
				if(dp[i][j])break;
			}
			if(pd(i,j,j))dp[i][j]=max(dp[i][j],dp[i-1][j]);
		}
	}
	cout<<dp[n][m];
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	cin>>c>>n>>m>>q;
	for(int i=1;i<=n;i++)cin>>x[i],tmpx[i]=x[i];
	for(int i=1;i<=m;i++)cin>>y[i],tmpy[i]=y[i];
	solve();
	while(q--)
	{
		int kx,ky;
		cin>>kx>>ky;
		for(int i=1;i<=kx;i++)cin>>posx[i]>>valx[i],x[posx[i]]=valx[i];
		for(int i=1;i<=ky;i++)cin>>posy[i]>>valy[i],y[posy[i]]=valy[i];
		solve();
		for(int i=1;i<=kx;i++)x[posx[i]]=tmpx[posx[i]];
		for(int i=1;i<=ky;i++)y[posy[i]]=tmpy[posy[i]];
	}
	return 0;
}

