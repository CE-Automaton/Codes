#include<bits/stdc++.h>
using namespace std;
const int N=3005;
int n,m,cnt[N][30],minn[N],maxx[N];
string s;
bool pd(int x,int y)
{
	if(minn[x]<maxx[y])return true;
	return false;
}
bool check(int x)
{
	for(int i=1;i<=n;i++)if(x!=i&&!pd(x,i))return false;
	return true;
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	cin>>n>>m;
	memset(minn,0x3f,sizeof(minn));
	for(int i=1;i<=n;i++)
	{
		cin>>s;
		for(int j=0;j<m;j++)
		{
			int x=s[j]-'a';
			cnt[i][x]++,minn[i]=min(minn[i],x),maxx[i]=max(maxx[i],x);
		}
	}
	for(int i=1;i<=n;i++)cout<<check(i);
	return 0;
}

