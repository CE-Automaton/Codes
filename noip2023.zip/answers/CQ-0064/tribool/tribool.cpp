#include<bits/stdc++.h>
using namespace std;
const int N=1e5+5;
int c,T,n,m,val1[N],val2[N],p[2*N];
bool flag[2*N];
int getfa(int x)
{
	if(p[x]==x)return x;
	return p[x]=getfa(p[x]);
}
void Merge(int x,int y)
{
	x=getfa(x),y=getfa(y);
	if(x!=y)p[y]=x;
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	cin>>c>>T;
	while(T--)
	{
		cin>>n>>m;
		for(int i=1;i<=n;i++)val1[i]=i,val2[i]=0;
		for(int i=1;i<=m;i++)
		{
			char op;
			int x,y;
			cin>>op>>x;
			if(op=='F')val1[x]=0,val2[x]=-1;
			if(op=='T')val1[x]=1,val2[x]=-1;
			if(op=='U')val1[x]=2,val2[x]=-1;
			if(op=='+')cin>>y,val1[x]=val1[y],val2[x]=val2[y];
			if(op=='-')
			{
				cin>>y;
				if(val2[y]==-1)
				{
					val2[x]=-1;
					if(val1[y]==2)val1[x]=2;
					else val1[x]=1-val1[y];
				}
				else val1[x]=val1[y],val2[x]=(val2[y]^1);
			}
		}
		memset(flag,0,sizeof(flag));
		for(int i=1;i<=2*n;i++)p[i]=i;
		for(int i=1;i<=n;i++)
		{
			if(!val2[i])Merge(i,val1[i]),Merge(i+n,val1[i]+n);
			else if(val2[i]==1)Merge(i,val1[i]+n),Merge(i+n,val1[i]);
		}
		for(int i=1;i<=n;i++)
		{
			int x=getfa(i),y=getfa(i+n);
			if(val2[i]==-1&&val1[i]==2)flag[x]=flag[y]=1;
			if(x==y)flag[x]=1;
		}
		int res=0;
		for(int i=1;i<=n;i++)if(flag[getfa(i)])res++;
		cout<<res<<'\n';
	}
	return 0;
}

