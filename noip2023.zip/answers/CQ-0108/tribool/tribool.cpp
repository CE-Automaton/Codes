#include <bits/stdc++.h>
#define rep1(i, l, r) for (int i = l; i <= int(r); ++i)
#define rep2(i, l, r) for (int i = l; i >= int(r); --i)
#define fst first
#define snd second
#define eb emplace_back
#define mp make_pair
#define ptc putchar
#define il inline
using namespace std;
const int MAXN = 1e6 + 10;
typedef long long ll;
typedef unsigned long long ull;
typedef pair <int, int> pii;
typedef pair <ll, ll> pll;
namespace stupid_lrc {
	template <typename T> il void read(T &x) {
		x = 0; int f = 1; char ch;
		while (!isdigit(ch = getchar())) f -= (ch == '-') * 2;
		while (isdigit(ch)) x = (x << 1) + (x << 3) + (ch & 15), ch = getchar();
		x *= f;
	}

	template <typename T, typename ...L> il void read(T &x, L &...y) {
		read(x); read(y...);
	}

	template <typename T> il void read(pair <T, T> &x) {
		read(x.fst, x.snd);
	}

	il int read() {
		int x; read(x); return x;
	}

	template <typename T> il void gmin(T &x, T y) {
		x = x < y ? x : y;
	}

	template <typename T> il void gmax(T &x, T y) {
		x = x > y ? x : y;
	}
};
using namespace stupid_lrc;
int C, n, m, tot, pa[MAXN], idx[MAXN];
// T, F, U: n * 2 + 1, n * 2 + 2, n * 2 + 3

il int fpa(int x) {
	return x ^ pa[x] ? pa[x] = fpa(pa[x]) : x;
}

il void U(int x, int y) {
	x = fpa(x); y = fpa(y);
	pa[y] = x;
}

struct {
	int op, i, j, v;
} a[MAXN];

il void newnode(int x) {
	idx[x] = ++tot; pa[tot] = tot;
}

int main() {
	freopen("tribool.in", "r", stdin);
	freopen("tribool.out", "w", stdout);
	read(C);
	for (int T = read(); T--; ) {
		read(n, m); const int p = n << 1; tot = p + 3;
		rep1(i, 1, p + 3) pa[i] = idx[i] = i;
//		pa[p + 1] = p + 1; pa[p + 2] = p + 2; pa[p + 3] = p + 3;
		
		rep1(i, 1, m) {
			char ch; scanf(" %c", &ch);
			if (ch == 'T') {
				a[i].op = -1; read(a[i].i);
			} else if (ch == 'F') {
				a[i].op = -2; read(a[i].i);
			} else if (ch == 'U') {
				a[i].op = -3; read(a[i].i);
			} else if (ch == '+') {
				a[i].op = 1; read(a[i].i, a[i].j);
			} else {
				a[i].op = 2; read(a[i].i, a[i].j);
			}
		}
		
		rep1(i, 1, m) {
			int p1 = idx[a[i].j], p2 = idx[a[i].j + n];
//			if (a[i].op == 1 && a[i].i == a[i].j) continue;
			newnode(a[i].i), newnode(a[i].i + n);
//			vis[a[i].i] = 1;
//			cout << "!!" << a[i].i << ' ' << idx[a[i].i] << ' ' << idx[a[i].i + n] << endl;
			if (a[i].op == 1) {
				U(idx[a[i].i], p1);
				U(idx[a[i].i + n], p2);
			} else if (a[i].op == 2) {
				U(idx[a[i].i], p2);
				U(idx[a[i].i + n], p1);
			} else {
				if (a[i].op == -1) {
					U(idx[a[i].i], idx[p + 1]);
					U(idx[a[i].i + n], idx[p + 2]);
				} else if (a[i].op == -2) {
					U(idx[a[i].i], idx[p + 2]);
					U(idx[a[i].i + n], idx[p + 1]);
				} else {
					U(idx[a[i].i], idx[p + 3]);
					U(idx[a[i].i + n], idx[p + 3]);
				}
			}
		} int ans = 0;
//		cout << idx[2] << ' ' << idx[2 + n] << endl;
		rep1(i, 1, n) U(idx[i], i), U(idx[i + n], i + n);
		rep1(i, 1, n) ans += fpa(idx[i]) == fpa(idx[i + n]);
//		rep1(i, 1, n) if (fpa(i) == fpa(i + n)) printf("%d ", i); puts("");
		printf("%d\n", ans);
	}
	return 0;
}
/*
1 5
1 4
U 1
+ 1 1
+ 1 1
+ 1 1
3 1
T 2
4 2
U 2
T 3
5 5
U 5
T 4
T 1
U 2
+ 3 5
1 3
U 1
+ 1 1
T 1
*/
