#include <bits/stdc++.h>
#define rep1(i, l, r) for (int i = l; i <= int(r); ++i)
#define rep2(i, l, r) for (int i = l; i >= int(r); --i)
#define fst first
#define snd second
#define eb emplace_back
#define mp make_pair
#define ptc putchar
#define il inline
using namespace std;
const int MAXN = 2e5 + 10;
typedef long long ll;
typedef unsigned long long ull;
typedef pair <int, int> pii;
typedef pair <ll, ll> pll;
namespace stupid_lrc {
	template <typename T> il void read(T &x) {
		x = 0; int f = 1; char ch;
		while (!isdigit(ch = getchar())) f -= (ch == '-') * 2;
		while (isdigit(ch)) x = (x << 1) + (x << 3) + (ch & 15), ch = getchar();
		x *= f;
	}
	
	template <typename T, typename ...L> il void read(T &x, L &...y) {
		read(x); read(y...);
	}
	
	template <typename T> il void read(pair <T, T> &x) {
		read(x.fst, x.snd);
	}
	
	il int read() {
		int x; read(x); return x;
	}
	
	template <typename T> il void gmin(T &x, T y) {
		x = x < y ? x : y;
	}
	
	template <typename T> il void gmax(T &x, T y) {
		x = x > y ? x : y;
	}
};
using namespace stupid_lrc;
int n, m; char ch[3010][3010], ans[3010];
//int cnt[3010][30];

il bool check(int x, int y) {
	if (ch[x][1] < ch[y][m]) return true;
//	if (ch[x][1] > ch[y][m]) return false;
	return false;
//	int xp = ch[x][1] - 'a', yp = ch[y][m] - 'a';
//	if (cnt[x][xp] == m && cnt[y][yp] == m) return false;
//	return true;
}

int main() {
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);
	read(n, m);
	rep1(i, 1, n) scanf("%s", ch[i] + 1), sort(ch[i] + 1, ch[i] + 1 + m);
//	rep1(i, 1, n) {
//		rep1(j, 1, m) ++cnt[i][ch[i][j] - 'a'];
//	}
	rep1(i, 1, n) {
		int ok = 1;
		rep1(j, 1, n) if (i ^ j) {
			ok &= check(i, j);
			if (!ok) break;
		} ans[i] = ok + '0';
	} puts(ans + 1);
	return 0;
}
