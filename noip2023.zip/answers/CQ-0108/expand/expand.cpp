#include <bits/stdc++.h>
#define rep1(i, l, r) for (int i = l; i <= int(r); ++i)
#define rep2(i, l, r) for (int i = l; i >= int(r); --i)
#define rer(i, l, r, a) rep1(i, l, r) read(a[i])
#define fst first
#define snd second
#define eb emplace_back
#define mp make_pair
#define ptc putchar
#define il inline
using namespace std;
const int MAXN = 5e5 + 10;
typedef long long ll;
typedef unsigned long long ull;
typedef pair <int, int> pii;
typedef pair <ll, ll> pll;
namespace stupid_lrc {
	template <typename T> il void read(T &x) {
		x = 0; int f = 1; char ch;
		while (!isdigit(ch = getchar())) f -= (ch == '-') * 2;
		while (isdigit(ch)) x = (x << 1) + (x << 3) + (ch & 15), ch = getchar();
		x *= f;
	}

	template <typename T, typename ...L> il void read(T &x, L &...y) {
		read(x); read(y...);
	}

	template <typename T> il void read(pair <T, T> &x) {
		read(x.fst, x.snd);
	}

	il int read() {
		int x; read(x); return x;
	}

	template <typename T> il void gmin(T &x, T y) {
		x = x < y ? x : y;
	}

	template <typename T> il void gmax(T &x, T y) {
		x = x > y ? x : y;
	}
};
using namespace stupid_lrc;
int C, n, m, q, b1[MAXN], b2[MAXN], a[MAXN], b[MAXN];
int f[2010][2010];

il bool check() {
	if (a[1] <= b[1]) return false;
	int i = 1, j = 1;
	while (i <= n && j <= m) {
		if (i == n && j == m) return true;
		if (i < n && a[i + 1] > b[j]) ++i;
		else if (j < m && a[i] > b[j + 1]) ++j;
		else if (i < n && j < m && a[i + 1] > b[j + 1]) ++i, ++j;
		else break;
	} i = 1, j = 1;
	while (i <= n && j <= m) {
		if (i == n && j == m) return true;
		if (j < m && a[i] > b[j + 1]) ++j;
		else if (i < n && a[i + 1] > b[j]) ++i;
		else if (i < n && j < m && a[i + 1] > b[j + 1]) ++i, ++j;
		else return false;
	} return true;
}

il bool check2() {
	if (a[1] >= b[1]) return false;
	int i = 1, j = 1;
	while (i <= n && j <= m) {
		if (i == n && j == m) return true;
		if (i < n && a[i + 1] < b[j]) ++i;
		else if (j < m && a[i] < b[j + 1]) ++j;
		else if (i < n && j < m && a[i + 1] < b[j + 1]) ++i, ++j;
		else return false;
	} i = 1, j = 1;
	while (i <= n && j <= m) {
		if (i == n && j == m) return true;
		if (j < m && a[i] < b[j + 1]) ++j;
		else if (i < n && a[i + 1] < b[j]) ++i;
		else if (i < n && j < m && a[i + 1] < b[j + 1]) ++i, ++j;
		else return false;
	} return true;
}

il void solve() {
	rep1(i, 0, n) rep1(j, 0, m) f[i][j] = 0;
	f[0][0] = 1; int ok;
	rep1(i, 1, n) rep1(j, 1, m) if (a[i] > b[j]) {
		f[i][j] = f[i - 1][j] | f[i][j - 1] | f[i - 1][j - 1];
	} ok = f[n][m];
	rep1(i, 0, n) rep1(j, 0, m) f[i][j] = 0;
	f[0][0] = 1;
	rep1(i, 1, n) rep1(j, 1, m) if (a[i] < b[j]) {
		f[i][j] = f[i - 1][j] | f[i][j - 1] | f[i - 1][j - 1];
	} ok |= f[n][m];
	ptc(ok + '0');
}

int main() {
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);
	read(C, n, m, q);
	rer(i, 1, n, b1), a[i] = b1[i]; rer(i, 1, m, b2), b[i] = b2[i];
	solve();
	while (q--) {
		int kx, ky; read(kx, ky);
		rep1(i, 1, n) a[i] = b1[i];
		rep1(i, 1, m) b[i] = b2[i];
		rep1(i, 1, kx) {
			int p, x;
			read(p, x); a[p] = x;
		}
		rep1(i, 1, ky) {
			int p, x;
			read(p, x); b[p] = x;
		}
		solve();
	}
	return 0;
}

