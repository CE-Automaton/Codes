#include <bits/stdc++.h>
#define rep1(i, l, r) for (int i = l; i <= int(r); ++i)
#define rep2(i, l, r) for (int i = l; i >= int(r); --i)
#define fst first
#define snd second
#define eb emplace_back
#define mp make_pair
#define ptc putchar
#define il inline
using namespace std;
const int MAXN = 2e5 + 10;
typedef long long ll;
typedef unsigned long long ull;
typedef pair <int, int> pii;
typedef pair <ll, ll> pll;
#define int ll
namespace stupid_lrc {
	template <typename T> il void read(T &x) {
		x = 0; int f = 1; char ch;
		while (!isdigit(ch = getchar())) f -= (ch == '-') * 2;
		while (isdigit(ch)) x = (x << 1) + (x << 3) + (ch & 15), ch = getchar();
		x *= f;
	}

	template <typename T, typename ...L> il void read(T &x, L &...y) {
		read(x); read(y...);
	}

	template <typename T> il void read(pair <T, T> &x) {
		read(x.fst, x.snd);
	}

	il int read() {
		int x; read(x); return x;
	}

	template <typename T> il void gmin(T &x, T y) {
		x = x < y ? x : y;
	}

	template <typename T> il void gmax(T &x, T y) {
		x = x > y ? x : y;
	}
};
using namespace stupid_lrc;
int C, n, m, k, d; ll f[1010][1010], maa[1010];
vector <pll> bon[1010];

signed main() {
	freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);
	read(C);
	for (int T = read(); T--; ) {
		read(n, m, k, d);
		rep1(i, 1, n) bon[i].clear();
		rep1(i, 1, m) {
			int x, y, k;
			read(x, y, k); bon[x].eb(y, k);
		}
		rep1(i, 1, n) if (bon[i].size()) {
			sort(bon[i].begin(), bon[i].end());
			int len = bon[i].size();
			rep1(j, 1, len - 1) bon[i][j].snd += bon[i][j - 1].snd;
		}
		rep1(i, 0, n) rep1(j, 0, n) f[i][j] = 0;
//		rep1(i, 0, n) maa[i] = 0;
		rep1(i, 1, n) {
//			maa[i] = maa[i - 1];
			rep1(j, 0, min(i - 1, k)) gmax(f[i][0], f[i - 1][j]);
			rep1(j, 1, min(i, k)) {
				ll dt = 0;
				auto it = upper_bound(bon[i].begin(), bon[i].end(), mp(j, LLONG_MAX));
				if (it != bon[i].begin()) dt = (--it) -> snd;
				f[i][j] = f[i - 1][j - 1] + dt - d;
//				gmax(maa[i], f[i][j]);
//				cout << "!!" << i << ' ' << j << ' ' << f[i][j] << endl;
			}
		} ll ans = 0;
		rep1(i, 1, n) rep1(j, 0, min(i, k)) gmax(ans, f[i][j]);
		printf("%lld\n", ans);
	}
	return 0;
}

