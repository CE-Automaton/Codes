#include<bits/stdc++.h>
#define int long long
using namespace std;
bool ppp;
int n,m,t=0,b[6005],c[6005],C[6005];
char a[6005][3005];
bool pppp;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline bool CMP(char x,char y){
    return x>y;
}
inline bool cmp(int x,int y){
    if(c[x]==c[y]) return a[x][t]<a[y][t];
    return c[x]<c[y];
}
signed main(){
    freopen("dict.in","r",stdin);
    freopen("dict.out","w",stdout);
    // cerr<<(double)(&ppp-&pppp)/1024.0/1024.0<<"MB\n";
    n=read(),m=read();
    for(int i=1;i<=n;i++) scanf("%s",a[i]+1);
    for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) a[i+n][j]=a[i][j];
    for(int i=1;i<=n;i++) sort(a[i]+1,a[i]+1+m),sort(a[i+n]+1,a[i+n]+1+m,CMP);
    for(int i=1;i<=(n<<1);i++) b[i]=i,c[i]=1;
    sort(b+1,b+1+(n<<1),cmp);
    c[0]=-1e9;
    int d=0;
    for(int i=1;i<=(n<<1);i++){
        if((c[b[i]]!=c[b[i-1]])||(a[b[i]][t]!=a[b[i-1]][t])) d++;
        c[b[i]]=d;
    }
    for(int i=1;i<=m;i++){
        t++;
        sort(b+1,b+1+(n<<1),cmp);
        d=0;
        for(int j=1;j<=(n<<1);j++) C[j]=c[j];
        for(int j=1;j<=(n<<1);j++){
            if((C[b[j]]!=C[b[j-1]])||(a[b[j]][t]!=a[b[j-1]][t])) d++;
            c[b[j]]=d;
        }
    }
    for(int i=1;i<=n;i++){
        bool f=1;
        for(int j=1;j<=n;j++){
            if(i==j) continue;
            if(c[j+n]<=c[i]) f=0;
        }
        if(f) putchar('1');
        else putchar('0');
    }
    return 0;
}