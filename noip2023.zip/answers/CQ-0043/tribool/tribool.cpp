#include<bits/stdc++.h>
#define int long long
using namespace std;
bool ppp;
int T,tid,n,m,f[400005],rt[400005],cnt,c[400005],ans,sz[400005],dfn[400005],low[400005],tnt,tot,id[400005],b[400005];
bool v[400005],vis[400005];
vector<int> e[400005],E[400005];
stack<int> q;
struct ok{
    char t1;
    int t2,t3;
}a[100005];
bool pppp;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void add(int x,int y){
    e[x].push_back(y);
}
inline int find(int k){
    if(k==f[k]) return k;
    return f[k]=find(f[k]);
}
inline void dfs(int k){
    dfn[k]=low[k]=++tnt;vis[k]=1;q.push(k);
    for(int i=0;i<(int)e[k].size();i++){
        int d=e[k][i];
        if(!dfn[d]){
            dfs(d);
            low[k]=min(low[k],low[d]);
        }
        else if(vis[d]) low[k]=min(low[k],dfn[d]);
    }
    if(low[k]>=dfn[k]){
        tot++;
        while(q.top()!=k){
            E[tot].push_back(q.top());
            vis[q.top()]=0;id[q.top()]=tot;
            q.pop();
        }
        E[tot].push_back(q.top());
        vis[q.top()]=0;id[q.top()]=tot;
        q.pop();
    }
}
inline void dfs1(int k){
    if(k==(n+1)){
        for(int i=1;i<=n;i++) c[i]=b[i];
        for(int i=1;i<=m;i++){
            if(a[i].t1=='+') c[a[i].t2]=c[a[i].t3];
            if(a[i].t1=='-'){
                if(c[a[i].t3]==2) c[a[i].t2]=c[a[i].t3];
                else c[a[i].t2]=c[a[i].t3]^1;
            }
            if(a[i].t1=='U') c[a[i].t2]=2;
            if(a[i].t1=='T') c[a[i].t2]=0;
            if(a[i].t1=='F') c[a[i].t2]=1; 
        }
        bool f=1;
        for(int i=1;i<=n;i++) if(c[i]!=b[i]) f=0;
        if(f){
            int d=0;
            for(int i=1;i<=n;i++) if(b[i]==2) d++;
            ans=min(ans,d);
        }
        return;
    }
    for(int i=0;i<=2;i++){
        b[k]=i;
        dfs1(k+1);
    }
}
inline void solve1(){
    for(int i=1;i<=m;i++){
            cin>>a[i].t1;
            a[i].t2=read();
            if(a[i].t1=='+'||a[i].t1=='-') a[i].t3=read();
        }
    ans=1e18;
    dfs1(1);
    cout<<ans<<"\n";
}
inline void solve2(){
    for(int i=1;i<=m;i++){
            cin>>a[i].t1;
            a[i].t2=read();
            if(a[i].t1=='+'||a[i].t1=='-') a[i].t3=read();
        }
    for(int i=1;i<=n;i++) b[i]=3;
    for(int i=1;i<=m;i++){
        if(a[i].t1=='U') b[a[i].t2]=2;
        if(a[i].t1=='T') b[a[i].t2]=0;
        if(a[i].t1=='F') b[a[i].t2]=1;
    }
    ans=0;
    for(int i=1;i<=n;i++) if(b[i]==2) ans++;
    cout<<ans<<"\n";
}
signed main(){
    freopen("tribool.in","r",stdin);
    freopen("tribool.out","w",stdout);
    // cerr<<(double)(&ppp-&pppp)/1024.0/1024.0<<"MB\n";
    tid=read(),T=read();
    while(T--){
        n=read(),m=read();
        if(n<=10){
            // cerr<<"bom\n";
            solve1();
            continue;
        }
        else if(tid<=4){
            solve2();
            continue;
        }
        for(int i=1;i<=400000;i++) b[i]=0,f[i]=i,rt[i]=0,v[i]=0,sz[i]=0,vis[i]=0,e[i].clear(),E[i].clear(),dfn[i]=low[i]=0;
        for(int i=1;i<=n;i++) c[i]=i*2-1;
        cnt=n<<1;tnt=tot=0;
        for(int i=1;i<=m;i++){
            cin>>a[i].t1;
            a[i].t2=read();
            if(a[i].t1=='+'){
                a[i].t3=read();
                a[i].t2=c[a[i].t2];a[i].t3=c[a[i].t3];
                add(a[i].t3,a[i].t2);
                add(a[i].t3+1,a[i].t2+1);
                int d1=find(a[i].t2),d2=find(a[i].t3);
                if(d1!=d2) f[d1]=f[d2];
                d1=find(a[i].t2+1);d2=find(a[i].t3+1);
                if(d1!=d2) f[d1]=f[d2];
            }
            else if(a[i].t1=='-'){
                a[i].t3=read();
                a[i].t2=c[a[i].t2];a[i].t3=c[a[i].t3];
                add(a[i].t3,a[i].t2+1);
                add(a[i].t3+1,a[i].t2);
                int d1=find(a[i].t2),d2=find(a[i].t3+1);
                if(d1!=d2) f[d1]=f[d2];
                d1=find(a[i].t2+1);d2=find(a[i].t3);
                if(d1!=d2) f[d1]=f[d2];
            }
            else if(a[i].t1=='T'){
                cnt++;
                rt[c[a[i].t2]]=2;
                rt[c[a[i].t2]+1]=3;
                rt[cnt]=2;
                rt[cnt+1]=3;
                c[a[i].t2]=cnt;
                cnt++;
            }
            else if(a[i].t1=='F'){
                cnt++;
                rt[c[a[i].t2]]=3;
                rt[c[a[i].t2]+1]=2;
                c[a[i].t2]=cnt;
                rt[cnt]=3;
                rt[cnt+1]=2;
                cnt++;
            }
            else{
                cnt++;
                rt[c[a[i].t2]]=1;
                rt[c[a[i].t2]+1]=1;
                c[a[i].t2]=cnt;
                rt[cnt]=1;
                rt[cnt+1]=1;
                cnt++;
            }
        }
        for(int i=1;i<=cnt;i++) if(!dfn[i]) dfs(i);
        ans=0;
        for(int i=1;i<=n;i++){
            sz[find(c[i])]++,sz[find(c[i]+1)]++;
            if(id[c[i]]==id[c[i]+1]) rt[find(c[i])]=rt[find(c[i]+1)]=1;
        }
        for(int i=1;i<=cnt;i++){
            if(sz[i]){
                if(rt[i]==1) ans+=sz[i];
            }
        }
        cout<<ans/2<<"\n";
    }
    return 0;
}
/*
T2�����ԣ����ˡ�
�������ֻ������͵�����

AFO�� 
*/
