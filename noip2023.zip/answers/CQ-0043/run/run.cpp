#include<bits/stdc++.h>
#define int long long
using namespace std;
bool ppp;
int tid,T,n,m,K,D,t1,t2,t3,dp[50005][1005];
vector<pair<int,int>> e[100005];
bool pppp;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
signed main(){
    freopen("run.in","r",stdin);
    freopen("run.out","w",stdout);
    // cerr<<(double)(&ppp-&pppp)/1024.0/1024.0<<"MB\n";
    tid=read(),T=read();
    while(T--){
        n=read(),m=read(),K=read(),D=read();
        for(int i=1;i<=m;i++){
            t1=read(),t2=read(),t3=read();
            e[t1].push_back(make_pair(t2,t3));
        }
        for(int i=0;i<=n;i++) for(int j=0;j<=m;j++) dp[i][j]=-1e16;
        dp[0][0]=0;
        for(int i=0;i<=n;i++){
            for(int j=0;j<(int)e[i].size();j++){
                // cerr<<i<<" "<<e[i][j].first<<"\n";
                for(int g=e[i][j].first;g<=min(i,K);g++) dp[i][g]+=e[i][j].second;
            }
            if(i<n){
                for(int j=0;j<=min(i,K);j++){
                    if(dp[i][j]<(-(int)1e15)) break;
                    dp[i+1][j+1]=max(dp[i+1][j+1],dp[i][j]-D);
                    dp[i+1][0]=max(dp[i+1][0],dp[i][j]);
                }
            } 
        }
        // for(int i=0;i<=n;i++){
        //     for(int j=0;j<=min(i,K);j++) cerr<<i<<" "<<j<<" "<<dp[i][j]<<"\n";
        // }
        int ans=-1e18;
        for(int i=0;i<=min(K,n);i++) ans=max(ans,dp[n][i]);
        cout<<ans<<"\n";
        for(int i=1;i<=n;i++) e[i].clear();
    }
    return 0;
}