#include<bits/stdc++.h>
#define int long long
using namespace std;
bool ppp;
int tid,n,m,q,a[500005],b[500005],A[500005],B[500005],t1,t2,t3,t4;
vector<int> e,E;
bool f;
bool pppp;
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline int js(){
    e.clear();
    e.push_back(m);
    for(int i=n;i>=1;i--){
        int t=m;E.clear();
        int o=0;
        if(n>2000||m>2000) o=max(o,(int)e.size()-10000);
        for(int j=o;j<(int)e.size();j++){
            t=min(t,e[j]);
            // cerr<<i<<" "<<j<<" "<<t<<"\n";
            while(t&&a[i]>b[t]) E.push_back(t),t--;
            // cerr<<i<<" "<<j<<" "<<t<<"\n";
        }
        if(E.empty()) return 0;
        e=E;
    }
    if(e.back()>1) return 0;
    return 1;
}
inline int js2(){
    e.clear();
    e.push_back(n);
    for(int i=m;i>=1;i--){
        int t=n;E.clear();
        int o=0;
        if(n>2000||m>2000) o=max(o,(int)e.size()-10000);
        // cerr<<o<<"\n";
        for(int j=o;j<(int)e.size();j++){
            // cerr<<i<<" "<<j<<"\n";
            t=min(t,e[j]);
            while(t&&b[i]>a[t]) E.push_back(t),t--;
        }
        if(E.empty()) return 0;
        e=E;
    }
    if(e.back()>1) return 0;
    return 1;
}
signed main(){
    freopen("expand.in","r",stdin);
    freopen("expand.out","w",stdout);
    // cerr<<(double)(&ppp-&pppp)/1024.0/1024.0<<"MB\n";
    tid=read(),n=read(),m=read(),q=read();
    for(int i=1;i<=n;i++) A[i]=a[i]=read();
    for(int i=1;i<=m;i++) B[i]=b[i]=read();
    f=js()|js2();
    if(f) putchar('1');
    else putchar('0');
    for(int i=1;i<=q;i++){
        // cerr<<i<<"\n";
        t1=read(),t2=read();
        for(int j=1;j<=n;j++) a[j]=A[j];
        for(int j=1;j<=m;j++) b[j]=B[j];
        for(int j=1;j<=t1;j++){
            t3=read(),t4=read();
            a[t3]=t4;
        }
        for(int j=1;j<=t2;j++){
            t3=read(),t4=read();
            b[t3]=t4;
        }
        // for(int j=1;j<=n;j++) cout<<a[j]<<" ";
        // cout<<"\n";
        // for(int j=1;j<=m;j++) cout<<b[j]<<" ";
        // cout<<"\n";
        // cerr<<"bom\n";
        f=js()|js2();
        if(f) putchar('1');
        else putchar('0');
    }
    return 0;
}