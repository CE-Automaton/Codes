// rp++
#include<bits/stdc++.h>
#define inl inline
using namespace std;
const int N=3005,IB=1<<21; char IN[IB],*IS=IN+IB,*IT=IS;
#define getchar() (IS==IT&&(fread(IS=IN,1,IB,stdin)),*IS++)
int n,m,fi,se,a[N][N],b[N][N];
inl void G(int p)
{
	for(int i=1;i<=m&&b[p][i]<=b[se][i];++i)
		if(b[p][i]<b[se][i]) return se=p, void();
}
int main()
{
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	scanf("%d%d",&n,&m); b[0][1]=26; for(int i=1;i<=n;++i)
	{
		char c; while(!isalpha(c=getchar()));
		for(int j=1;j<=m;++j) a[i][j]=b[i][j]=c-'a', c=getchar();
		sort(a[i]+1,a[i]+m+1); sort(b[i]+1,b[i]+m+1,greater<int>());
		for(int j=1;j<=m&&b[i][j]<=b[fi][j];++j)
			if(b[i][j]<b[fi][j]) {G(fi); fi=i; break; }
		fi!=i&&(G(i),0);
	}
	for(int i=1;i<=n;++i)
	{
		int j=1,an=1,t=i==fi?se:fi;
		for(;j<=m&&an&&a[i][j]>=b[t][j];++j) an&=a[i][j]==b[t][j];
		putchar((j<=m&&an)+'0');
	}
	return 0;
}
