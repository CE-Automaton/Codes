// faith++
#include<bits/stdc++.h>
#define inl inline
using namespace std;
const int N=5e5+5,IB=1<<21; char IN[IB],*IS=IN+IB,*IT=IS;
#define getchar() (IS==IT&&(fread(IS=IN,1,IB,stdin)),*IS++)
int on,om,n,m,Q,oa[N],ob[N],a[N],b[N],ma[N],mb[N],st[N],ca[N][2],cb[N][2];
inl int Read()
{
	int s=0; char c; while(!isdigit(c=getchar()));
	for(;isdigit(c);c=getchar()) s=s*10+c-'0'; return s;
}
inl int Getl(int pa,int pb,int t)
{
	if(t)
	{
		if(!cb[pb][0]) return 1;
		int i=pb; while(cb[i][0]&&b[cb[i][0]]>ma[pa-1]) i=cb[i][0];
		return i==pb?0:Getl(pa,i,0);
	}
	else
	{
		if(!ca[pa][0]) return 1;
		int i=pa; while(ca[i][0]&&a[ca[i][0]]<mb[pb-1]) i=ca[i][0];
		return i==pa?0:Getl(i,pb,1);
	}
}
inl int Getr(int pa,int pb,int t)
{
	if(t)
	{
		if(!cb[pb][1]) return 1;
		int i=pb; while(cb[i][1]&&b[cb[i][1]]>ma[pa+1]) i=cb[i][1];
		return i==pb?0:Getr(pa,i,0);
	}
	else
	{
		if(!ca[pa][1]) return 1;
		int i=pa; while(ca[i][1]&&a[ca[i][1]]<mb[pb+1]) i=ca[i][1];
		return i==pa?0:Getr(i,pb,1);
	}
}
inl int Solve()
{
	if(a[1]==b[1]||a[n]==b[m]||(a[1]<b[1])!=(a[n]<b[m])) return 0;
	a[1]>b[1]&&(swap(a,b),n^=m^=n^=m);
	ma[0]=ma[n+1]=0; mb[0]=mb[m+1]=2e9; int tp,rta,rtb;
	tp=0; for(int i=1;i<=n;++i)
	{
		ca[i][0]=ca[i][1]=0;
		while(tp>1&&a[st[tp-1]]>a[i]) ca[st[tp-1]][1]=st[tp], --tp;
		tp&&a[st[tp]]>=a[i]&&(ca[i][0]=st[tp--]); st[++tp]=i;
	}
	rta=st[1]; while(tp>1) ca[st[tp-1]][1]=st[tp], --tp;
	tp=0; for(int i=1;i<=m;++i)
	{
		cb[i][0]=cb[i][1]=0;
		while(tp>1&&b[st[tp-1]]<b[i]) cb[st[tp-1]][1]=st[tp], --tp;
		tp&&b[st[tp]]<=b[i]&&(cb[i][0]=st[tp--]); st[++tp]=i;
	}
	rtb=st[1]; while(tp>1) cb[st[tp-1]][1]=st[tp], --tp;
	for(int i=1;i<=n;++i) if(a[i]>=b[rtb]) return 0;
	for(int i=1;i<=m;++i) if(b[i]<=a[rta]) return 0;
	for(int i=1;i<rta;++i) ma[i]=max(ma[i-1],a[i]);
	for(int i=1;i<rtb;++i) mb[i]=min(mb[i-1],b[i]);
	for(int i=n;i>rta;--i) ma[i]=max(ma[i+1],a[i]);
	for(int i=m;i>rtb;--i) mb[i]=min(mb[i+1],b[i]);
	if(!Getl(rta,rtb,0)&&!Getl(rta,rtb,1)) return 0;
	if(!Getr(rta,rtb,0)&&!Getr(rta,rtb,1)) return 0;
	return 1;
}
int main()
{
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	Read(); n=on=Read(); m=om=Read(); Q=Read();
	for(int i=1;i<=n;++i) a[i]=oa[i]=Read(); for(int i=1;i<=m;++i) b[i]=ob[i]=Read();
	for(putchar(Solve()+'0');Q--;putchar(Solve()+'0'))
	{
		n=on; m=om; int x=Read(),y=Read();
		for(int i=1;i<=n;++i) a[i]=oa[i]; for(int i=1;i<=m;++i) b[i]=ob[i];
		for(int t;x--;t=Read(),a[t]=Read()); for(int t;y--;t=Read(),b[t]=Read());
	}
	return 0;
}
