// karma++
#include<bits/stdc++.h>
#define inl inline
using namespace std;
typedef long long ll;
const int N=2e5+5,IB=1<<21; char IN[IB],*IS=IN+IB,*IT=IS;
#define getchar() (IS==IT&&(fread(IS=IN,1,IB,stdin)),*IS++)
struct A {int l,r,v; }a[N]; vector<A> b[N];
struct TR {ll v,t; }tr[N*4];
int T,n,m,K,D,ls,lh[N]; ll f[N];
inl int Read()
{
	int s=0; char c; while(!isdigit(c=getchar()));
	for(;isdigit(c);c=getchar()) s=s*10+c-'0'; return s;
}
inl void GLH(int &v) {v=lower_bound(lh+1,lh+ls+1,v)-lh; }
#define L (p<<1)
#define R (L|1)
#define md ((l+r)>>1)
inl void PU(int p) {tr[p].v=max(tr[L].v,tr[R].v); }
inl void PO(int p,ll t) {tr[p].v+=t; tr[p].t+=t; }
inl void PD(int p) {ll &t=tr[p].t; t&&(PO(L,t),PO(R,t),t=0); }
inl void BD(int p,int l,int r)
{
	tr[p].v=-LLONG_MAX; tr[p].t=0;
	l<r&&(BD(L,l,md),BD(R,md+1,r),0);
}
inl void MD(int p,int l,int r,int ra,ll t)
{
	if(l>ra) return; if(r<=ra) return PO(p,t);
	PD(p); MD(L,l,md,ra,t); MD(R,md+1,r,ra,t); PU(p);
}
inl void AD(int p,int l,int r,int po,ll v)
{
	if(l==r) return tr[p].v=v, void(); PD(p);
	po<=md?AD(L,l,md,po,v):AD(R,md+1,r,po,v); PU(p);
}
#undef L
#undef R
#undef md
int main()
{
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	for(Read(),T=Read();T--;printf("%lld\n",f[ls]))
	{
		n=Read(); m=Read(); K=Read(); D=Read(); ls=0;
		for(int i=1;i<=m;++i) lh[++ls]=a[i].r=Read(), lh[++ls]=a[i].l=a[i].r-Read(), a[i].v=Read();
		lh[++ls]=0; sort(lh+1,lh+ls+1); ls=unique(lh+1,lh+ls+1)-lh-1;
		for(int i=1;i<=ls;++i) b[i].clear();
		for(int i=1;i<=m;++i) GLH(a[i].l), GLH(a[i].r), b[a[i].r].push_back(a[i]);
		BD(1,1,ls); AD(1,1,ls,1,0); for(int i=2,j=1;i<=ls;++i)
		{
			AD(1,1,ls,i,f[i-1]+1ll*D*lh[i]);
			while(j<i&&lh[i]-lh[j]>K) AD(1,1,ls,j++,-LLONG_MAX);
			for(A v:b[i]) MD(1,1,ls,v.l,v.v);
			f[i]=max(-1ll*D*lh[i]+tr[1].v,0ll);
		}
	}
	return 0;
}
/*
#include<bits/stdc++.h>
#define inl inline
using namespace std;
typedef long long ll;
char MST;
const int M=1e5+5,IB=1<<21; char IN[IB],*IS=IN+IB,*IT=IS;
#define getchar() (IS==IT&&(fread(IS=IN,1,IB,stdin)),*IS++)
struct A {int l,r,v; }a[M];
int T,n,m,K,D,ls,lh[M*2];
inl int Read()
{
	int s=0; char c; while(!isdigit(c=getchar()));
	for(;isdigit(c);c=getchar()) s=s*10+c-'0'; return s;
}
inl void GLH(int &v) {v=lower_bound(lh+1,lh+ls+1,v)-lh; }
namespace C1
{
	const int N=2e3+5;
	ll g[N][N],f[N];
	inl void mian()
	{
		for(int i=1;i<=ls;++i) for(int j=i;j<=ls;++j) g[i][j]=0;
		for(int i=1;i<=m;++i) g[a[i].l][a[i].r]+=a[i].v;
		for(int i=ls-1;i;--i)
		{
			for(int j=i+1;j<=ls&&lh[j]-lh[i]<=K;++j) g[i][j]+=g[i][j-1];
			for(int j=i+1;j<=ls&&lh[j]-lh[i]<=K;++j) g[i][j]+=g[i+1][j];
		}
		for(int i=2;i<=ls;++i)
		{
			f[i]=0; for(int j=i;j&&lh[i]-lh[j]<=K;--j)
				f[i]=max(f[i],f[j-1]+g[j][i]-1ll*(lh[i]-lh[j])*D);
		}
		printf("%lld\n",f[ls]);
	}
}
namespace C2
{
	const int N=2e5+5;
	ll g[N][105],f[N];
	inl void mian()
	{
		for(int i=1;i<=ls;++i) for(int j=0;j<=K;++j) g[i][j]=0;
		for(int i=1;i<=m;++i) if(a[i].r-a[i].l<=K) g[a[i].l][a[i].r-a[i].l]+=a[i].v;
		for(int i=ls-1;i;--i)
		{
			for(int j=i+1;j<=ls&&lh[j]-lh[i]<=K;++j) g[i][j-i]+=g[i][j-i-1];
			for(int j=i+1;j<=ls&&lh[j]-lh[i]<=K;++j) g[i][j-i]+=g[i+1][j-i-1];
		}
		for(int i=2;i<=ls;++i)
		{
			f[i]=0; for(int j=i;j&&lh[i]-lh[j]<=K;--j)
				f[i]=max(f[i],f[j-1]+g[j][i-j]-1ll*(lh[i]-lh[j])*D);
		}
		printf("%lld\n",f[ls]);
	}
}
char MED;
int main()
{
cerr<<(&MST-&MED)/1024./1024<<"\n\n";
	freopen("run.in","r",stdin);
freopen("run3.in","r",stdin);
	freopen("std.out","w",stdout);
	for(Read(),T=Read();T--;)
	{
		n=Read(); m=Read(); K=Read(); D=Read(); ls=0;
		for(int i=1;i<=m;++i) lh[++ls]=a[i].r=Read(), lh[++ls]=a[i].l=a[i].r-Read(), a[i].v=Read();
		lh[++ls]=0; sort(lh+1,lh+ls+1); ls=unique(lh+1,lh+ls+1)-lh-1;
		for(int i=1;i<=m;++i) GLH(a[i].l), GLH(a[i].r);
		if(n<=1e3||m<=1e3) C1::mian();
		else if(K<=100) C2::mian();
	}
	return 0;
}
*/
