// luck++
#include<bits/stdc++.h>
#define inl inline
using namespace std;
const int N=1e5+5,IB=1<<21; char IN[IB],*IS=IN+IB,*IT=IS;
#define getchar() (IS==IT&&(fread(IS=IN,1,IB,stdin)),*IS++)
int T,n,m,an,a[N],fa[N],vs[N]; vector<int> e[N];
inl int Read()
{
	int s=0; char c; while(!isdigit(c=getchar()));
	for(;isdigit(c);c=getchar()) s=s*10+c-'0'; return s;
}
int main()
{
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	for(Read(),T=Read();T--;printf("%d\n",an),an=0)
	{
		n=Read(); m=Read(); for(int i=1;i<=n;++i) e[a[i]=i].clear(), fa[i]=vs[i]=0;
		a[n+1]=n+1; vs[0]=vs[n+1]=-1; for(int i=1;i<=m;++i)
		{
			char c; while((c=getchar())!='+'&&c!='-'&&!isalpha(c));
			int p=Read(); if(isalpha(c)) a[p]=c=='T'?n+1:(c=='F'?-n-1:0);
			else a[p]=(c=='+'?1:-1)*a[Read()];
		}
		for(int i=1;i<=n;++i) fa[i]=abs(a[i]);
		for(int i=1;i<=n;++i) if(!vs[i])
		{
			int j=i; for(;j&&!vs[j];vs[j]=i,j=fa[j]);
			if(vs[j]==i)
			{
				int t=a[j]>0?1:-1; for(int k=fa[j];k!=j;k=fa[k]) a[k]<0&&(t=-t);
				if(t==-1) for(j=i;vs[j]==i;vs[j]=-1,j=fa[j]) a[j]=0, ++an;
			}
			else if(!a[j]) for(j=i;vs[j]==i;j=fa[j]) a[j]=0, ++an;
		}
	}
	return 0;
}
