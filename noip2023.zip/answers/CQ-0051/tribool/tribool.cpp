#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=1e5+5;
int n,m,x[N],fa[N<<1],sz[N<<1];
char op[5];
int find(int u){
	return fa[u]==u?u:fa[u]=find(fa[u]);
}
void merge(int u,int v){
	u=find(u),v=find(v);
	if(u==v)return;
	if(sz[u]<sz[v])fa[u]=v,sz[v]+=sz[u];
	else fa[v]=u,sz[u]+=sz[v];
}
int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	int T;
	scanf("%*d %d",&T);
	while(T--){
		scanf("%d %d",&n,&m);
		for(int i=1;i<=n;i++)x[i]=i;
		for(int i=0;i<=n<<1;i++)fa[i]=i,sz[i]=1;
		while(m--){
			scanf("%s",op);
			int i,j;
			if(op[0]=='+')scanf("%d %d",&i,&j),x[i]=x[j];
			else if(op[0]=='-')scanf("%d %d",&i,&j),x[i]=-x[j];
			else scanf("%d",&i),x[i]=op[0]=='U'?0:(op[0]=='T'?n+1:-n-1);
		}
		for(int i=1;i<=n;i++){
			// printf("%d ",x[i]);//!!!
			if(x[i]==0)merge(i,0),merge(i+n,0);
			else if(abs(x[i])!=n+1){
				if(x[i]>0)merge(i,x[i]),merge(i+n,x[i]+n);
				else merge(i,-x[i]+n),merge(i+n,-x[i]);
			}
		}
		int ans=0;
		for(int i=1;i<=n;i++){
			if(find(i)==find(0)||find(i)==find(i+n))ans++;
		}
		printf("%d\n",ans);
	}
	return 0;
}