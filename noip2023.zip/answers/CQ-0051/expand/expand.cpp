#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int SZ=1<<20;
char buf[SZ],*p1,*p2;
#define gc() (p1==p2&&(p2=(p1=buf)+fread(buf,1,SZ,stdin),p1==p2)?EOF:*p1++)
int read(){
	int n=0;
	char c=gc();
	while(c<'0'||c>'9')c=gc();
	while(c>='0'&&c<='9')n=(n<<3)+(n<<1)+(c^'0'),c=gc();
	return n;
}
const int N=5e5+5,inf=0x7fffffff;
int n,m,q,A[N],B[N],a[N],b[N],lca[N],lcb[N],rca[N],rcb[N];
int premax[N],sufmax[N],premin[N],sufmin[N];
int Max(int x,int y){return x>y?x:y;}
int Min(int x,int y){return x<y?x:y;}
bool checka(int u,int v,int x,int y){
	while(1){
		// printf("a %d %d %d %d\n",u,v,x,y);//!!!
		if(x==1||y==1)return 1;
		if(a[u]<premin[y-1])x=u,u=lca[u];
		else if(premax[x-1]<b[v])y=v,v=lcb[v];
		else return 0;
	}
}
bool checkb(int u,int v,int x,int y){
	while(1){
		// printf("b %d %d %d %d\n",u,v,x,y);//!!!
		if(x==n||y==m)return 1;
		if(a[u]<sufmin[y+1])x=u,u=rca[u];
		else if(sufmax[x+1]<b[v])y=v,v=rcb[v];
		else return 0;
	}
}
void solve(){
	if(a[1]==b[1])return putchar('0'),void();
	bool flg=0;
	if(a[1]>b[1])swap(a,b),swap(n,m),flg=1;
	premax[0]=sufmax[n+1]=-inf,premin[0]=sufmin[m+1]=inf;
	int x=0;
	for(int i=1;i<=n;i++){
		if(!x||a[i]<=a[x])lca[i]=x,x=i;
		premax[i]=Max(premax[i-1],a[i]);
	}
	x=0;
	for(int i=n;i;i--){
		if(!x||a[i]<=a[x])rca[i]=x,x=i;
		sufmax[i]=Max(sufmax[i+1],a[i]);
	}
	int rta=x;
	x=0;
	for(int i=1;i<=m;i++){
		if(!x||b[i]>=b[x])lcb[i]=x,x=i;
		premin[i]=Min(premin[i-1],b[i]);
	}
	x=0;
	for(int i=m;i;i--){
		if(!x||b[i]>=b[x])rcb[i]=x,x=i;
		sufmin[i]=Min(sufmin[i+1],b[i]);
	}
	int rtb=x;
	// printf("\n%d %d %d\n",flg,rta,rtb);//!!!
	// for(int i=1;i<=n;i++)
	// 	printf("%d %d %d %d %d %d\n",i,lca[i],rca[i],a[i],premax[i],sufmax[i]);
	// printf("\n");
	// for(int i=1;i<=m;i++)
	// 	printf("%d %d %d %d %d %d\n",i,lcb[i],rcb[i],b[i],premin[i],sufmin[i]);
	// printf("\n");
	if(a[rta]<premin[m]&&premax[n]<b[rtb]&&
		checka(lca[rta],lcb[rtb],rta,rtb)&&checkb(rca[rta],rcb[rtb],rta,rtb)){
		putchar('1');
	}else putchar('0');
	if(flg)swap(a,b),swap(n,m);
}
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	read(),n=read(),m=read(),q=read();
	for(int i=1;i<=n;i++)A[i]=read();
	for(int i=1;i<=m;i++)B[i]=read();
	copy(A+1,A+n+1,a+1),copy(B+1,B+m+1,b+1);
	solve();
	while(q--){
		int kx,ky,p,v;
		kx=read(),ky=read();
		copy(A+1,A+n+1,a+1),copy(B+1,B+m+1,b+1);
		while(kx--)p=read(),v=read(),a[p]=v;
		while(ky--)p=read(),v=read(),b[p]=v;
		solve();
	}
	// printf("\n%lf",(double)clock()/CLOCKS_PER_SEC);//!!!
	return 0;
}