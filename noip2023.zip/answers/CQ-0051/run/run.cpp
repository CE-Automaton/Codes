#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=2e5+10;
int n,m,k,d,pos[N],tot;
ll a[N<<2],tag[N<<2],f[N];
void pushtag(int u,ll x){
	a[u]+=x,tag[u]+=x;
}
void pushup(int u){
	a[u]=max(a[u<<1],a[u<<1|1]);
}
void pushdown(int u){
	if(tag[u])pushtag(u<<1,tag[u]),pushtag(u<<1|1,tag[u]),tag[u]=0;
}
void build(int u,int l,int r){
	a[u]=tag[u]=0;
	if(l==r)return;
	int mid=l+r>>1;
	build(u<<1,l,mid),build(u<<1|1,mid+1,r);
}
void upd(int u,int l,int r,int x,int y,ll z){
	if(x<=l&&r<=y)return pushtag(u,z),void();
	pushdown(u);
	int mid=l+r>>1;
	if(x<=mid)upd(u<<1,l,mid,x,y,z);
	if(y>mid)upd(u<<1|1,mid+1,r,x,y,z);
	pushup(u);
}
ll ask(int u,int l,int r,int x,int y){
	if(x<=l&&r<=y)return a[u];
	pushdown(u);
	int mid=l+r>>1;
	if(x<=mid&&y>mid)return max(ask(u<<1,l,mid,x,y),ask(u<<1|1,mid+1,r,x,y));
	if(x<=mid)return ask(u<<1,l,mid,x,y);
	return ask(u<<1|1,mid+1,r,x,y);
}
struct node{int l,r,v;}b[N];
bool cmp(node x,node y){return x.r<y.r;}
int main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	int T;
	scanf("%*d %d",&T);
	while(T--){
		scanf("%d %d %d %d",&n,&m,&k,&d);
		tot=0;
		for(int i=1,x,y;i<=m;i++){
			// scanf("%d %d %d",&b[i].l,&b[i].r,&b[i].v);//!!!
			scanf("%d %d %d",&x,&y,&b[i].v);
			b[i].l=x-y,b[i].r=x;
			pos[++tot]=b[i].l,pos[++tot]=b[i].r;
		}
		// for(int i=1;i<=m;i++)printf("%d %d %d\n",b[i].l,b[i].r,b[i].v);//!!!
		pos[++tot]=n;
		stable_sort(pos+1,pos+tot+1);
		tot=unique(pos+1,pos+tot+1)-pos-1;
		for(int i=1;i<=m;i++){
			b[i].l=lower_bound(pos+1,pos+tot+1,b[i].l)-pos;
			b[i].r=lower_bound(pos+1,pos+tot+1,b[i].r)-pos;
		}
		stable_sort(b+1,b+m+1,cmp);
		build(1,0,tot);
		f[0]=0;
		// for(int i=1;i<=m;i++)printf(">>%d %d %d\n",b[i].l,b[i].r,b[i].v);//!!!
		// for(int i=1;i<=tot;i++)printf("%d ",pos[i]);
		// printf("\n");
		for(int i=1,j=0,p=1;i<=tot;i++){
			while(p<=m&&b[p].r==i)upd(1,0,tot,0,b[p].l,b[p].v),p++;
			while(pos[i]-pos[j]>k)j++;
			upd(1,0,tot,0,i-1,(ll)d*(pos[i-1]-pos[i]));
			if(j<i)f[i]=max(f[i-1],ask(1,0,tot,j,i-1));
			else f[i]=f[i-1];
			upd(1,0,tot,i,i,f[i]);
			// printf("%d %d %d %lld\n",i,j,p,f[i]);//!!!
		}
		printf("%lld\n",f[tot]);
	}
	return 0;
}