#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=3005;
int n,m;
char a[N][N];
bool cmp(int x,int y){
	for(int i=1;i<=m;i++){
		if(a[x][i]<a[y][i])return 1;
		if(a[x][i]>a[y][i])return 0;
	}
	return 0;
}
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	scanf("%d %d",&n,&m);
	if(n==1)return printf("1"),0;
	int p=0,q=0;
	for(int i=1;i<=n;i++){
		scanf("%s",a[i]+1);
		stable_sort(a[i]+1,a[i]+m+1);
		reverse(a[i]+1,a[i]+m+1);
		if(!p||!cmp(p,i))q=p,p=i;
		else if(!q||!cmp(q,i))q=i;
	}
	for(int i=1;i<=n;i++){
		reverse(a[i]+1,a[i]+m+1);
		if(i==p&&cmp(i,q)||cmp(i,p))putchar('1');
		else putchar('0');
		reverse(a[i]+1,a[i]+m+1);
	}
	return 0;
}