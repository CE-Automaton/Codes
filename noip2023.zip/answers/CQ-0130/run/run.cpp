#include<bits/stdc++.h>
#define int long long
using namespace std;
vector<pair<int,int> > v[1000005];
int n,m,k,d,cc,T;
int f[1000005],c[1000005];
int lowbit(int x) {
	return x&(-x);
}
void add(int x,int y) {
	for(;x<=n+1;x+=lowbit(x)) c[x]+=y;
}
int ask(int x)  {
	int res=0;
	for(;x;x-=lowbit(x)) res+=c[x];
	return res;
}
void change(int l,int r,int x) {
	add(l,x),add(r+1,-x);
}
signed main() {
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	scanf("%lld%lld",&cc,&T);
	while(T--) {
		scanf("%lld%lld%lld%lld",&n,&m,&k,&d);
		for(int i=1;i<=m;i++) {
			int x,y,z;scanf("%lld%lld%lld",&x,&y,&z);
			y=x-y+1;swap(x,y);
			v[y].push_back({x,z});
		}
		int ans=0;
		for(int i=1;i<=n+1;i++) {
			for(pair<int,int> p:v[i-1]) {
				change(1,p.first,p.second);
			}
			for(int j=max((i-1-k+1),1ll);j<i;j++) {
//				cout<<j<<" "<<i<<" "<<ask(j)<<endl;
				f[i]=max(f[i],f[j-1]+ask(j)-d*(i-j));
			}
//			cout<<f[i]<<" ";
			ans=max(ans,f[i]);
			f[i]=max(f[i],f[i-1]);
		}
		printf("%lld\n",ans);
		for(int i=0;i<=n+2;i++) f[i]=c[i]=0,v[i].clear();
	}
	return 0;
}
