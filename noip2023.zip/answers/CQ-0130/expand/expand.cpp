#include<bits/stdc++.h>
//#define int long long
using namespace std;
const int INF=1e9;
int ty,n,m,Q;
int a[1000005],b[1000005],c[1000005],d[1000005],sub[1000005],lo[1000005];
pair<int,int> sta[1000005];
int px[2][500005][20],pn[2][500005][20];
void st(int op) {
	if(op==0) {
		for(int i=1;i<=n;i++) px[0][i][0]=pn[0][i][0]=c[i];
		for(int j=1;(1<<j)<=n;j++) {
			for(int i=1;i+(1<<j)-1<=n;i++) {
				px[0][i][j]=max(px[0][i][j-1],px[0][i+(1<<j-1)][j-1]);
				pn[0][i][j]=min(pn[0][i][j-1],pn[0][i+(1<<j-1)][j-1]);
			}
		}
	}
	else {
		for(int i=1;i<=m;i++) px[1][i][0]=pn[1][i][0]=d[i];
		for(int j=1;(1<<j)<=m;j++) {
			for(int i=1;i+(1<<j)-1<=m;i++) {
				px[1][i][j]=max(px[1][i][j-1],px[1][i+(1<<j-1)][j-1]);
				pn[1][i][j]=min(pn[1][i][j-1],pn[1][i+(1<<j-1)][j-1]);
			}
		}
	}
}
int askx(int op,int l,int r) {
	int k=lo[r-l+1];
	return max(px[op][l][k],px[op][r-(1<<k)+1][k]);
}
int askn(int op,int l,int r) {
	int k=lo[r-l+1];
	return min(pn[op][l][k],pn[op][r-(1<<k)+1][k]);
}
int Find(int op,int x,int y,int z) {
	int l=x,r=y,res=-1;
	while(l<=r) {
		int mid=(l+r)>>1;
		if(askx(op,x,mid)<z) l=mid+1,res=mid;
		else r=mid-1;
	}
	return res;
}
int Find3(int op,int x,int y,int z) {
	int l=x,r=y,res=-1;
	while(l<=r) {
		int mid=(l+r)>>1;
		if(askn(op,mid,y)<z) r=mid-1,res=mid;
		else l=mid+1;
	}
	return res;
}
int Find2(int op,int x,int y,int z) {
	int l=x,r=y,res=-1;
	while(l<=r) {
		int mid=(l+r)>>1;
		if(askn(op,mid,y)<z) l=mid+1,res=mid;
		else r=mid-1;
	}
	return res;
}
bool check() {
	if(c[1]>d[1]&&c[n]<d[m]) {
		return 0;
	}
	if(c[1]<d[1]&&c[n]>d[m]) {
		return 0;
	}
	int top=0;
	if(c[1]>d[1]) {
		for(int i=1;i<=n;i++) {
			while(top&&sta[top].first>=c[i]) top--;
			if(!top||(sta[top].first<c[i])) sta[++top]={c[i],i};
		}
		sub[m+1]=INF;
		for(int i=m;i>=1;i--) sub[i]=min(sub[i+1],d[i]);
		int l=0;
		for(int i=1;i<=top;i++) {
			int mx=0,mn=INF;
			for(int j=sta[i-1].second+1;j<=sta[i].second;j++) mx=max(mx,c[j]),mn=min(mn,c[j]);
			int now=Find(1,max(1,l),m,mx),now2=Find3(1,max(1,l),m,mn);
			if(now2>now) return 0;
			l=Find2(1,now2,now,sta[i].first);
			if(l==-1) return 0;
		}
		if(l==m) return 1;
		return 0;
	}
	else {
		for(int i=1;i<=m;i++) {
			while(top&&sta[top].first>=d[i]) top--;
			if(!top||(sta[top].first<d[i])) sta[++top]={d[i],i};
		}
		sub[n+1]=INF;
		for(int i=n;i>=1;i--) sub[i]=min(sub[i+1],c[i]);
		int l=0;
		for(int i=1;i<=top;i++) {
			int mx=0,mn=INF;
			for(int j=sta[i-1].second+1;j<=sta[i].second;j++) mx=max(mx,d[j]),mn=min(mn,d[j]);
			int now=Find(0,max(1,l),n,mx),now2=Find3(0,max(1,l),n,mn);
			if(now2>now) return 0;
			l=Find2(0,now2,now,sta[i].first);
			if(l==-1) return 0;
		}
		if(l==n) return 1;
		return 0;
	}
}
int f[3005][3005];
bool ck2() {
	if(c[1]>d[1]&&c[n]<d[m]) {
		return 0;
	}
	if(c[1]<d[1]&&c[n]>d[m]) {
		return 0;
	}
	if(c[1]>d[1]) {
		f[0][0]=1;
		for(int i=1;i<=n;i++) {
			for(int j=1;j<=m;j++) {
				f[i][j]=0;
				if(c[i]>d[j]) f[i][j]|=f[i-1][j]|f[i-1][j-1]|f[i][j-1];
			}
		}
		return f[n][m];
	}
	else {
		f[0][0]=1;
		for(int i=1;i<=m;i++) {
			for(int j=1;j<=n;j++) {
				f[i][j]=0;
				if(d[i]>c[j]) f[i][j]|=f[i-1][j]|f[i-1][j-1]|f[i][j-1];
			}
		}
		return f[m][n];
	}
}
signed main() {
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	scanf("%d%d%d%d",&ty,&n,&m,&Q);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]),c[i]=a[i];
	for(int i=1;i<=m;i++) scanf("%d",&b[i]),d[i]=b[i];
	for(int i=1;i<=max(n,m);i++) lo[i]=__lg(i);
	if(n<=3000&&m<=3000) {
		if(ck2()) printf("1");
		else printf("0");
	}
	else {
		st(0),st(1);
		if(check()) printf("1");
		else printf("0");
	}
	int ct=1;
	while(Q--) {
		for(int i=1;i<=n;i++) c[i]=a[i],d[i]=b[i];
		int k1,k2;
		scanf("%d%d",&k1,&k2);
		for(int i=1;i<=k1;i++) {
			int x,y;scanf("%d%d",&x,&y);c[x]=y;
		}
		for(int i=1;i<=k2;i++) {
			int x,y;scanf("%d%d",&x,&y);d[x]=y;
		}
		if(n<=3000&&m<=3000) {
			if(ck2()) printf("1");
			else printf("0");
		}
		else {
			st(0),st(1);
			if(check()) printf("1");
			else printf("0");
		}
	}
	return 0;
}
