#include<bits/stdc++.h>
//#define int long long
using namespace std;
int n,m;
int pos[100005];
char s[100005];
int mp[3005][3005];
bool cmp(int x,int y) {
	return x>y;
}
bool cmp2(int x,int y) {
	for(int i=0;i<m;i++) {
		if(mp[x][i]!=mp[y][i]) return mp[x][i]<mp[y][i];
	}
	return 0;
}
signed main() {
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) {
		scanf("%s",s);
		for(int j=0;j<m;j++) {
			mp[i][j]=s[j]-'a'+1;
		}
		sort(mp[i],mp[i]+m,cmp);
	}
	for(int i=1;i<=n;i++) pos[i]=i;
	sort(pos+1,pos+n+1,cmp2);
	for(int i=1;i<=n;i++) {
		int id=1;
		if(pos[1]==i) id=2;
		sort(mp[i],mp[i]+m);
		if(cmp2(i,pos[id])) printf("1");
		else printf("0");
		sort(mp[i],mp[i]+m,cmp);
	}
	return 0;
}
