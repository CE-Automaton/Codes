#include<bits/stdc++.h>
//#define int long long
using namespace std;
int c,T,n,m,ans=0;
int a[1000005],b[1000005],prt[1000005];
int gf(int x) {
	if(prt[x]==x) return x;
	return prt[x]=gf(prt[x]);
}
signed main() {
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	scanf("%d%d",&c,&T);
	while(T--) {
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;i++) a[i]=0,b[i]=i;
		for(int i=1;i<=m;i++) {
			char op;int x,y;scanf("\n%c%d",&op,&x);
			if(op=='T') a[x]=1,b[x]=x;
			else if(op=='F') a[x]=2,b[x]=x;
			else if(op=='U') a[x]=3,b[x]=-x;
			else {
				scanf("%d",&y);
				if(op=='+') {
					if(a[y]==0) {
						a[x]=0;
						b[x]=b[y];
					}
					else {
						if(a[y]==3) a[x]=3,b[x]=-x;
						else a[x]=a[y],b[x]=b[y];
					}
				}
				else {
					if(a[y]==0) {
						b[x]=-b[y];a[x]=0;
					}
					else {
						if(a[y]==3) a[x]=3,b[x]=-x;
						else a[x]=3-a[y],b[x]=x;
					}
				}
			}
		}
		for(int i=1;i<=2*n;i++) prt[i]=i;
		for(int i=1;i<=n;i++) if(b[i]==-i) a[i]=3,a[i+n]=3,prt[gf(i)]=gf(i+n),b[i]=i;
		for(int i=1;i<=n;i++) if(a[i]==3) prt[gf(i)]=gf(i+n),b[i]=i;
//		for(int i=1;i<=n;i++) cout<<b[i]<<" ";
		for(int i=1;i<=n;i++) {
			if(b[i]>0) prt[gf(i)]=gf(b[i]),prt[gf(i+n)]=gf(b[i]+n);
			else prt[gf(i)]=gf(-b[i]+n),prt[gf(i+n)]=gf(-b[i]);
		}
		for(int i=1;i<=n;i++) if(gf(i)==gf(i+n)) ans++;
		printf("%d\n",ans);
		for(int i=1;i<=2*n;i++) prt[i]=a[i]=b[i]=0;ans=0;
	}
	return 0;
}
