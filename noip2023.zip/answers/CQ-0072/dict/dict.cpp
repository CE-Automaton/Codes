#include<bits/stdc++.h>
using namespace std;
const int maxn=3005;
int mn[maxn],mx[maxn];
char s[maxn];
int n,m;
const int inf=1e9;
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("%s",s+1);
		mn[i]=inf;
		for(int j=1;j<=m;j++){
			mn[i]=min(mn[i],(int)s[j]);
			mx[i]=max(mx[i],(int)s[j]);
		}
	}
	for(int i=1;i<=n;i++){
		int fl=1;
		for(int j=1;j<=n;j++){
			if(j==i)continue;
			if(mn[i]<mx[j])continue;
			if(mx[j]<mn[i]){
				fl=0;
				break;
			}
			fl=0;
			break;
		}
		if(fl)putchar('1');
		else putchar('0');
	}
	putchar('\n');
	return 0;
}
