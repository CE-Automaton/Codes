#include<bits/stdc++.h>
using namespace std;
int c,n,m,q;
const int maxn=2e6+5;
int a[maxn],b[maxn],ta[maxn],tb[maxn],pb[maxn],nxt[maxn],bmx[maxn];
const int inf=1e9;
bool check(int ml,int mr){
	int R=m;
		int mn=inf;
		int lst=0,mxx=0;
		for(int i=1;i<=m;i++){
			nxt[i]=0;
			mn=min(mn,b[i]);
			mxx=max(mxx,b[i]);
			if(mn==b[i]){
				nxt[lst]=i;
				bmx[lst]=mxx;
				mxx=b[i];
				lst=i;
				pb[i]=1;
			}
			else pb[i]=0;
		}
		for(int i=1;i<=m;i++){
			if(a[1]<=b[i]){
				R=i-1;
				break;
			}
		}
		if(!R)return 0;
		while(!pb[R])R--;		
		for(int i=1;i<mr;i++){
			if(a[i+1]<=a[i]){ 
				if(b[R]>=a[i+1]){
					return 0;
				}
			}
			else{
				while(nxt[R]){
					if(a[i+1]>bmx[R])R=nxt[R];
					else break;
				}
			}  
			while(!pb[R])R--;	
		}
		return 1;
}
char solve2(){
	bool fl=0;
	if(a[1]==b[1])return '0';
	if(a[1]<b[1]){
		swap(n,m);
		swap(a,b);
		fl=1;
	}
	char res='1';
	if(a[n]<b[m])res='0';
	int L=1,R=m;
	for(int j=2;j<=m;j++){
		if(a[1]<=b[j]){
			R=j-1;
			break;
		}
	}
	for(int i=1;i<n;i++){
		if(a[i+1]<=a[i]){ 
			int ct=0;
			for(int j=R;j>=L;j--){
				if(a[i+1]>b[j]){
					ct++;
					R=j;
					break;
				}
			}
			if(!ct){
				res='0';
				break;
			}
		}
		else{
			bool ffl=0;
			for(int j=R+1;j<=m;j++){
				if(a[i+1]<=b[j]){
					ffl=1;
					R=j-1;
					break;
				}
			}
			if(!ffl)R=m;
		} 
	}
	if(R!=m)res='0';
	if(fl){
		swap(n,m);
		swap(a,b); 
	}
	return res;
}
char solve1(){
	bool fl=0;
	if(a[1]==b[1])return '0';
	if(a[1]<b[1]){
		swap(n,m);
		swap(a,b);
		fl=1;
	} 
	char res='1'; 
	if(a[n]<=b[m])res='0'; 
	int mx1=0;
	for(int i=1;i<=n;i++)mx1=max(mx1,a[i]);
	int pos=0;
	int mx2=0;
	for(int i=1;i<=m;i++)mx2=max(mx2,b[i]);
	for(int i=1;i<=n;i++){
		if(a[i]==mx1)pos=i;
	}
	if(mx1<=mx2){
		res='0';
	}
	if(pos==n){
		if(!check(1,n-1))res='0';
		if(fl){
			swap(n,m);
			swap(a,b); 
		}
		return res;
	}
	if(!check(1,pos-1))res='0'; 
	reverse(a+1,a+n+1);
	reverse(b+1,b+m+1);
	if(!check(1,n-pos+1))res='0'; 
	if(fl){
		swap(n,m);
		swap(a,b); 
	}
	return res;
}
const int D=4e4;
char solve(){
	if(n<=D&&m<=D)return solve2();
	else return solve1();
}
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	scanf("%d%d%d%d",&c,&n,&m,&q);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)scanf("%d",&b[i]);
	putchar(solve()); 
	while(q--){
		int kx,ky;
		scanf("%d%d",&kx,&ky);
		for(int i=1;i<=n;i++)ta[i]=a[i];
		for(int i=1;i<=m;i++)tb[i]=b[i];
		while(kx--){
			int x,k;
			scanf("%d%d",&x,&k);
			a[x]=k;
		}
		while(ky--){
			int x,k;
			scanf("%d%d",&x,&k);
			b[x]=k; 
		}	 
		putchar(solve());
		for(int i=1;i<=n;i++)a[i]=ta[i];
		for(int i=1;i<=m;i++)b[i]=tb[i];
	}
	return 0;
}

