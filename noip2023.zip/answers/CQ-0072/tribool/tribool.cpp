#include<bits/stdc++.h>
using namespace std;
const int maxn=5e5+5;
int n,m,T;
const int inf=1e9;
int bl[maxn];//-1 T -2 F -3 U
bool fl[maxn],mst[maxn],s[maxn];
int val[maxn],tv[maxn];
bool vis[maxn];
vector<int>G[maxn];
int tmp[maxn],tt;
bool tmpv[maxn];
char op[10];
int upd(int x){
	if(x==1)return 2;
	if(x==2)return 1;
	if(x==3)return 3;
	return -1;
}
bool check(int u,int v){
	if(mst[u]&&!s[u]){
		if(val[u]!=v)return 0;
	}
	return 1;
}
bool ffl;
void dfs(int u,int now){
	if(!check(u,now)){
		ffl=0;
		return ;
	}
	tv[u]=now;
	for(auto v:G[u]){
		if(tmpv[v])continue;
		tmpv[v]=1;
		tmp[++tt]=v;
		dfs(v,((fl[v])?upd(now):now));
	}
}
int solve(int u){
	tt=0;
	int res=inf;
	for(int v=1;v<=3;v++){
		if(!check(u,v))continue;
//		cout<<"val[u]="<<v<<endl;
		tv[u]=v;
		int now=u,vv=v;
		ffl=1;
		while(!tmpv[u]){
//			cout<<"now"<<u<<":"<<bl[u]<<endl;
			tmpv[u]=1;
			tmp[++tt]=u;
			if(!check(u,vv)){
				ffl=0;
				break;
			}
			tv[u]=vv;
			if(fl[u])vv=upd(vv);
			if(bl[u]<0)break;
			u=bl[u];
			if(!check(u,vv)){
				ffl=0;
				break;
			}
			if(tmpv[u]&&tv[u]!=vv){
				ffl=0;
				break;
			}
		}
//		cout<<"finished,now"<<ffl<<endl;
		u=now;
		if(ffl){
			int nt=tt;
			for(int i=1;i<=nt;i++){
				dfs(tmp[i],tv[tmp[i]]);
			}
		}
		if(ffl){
			int ct=0;
			for(int i=1;i<=tt;i++){
//				cout<<tmp[i]<<"->"<<tv[tmp[i]]<<endl;
				ct+=(tv[tmp[i]]==3);
			}
			res=min(res,ct);
		}
		for(int i=1;i<=tt;i++){
//			cout<<"now have"<<tmp[i]<<endl;
			vis[tmp[i]]=1;
			tmpv[tmp[i]]=0;
			tv[tmp[i]]=0;
		}
		tt=0;
	}
	return res;
}
int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	int tid;
	scanf("%d%d",&tid,&T);
	while(T--){
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;i++){
			bl[i]=i;
			fl[i]=0;
			mst[i]=0;
			val[i]=0;
			tv[i]=0;
			s[i]=0;
			tmpv[i]=0;
			vis[i]=0;
			G[i].clear();
		}
		tt=0;
		for(int i=1;i<=m;i++){
			scanf("%s",op+1);
			int x,y;
			if(op[1]=='T'){
				scanf("%d",&x);
				bl[x]=-1;
				fl[x]=0;
			}
			if(op[1]=='F'){
				scanf("%d",&x);
				bl[x]=-2;
				fl[x]=0;
			}
			if(op[1]=='U'){
				scanf("%d",&x);
				bl[x]=-3;
				fl[x]=0;
			}
			if(op[1]=='+'){
				scanf("%d%d",&x,&y);
				bl[x]=bl[y];
				fl[x]=fl[y];
			}
			if(op[1]=='-'){
				scanf("%d%d",&x,&y);
				bl[x]=bl[y];
				fl[x]=!fl[y];
			}
		}
		for(int i=1;i<=n;i++){ 
			if(bl[i]==i){
				mst[i]=1;
				s[i]=0;
				if(!fl[i])s[i]=1;
				else val[i]=3;
				continue;
			}
			if(bl[i]<0){
				mst[i]=1;
				val[i]=-bl[i];
				if(fl[i])val[i]=upd(val[i]);	
				continue;
			}
			G[bl[i]].push_back(i);
		}
		int ans=0;
		for(int i=1;i<=n;i++){
			if(vis[i])continue;
			ans+=solve(i); 
		}
		printf("%d\n",ans); 
	}
	return 0;
}
