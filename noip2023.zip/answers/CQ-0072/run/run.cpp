#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+5;
typedef long long ll;
ll dp[1005][1005],sum[1005][1005];
int n,m,k;
ll d; 
const ll inf=1e17;
int l[maxn],r[maxn];
ll val[maxn];
int main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	int tid,T;
	scanf("%d%d",&tid,&T);
	while(T--){
		scanf("%d%d%d%lld",&n,&m,&k,&d); 
		for(int i=1,x,y;i<=m;i++){
			scanf("%d%d%lld",&x,&y,&val[i]);
			r[i]=x;
			l[i]=x-y+1;
		}
		if(tid>=10){
			ll ans=0;
			for(int i=1;i<=m;i++){
				if(r[i]-l[i]+1<=k&&l[i]>=1)ans+=max(0ll,val[i]-(r[i]-l[i]+1)*d);
			}
			printf("%lld\n",ans);
			continue;
		}
		for(int i=0;i<=n;i++){
			for(int j=0;j<=n;j++){
				sum[i][j]=0;
				dp[i][j]=-inf;
			}
		}
		for(int i=1;i<=m;i++){
			sum[r[i]][r[i]-l[i]+1]+=val[i];
		}
		dp[0][0]=0;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				sum[i][j]+=sum[i][j-1];
			}
			dp[i][0]=dp[i-1][0];
			for(int j=1;j<=min(i,k);j++){
				dp[i][0]=max(dp[i][0],dp[i-1][j]);
			}
			for(int j=1;j<=min(i,k);j++){
				dp[i][j]=dp[i-1][j-1]-d+sum[i][j];
			}
		}
		ll ans=0;
		for(int j=0;j<=min(n,k);j++)ans=max(ans,dp[n][j]);
		printf("%lld\n",ans);
	}
	return 0;
}
