#include<bits/stdc++.h>
using namespace std;
const int N=3005;
int n,m,buc[N];
char a[N];
string b[N],c[N];
int main()
{
    freopen("dict.in","r",stdin);
    freopen("dict.out","w",stdout);

    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
    {
		scanf("%s",a);
        for(int j=0;j<m;j++)++buc[a[j]-'a'];
        for(int j=0;j<26;j++)while(buc[j])b[i]+=j+'a',--buc[j];
        for(int j=0;j<m;j++)++buc[a[j]-'a'];
        for(int j=25;~j;j--)while(buc[j])c[i]+=j+'a',--buc[j];
    }
    int Mic=1;
    for(int i=2;i<=n;i++)if(c[Mic]>c[i])Mic=i;
    for(int i=1;i<=n;i++)
    {
        bool Flag=1;
        if(i==Mic){for(int j=1;j<=n;j++)if(i!=j)
        {
            if(b[i]>=c[j]){Flag=0;break;}
        }}
        else Flag=b[i]<c[Mic];
        putchar(Flag+'0');
    }
}
