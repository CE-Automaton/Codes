#include<bits/stdc++.h>
using namespace std;
int Read()
{
    int x=0;char ch=getchar();
    while(ch<'0'||ch>'9')ch=getchar();
    while(ch>='0'&&ch<='9')x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
    return x;
}
const int N=1e5+5;
int n,m,a[N],fa[N*2],vis[N*2];
int Find(int x){return fa[x]==x?x:fa[x]=Find(fa[x]);}
void Solve()
{
    n=Read(),m=Read();
    for(int i=0;i<=2*(n+1);i++)fa[i]=i,vis[i]=0;
    for(int i=1;i<=n;i++)a[i]=i;
    for(int i=1;i<=m;i++)
    {
        char op[5];int u,v;
        scanf("%s",op);
        u=Read();
        if(op[0]=='+'||op[0]=='-')v=Read();
        if(op[0]=='+')a[u]=a[v];
        else if(op[0]=='-')a[u]=-a[v];
        else if(op[0]=='T')a[u]=n+1;
        else if(op[0]=='F')a[u]=-(n+1);
        else a[u]=0;
    }
    for(int i=1;i<=n;i++)fa[Find(i+(n+1))]=Find(a[i]+(n+1)),
                         fa[Find((-i)+(n+1))]=Find((-a[i])+(n+1));
    int ans=0;
     vis[Find(n+1)]=1;
     for(int i=1;i<=n;i++)if(Find(i+(n+1))==Find(-i+(n+1)))vis[fa[i+(n+1)]]=1;
     for(int i=1;i<=n;i++)if(vis[fa[i+(n+1)]])++ans;
    printf("%d\n",ans);
}
int main()
{
    freopen("tribool.in","r",stdin);
    freopen("tribool.out","w",stdout);

    int op=Read(),Q=Read();
    while(Q--)Solve();
}
/*
#include<bits/stdc++.h>
using namespace std;
const int N=1e5+5;
int n,m,a[N],b[N],ans,fa[N*2];
bool vis[N*2];
struct Operator{char op;int u,v;}c[N];
int Find(int x){return fa[x]==x?x:fa[x]=Find(fa[x]);}
bool Check()
{
    for(int i=1;i<=n;i++)b[i]=a[i];
    for(int i=1;i<=m;i++)
    {
        if(c[i].op=='T')b[c[i].u]=1;
        else if(c[i].op=='F')b[c[i].u]=-1;
        else if(c[i].op=='U')b[c[i].u]=0;
        else if(c[i].op=='+')b[c[i].u]=b[c[i].v];
        else b[c[i].u]=-b[c[i].v];
    }
    for(int i=1;i<=n;i++)if(a[i]!=b[i])return 0;
    // for(int i=1;i<=n;i++)printf("%d ",a[i]);puts("");
    return 1;
}
void DFS1(int x,int y)
{
    if(y>=ans)return;
    if(x>n)
    {
        if(Check())ans=min(ans,y);
        return;
    }
    for(int i=-1;i<=1;i++)a[x]=i,DFS1(x+1,y+!i);
}
void Solve12()
{
    ans=1e9;
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++)
    {
        char op[5];int u,v=0;
        scanf("%s%d",op,&u);
        if(op[0]=='+'||op[0]=='-')scanf("%d",&v);
        c[i]={op[0],u,v};
    }
    DFS1(1,0);
    printf("%d\n",!ans);
}
void Solve34()
{
    memset(a,1,sizeof(a));
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++)
    {
        char op[5];int u;
        scanf("%s%d",op,&u);
        if(op[0]=='U')a[u]=0;
    }
    ans=0;
    for(int i=1;i<=n;i++)if(!a[i])++ans;
    printf("%d\n",ans);
}
void Solve78()
{
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)a[i]=i*2;
    for(int i=1;i<=m;i++)
    {
        char op[5];int u,v;
        scanf("%s%d%d",op,&u,&v);
        if(op[0]=='+')a[u]=a[v];
        else if(op[0]=='-')a[u]=a[v]^1;
    }
    for(int i=2;i<=2*n+1;i++)fa[i]=i,vis[i]=0;
    for(int i=1;i<=n;i++)fa[Find(2*i)]=Find(a[i]),fa[Find(2*i+1)]=Find(a[i]^1);
    ans=0;
    for(int i=1;i<=n;i++)if(Find(2*i)==Find(2*i+1))vis[fa[2*i]]=1;
    for(int i=1;i<=n;i++)if(vis[fa[2*i]])++ans;
    printf("%d\n",ans);
}
int main()
{
    freopen("tribool.in","r",stdin);
    freopen("tribool.out","w",stdout);

    int op,Q;
    scanf("%d%d",&op,&Q);
    while(Q--)
    {
        if(op<3)Solve12();
        else if(op<5)Solve34();
        else if(op<9)Solve78();
    }
}
*/
/*
#include<bits/stdc++.h>
using namespace std;
const int N=1e5+5;
random_device Seed;
mt19937 Rand(Seed());
int Rd(int l,int r){return Rand()%(r-l+1)+l;}
int n=10,m=10;
int main()
{
    freopen("Data.in","w",stdout);

    printf("1 1\n%d %d\n",n,m);
    // for(int i=1;i<=m;i++)
    // {
    //     printf("%c %d %d\n",Rd(0,1)?'+':'-',Rd(1,n),Rd(1,n));
    // }

    for(int i=1;i<=m;i++)
    {
        if(Rd(1,5)<=3)printf("%c %d\n",!Rd(0,3)?'T':!Rd(0,1)?'F':'U',Rd(1,n));
        printf("%c %d %d\n",Rd(0,1)?'+':'-',Rd(1,n),Rd(1,n));
    }
}
*/