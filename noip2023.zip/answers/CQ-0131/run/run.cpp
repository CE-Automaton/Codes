#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=1005;
int n,m,k,d;
ll f[N][N],g[N][N];
void Solve()
{
    memset(f,-63,sizeof(f));
    f[0][0]=0;
    scanf("%d%d%d%d",&n,&m,&k,&d);
    for(int i=1;i<=n;i++)for(int j=0;j<=i;j++)g[i][j]=0;
    while(m--)
    {
        int x,y,v;
        scanf("%d%d%d",&x,&y,&v);
        if(y<=x)g[x][y]+=v;
    }
    ll ans=-1e18,sum;
    for(int i=0;i<n;i++)
    {
        sum=0;
        for(int j=0;j<=min(i,k);j++)
        {
            sum+=g[i][j];
            f[i+1][0]=max(f[i+1][0],f[i][j]+sum);
            if(j<k)f[i+1][j+1]=max(f[i+1][j+1],f[i][j]-d+sum);
        }
    }
    sum=0;
    for(int j=0;j<=min(n,k);j++)
    {
        sum+=g[n][j];
        ans=max(ans,f[n][j]+sum);
    }
    printf("%lld\n",ans);
}
int main()
{
    freopen("run.in","r",stdin);
    freopen("run.out","w",stdout);

    int op,Q;
    scanf("%d%d",&op,&Q);
    while(Q--)Solve();
}