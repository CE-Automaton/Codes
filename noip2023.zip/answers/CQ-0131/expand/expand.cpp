#include<bits/stdc++.h>
using namespace std;
int Read()
{
    int x=0;char ch=getchar();
    while(ch<'0'||ch>'9')ch=getchar();
    while(ch>='0'&&ch<='9')x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
    return x;
}
const int N=2005,N2=5e5+5;
int n,m,a1[N2],b1[N2],a[N2],b[N2],f[N][N];
void Change()
{
    for(int i=1;i<=n;i++)a[i]=a1[i];
    for(int i=1;i<=m;i++)b[i]=b1[i];
    int kn=Read(),km=Read();
    while(kn--)a[Read()]=Read();
    while(km--)b[Read()]=Read();
}
bool DFS(int i,int j)
{
    int &ans=f[i][j];
    if(a[i]>=b[j]||i>n||j>m)ans=0;
    if(ans!=-1)return ans;
    if(i==n&&j==m)return 1;
    return ans=DFS(i+1,j)||DFS(i,j+1);
}
void Solve()
{
    memset(f,-1,sizeof(f));
    bool Flag=a[1]>b[1];
    if(Flag)swap(a,b),swap(n,m);
    putchar(DFS(1,1)+'0');
    if(Flag)swap(n,m);
}
bool DFS1(int i,int j)
{
    if(a[i]>=b[j]||i>n||j>m)return 0;
    if(i==n&&j==m)return 1;
    if(i<n&&a[i+1]<b[j])return DFS1(i+1,j);
    return DFS1(i,j+1);
}
bool DFS2(int i,int j)
{
    if(a[i]>=b[j]||i>n||j>m)return 0;
    if(i==n&&j==m)return 1;
    if(j<m&&a[i]<b[j+1])return DFS2(i,j+1);
    return DFS2(i+1,j);
}
bool DFS3(int i,int j,bool op)
{
    if(a[i]>=b[j]||i>n||j>m)return 0;
    if(i==n&&j==m)return 1;
    if(op&&j<m&&a[i]<b[j+1])return DFS3(i,j+1,1);
    if(!op&&i<n&&a[i+1]<b[j])return DFS3(i+1,j,0);
    return DFS3(i,j+1,1)||DFS3(i+1,j,0);
}
void Solve2()
{
    bool Flag=a[1]>b[1];
    if(Flag)swap(a,b),swap(n,m);
    bool ans=DFS1(1,1);
    if(!ans)ans=DFS2(1,1);
    if(!ans)ans=DFS3(1,1,0);
    if(!ans)ans=DFS3(1,1,1);
    putchar(ans+'0');
    if(Flag)swap(n,m);
}
int main()
{
    freopen("expand.in","r",stdin);
    freopen("expand.out","w",stdout);

    int op,Q;
    op=Read(),n=Read(),m=Read(),Q=Read();
    for(int i=1;i<=n;i++)a[i]=a1[i]=Read();
    for(int i=1;i<=m;i++)b[i]=b1[i]=Read();
    if(op<8)Solve();
    else Solve2();
    while(Q--)
    {
        Change();
        if(op<8)Solve();
        else Solve2();
    }
}
