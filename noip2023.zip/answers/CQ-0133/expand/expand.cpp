#include <bits/stdc++.h>
using namespace std;
const int N = 3e5+5;
int c, n, m, q, x[N], y[N], az[N], azz[N], pd[2][N], k, kk, u, v, a[N], b[N];

template <typename T> void read(T& x) {
	x=0; int f=0; char c=getchar();
	while(c < '0' || c > '9') f|=(c == '-'), c=getchar();
	while(c >= '0' && c <= '9') x=(x<<1)+(x<<3)+(c^48), c=getchar();
	x=(f ? -x : x);
}
int lne; char put[105];
template <typename T> void write(T x, char ch) {
	lne=0; if(x < 0) putchar('-'), x=-x;
	do { put[++lne]=x%10, x/=10; } while(x);
	while(lne) putchar(put[lne]^48), --lne;
	putchar(ch);
}
void sol() {
	if(x[1] == y[1]) {
		putchar('0');
		return ;
	}
	if(x[1] < y[1]) {
		u=n, v=m;
		for(int i = 1; i <= n; ++i)
			a[i]=x[i];
		for(int i = 1; i <= m; ++i)
			b[i]=y[i];
	}
	else {
		u=m, v=n;
		for(int i = 1; i <= m; ++i)
			a[i]=y[i];
		for(int i = 1; i <= n; ++i)
			b[i]=x[i];
	}
	int now = 0;
	pd[0][0]=pd[1][0]=0;
	for(int i = 1; i <= u; ++i)
		pd[0][i]=0;
	pd[now][1]=1;
	for(int i = 1; i <= v; ++i) {
		now^=1;
		for(int j = 1; j <= u; ++j)
			pd[now][j]=0;
		for(int j = 1; j <= u; ++j)
			pd[now][j]=((pd[now][j-1]|pd[now^1][j])&(b[i] > a[j]));
	}
	putchar(pd[now][u] ? '1' : '0');
}

signed main() {
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);
	read(c), read(n), read(m), read(q);
	for(int i = 1; i <= n; ++i)
		read(x[i]);
	for(int i = 1; i <= m; ++i)
		read(y[i]);
	sol();
	for(int i = 1; i <= q; ++i) {
		read(k), read(kk);
		for(int i = 1; i <= n; ++i)
			az[i]=x[i];
		for(int i = 1; i <= m; ++i)
			azz[i]=y[i];
		for(int j = 1; j <= k; ++j)
			read(u), read(v), x[u]=v;
		for(int j = 1; j <= kk; ++j)
			read(u), read(v), y[u]=v;
		sol();
		for(int i = 1; i <= n; ++i)
			x[i]=az[i];
		for(int i = 1; i <= m; ++i)
			y[i]=azz[i];
	}
	return 0;
}
