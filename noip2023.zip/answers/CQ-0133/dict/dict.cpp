#include <bits/stdc++.h>
using namespace std;
const int base = 31, mod = 998244353, mod2 = 1000000007, N = 3e3+5;
int n, m, hs[2][N][N], hs2[2][N][N], pd[N];
char s[2][N][N];

template <typename T> void read(T& x) {
	x=0; int f=0; char c=getchar();
	while(c < '0' || c > '9') f|=(c == '-'), c=getchar();
	while(c >= '0' && c <= '9') x=(x<<1)+(x<<3)+(c^48), c=getchar();
	x=(f ? -x : x);
}
int lne; char put[105];
template <typename T> void write(T x, char ch) {
	lne=0; if(x < 0) putchar('-'), x=-x;
	do { put[++lne]=x%10, x/=10; } while(x);
	while(lne) putchar(put[lne]^48), --lne;
	putchar(ch);
}
int comp(char x, char y) {
	return x < y;
}
int upd(int x) {
	return (x >= mod ? x-mod : x);
}
int upd2(int x) {
	return (x >= mod2 ? x-mod2 : x);
}
int ask(int x/*0*/, int y/*1*/) {
	int l = 1, r = m, ret = 0;
	while(l <= r) {
		int mid = ((l+r)>>1);
		if(hs[0][x][mid] == hs[1][y][mid] && hs2[0][x][mid] == hs2[1][y][mid])
			ret=mid, l=mid+1;
		else
			r=mid-1;
	}
	return (ret == m/*��Ȳ���*/ ? 0 : (s[0][x][ret+1] < s[1][y][ret+1]));
}

signed main() {
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);
	read(n), read(m);
	for(int i = 1; i <= n; ++i) {
		char ch = getchar();
		while(ch < 'a' || ch > 'z')
			ch=getchar();
		for(int j = 1; j <= m; ++j)
			s[0][i][j]=ch, ch=getchar();
		sort(s[0][i]+1, s[0][i]+1+m, comp);
		for(int j = 1; j <= m; ++j)
			s[1][i][j]=s[0][i][m-j+1];
	}
	for(int o = 0; o <= 1; ++o)//˫��ϣ 
		for(int i = 1; i <= n; ++i)
			for(int j = 1; j <= m; ++j)
				hs[o][i][j]=upd(1LL*hs[o][i][j-1]*base%mod+s[o][i][j]-'a'+1), 
				hs2[o][i][j]=upd2(1LL*hs2[o][i][j-1]*base%mod2+s[o][i][j]-'a'+1);
	for(int i = 1; i <= n; ++i) {
		pd[i]=1;
		for(int j = 1; j <= n; ++j)
			if(i != j)
				pd[i]&=ask(i, j);
		if(pd[i]) putchar('1');
		else putchar('0');
	}
	return 0;
}
