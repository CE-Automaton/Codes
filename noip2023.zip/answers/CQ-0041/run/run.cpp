#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int NN=1004;
ll f[NN][NN];
vector<pair<int,int> >g[NN];
int main()
{
    freopen("run.in","r",stdin);
    freopen("run.out","w",stdout);
    int c,t;
    scanf("%d%d",&c,&t);
    while(t--)
    {
        int n,m,k,d;
        scanf("%d%d%d%d",&n,&m,&k,&d);
        for(int i=1;i<=n;i++)
            g[i].clear();
        for(int i=1;i<=m;i++)
        {
            int x,y,v;
            scanf("%d%d%d",&x,&y,&v);
            g[x].push_back({y,v});
        }
        for(int i=1;i<=n;i++)
        {
            f[i][0]=f[i-1][0];
            for(int j=1;j<=min(k,i);j++)
            {
                f[i][0]=max(f[i][0],f[i-1][j]);
                ll res=0;
                for(int l=0;l<g[i].size();l++)
                    if(g[i][l].first<=j)
                        res+=g[i][l].second;
                f[i][j]=f[i-1][j-1]+res-d;
            }
        }
        ll ans=0;
        for(int i=0;i<=k;i++)
            ans=max(ans,f[n][i]);
        printf("%lld\n",ans);
    }
    return 0;
}