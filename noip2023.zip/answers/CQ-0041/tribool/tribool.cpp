#include<bits/stdc++.h>
using namespace std;
const int NN=2e5+4;
struct node
{
    char v;
    int tag,id;
}a[NN];
int fa[NN];
vector<int>g[NN];
int find(int u)
{
    return fa[u]==u?u:fa[u]=find(fa[u]);
}
void merge(int u,int v)
{
    fa[find(u)]=find(v);
}
int main()
{
    freopen("tribool.in","r",stdin);
    freopen("tribool.out","w",stdout);
    int c,t;
    scanf("%d%d",&c,&t);
    while(t--)
    {
        int n,m;
        scanf("%d%d",&n,&m);
        for(int i=1;i<=n;i++)
        {
            a[i]={'?',0,i};
            g[i].clear();
        }
        for(int i=1;i<=n*2;i++)
            fa[i]=i;
        while(m--)
        {
            char opt[4];
            scanf("%s",opt+1);
            if(opt[1]=='+')
            {
                int u,v;
                scanf("%d%d",&u,&v);
                a[u]=a[v];
            }
            else if(opt[1]=='-')
            {
                int u,v;
                scanf("%d%d",&u,&v);
                a[u]=a[v];
                a[u].tag^=1;
            }
            else
            {
                int u;
                scanf("%d",&u);
                a[u].v=opt[1];
            }
        }
        for(int i=1;i<=n;i++)
        {
            if(a[i].v!='?')
                continue;
            if(a[i].tag)
            {
                merge(i*2-1,a[i].id*2);
                merge(i*2,a[i].id*2-1);
            }
            else
            {
                merge(i*2,a[i].id*2);
                merge(i*2-1,a[i].id*2-1);
            }
            g[a[i].id].push_back(i);
            g[i].push_back(a[i].id);
        }
        queue<int>q;
        for(int i=1;i<=n;i++)
        {
            if(find(i*2-1)==find(i*2))
                a[i].v='U';
            if(a[i].v=='U')
                q.push(i);
        }
        int ans=0;
        while(q.size())
        {
            int u=q.front();
            q.pop();
            ans++;
            for(int i=0;i<g[u].size();i++)
            {
                int v=g[u][i];
                if(a[v].v=='?')
                {
                    a[v].v='U';
                    q.push(v);
                }
            }
        }
        printf("%d\n",ans);
    }
    return 0;
}