#include<bits/stdc++.h>
using namespace std;
const int NN=3004;
string s[NN],t1[NN],t2[NN];
int main()
{
    freopen("dict.in","r",stdin);
    freopen("dict.out","w",stdout);
    ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
    int n,m;
    cin>>n>>m;
    if(n==1)
    {
        cout<<1;
        return 0;
    }
    for(int i=1;i<=n;i++)
    {
        cin>>s[i];
        sort(s[i].begin(),s[i].end());
        reverse(s[i].begin(),s[i].end());
        t1[i]=t2[i]=s[i];
        reverse(s[i].begin(),s[i].end());
    }
    sort(t1+1,t1+1+n);
    for(int i=1;i<=n;i++)
        if(s[i]<t1[1]||t2[i]==t1[1]&&s[i]<t1[2])
            cout<<1;
        else
            cout<<0;
    return 0;
}