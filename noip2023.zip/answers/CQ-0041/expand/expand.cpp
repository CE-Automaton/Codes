#include<bits/stdc++.h>
using namespace std;
const int NN=2004;
int x[NN],y[NN],tx[NN],ty[NN],n,m;
bool f1[NN][NN],f2[NN][NN];
bool solve()
{
    memset(f1,false,sizeof(f1));
    memset(f2,false,sizeof(f2));
    f1[0][0]=f2[0][0]=true;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)
            if(x[i]>y[j])
                f1[i][j]|=f1[i-1][j]|f1[i-1][j-1]|f1[i][j-1];
            else if(x[i]<y[j])
                f2[i][j]|=f2[i-1][j]|f2[i-1][j-1]|f2[i][j-1];
    return f1[n][m]|f2[n][m];
}
int main()
{
    freopen("expand.in","r",stdin);
    freopen("expand.out","w",stdout);
    int c,q;
    scanf("%d%d%d%d",&c,&n,&m,&q);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&x[i]);
        tx[i]=x[i];
    }
    for(int i=1;i<=m;i++)
    {
        scanf("%d",&y[i]);
        ty[i]=y[i];
    }
    printf("%d",solve());
    while(q--)
    {
        int kx,ky;
        scanf("%d%d",&kx,&ky);
        for(int i=1;i<=kx;i++)
        {
            int p,v;
            scanf("%d%d",&p,&v);
            x[p]=v;
        }
        for(int i=1;i<=ky;i++)
        {
            int p,v;
            scanf("%d%d",&p,&v);
            y[p]=v;
        }
        printf("%d",solve());
        memcpy(x,tx,sizeof(tx));
        memcpy(y,ty,sizeof(ty));
    }
    return 0;
}