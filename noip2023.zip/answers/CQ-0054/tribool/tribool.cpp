//clear!!!!!!!!!!!!!!!!!!!!!!!!!
#include<bits/stdc++.h>
typedef long long ll;
using namespace std;
const int N=200015;
#define ms(RA) memset(RA,0,sizeof(RA))
// -2 U
// -1 T 
// 0 F
// 1-n xi
// n+1-2n !xi

int n,m,num[N],prt[N],prt2[N],siz[N],siz2[N],id[N],cnn,cr[N],sizadd,ghost[N],beenadd[N];
bool vst[N];
vector<int> g[N];
int fa(int s){return prt[s]==s?s:prt[s]=fa(prt[s]);}
int fa2(int s){return prt2[s]==s?s:prt2[s]=fa2(prt2[s]);}
void add(int x,int y){/*printf("add:%d %d\n",x,y),*/g[x].push_back(y),g[y].push_back(x);}
void merge(int x,int y)
{
	x=fa(x),y=fa(y);
	if(x==y) return;
	siz[y]+=siz[x],prt[x]=y;
}
void merge2(int x,int y)
{
	x=fa2(x),y=fa2(y);
	if(x==y) return vst[x]=true,void();
	siz2[y]+=siz2[x],prt2[x]=y;
}
int tfu(int x)
{
	if(x==-2) return -2;
	if(x==-1) return 0;
	if(x==0) return -1;
	if(1<=x && x<=n) return x+n;
	if(n+1<=x && x<=2*n) return x-n;
}
int dfs(int r,int up,int ori,int len)
{
	if(r==ori && len) return len;
	int rec=-1;
	for(auto y:g[r])
	{
		if(y!=up) rec=max(rec,dfs(y,r,ori,len+1));
	}
	return rec;
}
void solve()
{
	ms(num),ms(prt),ms(prt2),ms(siz),ms(siz2),ms(id),cnn=0,ms(cr),ms(vst),sizadd=0,ms(ghost),ms(beenadd);
	scanf("%d %d",&n,&m);
	for(int i=0;i<=n;i++) g[i].clear();
	for(int i=1;i<=n;i++) prt[i]=num[i]=i,siz[i]=1;
	prt[n+1]=n+1,prt[n+2]=n+2,prt[n+3]=n+3;
	num[n+1]=0,num[n+2]=-1,num[n+3]=-2;
	for(int i=1,x,y;i<=m;i++)
	{
		char c;cin>>c;
		if(c=='-')
		{
			scanf("%d %d",&x,&y);
			num[x]=tfu(num[y]);
		}
		else if(c=='+')
		{
			scanf("%d %d",&x,&y);
			num[x]=num[y];
		}
		else
		{
			scanf("%d",&x);
			if(c=='T') num[x]=-1;
			if(c=='F') num[x]=0;
			if(c=='U') num[x]=-2;
		}
	}
	int F=n+1,T=n+2,U=n+3;
	//ͬ�ߴ��������鼯�� 
	for(int x=1;x<=n;x++)
	{
		int to=num[x];
		if(to<=0) merge(x,n-to+1);
		else if(1<=to && to<=n) merge(x,to);
	}
	//����� ���ڽڵ�/����ڵ�/�����������ɻ���Ϊ1�Ļ������� 
	//��߹��ɻ�����ɭ�֣�
	//�������ϻ���Ϊ�����������û�����triboolΪU
	
	
	//����� ����ڵ�/���ڽڵ� 
	
	//�����ڽڵ��ȫ����Ϊ U 
	for(int i=1;i<=n;i++)
		if(prt[i]==i) 
		{
			int to=num[i];
			if(n+1<=to && to<=2*n)
			{
				if(fa(to-n)==i || fa(to-n)==U) merge(i,U),num[i]=-2,ghost[i]=1;
			}
		}
	for(int i=1;i<=n;i++)
	{
		if(prt[i]==i)
		{
			++cnn;
			id[i]=cnn,siz2[cnn]=siz[i];
		}
	}
	for(int i=1;i<=cnn;i++) prt2[i]=i,cr[i]=-1;
	for(int i=1;i<=n;i++)
		if(prt[i]==i)
		{
			int to=num[i];
			if(n+1<=to && to<=2*n)
			{
				int goal=fa(to-n);
				if(goal!=U) add(id[i],id[goal]),merge2(id[i],id[goal]);
			}
		}
	//�� U �����ȫ����Ϊ U
	for(int i=1;i<=n;i++)
	{
		if(ghost[i]) sizadd+=(1-beenadd[fa2(id[i])])*siz2[fa2(id[i])],beenadd[fa2(id[i])]=1;
	}
//	printf("num:");for(int i=1;i<=n;i++) printf("%d ",num[i]);puts(""); 
//	printf("siz U:");printf("%d ",siz[U]);puts("");
//	printf("prt:");for(int i=1;i<=n;i++) printf("%d ",fa(i));puts(""); 
//	printf("prt:");for(int i=1;i<=n;i++) printf("%d ",siz[i]);puts(""); 
//	
//	printf("id:");for(int i=1;i<=n;i++) printf("%d ",id[i]);puts("");
//	printf("ff:");for(int i=1;i<=n;i++) printf("%d ",fa2(i));puts("");
//	printf("%d\n",siz2[0]);
//	for(int i=1;i<=n;i++) id[i]=id[fa(i)];
	
	int rec=0;
	for(int i=1;i<=cnn;i++)
		if(vst[i]==true)
		{
//			printf("find:%d\n",i);
			cr[i]=1;
			if(dfs(i,0,i,0)%2==1) rec+=siz2[fa2(i)];
		}
	printf("%d\n",sizadd+rec+siz[n+3]);
}
int main()
{
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	int c,t;
	scanf("%d %d",&c,&t);
	while(t--) solve();
	return 0;
}

