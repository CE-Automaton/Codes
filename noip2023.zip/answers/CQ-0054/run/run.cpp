#include<bits/stdc++.h>
typedef long long ll;
using namespace std;
#define int ll
const int N=1005;
const ll INF=4485090715960753727;
int n,m,k,d;
vector< pair<int,ll> > add[N];
ll f[N][N];
ll calc(int pos,int num)
{
	if(!add[pos].size()) return 0ll;
	int l=0,r=add[pos].size()-1,ans=-1;
	while(l<=r)
	{
		int mid=l+r>>1;
		if(num>=add[pos][mid].first) ans=mid,l=mid+1;
		else r=mid-1;
	}
	return (ans==-1)?0ll:add[pos][ans].second;
}
void solve()
{
	scanf("%lld %lld %lld %lld",&n,&m,&k,&d);
	for(int i=1;i<=n;i++) add[i].clear();
	for(int i=1,pos,cnn,v;i<=m;i++)
		scanf("%lld %lld %lld",&pos,&cnn,&v),add[pos].push_back({cnn,1ll*v});
	for(int i=1;i<=n;i++)
	{
		sort(add[i].begin(),add[i].end());
		for(int j=1;j<add[i].size();j++) add[i][j].second+=add[i][j-1].second;
	}
	memset(f,-0x3f,sizeof(f));
	f[0][0]=0;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<=k;j++) f[i+1][0]=max(f[i+1][0],f[i][j]);
		for(int j=0;j<k;j++)
			if(f[i][j]!=-INF)
				f[i+1][j+1]=max(f[i+1][j+1],f[i][j]-d+calc(i+1,j+1));
	}
	ll Ans=-LLONG_MAX;
	for(int j=0;j<=k;j++) Ans=max(Ans,f[n][j]);
	printf("%lld\n",Ans);
}
signed main()
{
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	int c,t;
	scanf("%lld %lld",&c,&t);
	while(t--) solve();
	return 0;
}

