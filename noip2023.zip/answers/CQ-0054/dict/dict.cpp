#include<bits/stdc++.h>
typedef long long ll;
using namespace std;
typedef vector< pair<int,int> > vpl;
const int N=3005;
int t[50],n,m;
bool ans[N];
string s[N<<1];
vector< pair< vpl , int > > ttl;
vpl mn,mx;
int cdd(const vpl &x,const vpl &y)
{
	int i=0,j=0;
	while(true)
	{
		while(i<26 && x[i].second==0) i++;
		while(j<26 && y[j].second==0) j++;
		if(i>25 || j>25) return 0;
//		printf("%d %d\n",i,j);
		if(x[i].first==y[j].first)
		{
			if(x[i].second==y[j].second) i++,j++;
			else if(x[i].second<y[j].second) i++;
			else j++;
		}
		else if(x[i].first<y[j].first) return 1;
		else return -1;
	}
}
void output(int i)
{
	for(int j=0;j<26;j++)
			for(int tm=1;tm<=ttl[i].first[j].second;tm++) putchar(ttl[i].first[j].first+'a'-1);
	printf(" %d\n",ttl[i].second);
}
bool cmp(pair< vpl , int > &x,pair< vpl , int > &y)
{
	int r=cdd(x.first,y.first);
	if(r==0) return x.second<y.second;
	else return r==1;
}
int main()
{
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++) cin>>s[i];
	for(int i=1;i<=n;i++)
	{
		mn.clear(),mx.clear(); for(int j=1;j<=26;j++) t[j]=0;
		for(auto c:s[i]) t[c-'a'+1]++;
		
		for(int j=1;j<=26;j++) mn.push_back({j,t[j]});
		for(int j=26;j>=1;j--) mx.push_back({j,t[j]});
//		printf("%d\n",cmp({mx,1},{mn,1}));
//		printf("%s %s\n",mn.c_str(),mx.c_str());
		ttl.push_back({mn,i}),ttl.push_back({mx,n+i});
	}
//	output(0),output(2);
//	printf("%d\n",cdd(ttl[0].first,ttl[1].first));
	sort(ttl.begin(),ttl.end(),cmp);
	for(int i=0;i<ttl.size();i++)
	{
		if(ttl[i].second>n) break;
		else ans[ttl[i].second]=true; 
	}
	for(int i=1;i<=n;i++) printf("%d",(int)ans[i]);
	return 0;
}

