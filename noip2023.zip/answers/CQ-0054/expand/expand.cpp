#include<bits/stdc++.h>
typedef long long ll;
using namespace std;
int main()
{
	return 0;
}

