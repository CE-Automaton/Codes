#include<bits/stdc++.h>
using namespace std;
const int MAXN=5e5+5;
int c,n,m,q;
int A[MAXN];
int B[MAXN];
int Pa[MAXN];
int Pb[MAXN];
int kx,ky;
int p,v;
int dp[2005][2005];
int cal()
{
    dp[0][0]=1;
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m;j++)
        {
            dp[i][j]=0;
            if(A[i]<B[j])
            {
                dp[i][j]|=dp[i-1][j-1];
                dp[i][j]|=dp[i][j-1];
                dp[i][j]|=dp[i-1][j];
            }
        }
    }
    if(dp[n][m])
    {
        return 1;
    }

    dp[0][0]=1;
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m;j++)
        {
            dp[i][j]=0;
            if(A[i]>B[j])
            {
                dp[i][j]|=dp[i-1][j-1];
                dp[i][j]|=dp[i][j-1];
                dp[i][j]|=dp[i-1][j];
            }
        }
    }
    if(dp[n][m])
    {
        return 1;
    }
    return 0;
}
int main()
{
    freopen("expand.in","r",stdin);
    freopen("expand.out","w",stdout);
    scanf("%d %d %d %d",&c,&n,&m,&q);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&A[i]);
    }
    for(int i=1;i<=m;i++)
    {
        scanf("%d",&B[i]);
    }
    printf("%d",cal());
    while(q--)
    {
        for(int i=1;i<=n;i++)
        {
            Pa[i]=A[i];
            Pb[i]=B[i];
        }
        scanf("%d %d",&kx,&ky);
        while(kx--)
        {
            scanf("%d %d",&p,&v);
            A[p]=v;
        }
        while(ky--)
        {
            scanf("%d %d",&p,&v);
            B[p]=v;
        }
        printf("%d",cal());
        for(int i=1;i<=n;i++)
        {
            A[i]=Pa[i];
            B[i]=Pb[i];
        }
    }
}