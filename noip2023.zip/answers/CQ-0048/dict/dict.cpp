#include<bits/stdc++.h>
using namespace std;
const int MAXN=3005;
int n,m;
string S;
int Cnt[MAXN][26];
pair<int,int>Fir[MAXN],Las[MAXN];
int main()
{
    freopen("dict.in","r",stdin);
    freopen("dict.out","w",stdout);
    scanf("%d %d",&n,&m);
    for(int i=1;i<=n;i++)
    {
        cin>>S;
        for(int j=0;j<m;j++)
        {
            Cnt[i][S[j]-'a']++;
        }
    }    

    for(int i=1;i<=n;i++)
    {
        for(int j=0;j<26;j++)
        {
            if(Cnt[i][j])
            {
                Fir[i]=make_pair(j,Cnt[i][j]);
                break;
            }
        }
        for(int j=25;j>=0;j--)
        {
            if(Cnt[i][j])
            {
                Las[i]=make_pair(j,Cnt[i][j]);
                break;
            }
        }
    }
    for(int i=1;i<=n;i++)
    {
        bool f=1;
        for(int j=1;j<=n;j++)
        {
            if(i==j)
            {
                continue;
            }
            if(Fir[i].first>=Las[j].first)
            {
                f=0;
            }
        }
        printf("%d",f);
    }
}