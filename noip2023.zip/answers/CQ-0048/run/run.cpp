#include<bits/stdc++.h>
#define ls Tree[p].lc
#define rs Tree[p].rc
using namespace std;
void read(int &x)
{
    x=0;
    int f=1;
    char s=getchar();
    while(s<'0'||s>'9')
    {
        if(s=='-')
        {
            f*=-1;
        }
        s=getchar();
    }
    while(s>='0'&&s<='9')
    {
        x=(x*10)+(s-'0');
        s=getchar();
    }
    x*=f;
    return;
}
const int MAXN=2e5+5;
int c,t;
int n,m,k,d;
struct node{
    int x,y,v;
}a[MAXN];
int lsh[MAXN];
vector<pair<int,int> >Rec[MAXN];
mt19937 Niuzi(998244353);
struct FHQ_node{
    int key;
    int lc,rc;
    int x,len;
    long long val;
    long long date;
    long long lazy;
    int Siz;
    int add;
    int Mx;
}Tree[MAXN];
int rt,cnt_node;
int New(int x,int len,long long vx)
{
    if(!len)
    {
        return 0;
    }
    ++cnt_node;
    Tree[cnt_node].key=Niuzi();
    Tree[cnt_node].lc=Tree[cnt_node].rc=0;
    Tree[cnt_node].Siz=1;
    Tree[cnt_node].date=Tree[cnt_node].val=vx;
    Tree[cnt_node].x=x;
    Tree[cnt_node].len=len;
    Tree[cnt_node].lazy=0;
    Tree[cnt_node].add=0;
    Tree[cnt_node].Mx=x;
    return cnt_node;
}
void push_up(int p)
{
    Tree[p].Siz=Tree[ls].Siz+Tree[rs].Siz+1;
    Tree[p].date=Tree[p].val;
    if(ls)
    {
        Tree[p].date=max(Tree[p].date,Tree[ls].date);
    }
    if(rs)
    {
        Tree[p].date=max(Tree[p].date,Tree[rs].date);
    }


    Tree[p].Mx=Tree[p].x;
    if(ls)
    {
        Tree[p].Mx=min(Tree[p].Mx,Tree[ls].Mx);
    }
    if(rs)
    {
        Tree[p].Mx=min(Tree[p].Mx,Tree[rs].Mx);
    }
}
void push_down(int p)
{
    if(Tree[p].lazy)
    {
        if(ls)
        {
            Tree[ls].lazy+=Tree[p].lazy;
            Tree[ls].date+=Tree[p].lazy;
            Tree[ls].val+=Tree[p].lazy;
        }
        if(rs)
        {
            Tree[rs].lazy+=Tree[p].lazy;
            Tree[rs].date+=Tree[p].lazy;
            Tree[rs].val+=Tree[p].lazy;
        }
        Tree[p].lazy=0;
    }

    if(Tree[p].add)
    {
        if(ls)
        {
            Tree[ls].add+=Tree[p].add;
            Tree[ls].x+=Tree[p].add;
            Tree[ls].Mx+=Tree[p].add;
        }
        if(rs)
        {
            Tree[rs].add+=Tree[p].add;
            Tree[rs].x+=Tree[p].add;
            Tree[rs].Mx+=Tree[p].add;
        }
        Tree[p].add=0;
    }
}
void split(int p,int &x,int &y,int k)
{
    if(!p)
    {
        x=0;
        y=0;
        return;
    }
    push_down(p);
    if(Tree[ls].Siz+1<=k)
    {
        x=p;
        split(rs,rs,y,k-(Tree[ls].Siz+1));
    }
    else
    {
        y=p;
        split(ls,x,ls,k);
    }
    push_up(p);
}
void Split(int p,int &x,int &y,int k)
{
    if(!p)
    {
        x=0;
        y=0;
        return;
    }
    push_down(p);
    if(Tree[p].x<=k)
    {
        x=p;
        Split(rs,rs,y,k);
    }
    else
    {
        y=p;
        Split(ls,x,ls,k);
    }
    push_up(p);
}
int Merge(int x,int y)
{
    if((!x)||(!y))
    {
        return x+y;
    }
    if(Tree[x].key<Tree[y].key)
    {
        push_down(x);
        Tree[x].rc=Merge(Tree[x].rc,y);
        push_up(x);
        return x;
    }
    else
    {
        push_down(y);
        Tree[y].lc=Merge(x,Tree[y].lc);
        push_up(y);
        return y;
    }
}
int Query(int p,int x)
{
    if(!p)
    {
        return 0;
    }
    if(Tree[p].Mx>x)
    {
        return 0;
    }
    if(Tree[p].x<=x&&Tree[p].x+Tree[p].len-1>=x)
    {
        return p;
    }
    push_down(p);
    int Res=0;
    if(rs)
    {
        Res=Query(rs,x);
    } 
    if(Res)
    {
        return Res;
    }
    if(ls)
    {
        Res=Query(ls,x);
    }
    return Res;
}
int main()
{
    freopen("run.in","r",stdin);
    freopen("run.out","w",stdout);
    scanf("%d %d",&c,&t);
    while(t--)
    {
        int Cnt=0;
        read(n);
        read(m);
        read(k);
        read(d);
        for(int i=1;i<=m;i++)
        {
            read(a[i].x);
            read(a[i].y);
            read(a[i].v);
            lsh[++Cnt]=a[i].x;
        }
        lsh[++Cnt]=n;
        sort(lsh+1,lsh+1+Cnt);
        Cnt=unique(lsh+1,lsh+1+Cnt)-lsh-1;
        for(int i=1;i<=m;i++)
        {
            a[i].x=lower_bound(lsh+1,lsh+1+Cnt,a[i].x)-lsh;
            Rec[a[i].x].push_back(make_pair(a[i].y,a[i].v));
        }

        rt=0;
        cnt_node=0;
        rt=New(0,1,0);
        int Las=0;
        for(int i=1;i<=Cnt;i++)
        {
            int det=lsh[i]-Las;
            long long fv=Tree[rt].date;
            Tree[rt].x+=det;
            Tree[rt].add+=det;
            Tree[rt].Mx+=det;

            Tree[rt].date-=(long long)det*d;
            Tree[rt].lazy-=(long long)det*d;
            Tree[rt].val-=(long long)det*d;
            rt=Merge(New(0,det,fv),rt);
            while(1)
            {
                int lx,rx;
                split(rt,lx,rx,Tree[rt].Siz-1);
                if(Tree[rx].x>k)
                {
                    rt=lx;
                }
                else
                {
                    int Lx=k-Tree[rx].x+1;
                    Tree[rx].len=min(Tree[rx].len,Lx);
                    if(Tree[rx].len)
                    {
                        rt=Merge(lx,rx);
                    }
                    else
                    {
                        rt=lx;
                    }
                    break;
                }
            }
            for(int j=0;j<Rec[i].size();j++)
            {
                int Pi=Rec[i][j].first;
                int Vi=Rec[i][j].second;
                int fid=Query(rt,Pi);
                if(fid)
                {
                    int lx,rx;
                    int xi=Tree[fid].x;
                    Split(rt,lx,rx,xi);
                    int zx;
                    split(lx,lx,zx,Tree[lx].Siz-1);
                    
                    int RR=Tree[zx].x+Tree[zx].len-1;
                    int Ri=Pi-1;
                    int Li=Pi;
                    long long VV=Tree[zx].val-((long long)d*(Pi-Tree[zx].x));
                    int Id=New(Li,RR-Li+1,VV);
                    Tree[zx].len=Ri-Tree[zx].x+1;
                    if(!Tree[zx].len)
                    {
                        zx=0;
                    }
                    rx=Merge(Id,rx);
                    Tree[rx].date+=Vi;
                    Tree[rx].lazy+=Vi;
                    Tree[rx].val+=Vi;
                    rt=Merge(Merge(lx,zx),rx);
                }
            }
            

            Las=lsh[i];
        }   

        printf("%lld\n",Tree[rt].date);
        for(int i=1;i<=Cnt;i++)
        {
            Rec[i].clear();
        }

    }       
}