#include<bits/stdc++.h>
using namespace std;
const int MAXN=2e5+5;
int c,t;
int n,m;
struct node{
    int id,op; 
}a[MAXN];
char s[4];
int x,y;
vector<int>g[MAXN];
int dfn[MAXN];
int cnt_dfn;
int cnt_scc;
int low[MAXN];
int scc[MAXN];
stack<int>st;
void dfs(int x)
{
    st.push(x);
    dfn[x]=++cnt_dfn;
    low[x]=dfn[x];
    for(int i=0;i<g[x].size();i++)
    {
        int v=g[x][i];
        if(dfn[v])
        {
            if(!scc[v])
            {
                low[x]=min(low[x],dfn[v]);
            }
        }
        else
        {
            dfs(v);
            low[x]=min(low[x],low[v]);
        }
    }
    if(dfn[x]==low[x])
    {
        ++cnt_scc;
        while(st.size())
        {
            scc[st.top()]=cnt_scc;
            if(st.top()==x)
            {
                st.pop();
                break;
            }
            st.pop();
        }
    }
}
int col[MAXN];
vector<int>G[MAXN];
int rd[MAXN];
int main()
{
    freopen("tribool.in","r",stdin);
    freopen("tribool.out","w",stdout);
    scanf("%d %d",&c,&t);
    while(t--)
    {
        scanf("%d %d",&n,&m);
        for(int i=1;i<=n;i++)
        {
            a[i].id=i;
            a[i].op=0;
        }
        for(int i=1;i<=2*n;i++)
        {
            g[i].clear();
            dfn[i]=scc[i]=low[i]=0;
            col[i]=0;
            G[i].clear();
            rd[i]=0;
        }
        cnt_dfn=0;
        cnt_scc=0;
        for(int i=1;i<=m;i++)
        {
            scanf("%s",s);
            if(s[0]=='T')
            {   
                scanf("%d",&x);
                a[x].id=0;
                a[x].op=1;
            }
            else if(s[0]=='F')
            {
                scanf("%d",&x);
                a[x].id=0;
                a[x].op=0;
            }  
            else if(s[0]=='U')
            {
                scanf("%d",&x);
                a[x].id=0;
                a[x].op=-1;
            }
            else if(s[0]=='+')
            {   
                scanf("%d %d",&x,&y);
                a[x].id=a[y].id;
                a[x].op=a[y].op;
            }
            else if(s[0]=='-')
            {
                scanf("%d %d",&x,&y);
                a[x].id=a[y].id;
                a[x].op=a[y].op;
                if(a[x].op!=-1)
                {
                    a[x].op^=1;
                }
            }
        }

        for(int i=1;i<=n;i++)
        {
            if(a[i].id)
            {
                if(a[i].op==0)
                {
                    g[a[i].id].push_back(i);
                    g[a[i].id+n].push_back(i+n);
                }
                else
                {
                    g[a[i].id].push_back(i+n);
                    g[a[i].id+n].push_back(i);
                }
            
            }
            else
            {
                if(a[i].op==0)
                {
                    g[i].push_back(i+n);
                }
                else if(a[i].op==1)
                {
                    g[i+n].push_back(i);
                }
                else
                {
                    g[i].push_back(i+n);
                    g[i+n].push_back(i);
                }
            }
        }
        for(int i=1;i<=2*n;i++)
        {
            if(!dfn[i])
            {
                dfs(i);
            }
        }
        
        for(int i=1;i<=n;i++)
        {
            if(scc[i]==scc[i+n])
            {
                col[scc[i]]=1;
            }
        }
        for(int i=1;i<=2*n;i++)
        {
            for(int j=0;j<g[i].size();j++)
            {
                int v=g[i][j];
                if(scc[i]!=scc[v])
                {
                    G[scc[i]].push_back(scc[v]);
                    rd[scc[v]]++;
                }
            }
        }
        queue<int>q;
        for(int i=1;i<=cnt_scc;i++)
        {
            if(!rd[i])
            {   
                q.push(i);
            }
        }
        while(q.size())
        {
            int temp=q.front();
            q.pop();
            for(int i=0;i<G[temp].size();i++)
            {
                int v=G[temp][i];
                rd[v]--;
                if(!rd[v])
                {
                    q.push(v);
                }
                col[v]|=col[temp];
            }
        }
        int Res=0;
        for(int i=1;i<=n;i++)
        {
            if(col[scc[i]]||col[scc[i+n]])
            {
                ++Res;
            }
        }
        printf("%d\n",Res);
    }
}