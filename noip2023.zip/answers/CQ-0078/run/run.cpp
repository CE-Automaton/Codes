#include<bits/stdc++.h>
using namespace std;
const int maxN=1e3+5;
const int MAXN=1e5+5;
const int MAXK=105;
int c,t;
int n;
long long m,k;
long long d,ans;
long long f[maxN][maxN],g[MAXN][MAXK],Max[MAXN];
struct node{
	long long val;
	long long l,r;
}a[MAXN];
bool cmp(node u,node v)
{
	if(u.r==v.r) return u.l>=v.l;
	return u.r<v.r;
}
int main()
{
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	std::ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	cin>>c>>t;
	while(t--)
	{
		cin>>n>>m>>k>>d;
		ans=0;
		for(int i=1;i<=m;i++)
		{
			long long x,y;
			long long val;
			cin>>x>>y>>val;
			a[i].r=x,a[i].l=x-y+1,a[i].val=val;
		}
		sort(a+1,a+m+1,cmp);
		if(c<=9)
		{
			for(int i=0;i<=n;i++)
			{
				for(int j=0;j<=k;j++)
				{
					f[i][j]=-0x7ffffffffffff;
				}
			}
			int L=0;
			f[0][0]=0;
			for(int i=1;i<=n;i++)
			{
				long long res=0;
				f[i][0]=f[i-1][0];
				while(a[L+1].r<i) L++;
				for(int j=1;j<=k;j++)
				{
					while(L+1<=m&&a[L+1].r==i&&a[L+1].l>=i-j+1)
					{
						L++;
						res+=a[L].val; 
					}
					f[i][j]=max(f[i][j],f[i-1][j-1]-d+res);
					f[i][0]=max(f[i][0],f[i-1][j]);
					ans=max(ans,f[i][j]);
				}
				ans=max(ans,f[i][0]);
			}
			cout<<ans<<'\n';
			continue;
		}
		if(c>=15&&c<=16)
		{
			for(int i=0;i<=m;i++)
			{
				for(int j=0;j<=k;j++)
				{
					g[i][j]=-0x7ffffffffffff;
				}
				Max[i]=-0x7fffffffffffff;
			}
			g[0][0]=0;
			a[0].r=-1; 
			Max[0]=0;
			for(int i=1;i<=m;i++)
			{
				long long res=0;
				g[i][0]=Max[i-1];
				for(long long j=1;j<=k;j++)
				{
					long long site=a[i-1].r-(a[i].r-j+1)+1;
					if(a[i].r-j+1<=a[i].l) res=a[i].val;
					if(site<0)
					{
						g[i][j]=max(g[i][j],Max[i-1]-d*j+res);
					}
					else
					{
						g[i][j]=max(g[i][j],g[i-1][site]-d*(j-site)+res);
					}
					Max[i]=max(Max[i],g[i][j]); 
				}
				Max[i]=max(Max[i],g[i][0]);
			}
			cout<<Max[m]<<'\n';
			continue;
		}
//		if(c>=17&&c<=18)
//		{
			for(int i=1;i<=m;i++)
			{
				if(a[i].r-a[i].l+1<=k&&((a[i].r-a[i].l+1)*d)<=a[i].val)
				{
					ans+=a[i].val-(a[i].r-a[i].l+1)*d;
				}
			}
			cout<<ans<<'\n';
//		}
	}
	return 0;
}
/*
0 1
10 5 5 13
7 2 64
9 2 80
9 5 8
9 7 12
6 6 20
*/
