#include<bits/stdc++.h>
using namespace std;
const int MAXN=2e5+5;
int c,t;
int n,m;
int ans;
char val[MAXN];
vector<int>e[MAXN];
int prt[MAXN],num[MAXN];
bool flag[MAXN],bj[MAXN];
int getfather(int u)
{
	if(prt[u]==u) return u;
	return prt[u]=getfather(prt[u]);
}
void hb(int u,int v)
{
	int x=getfather(u),y=getfather(v);
	if(x!=y) prt[x]=y;
}
void dfs(int u)
{
	if(bj[u]) return;
	ans++;
	bj[u]=1;
	for(auto v:e[u])
	{
		if(bj[v]) continue;
		dfs(v);
	}
}
int main()
{
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	std::ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	cin>>c>>t;
	while(t--)
	{
		cin>>n>>m;
		ans=0;
		for(int i=1;i<=2*n;i++)
		{
			prt[i]=i;
			val[i]='A';
			bj[i]=0;
		}
		for(int i=1;i<=n;i++)
		{
			num[i]=i;
			flag[i]=1;
			while(!e[i].empty()) e[i].pop_back();
		}
		for(int i=1;i<=m;i++)
		{
			char opt;
			cin>>opt;
			if(opt=='T'||opt=='F'||opt=='U')
			{
				int x;
				cin>>x;
				flag[x]=1;
				num[x]=x;
				val[x]=opt;
				continue;
			}
			if(opt=='+')
			{
				int x,y;
				cin>>x>>y;
				if(val[y]!='A')
				{
					flag[x]=1;
					num[x]=x;
					val[x]=val[y];
				}
				else
				{
					val[x]='A';
					num[x]=num[y];
					flag[x]=flag[y];
				}
			}
			if(opt=='-')
			{
				int x,y;
				cin>>x>>y;
				if(val[y]!='A')
				{
					flag[x]=1;
					num[x]=x;
					if(val[y]=='T')
					{
						val[x]='F';
					}
					if(val[y]=='F')
					{
						val[x]='T';
					}
					if(val[y]=='U')
					{
						val[x]='U';
					}
				}
				else
				{
					val[x]='A';
					num[x]=num[y];
					flag[x]=1^flag[y];
				}
			}
		}
		for(int i=1;i<=n;i++)
		{
			if(val[i]!='A')
			{
				if(val[i]=='T')
				{
					val[i+n]='F';
				}
				if(val[i]=='F')
				{
					val[i+n]='T';
				}
				if(val[i]=='U')
				{
					val[i+n]='U';
				}
			}
			if(flag[i])
			{
				hb(num[i],i);
				hb(num[i]+n,i+n);
				e[num[i]].emplace_back(i);
				e[i].emplace_back(num[i]);
			}
			else
			{
				hb(num[i]+n,i);
				hb(num[i],n+i);
				e[num[i]].emplace_back(i);
				e[i].emplace_back(num[i]);
			}
		}
		for(int i=1;i<=n;i++)
		{
			if(getfather(i)==getfather(n+i))
			{
				dfs(i);
			}
		}
		for(int i=1;i<=n;i++)
		{
			if(bj[i]) continue;
			if(val[i]=='U')
			{
				dfs(i);
			}
		}
		cout<<ans<<'\n';
	}
	return 0;
}
/*
input:
0 1
10 10
- 7 6
+ 4 1
+ 6 4
T 1
+ 2 9
- 9 10
U 10
+ 5 5
U 8
T 3
output:
4
*/
