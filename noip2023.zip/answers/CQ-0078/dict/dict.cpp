#include<bits/stdc++.h>
using namespace std;
const int MAXN=3005;
int n,m,Max,Min;
char a[MAXN][MAXN],b[MAXN][MAXN];
bool cmp(char u,char v)
{
	return u>v;
}
bool pd(int u,int v)
{
	for(int i=1;i<=m;i++)
	{
		if(b[u][i]>b[v][i]) return 0;
		if(b[v][i]>b[u][i]) return 1;
	}
	return 1;
}
int main()
{
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	std::ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i]+1;
		for(int j=1;j<=m;j++)
		{
			b[i][j]=a[i][j];
		}
		sort(b[i]+1,b[i]+m+1,cmp);
		if(!Max||pd(i,Max))
		{
			Min=Max;
			Max=i;
		}
		else
		{
			if(!Min||pd(i,Min))
			{
				Min=i;
			}
		}
	}
	for(int i=1;i<=n;i++)
	{
		int k=(Max==i?Min:Max);
		sort(b[i]+1,b[i]+m+1);
		if(pd(k,i)) cout<<0;
		else cout<<1;
		sort(b[i]+1,b[i]+m+1,cmp);
	}
	cout<<'\n';
	return 0;
}
