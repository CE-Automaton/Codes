#include<bits/stdc++.h>
using namespace std;
const int MAXN=5e5+5;
const int maxN=2e3+5;
int c,n,m,q;
bool f[maxN][maxN][2];//< and >
long long X[MAXN],Y[MAXN],x[MAXN],y[MAXN];
void force()
{
	for(int i=0;i<=n;i++)
	{
		for(int j=0;j<=m;j++)
		{
			f[i][j][0]=f[i][j][1]=0;
		}
	}
	f[0][0][0]=f[0][0][1]=1;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			if(x[i]>y[j])
			{
				f[i][j][0]|=f[i-1][j-1][0];
				f[i][j][0]|=f[i][j-1][0];
				f[i][j][0]|=f[i-1][j][0];
			}
			if(x[i]<y[j])
			{
				f[i][j][1]|=f[i-1][j-1][1];
				f[i][j][1]|=f[i][j-1][1];
				f[i][j][1]|=f[i-1][j][1];
			}
		}
	}
	if(f[n][m][0]||f[n][m][1]) cout<<1;
	else cout<<0;
}
void get()
{
	int l=0,r=0;
	bool flag1=0,flag2=1;
	while(l<=n&&r<=m)
	{
		if(flag2&&r<=m)
		{
			r++;
			flag1=0;
			while(l+1<=n&&x[l+1]<y[min(m,r)])
			{
				flag1=1;
				l++;
			}
		}
		if(flag1&&l<=n)
		{
			l++;
			flag2=0;
			while(r+1<=m&&x[min(l,n)]<y[r+1])
			{
				flag2=1;
				r++;
			}
		}
		if(!flag1&&!flag2)
		{
			cout<<0;
			return;
		}
//		cout<<l<<" and "<<r<<'\n';
	}
	if(r>m)
	{
		for(int i=l;i<=n;i++)
		{
			if(y[m]<=x[i])
			{
				cout<<0;
				return;
			}
		}
		cout<<1;
		return;
	}
	if(l>n)
	{
		for(int i=r;i<=m;i++)
		{
			if(y[i]<=x[n])
			{
				cout<<0;
				return;
			}
		}
		cout<<1;
		return;
	}
	cout<<0;
	return;
}
int main()
{
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	std::ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	cin>>c>>n>>m>>q;
	for(int i=1;i<=n;i++) cin>>X[i],x[i]=X[i];
	for(int i=1;i<=m;i++) cin>>Y[i],y[i]=Y[i];
	if(n<=2000&&m<=2000)
	{
		force();
	}
	else
	{
		get();
	}
	while(q--)
	{
		for(int i=1;i<=n;i++) x[i]=X[i];
		for(int i=1;i<=m;i++) y[i]=Y[i];
		int kx,ky;
		cin>>kx>>ky;
		for(int i=1;i<=kx;i++)
		{
			int site;
			long long val;
			cin>>site>>val;
			x[site]=val;
		}
		for(int i=1;i<=ky;i++)
		{
			int site;
			long long val;
			cin>>site>>val;
			y[site]=val;
		}
		if(n<=2000&&m<=2000)
		{
			force();
			continue;
		}
		get();
	}
	return 0;
}
/*
0 5 5 0
1 2 3 4 5
2 2 2 2 3
*/
