#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>

using i64 = long long;
using u64 = unsigned long long;

namespace Read {
	i64 read() {
		i64 x = 0, Fx = 1; char c = getchar();
		while (c < '0' || c > '9') { Fx ^= (c == '-'); c = getchar(); }
		while ('0' <= c && c <= '9') { x = (x << 3) + (x << 1) + (c ^ 48); c = getchar(); }
		return Fx ? x : -x;
	}
	
	template <typename T>
	void read(T &x) {
		x = read();
	}
	
	template <typename T, typename... Ts>
	void read(T &x, Ts &...rest) {
		read(x);
		read(rest...);
	}
} using namespace Read;

namespace A {
	const int N = 5e5;
	const int Q = 60;
	
	int n, m, q;
	int x[N + 5];
	int y[N + 5];
	
	int px[N + 5];
	int vx[N + 5];
	int py[N + 5];
	int vy[N + 5];
	
	char ans[Q + 5];
	
	void print() {
		for (int i = 1; i <= n; i++)
			std::cerr << " " << x[i];
		std::cerr << "\n";
		for (int i = 1; i <= m; i++)
			std::cerr << " " << y[i];
		std::cerr << "\n";
	}
	
	int dp[2][N + 5];
	
	int work() {
		if (n > 2000) {
			if (x[1] == y[1]) {
				return 0;
			}
			if (x[n] == y[m]) {
				return 0;
			}
			if (x[1] > y[1] && x[n] < y[m]) {
				return 0;
			}
			if (x[1] < y[1] && x[n] > y[m]) {
				return 0;
			}
		}
		int mnx = x[1], mxx = x[1];
		int mny = y[1], mxy = y[1];
		for (int i = 1; i <= n; i++) {
			mnx = std::min(mnx, x[i]);
			mxx = std::max(mxx, x[i]);
		}
		for (int i = 1; i <= m; i++) {
			mny = std::min(mny, y[i]);
			mxy = std::max(mxy, y[i]);
		}
		if (n > 2000) {
			if (mxx == mxy) {
				return 0;
			}
			if (mnx == mny) {
				return 0;
			}
			if (x[1] < y[1] && mxx > mxy) {
				return 0;
			}
			if (x[1] > y[1] && mxx < mxy) {
				return 0;
			}
			if (x[1] < y[1] && mnx > mny) {
				return 0;
			}
			if (x[1] > y[1] && mnx < mny) {
				return 0;
			}
		}
		int good = (x[1] > y[1]);
		if (good) {
			std::swap(x, y);
			std::swap(n, m);
		}
		int now = 0, pre = 1;
		dp[now][0] = 1;
		for (int j = 1; j <= n; j++)
			dp[now][j] = 0;
		for (int i = 1; i <= m; i++) {
			std::swap(now, pre);
			dp[now][0] = 0;
			int ok = 0;
			for (int j = 1; j <= n; j++) {
				if (y[i] <= x[j]) {
					ok = 0;
				}
				if (y[i] > x[j]) {
					ok |= dp[pre][j - 1];
					ok |= dp[pre][j];
				}
				dp[now][j] = ok;
			}
		}
		int ans = dp[now][n];
		if (good) {
			std::swap(x, y);
			std::swap(n, m);
		}
		return ans;
	}
	
	void solve() {
		read(n, m, q);
		for (int i = 1; i <= n; i++)
			read(x[i]);
		for (int i = 1; i <= m; i++)
			read(y[i]);
		ans[0] = '0' + work();
		for (int id = 1; id <= q; id++) {
			int kx, ky;
			read(kx, ky);
			for (int i = 1; i <= kx; i++) {
				read(px[i], vx[i]);
				std::swap(x[px[i]], vx[i]);
			}
			for (int i = 1; i <= ky; i++) {
				read(py[i], vy[i]);
				std::swap(y[py[i]], vy[i]);
			}
			ans[id] = '0' + work();
			for (int i = kx; i >= 1; i--)
				std::swap(x[px[i]], vx[i]);
			for (int i = ky; i >= 1; i--)
				std::swap(y[py[i]], vy[i]);
		}
		printf("%s\n", ans);
	}
}

int main() {
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);
	
	int idx = 0, T = 1;
	
	read(idx);
//	read(T);
	
	while (T--) {
		A::solve();
	}
	
	return 0;
}
// 35
