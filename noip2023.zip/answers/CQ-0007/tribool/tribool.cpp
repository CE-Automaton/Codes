#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>

using i64 = long long;
using u64 = unsigned long long;

namespace Read {
	i64 read() {
		i64 x = 0, Fx = 1; char c = getchar();
		while (c < '0' || c > '9') { Fx ^= (c == '-'); c = getchar(); }
		while ('0' <= c && c <= '9') { x = (x << 3) + (x << 1) + (c ^ 48); c = getchar(); }
		return Fx ? x : -x;
	}
	
	template <typename T>
	void read(T &x) {
		x = read();
	}
	
	template <typename T, typename... Ts>
	void read(T &x, Ts &...rest) {
		read(x);
		read(rest...);
	}
} using namespace Read;

const int N = 100000;

int n, m, cnt;

int T, F, U;
int id[N + 5];

char str[3];

std::vector<std::pair<int, int> > adj[N * 2 + 5];

struct DSU {
	int fa[N * 2 + 5];
	
	int find(int x) {
		if (fa[x] == x) return x;
		return fa[x] = find(fa[x]);
	}
	
	void merge(int x, int y) {
		x = find(x);
		y = find(y);
		if (x == y) {
			return ;
		}
		fa[x] = y;
	}
	
	void init() {
		for (int i = 0; i <= N * 2; i++)
			fa[i] = i;
	}
} dsu;

int ed[N * 2 + 5];
int siz[N * 2 + 5];

bool vis[N * 2 + 5];

void dfs(int u, int now, int Root) {
	if (ed[u]) {
		if (now) {
			dsu.merge(ed[u], Root + n);
			dsu.merge(ed[u] + n, Root);
		} else {
			dsu.merge(ed[u], Root);
			dsu.merge(ed[u] + n, Root + n);
		}
	}
	for (const auto &e : adj[u]) {
		int v = e.first;
		int w = e.second;
		dfs(v, now ^ w, Root);
	}
}

void dfs2(int u, int now) {
	if (ed[u]) {
		dsu.merge(ed[u], ed[u] + n);
	}
	for (const auto &e : adj[u]) {
		int v = e.first;
		int w = e.second;
		dfs2(v, now ^ w);
	}
}

void solve() {
	read(n, m);
	for (int i = 1; i <= n; i++)
		id[i] = ++cnt;
	T = ++cnt;
	F = ++cnt;
	U = ++cnt;
	dsu.init();
	while (m--) {
		scanf("%s", str);
		if (str[0] == 'T') {
			int i;
			read(i);
			id[i] = ++cnt;
			adj[T].push_back({id[i], 0});
		} else if (str[0] == 'F') {
			int i;
			read(i);
			id[i] = ++cnt;
			adj[F].push_back({id[i], 0});
		} else if (str[0] == 'U') {
			int i;
			read(i);
			id[i] = ++cnt;
			adj[U].push_back({id[i], 0});
		} else if (str[0] == '+') {
			int i, j;
			read(i, j);
			int pre = id[j];
			id[i] = ++cnt;
			adj[pre].push_back({id[i], 0});
		} else if (str[0] == '-') {
			int i, j;
			read(i, j);
			int pre = id[j];
			id[i] = ++cnt;
			adj[pre].push_back({id[i], 1});
		}
	}
	for (int i = 0; i <= cnt; i++)
		ed[i] = 0;
	for (int i = 1; i <= n; i++)
		ed[id[i]] = i;
	for (int i = 1; i <= n; i++)
		dfs(i, 0, i);
	dfs2(n + 3, 0);
	for (int i = 1; i <= n * 2; i++) {
		vis[i] = false;
		siz[i] = 0;
	}
	for (int i = 1; i <= n; i++)
		++siz[dsu.find(i)];
	int ans = 0;
	for (int i = 1; i <= n; i++) {
		int x = dsu.find(i);
		int y = dsu.find(i + n);
		if (x == y) {
			if (!vis[x]) {
				vis[x] = true;
				ans += siz[x];
			}
		}
	}
	printf("%d\n", ans);
	for (int i = 0; i <= cnt; i++)
		adj[i].clear();
	cnt = 0;
}

int main() {
	freopen("tribool.in", "r", stdin);
	freopen("tribool.out", "w", stdout);
	
	int idx = 0, T = 1;
	read(idx, T);
	
	while (T--) {
		solve();
	}
	
	return 0;
}
// 100
