#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>

#include <random>

using i64 = long long;
using u64 = unsigned long long;

namespace Read {
	i64 read() {
		i64 x = 0, Fx = 1; char c = getchar();
		while (c < '0' || c > '9') { Fx ^= (c == '-'); c = getchar(); }
		while ('0' <= c && c <= '9') { x = (x << 3) + (x << 1) + (c ^ 48); c = getchar(); }
		return Fx ? x : -x;
	}
	
	template <typename T>
	void read(T &x) {
		x = read();
	}
	
	template <typename T, typename... Ts>
	void read(T &x, Ts &...rest) {
		read(x);
		read(rest...);
	}
} using namespace Read;

namespace Random {
	std::mt19937 myrand(1314520);
	int rnd() { return myrand(); }
	int rnd(int mod) { return (rnd() % mod + mod) % mod; }
	int rnd(int L, int R) { return rnd(R - L + 1); }
} using namespace Random;

const i64 INF = 1e18;

const int mod = 1e9 + 7;

const int N = 1e5;

int n, m, k, d, cnt;

struct info {
	int x, y, v;
} p[N + 5];

struct node {
	int ls, rs, key, siz;
	i64 val, mx, tag;
} tree[N + 5];

int NewNode(i64 val) {
	int u = ++cnt;
	tree[u].ls = 0;
	tree[u].rs = 0;
	tree[u].key = rnd(mod);
	tree[u].siz = 1;
	tree[u].val = val;
	tree[u].mx = val;
	tree[u].tag = 0;
	return u;
}

void spread(int u, i64 tag) {
	if (u) {
		tree[u].val += tag;
		tree[u].mx += tag;
		tree[u].tag += tag;
	}
}

void pushup(int u) {
	int ls = tree[u].ls;
	int rs = tree[u].rs;
	tree[u].siz = tree[ls].siz + 1 + tree[rs].siz;
	tree[u].mx = std::max({tree[ls].mx, tree[u].val, tree[rs].mx});
}

void pushdown(int u) {
	if (u && tree[u].tag) {
		spread(tree[u].ls, tree[u].tag);
		spread(tree[u].rs, tree[u].tag);
		tree[u].tag = 0;
	}
}

void split(int u, int siz, int &x, int &y) {
	if (!u) {
		x = y = 0;
	} else {
		pushdown(u);
		if (tree[tree[u].ls].siz >= siz) {
			y = u;
			split(tree[u].ls, siz, x, tree[u].ls);
		} else {
			x = u;
			split(tree[u].rs, siz - 1 - tree[tree[u].ls].siz, tree[u].rs, y);
		}
		pushup(u);
	}
}

int merge(int x, int y) {
	if (!x || !y) {
		return x | y;
	} else {
		if (tree[x].key < tree[y].key) {
			pushdown(x);
			tree[x].rs = merge(tree[x].rs, y);
			pushup(x);
			return x;
		} else {
			pushdown(y);
			tree[y].ls = merge(x, tree[y].ls);
			pushup(y);
			return y;
		}
	}
}

template<typename... Ts>
int merge(int x, int y, Ts ...rest) {
	return merge(merge(x, y), rest...);
}

std::vector<std::pair<int, int> > qry[N + 5];

void print(int u) {
	if (!u) return ;
	pushdown(u);
	print(tree[u].ls);
	std::cerr << " " << tree[u].val;
	print(tree[u].rs);
}

void solve() {
	read(n, m, k, d);
	for (int i = 1; i <= m; i++)
		read(p[i].x, p[i].y, p[i].v);
	for (int i = 1; i <= n; i++)
		qry[i].clear();
	for (int i = 1; i <= m; i++)
		qry[p[i].x].push_back({p[i].y, p[i].v});
	cnt = 0;
	tree[0].mx = -INF;
	int rt = NewNode(0);
	for (int i = 1; i <= n; i++) {
		i64 mx = tree[rt].mx;
		if (tree[rt].siz > k) {
			int x, y;
			split(rt, k, x, y);
			rt = x;
		}
		spread(rt, -d);
		rt = merge(NewNode(mx), rt);
		for (const auto &e : qry[i]) {
			int x, y;
			split(rt, e.first, x, y);
			spread(y, e.second);
			rt = merge(x, y);
		}
//		print(rt);
//		std::cerr << "\n";
	}
	i64 ans = tree[rt].mx;
	std::cout << ans << "\n";
}

int l[N + 5];
int r[N + 5];
int v[N + 5];

i64 dp[N + 5];
i64 sum[N + 5];

i64 val[N + 5];

int que[N + 5];
int head, tail;

void BC() {
	read(n, m, k, d);
	for (int i = 1; i <= m; i++) {
		read(p[i].x, p[i].y, p[i].v);
		if (p[i].y > k) {
			i--;
			m--;
			continue;
		}
		l[i] = p[i].x - p[i].y + 1;
		r[i] = p[i].x;
		v[i] = p[i].v;
		sum[i] = sum[i - 1] + v[i];
//		std::cerr << " " << l[i] << " " << r[i] << " " << v[i] << "\n";
	}
	head = 1;
	tail = 0;
	for (int i = 1, L = 1; i <= m; i++) {
//		dp[i] = dp[i - 1];
//		for (int j = i; j >= 1; j--) {
//			if (j != i && r[j] < l[j + 1] - 1) {
//				dp[i] = std::max(dp[i], dp[j] + sum[i] - sum[j] - (i64)(r[i] - l[j + 1] + 1) * d);
//				break;
//			}
//			if (r[i] - l[j] + 1 > k) {
//				break;
//			}
//			i64 val = sum[i] - sum[j - 1] - (i64)(r[i] - l[j] + 1) * d;
//			if (j >= 2) val += dp[j - 2];
//			dp[i] = std::max(dp[i], val);
//		}
//		continue;
		if (i != 1 && r[i - 1] + 1 < l[i]) L = i;
		while (L < i && r[i] - l[L] + 1 > k) L++;
		while (head <= tail && que[head] < L) ++head;
		dp[i] = std::max(dp[i - 1], dp[L - 1] + sum[i] - sum[L - 1] - (i64)(r[i] - l[L] + 1) * d);
		if (head <= tail && que[head] >= 2) {
			int j = que[head];
			dp[i] = std::max(dp[i], dp[j - 2] + sum[i] - sum[j - 1] - (i64)(r[i] - l[j] + 1) * d);
		}
		val[i] = (i64)l[i] * d - sum[i - 1];
		if (i >= 2) val[i] += dp[i - 2];
		while (head <= tail && val[i] > val[que[tail]]) --tail;
		que[++tail] = i;
	}
	i64 ans = std::max(dp[m], 0LL);
	std::cout << ans << "\n";
}

int main() {
	freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);
	
	int idx = 0, T = 1;
	read(idx, T);
	
	while (T--) {
		if (17 <= idx && idx <= 21) {
			BC();
		} else {
			solve();
		}
	}
	
	return 0;
}
// 56 + 20
