#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>

using i64 = long long;
using u64 = unsigned long long;

namespace Read {
	i64 read() {
		i64 x = 0, Fx = 1; char c = getchar();
		while (c < '0' || c > '9') { Fx ^= (c == '-'); c = getchar(); }
		while ('0' <= c && c <= '9') { x = (x << 3) + (x << 1) + (c ^ 48); c = getchar(); }
		return Fx ? x : -x;
	}
	
	template <typename T>
	void read(T &x) {
		x = read();
	}
	
	template <typename T, typename... Ts>
	void read(T &x, Ts &...rest) {
		read(x);
		read(rest...);
	}
} using namespace Read;

const int N = 3e3;

int n, m;
int cnt[N + 5][26 + 5];

int mx[N + 5];
int mn[N + 5];

char str[N + 5];

char ans[N + 5];

void solve() {
	read(n, m);
	for (int i = 0; i < n; i++) {
		scanf("%s", str);
		for (int j = 0; j < m; j++)
			++cnt[i][str[j] - 'a'];
		for (int j = 0; j < 26; j++)
			if (cnt[i][j]) mx[i] = j;
		for (int j = 25; j >= 0; j--)
			if (cnt[i][j]) mn[i] = j;
	}
	for (int i = 0; i < n; i++) {
		ans[i] = '1';
		for (int j = 0; j < n; j++) {
			if (j != i) {
				if (mn[i] >= mx[j]) {
					ans[i] = '0';
					break;
				}
			}
		}
	}
	printf("%s", ans);
}

int main() {
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);
	
	int T = 1;
//	read(T);
	
	while (T--) {
		solve();
	}
	
	return 0;
}
// 100
