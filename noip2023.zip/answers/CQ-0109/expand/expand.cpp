#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
int read() {
	int x=0; char ch=getchar();
	while (ch<'0') ch=getchar();
	while (ch>='0') x=x*10+ch-48, ch=getchar();
	return x;
}

const int N=5e5+3;
int c, n, m, Q, x[N], y[N], X[N], Y[N];
int f[2002][2002];

void sol1() {
//	for (int i=1; i<=n; i++) cout<<x[i]<<" ";
//	for (int j=1; j<=m; j++) 
	f[0][0]=1;
	for (int i=1; i<=n; i++) {
		for (int j=1; j<=m; j++) 
			if (1ll*(x[1]-y[1])*(x[i]-y[j])>0) 
				f[i][j]=f[i-1][j-1]|f[i-1][j]|f[i][j-1];
			else f[i][j]=0;
	}
	putchar(f[n][m]+'0');
}
void sol2() {
	if (1ll*(x[1]-y[1])*(x[n]-y[m])<=0) {
		putchar('0');
		return;
	}
	int mix=1e9+5, mxx=0, miy=1e9+5, mxy=0;
	for (int i=1; i<=n; i++) mix=min(mix, x[i]), mxx=max(mxx, x[i]);
	for (int i=1; i<=m; i++) miy=min(miy, y[i]), mxy=max(mxy, y[i]);
	if (x[1]<y[1]) {
		if (mxx>=mxy||miy<=mix) {
			putchar('0');
			return;
		}
	} else {
		if (mxx<=mxy||mix<=miy) {
			putchar('0');
			return;
		}
	}
	putchar('1');
}

int main() {
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);
	c=read(), n=read(), m=read(), Q=read();
	for (int i=1; i<=n; i++) X[i]=x[i]=read();
	for (int i=1; i<=m; i++) Y[i]=y[i]=read();
	if (n<=2000&&m<=2000) sol1();
	else sol2();
	while (Q--) {
		for (int i=1; i<=n; i++) x[i]=X[i];
		for (int i=1; i<=m; i++) y[i]=Y[i];
		int kx=read(), ky=read();
		for (int i=1; i<=kx; i++) {
			int p=read(), v=read();
			x[p]=v;
		}
		for (int i=1; i<=ky; i++) {
			int p=read(), v=read();
			y[p]=v;
		}
		if (n<=2000&&m<=2000) sol1();
		else sol2();
	}
	return 0;
}
/*
*/
