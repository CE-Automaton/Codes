#include <bits/stdc++.h>
using namespace std;

int read() {
	int x=0; char ch=getchar();
	while (ch<'0') ch=getchar();
	while (ch>='0') x=x*10+ch-48, ch=getchar();
	return x;
}

const int N=3003;
int n, m, p=1, flag=1;
vector<char> mx[N], mi[N];
char ss[N];

int cmp1(char x, char y) {
	return x>y;
}
int cmp2(char x, char y) {
	return x<y;
}

int solve(int i) {
	if (i==p&&flag) return 1;
	int k=0;
	while (k<m) {
		if (mi[i][k]==mx[p][k]) {
			k++; continue;
		}
		if (mi[i][k]<mx[p][k]) return 1;
		return 0;
	}
	return 0;
}

int main() {
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);
	n=read(), m=read();
	for (int i=1; i<=n; i++) {
		scanf("%s", ss);
		for (int j=0; j<m; j++) mx[i].push_back(ss[j]);
		mi[i]=mx[i];
		sort(mx[i].begin(), mx[i].end(), cmp1);
		sort(mi[i].begin(), mi[i].end(), cmp2);
		if (i==1) continue;
		int k=0;
		while (k<m) {
			if (mx[i][k]==mx[p][k]) {
				k++; continue;
			}
			if (mx[i][k]<mx[p][k]) p=i, flag=1;
			break;
		}
		if (k==m) flag=0;
	}
	for (int i=1; i<=n; i++) {
		putchar(solve(i)+48);
	}
	return 0;
}
