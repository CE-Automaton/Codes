#include <bits/stdc++.h>
using namespace std;

int read() {
	int x=0; char ch=getchar();
	while (ch<'0') ch=getchar();
	while (ch>='0') x=x*10+ch-48, ch=getchar();
	return x;
}

const int N=1e5+3, inf=1e5+1;
int x[N], flag, num, vis[N];
char opt[5];
struct edge {
	int to, w;
};
vector<edge> e[N];

void dfs(int u) {
	num++;
	vis[u]=1;
	for (auto i:e[u]) {
		int v=i.to;
		if (!vis[v]) {
			dfs(v);
		}
	}
	if (abs(x[u])==inf||x[u]==0) flag=u;
}
void dfs2(int u) {
	vis[u]=2;
	num+=(x[u]==0);
	for (auto i:e[u]) {
		int v=i.to;
		if (vis[v]!=2) {
			if (i.w==1) x[v]=x[u];
			else x[v]=-x[u];
			dfs2(v);
		}
	}
}
int check(int u) {
	vis[u]=2;
	for (auto i:e[u]) {
		int v=i.to, w=i.w==1?x[u]:-x[u];
		if (vis[v]!=2) {
			x[v]=w;
			if (!check(v)) return 0;
		}
		else {
			if (w!=x[v]) return 0;
		}
	}
	return 1;
}

void solve() {
	// T:inf F:-inf U=0
	int n=read(), m=read();
	for (int i=1; i<=n; i++) x[i]=i, vis[i]=0;
	while (m--) {
		scanf("%s", opt);
		if (opt[0]=='+') {
			int i=read(), j=read();
			x[i]=x[j];
		} else if (opt[0]=='-') {
			int i=read(), j=read();
			x[i]=-x[j];
		} else {
			int i=read();
			if (opt[0]=='T') x[i]=inf;
			else if (opt[0]=='F') x[i]=-inf;
			else x[i]=0;
		}
	}
	for (int i=1; i<=n; i++) if (abs(x[i])!=inf&&x[i]!=0) {
		int j=abs(x[i]);
		e[i].push_back({j, (x[i]>0)});
		e[j].push_back({i, (x[i]>0)});
	}
	int ans=0;
	for (int i=1; i<=n; i++) if (!vis[i]) {
		flag=0, num=0, dfs(i);
		if (flag) {
			num=0, dfs2(flag);
			ans+=num;
			continue;
		}
		x[i]=inf;
		if (check(i)) continue;
		ans+=num;
	}
	printf("%d\n", ans);
	
	for (int i=1; i<=n; i++) e[i].clear();
}

int main() {
	freopen("tribool.in", "r", stdin);
	freopen("tribool.out", "w", stdout);
	int c=read(), T=read();
	while (T--) solve();
	return 0;
}
/*
1 3
3 3
- 2 1
- 3 2
+ 1 3
3 3
- 2 1
- 3 2
- 1 3
*/
