#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
int read() {
	int x=0; char ch=getchar();
	while (ch<'0') ch=getchar();
	while (ch>='0') x=x*10+ch-48, ch=getchar();
	return x;
}

const int N=1003;
int n, m, k, d;
ll en[N][N], f[N][N];

void solve() {
	n=read(), m=read(), k=read(), d=read();
	for (int i=1; i<=m; i++) {
		int x=read(), y=read(), v=read();
		if (y<=k) en[x][y]+=v;
	}
	for (int i=1; i<=n; i++) {
		for (int j=1; j<=k; j++) en[i][j]+=en[i][j-1];
	}
	for (int i=1; i<=n; i++) {
		f[i][0]=f[i-1][0];
		for (int j=1; j<=k; j++) {
			f[i][0]=max(f[i][0], f[i-1][j]);
			f[i][j]=f[i-1][j-1]+en[i][j]-d;
		}
	}
	ll ans=0;
	for (int i=0; i<=k; i++) ans=max(ans, f[n][i]);
	printf("%lld\n", ans);
	
	for (int i=1; i<=n; i++) {
		for (int j=1; j<=k; j++) en[i][j]=0;
	}
}

int main() {
	freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);
	int c=read(), T=read();
	while (T--) solve();
	return 0;
}
/*
*/
