#include<bits/stdc++.h>
using namespace std;
const int N=3010,inf=1e9;
int n,m;
char s[N];
int cnt[N][30],minv[N],maxv[N];
int main()
{
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%s",s+1);
		maxv[i]=0,minv[i]=inf;
		for(int j=1;j<=m;j++)
		{
			cnt[i][s[j]-'a'+1]++;
			maxv[i]=max(maxv[i],s[j]-'a'+1);
			minv[i]=min(minv[i],s[j]-'a'+1);
		}
	}
	for(int i=1;i<=n;i++)
	{
		bool flag=1;
		for(int j=1;j<=n;j++)
			if(i!=j)
			{
				if(minv[i]>maxv[j]||maxv[j]==minv[i])
				flag=0;
			}
		if(flag)printf("1");
		else printf("0");
	}
	return 0;
}
