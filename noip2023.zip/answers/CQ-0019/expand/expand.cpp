#include<bits/stdc++.h>
#define pii pair<int,int>
#define fi first
#define se second
using namespace std;
const int N=5e5+10;
int c,n,m,q;
int x[N],y[N];
int maxv[4*N],minv[4*N];
#define mid (l+r)/2
#define L 2*u
#define R 2*u+1
inline void build(int u,int l,int r)
{
	if(l==r)
	{
		maxv[u]=minv[u]=y[l];
		return;
	}
	build(L,l,mid);
	build(R,mid+1,r);
	maxv[u]=max(maxv[L],maxv[R]);
	minv[u]=min(minv[L],minv[R]);
}
inline void change(int u,int l,int r,int p,int v)
{
	if(l==r)
	{
		maxv[u]=minv[u]=v;
		return;
	}
	if(p<=mid)change(L,l,mid,p,v);
	else change(R,mid+1,r,p,v);
	maxv[u]=max(maxv[L],maxv[R]);
	minv[u]=min(minv[L],minv[R]);
}
inline int ask(int u,int l,int r,int lp,int rp,int v,int op)
{
	if(lp>rp)return 0;
	if((op==1&&minv[u]>=v)||(op==0&&maxv[u]<=v))return 0;
	if((op==1&&maxv[u]<v)||(op==0&&minv[u]>v))return r;
	if(l==r)return l;
	if(lp<=mid)
	{
		int p=ask(L,l,mid,lp,rp,v,op);
		if(p==mid)p=max(p,ask(R,mid+1,r,lp,rp,v,op));
		return p;
	}
	else return ask(R,mid+1,r,lp,rp,v,op);
}
inline int ask2(int u,int l,int r,int lp,int rp,int v,int op)
{
	if(lp>rp)return 0;
	if((op==1&&minv[u]>=v)||(op==0&&maxv[u]<=v))return 0;
	if(l==r)return l;
	if(rp>mid)
	{
		int p=ask2(R,mid+1,r,lp,rp,v,op);
		if(p)return p;
	}
	return ask2(L,l,mid,lp,rp,v,op);
}
inline void solve()
{
	if(x[1]-y[1]==0||x[n]-y[m]==0)
	{
		printf("0");
		return;
	}
	int op=(x[1]>y[1]),maxR=0;
	for(int i=1;i<=n;i++)
	{
		if(maxR!=m&&((op==1&&x[i]>y[maxR+1])||(op==0&&x[i]<y[maxR+1])))maxR=ask(1,1,m,maxR+1,m,x[i],op);
		else maxR=ask2(1,1,m,1,maxR,x[i],op);
		if(maxR==0)
		{
			printf("0");
			return;
		}
	}
	printf("%d",(maxR==m?1:0));
}
vector<pii>tmp,tmp2;
int main()
{
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	scanf("%d%d%d%d",&c,&n,&m,&q);
	for(int i=1;i<=n;i++)
		scanf("%d",&x[i]);
	for(int i=1;i<=m;i++)
		scanf("%d",&y[i]);
	build(1,1,m);
	solve();
	for(int i=1;i<=q;i++)
	{
		int kx,ky,p,v;tmp.clear(),tmp2.clear();
		scanf("%d%d",&kx,&ky);
		for(int j=1;j<=kx;j++)
		{
			scanf("%d%d",&p,&v);
			tmp.push_back({p,x[p]});
			x[p]=v;
		}
		for(int j=1;j<=ky;j++)
		{
			scanf("%d%d",&p,&v);
			tmp2.push_back({p,y[p]});
			y[p]=v;change(1,1,m,p,v);
		}
		solve();
		for(pii t:tmp)x[t.fi]=t.se;
		for(pii t:tmp2)y[t.fi]=t.se,change(1,1,m,t.fi,t.se);
	}
	return 0;
}
