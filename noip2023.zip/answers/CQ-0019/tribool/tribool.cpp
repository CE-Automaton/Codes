#include<bits/stdc++.h>
using namespace std;
const int N=4e5+10;
int c,t,n,m,tot,x;
int f[N];//yiyang he buyiyang
int las[N];
vector<int>to[N];
int find(int x){
	return x==f[x]?x:f[x]=find(f[x]);
}
bool vis[N];
void merge(int u,int v,int op)
{
	to[u].push_back(v);to[v].push_back(u);
	if(op==1)
	{
		int f1=find(u+x),f2=find(v);
		if(f1!=f2)f[f1]=f2;
		f1=find(u),f2=find(v+x);
		if(f1!=f2)f[f1]=f2;
	}
	else
	{
		int f1=find(u),f2=find(v);
		if(f1!=f2)f[f1]=f2;
		f1=find(u+x),f2=find(v+x);
		if(f1!=f2)f[f1]=f2;
	}
}
queue<int>q;
int main()
{
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	scanf("%d%d",&c,&t);
	while(t--)
	{
		scanf("%d%d",&n,&m);tot=n;x=n+m;
		for(int i=1;i<=2*x;i++)
		f[i]=i,to[i].clear(),vis[i]=0;
		for(int i=1;i<=n;i++)las[i]=i;
		for(int i=1;i<=m;i++)
		{
			++tot;
			char op[10];int x,y;
			scanf("%s",op+1);
			if(op[1]=='-')
			{
				scanf("%d%d",&x,&y);
				merge(tot,las[y],1);las[x]=tot;
			}
			else if(op[1]=='+')
			{
				scanf("%d%d",&x,&y);
				merge(tot,las[y],0);las[x]=tot;
			}
			else
			{
				scanf("%d",&x);
				if(op[1]=='U')q.push(tot),vis[tot]=1;
				las[x]=tot;
			}
		}
		for(int i=1;i<=n;i++)merge(i,las[i],0);
		for(int i=1;i<=n;i++)
		{
			if(find(i+x)==find(las[i]))
			q.push(i),q.push(las[i]),vis[i]=vis[las[i]]=1;
		}
		while(!q.empty())
		{
			int u=q.front();q.pop();
			for(int v:to[u])
			{
				if(!vis[v])q.push(v);
				vis[v]=1;
			}
		}
		int ans=0;
		for(int i=1;i<=n;i++)
			if(vis[i])ans++;
		printf("%d\n",ans);
	}
	return 0;
}
