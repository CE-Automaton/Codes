#include<bits/stdc++.h>
#define ll long long
#define pii pair<int,int>
#define fi first
#define se second
using namespace std;
const int N=2e5+10;
const ll inf=1e18;
int c,t;
int n,m,k,d;
int b[N],len;
struct line
{
	int l,r,v;
}q[N];
vector<pii>tmp[N];
ll maxv[4*N],tag[4*N],f[N],ans;
#define mid (l+r)/2
#define L 2*u
#define R 2*u+1
inline void build(int u,int l,int r)
{
	maxv[u]=tag[u]=0;
	if(l==r)return;
	build(L,l,mid);
	build(R,mid+1,r);
}
inline void change(int u,int l,int r,int lp,int rp,ll v)
{
	if(lp<=l&&r<=rp)
	{
		maxv[u]+=v;
		tag[u]+=v;
		return;
	}
	if(lp<=mid)change(L,l,mid,lp,rp,v);
	if(rp>mid)change(R,mid+1,r,lp,rp,v);
	maxv[u]=max(maxv[L],maxv[R])+tag[u];
}
int main()
{
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	scanf("%d%d",&c,&t);
	while(t--)
	{
		scanf("%d%d%d%d",&n,&m,&k,&d);len=0;ans=0;
		for(int i=1;i<=m;i++)
		{
			int x,y,v;
			scanf("%d%d%d",&x,&y,&v);
			q[i]={x-y,x,v};
			b[++len]=x-y;b[++len]=x;
		}
		sort(b+1,b+len+1);
		len=unique(b+1,b+len+1)-b-1;
		for(int i=1;i<=len;i++)tmp[i].clear();
		for(int i=1;i<=m;i++)
		{
			q[i].r=lower_bound(b+1,b+len+1,q[i].r)-b;
			q[i].l=lower_bound(b+1,b+len+1,q[i].l)-b;
			tmp[q[i].r].push_back({q[i].l,q[i].v});
		}
		build(1,1,len);
		for(int i=1,j=1;i<=len;i++)
		{
			while(b[i]-b[j]>k)change(1,1,len,j,j,-inf),j++;
			if(i>1)change(1,1,len,1,i-1,-1ll*d*(b[i]-b[i-1]));
			for(pii t:tmp[i])
				change(1,1,len,1,t.fi,t.se);
			f[i]=max(f[i-1],maxv[1]);
//			cout<<b[i]<<" "<<f[i]<<endl;
			change(1,1,len,i,i,f[i-1]);
			ans=max(ans,f[i]);
		}
		printf("%lld\n",ans);
	}
	return 0;
}
