#include <bits/stdc++.h>

using namespace std;

const int N = 500000 + 5;

int c, n, m, T;
int a[N], b[N], sz[N];
int cnta, cntb, pa[N], pb[N], va[N], vb[N];
int stmin[N][20], stmax[N][20];

int Getmax(int l, int r) {
	int len = sz[r - l + 1];
	return max(stmax[l][len], stmax[r - (1 << len) + 1][len]);
}

int Getmin(int l, int r) {
	int len = sz[r - l + 1];
	return min(stmin[l][len], stmin[r - (1 << len) + 1][len]);
}

int Solve() {
	for(int i = 1; i <= n; ++ i) stmin[i][0] = stmax[i][0] = a[i];
	int len = sz[n];
	for(int i = 1; i <= len; ++ i) {
		for(int j = 1; j <= n - (1 << i) + 1; ++ j) {
			stmin[j][i] = min(stmin[j][i - 1], stmin[j + (1 << (i - 1))][i - 1]);
			stmax[j][i] = max(stmax[j][i - 1], stmax[j + (1 << (i - 1))][i - 1]);
		}
	}
	
	int isok = 2;
	for(int i = 1, j = 1; i <= m; ++ i) {
		if(a[j] <= b[i]) {
			int l = 1, r = j, ans = -1, mid;
			while(l <= r) {
				mid = (l + r) >> 1;
				if(Getmax(mid, j) > b[i]) ans = mid, l = mid + 1;
				else r = mid - 1;
			}
			if(ans == -1) {
				isok --;
				break;
			}else j = ans + 1;
		}else{
			int l = j, r = n, mid, ans = n, g = j;
			while(l <= r) {
				mid = (l + r) >> 1;
				if(Getmin(j, mid) <= b[i]) ans = mid, r = mid - 1;
				else l = mid + 1;
			}
			j = ans;
		}
		if(i == m && j != n) isok --;
		if(i == m && j == n && a[j] <= b[i]) isok --;
	}
	
	if(isok == 2) return 1;
	
	for(int i = 1, j = 1; i <= m; i ++) {
		if(a[j] >= b[i]) {
			int l = 1, r = j, ans = -1, mid;
			while(l <= r) {
				mid = (l + r) >> 1;
				if(Getmin(mid, j) < b[i]) ans = mid, l = mid + 1;
				else r = mid - 1;
			}
			if(ans == -1) {
				isok --;
				break;
			}else j = ans + 1;
		}else {
			int l = j, r = n, mid, ans = n;
			while(l <= r) {
				mid = (l + r) >> 1;
				if(Getmax(j, mid) >= b[i]) ans = mid, r = mid - 1;
				else l = mid + 1;
			}
			j = ans;
		}
		if(i == m && j != n) isok --;
		if(i == m && j == n && a[j] >= b[i]) isok --;
	}
	
	if(isok) return 1;
	else return 0;
}

int Read() {
	int res = 0;
	char c = getchar();
	while(c < '0' || c > '9') c = getchar();
	while('0' <= c && c <= '9') res = 10 * res + c - '0', c = getchar();
	return res;
}

int main() {
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);

	c = Read(), n = Read(), m = Read(), T = Read();
	
	for(int i = 1; i <= n; ++ i) a[i] = Read();
	for(int j = 1; j <= m; ++ j) b[j] = Read();

	for(int i = 1; i <= n; ++ i) sz[i] = log2(i);

	putchar(Solve() + '0');

	int id  = 0;
	while(T --) {
		id ++;
		cnta = Read(), cntb = Read();
		for(int i = 1; i <= cnta; ++ i) {
			int v;
			pa[i] = Read(), v = Read();
			va[i] = a[pa[i]];
			a[pa[i]] = v;
		}
		for(int i = 1; i <= cntb; ++ i) {
			int v;
			pb[i] = Read(), v = Read();
			vb[i] = b[pb[i]];
			b[pb[i]] = v;
		}
		putchar(Solve() + '0');
		for(int i = 1; i <= cnta; ++ i) {
			a[pa[i]] = va[i];
		}
		for(int i = 1; i <= cntb; ++ i) {
			b[pb[i]] = vb[i];
		}
	}

	return 0;
}

