#include <bits/stdc++.h>

using namespace std;

const int N = 100000 + 5;

int c, T;
int n, m;
int f[N], g[N]; // 1~n  -2 -> T -1 -> F 0-> U
int fa[N * 2 + 5]; //dsu
char op[2];

int Getf(int x) {
	if(fa[x] == x) return x;
	else return fa[x] = Getf(fa[x]);
}

void Merge(int x, int y) {
	int fx = Getf(x), fy = Getf(y);
	fa[fx] = fy;
}

int main() {
	freopen("tribool.in", "r", stdin);
	freopen("tribool.out", "w", stdout); 

	scanf("%d%d", &c, &T);
	
	while(T --) {
		scanf("%d%d", &n, &m);
		
		for(int i = 1; i <= n; ++ i) f[i] = 1, g[i] = i;
		for(int i = 1; i <= m; ++ i) {
			scanf("%s", op);
			if(op[0] != '-' && op[0] != '+') {
				int u;
				scanf("%d", &u);
				f[u] = 1;
				if(op[0] == 'T') g[u] = -2;
				if(op[0] == 'F') g[u] = -1;
				if(op[0] == 'U') g[u] = 0;
			}
			if(op[0] == '-') {
				int u, v;
				scanf("%d%d", &u, &v);
				f[u] = -1 * f[v], g[u] = g[v];
			}
			if(op[0] == '+') {
				int u, v;
				scanf("%d%d", &u, &v);
				f[u] = f[v], g[u] = g[v];
			}
		}
		
		for(int i = 1; i <= n; ++ i) {
			fa[i] = i, fa[i + n] = i + n;
		}//1~n means +x_i  n+1~n+n means -x_{i-n}
		fa[n * 2 + 1] = n * 2 + 1;//T
		fa[n * 2 + 2] = n * 2 + 2;//F
		fa[n * 2 + 3] = n * 2 + 3;//U
		
		for(int i = 1; i <= n; ++ i) {
			if(g[i] <= 0) {
				if(g[i] == -2) {
					if(f[i] == 1) {
						Merge(i, n * 2 + 1), Merge(i + n, n * 2 + 2);
					}else Merge(i, n * 2 + 2), Merge(i + n, n * 2 + 1);
				}
				if(g[i] == -1) {
					if(f[i] == 1) {
						Merge(i, n * 2 + 2), Merge(i + n, n * 2 + 1);
					}else Merge(i, n * 2 + 1), Merge(i + n, n * 2 + 2);
				}
				if(g[i] == 0) {
					Merge(i, n * 2 + 3), Merge(i + n, n * 2 + 3);
				}
			}else {
				if(f[i] == 1) {
					Merge(i, g[i]), Merge(i + n, g[i] + n);
				}else {
					Merge(i, g[i] + n), Merge(i + n, g[i]);
				}
			}
		}
		
		int ans = 0;
		for(int i = 1; i <= n; ++ i) {
			if(Getf(i) == Getf(i + n)) ans ++;
		}
		
		printf("%d\n", ans);
	}

	return 0;
}
