#include <bits/stdc++.h> 

using namespace std;

const int N = 3000 + 5;

int n, m, maxx[N], minn[N];
int pre[N], suf[N];
char s[N];

int main() {
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	
	for(int i = 1; i <= n; ++ i) {
		scanf("%s", s + 1);
		minn[i] = 1000000000;
		for(int j = 1; j <= m; ++ j) {
			maxx[i] = max(maxx[i], s[j] - 'a' + 1);
			minn[i] = min(minn[i], s[j] - 'a' + 1);
		}
	}
	
	if(n == 1) {
		puts("1");
		return 0;
	}
	
	pre[0] = 1000000000;
	for(int i = 1; i <= n; ++ i) {
		pre[i] = min(maxx[i], pre[i - 1]);
	}
	
	suf[n + 1] = 1000000000;
	for(int i = n; i >= 1; -- i) {
		suf[i] = min(maxx[i], suf[i + 1]);
	}
	
	for(int i = 1; i <= n; ++ i) {
		if(min(pre[i - 1], suf[i + 1]) <= minn[i]) putchar('0');
		else putchar('1');
	}
	
	puts("");
	
	return 0;
}
