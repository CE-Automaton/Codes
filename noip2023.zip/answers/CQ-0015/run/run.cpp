#include <bits/stdc++.h>

using namespace std;

const int N = 100000 + 5;

long long c, T;
long long n, m, k, d;
long long dp[N];
struct Node {
	long long l, r, v;
}a[N];

bool cmp(Node x, Node y) {
	return x.r < y.r;
}

int main() {
	freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);

	scanf("%lld%lld", &c, &T);
	
	while(T --) {
		scanf("%lld%lld%lld%lld", &n, &m, &k, &d);
		for(long long i = 1; i <= m; ++ i) {
			long long x, y;
			scanf("%lld%lld%lld", &x, &y, &a[i].v);
			a[i].l = x - y + 1, a[i].r = x;
		}
		sort(a + 1, a + m + 1, cmp);
		
		memset(dp, 0, sizeof dp);
		for(long long i = 1; i <= n; ++ i) {
			dp[i] = dp[i - 1];
			for(long long j = 1; j <= min(k, i); ++ j) {
				long long tmp = -d * j;
				for(long long z = 1; z <= m; ++ z) {
					if(i - j + 1 <= a[z].l && a[z].r <= i) tmp += a[z].v;
				}
				if(i - j >= 1) dp[i] = max(dp[i], dp[i - j - 1] + tmp);
				else dp[i] = max(dp[i], tmp);
			}
		}
		
		printf("%lld\n", dp[n]);
	}

	return 0;
}

