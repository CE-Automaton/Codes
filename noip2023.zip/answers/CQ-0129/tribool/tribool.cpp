#include<bits/stdc++.h>
#define  Int  long long int
#define  Pub  public
using std::min;using std::max;
const int T=100000000,F=-100000000,U=0;

int Read(){
    int x=0,c=0;
    while(c<'0'||c>'9')c=getchar();
    while(c>='0'&&c<='9')x=x*10+c-'0',c=getchar();
    return x;
}

int cc,tt;
int n,m,a[100005];
int fa[100005],size[100005],ans[100005],A;
int FA(int x){
    if(fa[x]!=x)fa[x]=FA(fa[x]);
    return fa[x];
}

class Node{
Pub:std::vector<int> s;
    int vis,dis,calced;
}p[100005];
bool bfs(int s){
    bool f=1;
    std::queue<int> q;
    q.emplace(s),p[s].dis=0;
    while(q.size()){
        int x=q.front();q.pop();
        p[x].vis=1;
        for(int y:p[x].s){
            if(p[y].dis==T){
                p[y].dis=p[x].dis+1;
                q.emplace(y);
            }else if((p[x].dis+p[y].dis+1)&1)f=0;
        }
    }
    return f;
}
void calc(int s){
    std::queue<int> q;
    q.emplace(s),p[s].dis=0;
    while(q.size()){
        int x=q.front();q.pop();
        p[x].calced=1;
        A+=size[x];
        for(int y:p[x].s){
            if(p[y].dis==T)
                p[y].dis=p[x].dis+1,q.emplace(y);
        }
    }
}

int main(){
    freopen("tribool.in","r",stdin);
    freopen("tribool.out","w",stdout);
    
    for(cc=Read(),tt=Read();tt;--tt){
        n=Read(),m=Read();
        for(int i=1;i<=n;++i)a[i]=i;
        for(int i=1,x,y;i<=m;++i){
            char v=0;while(v!='T'&&v!='F'&&v!='U'&&v!='+'&&v!='-')v=getchar();
            if(v=='T'){
                x=Read();
                a[x]=T;
            }if(v=='F'){
                x=Read();
                a[x]=F;
            }if(v=='U'){
                x=Read();
                a[x]=U;
            }if(v=='+'){
                x=Read(),y=Read();
                a[x]=a[y];
            }if(v=='-'){
                x=Read(),y=Read();
                a[x]=-a[y];
            }
        }
        for(int i=1;i<=n;++i){
            fa[i]=i,size[i]=1;
            ans[i]=i;
            if(a[i]==U)ans[i]=U,a[i]=0;
            if(a[i]==T)ans[i]=T,a[i]=0;
            if(a[i]==F)ans[i]=F,a[i]=0;
        }
        for(int i=1;i<=n;++i){
            if(a[i]>0){
                int x=FA(i),y=FA(a[i]);
                if(x!=y){
                    fa[x]=y,size[y]+=size[x];
                    if(ans[x]!=x)ans[y]=ans[x];
                }
            }
        }
        
        for(int i=1;i<=n;++i)
            p[i].s.clear();
        for(int i=1;i<=n;++i){
            if(a[i]<0){
                int x=FA(i),y=FA(-a[i]);
                p[x].s.emplace_back(y),p[y].s.emplace_back(x);
            }
        }
        for(int i=1;i<=n;++i)
            p[i].vis=0,p[i].dis=T;
        for(int i=1;i<=n;++i)
            if(FA(i)==i&&!p[i].vis)
                if(!bfs(i))ans[i]=U;
        A=0;
        for(int i=1;i<=n;++i)
            p[i].calced=0,p[i].dis=T;
        for(int i=1;i<=n;++i)
            if(FA(i)==i&&ans[i]==U&&!p[i].calced)
                calc(i);
        printf("%d\n",A);
    }
    return 0;
}
