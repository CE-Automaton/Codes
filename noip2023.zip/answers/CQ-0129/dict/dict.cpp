#include<bits/stdc++.h>
#define  Int  long long int
#define  Pub  public
using std::min;using std::max;

int n,m;char s[3005];
class G{
Pub:char s[3005];
    int id,type;
}a[6005];
int rank,t[3005][2];
char rk[3005];
int main(){
    freopen("dict.in","r",stdin);
    freopen("dict.out","w",stdout);
    
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;++i){
        scanf("%s",s+1);
        memcpy(a[2*i-1].s,s,sizeof(a[2*i-1].s));
        std::sort(a[2*i-1].s+1,a[2*i-1].s+m+1,[](char x,char y)->bool{return x<y;});
        a[2*i-1].id=i,a[2*i-1].type=0;
        memcpy(a[2*i].s,s,sizeof(a[2*i].s));
        std::sort(a[2*i].s+1,a[2*i].s+m+1,[](char x,char y)->bool{return x>y;});
        a[2*i].id=i,a[2*i].type=1;
    }
    std::sort(a+1,a+2*n+1,[](G x,G y)->bool{return strcmp(x.s+1,y.s+1)<0;});
    
    for(int i=1;i<=2*n;++i){
        if(strcmp(rk+1,a[i].s+1)<0){
            ++rank;
            memcpy(rk,a[i].s,sizeof(rk));
        }
        t[a[i].id][a[i].type]=rank;
    }
    
    for(int i=1;i<=n;++i){
        int f=1;
        for(int j=1;j<=n;++j){
            if(i==j)continue;
            if(t[i][0]>=t[j][1])f=0;
        }
        printf("%d",f);
    }
    return 0;
}
