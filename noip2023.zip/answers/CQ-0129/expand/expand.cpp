#include<bits/stdc++.h>
#define  Int  long long int
#define  Pub  public
using std::min;using std::max;
int Rd(){
    int x=0,c=0;
    while(c<'0'||c>'9')c=getchar();
    while(c>='0'&&c<='9')x=x*10+c-'0',c=getchar();
    return x;
}

int cid,n,m,q,spd;
int x[500005],y[500005];

namespace SOLVE{
    int n,m,x[500005],y[500005];
    int maxx[500005],minx[500005],maxy[500005],miny[500005];
    
    int solve(int kx,int ky){
        n=::n,m=::m;
        for(int i=1;i<=n||i<=m;++i)x[i]=y[i]=0;
        for(int i=1;i<=n;++i)x[i]=::x[i];
        for(int i=1;i<=m;++i)y[i]=::y[i];
        for(int i=1,p,v;i<=kx;++i){
            p=Rd(),v=Rd();
            x[p]=v;
        }
        for(int i=1,p,v;i<=ky;++i){
            p=Rd(),v=Rd();
            y[p]=v;
        }
        
        if(x[1]==y[1])return 0;
        if(x[1]>y[1]){
            for(int i=1;i<=n||i<=m;++i)std::swap(x[i],y[i]);
            std::swap(n,m);
        }
        if(x[n]>=y[m])return 0;
        
        {
            maxx[0]=maxy[0]=-1;
            minx[0]=miny[0]=1000000000;
            std::vector<int> ox,oy;
            for(int i=1;i<=n;++i){
                if(x[i]<=minx[i-1])ox.emplace_back(i);
                maxx[i]=max(maxx[i-1],x[i]);
                minx[i]=min(minx[i-1],x[i]);
            }
            for(int i=1;i<=m;++i){
                if(y[i]>=maxy[i-1])oy.emplace_back(i);
                maxy[i]=max(maxy[i-1],y[i]);
                miny[i]=min(miny[i-1],y[i]);
            }
            for(int i=0,j=0;i<ox.size()&&j<oy.size();){
                if(i==ox.size()-1&&j==oy.size()-1)break;
                if(i!=ox.size()-1&&maxx[ox[i+1]]<y[oy[j]])++i;
                else if(j!=oy.size()-1&&miny[oy[j+1]]>x[ox[i]])++j;
                else return 0;
            }
        }
        std::reverse(x+1,x+n+1);
        std::reverse(y+1,y+m+1);
        {
            maxx[0]=maxy[0]=-1;
            minx[0]=miny[0]=1000000000;
            std::vector<int> ox,oy;
            for(int i=1;i<=n;++i){
                if(x[i]<=minx[i-1])ox.emplace_back(i);
                maxx[i]=max(maxx[i-1],x[i]);
                minx[i]=min(minx[i-1],x[i]);
            }
            for(int i=1;i<=m;++i){
                if(y[i]>=maxy[i-1])oy.emplace_back(i);
                maxy[i]=max(maxy[i-1],y[i]);
                miny[i]=min(miny[i-1],y[i]);
            }
            for(int i=0,j=0;i<ox.size()&&j<oy.size();){
                if(i==ox.size()-1&&j==oy.size()-1)break;
                if(i!=ox.size()-1&&maxx[ox[i+1]]<y[oy[j]])++i;
                else if(j!=oy.size()-1&&miny[oy[j+1]]>x[ox[i]])++j;
                else return 0;
            }
        }
        return 1;
    }
}

int main(){
    freopen("expand.in","r",stdin);
    freopen("expand.out","w",stdout);
    cid=Rd(),n=Rd(),m=Rd(),q=Rd();
    for(int i=1;i<=n;++i)x[i]=Rd();
    for(int i=1;i<=m;++i)y[i]=Rd();
    printf("%d",SOLVE::solve(0,0));
    for(int i=1,kx,ky;i<=q;++i){
        kx=Rd(),ky=Rd();
        printf("%d",SOLVE::solve(kx,ky));
    }
    return 0;
}
