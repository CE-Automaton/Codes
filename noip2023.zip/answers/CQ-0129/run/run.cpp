#include<bits/stdc++.h>
#define  Int  long long int
#define  Pub  public
using std::min;using std::max;

/*
I have been quasi-away-from-oi for 2months,
hoping to get back.

By the way,do Wolves and GG get enough sleep?
Wait for IVL with excitement.
*/

int cc,tt;
int n,m,k,d;
class Challenge{
Pub:int x,y,v;
}a[100005];
bool cmp(Challenge x,Challenge y){
    if(x.x!=y.x)return x.x<y.x;
    else return x.y<y.y;
}

Int dp[1005][1005];
int main(){
    freopen("run.in","r",stdin);
    freopen("run.out","w",stdout);
    for(scanf("%d%d",&cc,&tt);tt;--tt){
        scanf("%d%d%d%d",&n,&m,&k,&d);
        for(int i=1;i<=m;++i)scanf("%d%d%d",&a[i].x,&a[i].y,&a[i].v);
        std::sort(a+1,a+n+1,cmp);
        for(int i=1,s=1;i<=n;++i){
            for(int j=0;j<=k;++j)dp[i][j]=-100000000000000000;
            while(a[s].x<i)++s;
            Int D=0;
            for(int j=0;j<=k;++j)dp[i][0]=max(dp[i][0],dp[i-1][j]);
            for(int j=1;j<=k;++j){
                while(a[s].x==i&&a[s].y<=j)D+=a[s].v,++s;
                dp[i][j]=max(dp[i][j],dp[i-1][j-1]-d+D);
            }
        }
        Int A=0;
        for(int i=0;i<=k;++i)A=max(A,dp[n][i]);
        printf("%lld\n",A);
    }
    return 0;
}

/*
Oh no.The Monthly Exam is coming in 5 days!
When compared with 'whk',OI is nothing to me.
A ghost is back.
*/

/*
There is few time left,so I feel like writing something.
I,however,only do it in mind.
Best wishes,to all my friends.
*/
