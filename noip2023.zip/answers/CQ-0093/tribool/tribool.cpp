#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll c, t, n, m, x, y, ans, val[100005], from[2][100005], e[2][2000005];
vector<int> g[100005];
bool vis[100005];
char op;
void solve(int x) {
	ll now = n * m + x;
	while(e[0][now] != -1) {
		from[1][x] ^= e[1][now];
		now = e[0][now];
	}
	from[0][x] = now;
}
queue<int> q;
int main() {
	ios::sync_with_stdio(0);
	cin.tie(0), cout.tie(0);
	// freopen("tribool/tribool2.in", "r", stdin);
	freopen("tribool.in", "r", stdin);
	freopen("tribool.out", "w", stdout);
	cin >> c >> t;
	while(t--) {
		cin >> n >> m;
		for(int i = 0; i < n; ++i) {
			g[i].clear();
			val[i] = -1, vis[i] = false;
			from[0][i] = from[1][i] = 0;
			for(int j = 0; j <= m; ++j) {
				e[0][j * n + i] = -1, e[1][j * n + i] = 0;
			}
		}
		for(int i = 1; i <= m; ++i) {
			cin >> op;
			switch(op) {
				case 'T': {
					cin >> x;
					--x;
					val[x] = 1;
					break;
				}
				case 'F': {
					cin >> x;
					--x;
					val[x] = 2;
					break;
				}
				case 'U': {
					cin >> x;
					--x;
					val[x] = 0;
					break;
				}
				case '+': {
					cin >> x >> y;
					--x, --y;
					e[0][n * i + x] = n * (i - 1) + y, e[1][n * i + x] = 0;
					val[x] = val[y];
					break;
				}
				case '-': {
					cin >> x >> y;
					--x, --y;
					e[0][n * i + x] = n * (i - 1) + y, e[1][n * i + x] = 1;
					val[x] = val[y];
					if(val[x] >= 1) val[x] = (val[x] << 1) % 3;
					break;
				}
			}
			for(int j = 0; j < n; ++j) {
				if(j != x) {
					e[0][n * i + j] = n * (i - 1) + j, e[1][n * i + j] = 0;
				}
			}
		}
		ans = 0;
		for(int i = 0; i < n; ++i) {
			if(val[i] == -1) {
				solve(i);
				cerr << i << ": " << from[0][i] << " " << from[1][i] << '\n';
				if(from[0][i] == i && from[1][i]) q.push(i);
				if(from[0][i] != i) g[from[0][i]].push_back(i);
			}
			else if(val[i] == 0) q.push(i);
		}
		int now;
		while(!q.empty()) {
			now = q.front();
			q.pop();
			if(vis[now]) continue;
			vis[now] = true;
			++ans;
			for(const auto& i : g[now]) {
				if(!vis[i]) {
					q.push(i);
				}
			}
		}
		cout << ans << '\n';
	}
	return 0;
}
/*
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll c, t, n, m, x, y, ans, val[100005], root[100005], father[100005], dep[100005];
char op;
bool vis[100005];
map<ll, int> st;
map< ll, pair<ll, int> > g;
vector<ll> lsh, v[100005];
queue<ll> q;
pair<ll, int> edge;
void solve(int x) {
	// if(st.count(lsh[x])) {
	// 	return;
	// }
	while(!q.empty()) q.pop();
	int now_dep = 1;
	ll now;
	bool flag = false;
	for(const auto& i : v[x]) {
		if(father[i] % n == i && father[i] / n == m) {
			q.push(father[i]);
		}
	}
	while(!q.empty()) {
		now = q.front();
		q.pop();
		cerr << now << " " << now_dep << " " << dep[now % n] << '\n';
		auto it = lower_bound(v[x].begin(), v[x].end(), now % n);
		if(it != v[x].end() && *it == now % n && now == father[*it]) vis[now % n] = true;
		if(vis[now % n]) {
			if(dep[now % n]) {
				if((now_dep - dep[now % n]) & 1) {
					flag = true;
				}
			}
			dep[now % n] = now_dep;
		}
		if(val[now % n] == 0) flag = true;
		if(now != lsh[x]) {
			if(g.count(now)) {
				edge = g[now];
				now_dep += edge.second;
				q.push(edge.first);
			}
		}
	}
	if(flag) st[lsh[x]] = 0;
	for(const auto& i : v[x]) {
		vis[i] = false;
	}
}
int main() {
	ios::sync_with_stdio(0);
	cin.tie(0), cout.tie(0);
	freopen("tribool/tribool2.in", "r", stdin);
	// freopen("tribool.in", "r", stdin);
	// freopen("tribool.out", "w", stdout);
	cin >> c >> t;
	while(t--) {
		cin >> n >> m;
		for(int i = 0; i < n; ++i) {
			val[i] = -1, root[i] = father[i] = i, dep[i] = 0, vis[i] = false;
		}
		st.clear(), g.clear();
		for(int i = 1; i <= m; ++i) {
			cin >> op;
			switch(op) {
				case 'T': {
					cin >> x;
					--x;
					st[n * i + x] = 1;
					root[x] = father[x] = n * i + x;
					val[x] = 1;
					break;
				}
				case 'F': {
					cin >> x;
					--x;
					st[n * i + x] = 2;
					root[x] = father[x] = n * i + x;
					val[x] = 2;
					break;
				}
				case 'U': {
					cin >> x;
					--x;
					st[n * i + x] = 0;
					root[x] = father[x] = n * i + x;
					val[x] = 0;
					break;
				}
				case '+': {
					cin >> x >> y;
					--x, --y;
					root[x] = root[y];
					father[x] = n * i + x;
					cerr << i << ": " << x << "<-" << y << " 0" << '\n';
					cerr << n * i + x << " " << n * (i - 1) + y << '\n';
					g[n * i + x] = make_pair(n * (i - 1) + y, 0);
					if(!g.count(n * (i - 1) + y) && father[y] != n * (i - 1) + y) g[n * (i - 1) + y] = make_pair(father[y], 0);
					val[x] = val[y];
					break;
				}
				case '-': {
					cin >> x >> y;
					--x, --y;
					root[x] = root[y];
					father[x] = n * i + x;
					cerr << i << ": " << x << "<-" << y << " 1" << '\n';
					cerr << n * i + x << " " << n * (i - 1) + y << '\n';
					g[n * i + x] = make_pair(n * (i - 1) + y, 1);
					if(!g.count(n * (i - 1) + y) && father[y] != n * (i - 1) + y) g[n * (i - 1) + y] = make_pair(father[y], 0);
					val[x] = val[y];
					if(val[x] >= 1) val[x] = (val[x] << 1) % 3;
					break;
				}
			}
		}
		lsh.clear();
		for(int i = 0; i < n; ++i) {
			lsh.push_back(root[i]);
			v[i].clear();
		}
		stable_sort(lsh.begin(), lsh.end());
		lsh.erase(unique(lsh.begin(), lsh.end()), lsh.end());
		for(int i = 0; i < n; ++i) {
			v[lower_bound(lsh.begin(), lsh.end(), root[i]) - lsh.begin()].push_back(i);
		}
		ans = 0;
		for(int i = 0; i < n; ++i) {
			if(!v[i].empty()) solve(i);
			
		}
		for(int i = 0; i < n; ++i) {
			if(st.count(root[i]) && !st[root[i]]) ++ans;
		}
		cout << ans << '\n';
	}
	return 0;
}
*/
/*
#include <bits/stdc++.h>
using namespace std;
int c, t, n, m, x, y, ans, val[100005], from[2][100005], father[200005];
char op;
bool flag[100005];
int findset(int x) {return father[x] == x ? x : father[x] = findset(father[x]);}
int main() {
	ios::sync_with_stdio(0);
	cin.tie(0), cout.tie(0);
	freopen("tribool/tribool4.in", "r", stdin);
	// freopen("tribool.in", "r", stdin);
	// freopen("tribool.out", "w", stdout);
	cin >> c >> t;
	while(t--) {
		cin >> n >> m;
		for(int i = 1; i <= n; ++i) {
			from[0][i] = i, from[1][i] = i + n;
			father[i] = i, father[i + n] = i + n;
			val[i] = -1, flag[i] = false;
		}
		while(m--) {
			cin >> op;
			switch(op) {
				case 'T': {
					cin >> x;
					from[0][x] = from[1][x] = 0;
					val[x] = 1;
					break;
				}
				case 'F': {
					cin >> x;
					from[0][x] = from[1][x] = 0;
					val[x] = 2;
					break;
				}
				case 'U': {
					cin >> x;
					from[0][x] = from[1][x] = 0;
					val[x] = 0;
					break;
				}
				case '+': {
					cin >> x >> y;
					if(~val[y]) {
						from[0][x] = from[1][x] = 0;
						val[x] = val[y];
					}
					else {
						from[0][x] = from[0][y], from[1][x] = from[1][y];
						val[x] = -1;
					}
					break;
				}
				case '-': {
					cin >> x >> y;
					if(~val[y]) {
						from[0][x] = from[1][x] = 0;
						val[x] = (val[y] << 1) % 3;
					}
					else {
						from[0][x] = from[1][y], from[1][x] = from[0][y];
						val[x] = -1;
					}
					break;
				}
			}
		}
		ans = 0;
		for(int i = 1; i <= n; ++i) {
			if(from[0][i]) father[findset(i)] = findset(from[0][i]);
			if(from[1][i]) father[findset(i + n)] = findset(from[1][i]);
		}
		for(int i = 1; i <= n; ++i) {
			if(val[i] == 0 || findset(i) == findset(i + n)) flag[findset(i)] = flag[findset(i + n)] = true;
		}
		for(int i = 1; i <= n; ++i) {
			if(flag[findset(i)] || flag[findset(i + n)]) ++ans;
		}
		cout << ans << '\n';
	}
	return 0;
}
*/

/*
感觉就是 T = 1, F = 2, U = 0 然后在模3的意义下运算
因为这个取反操作正好符合模3意义下的取相反数
或者是乘2
不对，应该是基环树
一个点的值肯定是看最后修改的那一次，所以把修改操作看成有向边的话，那每个点最多有一条入边
应该是对的
但是修改过程中引起的变化怎么办？
直接连到引起变化的根源的地方应该可以
如果被修改成了确定的值的话就直接看那个值
但是具体该怎么做？
如果自己和自己的扩展结点在同一个集合里是不是就必须赋成U？
同时这个集合里面所有的点都会被赋成U
应该是的
但是不知道怎么实现
再想想
好像想到了
开打
统计部分不太好打
第二个大样例挂了
麻
看来这题没这么简单
别告诉我要用什么可持久化数据结构
分层图？
从最后一层开始倒退，看某一刻是否会回到自己并且走了奇数次取反操作？
记录根节点是哪个版本的哪个数并且记录距离？
那怎么判U？
同一层最多只有一条「错位边」
摆，去做T3
对了，我们只需要把这些「错位边」记录下来就可以了
然后拓扑？
但是有些时候错位边连不成一条链啊
还得把一些普通的边存着是吧
我不会了
绷不住了
打暴力
应该有50pts
md
暴力都打不对
想摆烂了
*/

/*
g++ ./tribool.cpp -o tribool -Wall -O2 -std=c++14 -static; ./tribool
*/