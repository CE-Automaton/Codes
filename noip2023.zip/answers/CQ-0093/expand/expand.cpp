#include <bits/stdc++.h>
using namespace std;
int c, n, m, q, mx, mn, kx, ky, px[500005], vx[500005], py[500005], vy[500005], x[500005], y[500005], visx[500005], visy[500005];
bool dp[2005][2005];
int main() {
	ios::sync_with_stdio(0);
	cin.tie(0), cout.tie(0);
	// freopen("expand/expand3.in", "r", stdin);
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);
	cin >> c >> n >> m >> q;
	for(int i = 1; i <= n; ++i) cin >> x[i];
	for(int i = 1; i <= m; ++i) cin >> y[i];
	memset(visx, 0xff, sizeof(visx));
	memset(visy, 0xff, sizeof(visy));
	if(c <= 7) {
		for(int Case = 0; Case <= q; ++Case) {
			if(Case) {
				cin >> kx >> ky;
				for(int j = 1; j <= kx; ++j) {
					cin >> px[j] >> vx[j];
					visx[px[j]] = vx[j];
				}
				for(int j = 1; j <= ky; ++j) {
					cin >> py[j] >> vy[j];
					visy[py[j]] = vy[j];
				}
			}
			#define a(pos) (~visx[pos] ? visx[pos] : x[pos])
			#define b(pos) (~visy[pos] ? visy[pos] : y[pos])
			memset(dp, false, sizeof(dp));
			if(a(1) < b(1)) {
				dp[1][1] = true;
				for(int i = 1; i <= n; ++i) {
					for(int j = 1; j <= m; ++j) {
						if(a(i) < b(j)) dp[i][j] |= dp[i - 1][j - 1] || dp[i][j - 1] || dp[i - 1][j];
					}
				}
			}
			else if(a(1) > b(1)) {
				dp[1][1] = true;
				for(int i = 1; i <= n; ++i) {
					for(int j = 1; j <= m; ++j) {
						if(a(i) > b(j)) dp[i][j] |= dp[i - 1][j - 1] || dp[i][j - 1] || dp[i - 1][j];
					}
				}
			}
			if(dp[n][m]) cout << "1";
			else cout << "0";
			if(Case) {
				for(int j = 1; j <= kx; ++j) {
					visx[px[j]] = -1;
				}
				for(int j = 1; j <= ky; ++j) {
					visy[py[j]] = -1;
				}
			}
		}
	}
	if(c >= 8 && c <= 14) {
		for(int i = 0; i <= q; ++i) {
			if(i) {
				cin >> kx >> ky;
				for(int j = 1; j <= kx; ++j) {
					cin >> px[j] >> vx[j];
					visx[px[j]] = vx[j];
				}
				for(int j = 1; j <= ky; ++j) {
					cin >> py[j] >> vy[j];
					visy[py[j]] = vy[j];
				}
			}
			mx = -1, mn = 2147483647;
			for(int j = 1; j <= n; ++j) {
				if(~visx[j]) mx = max(mx, visx[j]);
				else mx = max(mx, x[j]);
			}
			for(int j = 1; j <= m; ++j) {
				if(~visy[j]) mn = min(mn, visy[j]);
				else mn = min(mn, y[j]);
			}
			if(mx < (~visy[m] ? visy[m] : y[m]) && mn > (~visx[n] ? visx[n] : x[n])) cout << "1";
			else cout << "0";
			if(i) {
				for(int j = 1; j <= kx; ++j) {
					visx[px[j]] = -1;
				}
				for(int j = 1; j <= ky; ++j) {
					visy[py[j]] = -1;
				}
			}
		}
	}
	return 0;
}

/*
题目就是要所有的fi都小于gi或所有的fi都大于gi
分两种情况讨论就是了
不，看第一个元素就够了
特殊性质的分很好拿
那就先打了来
3e7能卡过去吗
呸，wssb，读错特殊性质了。
我是消愁
回去想T2
崩了
*/

/*
g++ ./expand.cpp -o expand -Wall -O2 -std=c++14 -static; ./expand
*/