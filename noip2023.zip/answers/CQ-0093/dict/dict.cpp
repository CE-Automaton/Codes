#include <bits/stdc++.h>
using namespace std;
int n, m, mn[3005], mx[3005];
char ch;
bool ans;
bool check(int i, int j) {
	return mx[j] > mn[i];
}
int main() {
	ios::sync_with_stdio(0);
	cin.tie(0), cout.tie(0);
	// freopen("dict/dict4.in", "r", stdin);
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);
	cin >> n >> m;
	for(int i = 1; i <= n; ++i) {
		mn[i] = 26, mx[i] = 0;
		for(int j = 1; j <= m; ++j) {
			cin >> ch;
			mn[i] = min(mn[i], (int)(ch - 'a'));
			mx[i] = max(mx[i], (int)(ch - 'a'));
		}
	}
	for(int i = 1; i <= n; ++i) {
		ans = true;
		for(int j = 1; j <= n; ++j) {
			if(i != j && !check(i, j)) {
				ans = false;
				break;
			}
		}
		cout << (ans ? 1 : 0);
	}
	return 0;
}

/*
一眼检查每个单词的字符集
O(n^2*sigma)
有点卡？
判断是否存在比它最小的字符大的字符
发现可以不用检查字符集
挺快的，算上通读的时间不到30min
*/

/*
g++ ./dict.cpp -o dict -Wall -O2 -std=c++14 -static; ./dict
*/