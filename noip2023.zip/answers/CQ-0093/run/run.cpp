#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll c, t, n, m, k, d, x, y, cnt, len, S, T, pos, sum, l[100005], r[100005], v[100005], sm[100005], dp[100005], mx[100005];//, pl[5000005], pr[5000005], co[5000005], cur[5000005], dep[5000005];
pair<pair<ll, ll>, ll> ch[100005];
// vector<ll> lsh;
// struct edge {
// 	ll to, c, pos;
// 	edge(ll To, ll C): to(To), c(C) {}
// };
// vector<edge> g[5000005];
// void add_edge(ll from, ll to, ll c) {
// 	g[from].push_back(edge(to, c));
// 	g[to].push_back(edge(from, 0));
// 	g[from].back().pos = g[to].size() - 1;
// 	g[to].back().pos = g[from].size() - 1;
// }
// queue<int> q;
// bool bfs(ll S, ll T) {
// 	memset(dep, 0, sizeof(dep));
// 	dep[S] = 1;
// 	while(!q.empty()) q.pop();
// 	q.push(S);
// 	int now;
// 	while(!q.empty()) {
// 		now = q.front();
// 		q.pop();
// 		for(const auto& i : g[now]) {
// 			if(i.c && !dep[i.to]) {
// 				dep[i.to] = dep[now] + 1;
// 				q.push(i.to);
// 			}
// 		}
// 	}
// 	return (bool)dep[T];
// }
// ll dfs(ll now, ll flw) {
// 	if(now == T || !flw) return flw;
// 	ll rest = flw, f;
// 	const int len = g[now].size();
// 	while(cur[now] < len) {
// 		auto& i = g[now][cur[now]];
// 		if(i.c && dep[i.to] == dep[now] + 1) {
// 			f = dfs(i.to, min(i.c, rest));
// 			if(!f) dep[i.to] = 0;
// 			i.c -= f;
// 			rest -= f;
// 			g[i.to][i.pos].c += f;
// 			if(!rest) break;
// 		}
// 		++cur[now];
// 	}
// 	return flw - rest;
// }
// ll Dinic(ll S, ll T) {
// 	ll flow = 0;
// 	while(bfs(S, T)) {
// 		memset(cur, 0, sizeof(cur));
// 		flow += dfs(S, 1ll << 60);
// 	}
// 	return flow;
// }
int main() {
	ios::sync_with_stdio(0);
	cin.tie(0), cout.tie(0);
	// freopen("run/run1.in", "r", stdin);
	freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);
	cin >> c >> t;
	if(c >= 1 && c <= 2) {
		while(t--) {
			cin >> n >> m >> k >> d;
			for(int i = 1; i <= m; ++i) {
				cin >> x >> y >> v[i];
				l[i] = x - y + 1, r[i] = x;
				ch[i] = make_pair(make_pair(l[i], r[i]), v[i]);
			}
			stable_sort(ch + 1, ch + 1 + m);
			for(int i = 1; i <= m; ++i) {
				l[i] = ch[i].first.first, r[i] = ch[i].first.second, v[i] = ch[i].second;
				sm[i] = sm[i - 1] + v[i];
			}
			dp[0] = 0;
			sum = 0;
			for(int i = 1; i <= m; ++i) {
				dp[i] = 0;
				for(int j = 1; j <= i; ++j) {
					if(r[i] - l[j] + 1 > k) break;
					dp[i] = max(dp[i], mx[j - 1] + sm[i] - sm[j - 1] - (r[i] - l[j] + 1) * d);
					if(l[j] > r[j - 1] + 1)
					dp[i] = max(dp[i], dp[j] + sm[i] - sm[j - 1] - (r[i] - l[j] + 1) * d);
				}
				mx[i] = max(mx[i - 1], dp[i]);
				sum = max(sum, dp[i]);
			}
			cout << sum << '\n';
		}
	}
	else {
		while(t--) {
			cin >> n >> m >> k >> d;
			// lsh.clear();
			sum = 0;
			for(int i = 1; i <= m; ++i) {
				cin >> x >> y >> v[i];
				l[i] = x - y + 1, r[i] = x;
				if(r[i] - l[i] + 1 <= k && v[i] > (r[i] - l[i] + 1) * d) {
					sum += v[i] - (r[i] - l[i] + 1) * d;
				}
				// lsh.push_back(l[i]), lsh.push_back(r[i]);
			}
			// lsh.push_back(1);
			// lsh.push_back(n);
			// stable_sort(lsh.begin(), lsh.end());
			// lsh.erase(unique(lsh.begin(), lsh.end()), lsh.end());
			// len = lsh.size();
			// for(int i = 0; i < len; ++i) {
			// 	if(i && lsh[i - 1] < lsh[i] - 1) {
			// 		++cnt;
			// 		pl[cnt] = lsh[i - 1] + 1, pr[cnt] = lsh[i] - 1;
			// 		if(pr[cnt] - pl[cnt] + 1 <= k) co[cnt] = (pr[cnt] - pl[cnt] + 1) * d;
			// 	}
			// 	++cnt;
			// 	pl[cnt] = pr[cnt] = lsh[i];
			// 	co[cnt] = d;
			// }
			// S = 0, T = cnt + m + 1;
			// for(int i = S; i <= T; ++i) g[i].clear();
			// for(int i = 1; i <= cnt; ++i) {
			// 	// cerr << pl[i] << " " << pr[i] << " " << co[i] << "\n";
			// 	if(pr[i] - pl[i] + 1 <= k) add_edge(i, T, co[i]);
			// }
			// for(int i = 1; i <= m; ++i) {
			// 	add_edge(S, cnt + i, v[i]);
			// 	sum += v[i];
			// 	pos = lower_bound(pl + 1, pl + 1 + cnt, l[i]) - pl;
			// 	while(pr[pos] <= r[i]) {
			// 		add_edge(cnt + i, pos, 1ll << 60);
			// 		++pos;
			// 	}
			// }
			cout << sum << '\n';//- Dinic(S, T) << '\n';
		}
	}
	return 0;
}

/*
崩溃了
3h拿的分不如我15min拿的
菜了
明年加油
md我才初三今年的NOIP就是一次磨练
网络流？
来得及
这个不能连续怎么整！
我吐了！
这玩意能过A
就两个点！不如暴力！
我破防了！
我想哭了
不对
没过
崩
不如直接贪心
*/

/*
g++ ./run.cpp -o run -Wall -O2 -std=c++14 -static; ./run
*/