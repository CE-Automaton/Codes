#include <bits/stdc++.h>
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=100005;
int n,m,a[N],fa[N*3];
bool b[N*3];
int find(int x) {return fa[x]==x?x:fa[x]=find(fa[x]);}
void merge(int x,int y) {
	int fx=find(x),fy=find(y);
	if(fx!=fy) fa[fx]=fy;
}
void _main() {
	n=read(),m=read();
	for(int i=1;i<=n;++i) a[i]=i;
	while(m--) {
		char ch;
		cin>>ch;
		int x=0,y=0;
		if(ch=='T') x=read(),a[x]=n+1;
		if(ch=='F') x=read(),a[x]=n-1;
		if(ch=='U') x=read(),a[x]=0;
		if(ch=='+') x=read(),y=read(),a[x]=a[y];
		if(ch=='-') x=read(),y=read(),a[x]=-a[y];
	}
	for(int i=0;i<=n*3;++i) fa[i]=i,b[i]=0;
	for(int i=1;i<=n;++i)
		if(a[i]!=0&&abs(a[i])<=n) merge(i+n,a[i]+n),merge(-i+n,-a[i]+n);
	for(int i=1;i<=n;++i)
		if(a[i]==0) b[find(i+n)]=1,merge(i+n,-i+n);
	int ans=0;
	for(int i=1;i<=n;++i)
		if(find(i+n)==find(n-i)) b[find(i+n)]=1,merge(i+n,-i+n);
	for(int i=1;i<=n;++i) ans+=b[find(i+n)]|b[find(-i+n)];
	cout<<ans<<endl;
}
signed main() {
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	read();
	int _=read();
	while(_--) _main();
	return 0;
}
/*
1 3
3 3
- 2 1
- 3 2
+ 1 3
3 3
- 2 1
- 3 2
- 1 3
2 2
T 2
U 2

0
3
1
*/
