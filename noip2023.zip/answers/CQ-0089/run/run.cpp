#include <bits/stdc++.h>
#define int long long
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
void chkmax(int &x,int y) {x<y&&(x=y);}
const int M=100005;
int n,m,k,d;
namespace sub1 {
	const int N=1005;
	int sum[N][N],f[N][N],ans;
	void _main() {
		int _=read();
		while(_--) {
			n=read(),m=read(),k=read(),d=read();
			for(int i=1;i<=n;++i)
			for(int j=0;j<=n;++j)
				f[i][j]=-1e18,sum[i][j]=0;
			while(m--) {
				int x=read(),y=read(),v=read();
				sum[x][y]+=v;
			}
			for(int i=1;i<=n;++i)
			for(int j=1;j<=n;++j)
				sum[i][j]+=sum[i][j-1];
			f[0][0]=0;
			for(int i=0;i<n;++i)
			for(int j=0;j<=min(k,i);++j) {
				if(j+1<=k) chkmax(f[i+1][j+1],f[i][j]-d+sum[i+1][j+1]);
				chkmax(f[i+1][0],f[i][j]);
			}
			ans=-1e18;
			for(int i=0;i<=k;++i) chkmax(ans,f[n][i]);
			cout<<ans<<'\n';
		}
		exit(0);
	}
}
namespace B {
	int ans=0;
	void _main() {
		int _=read();
		while(_--) {
			ans=0;
			n=read(),m=read(),k=read(),d=read();
			while(m--) {
				int x=read(),y=read(),v=read();
				if(v>y*d&&y<=k) ans+=v-y*d;
			}
			cout<<ans<<'\n';
		}
		exit(0);
	}
}
signed main() {
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	int num=read();
	if(num<=9) sub1::_main();
	if(num==17||num==18) B::_main();
	puts("0");
	return 0;
}
/*
1 1
3 2 2 1
2 2 4
3 2 3

2
*/
