#include <bits/stdc++.h>
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=3005;
int n,m,s[N][N],t[N][N],fi,se;
bool cmp(int *x,int *y) {
	for(int i=1;i<=m;++i) {
		if(x[i]<y[i]) return 1;
		if(x[i]>y[i]) return 0;
	}
	return 0;
}
signed main() {
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;++i) {
		for(int j=1;j<=m;++j) {
			char ch=getchar();
			while(ch<'a'||ch>'z') ch=getchar();
			s[i][j]=ch-'a';
			t[i][j]=s[i][j];
		}
		sort(s[i]+1,s[i]+1+m);
		for(int j=1;j<=m;++j) t[i][j]=s[i][m-j+1];
		if(!fi) fi=i;
		else if(!se) {
			if(cmp(t[i],t[fi])) se=fi,fi=i;
			else se=i;
		}
		else if(cmp(t[i],t[se]))  {
			se=i;
			if(cmp(t[se],t[fi])) swap(fi,se);
		}
	}
	for(int i=1;i<=n;++i) {
		if(fi!=i) putchar(cmp(s[i],t[fi])?'1':'0');
		else putchar(cmp(s[i],t[se])?'1':'0');
	}
	return 0;
}
/*
4 7
abandon
bananaa
baannaa
notnotn

1110
*/
