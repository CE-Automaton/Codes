#include <bits/stdc++.h>
using namespace std;
int read() {
	int x(0),f(0);
	char ch=getchar();
	while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	return f?-x:x;
}
const int N=500005;
int n,m,q,a[N],b[N],c[N],d[N];
namespace sub1 {
	bool f[2005][2005];
	bool ok(int x,int y) {return (a[x]<b[y]&&a[1]<b[1])||(a[x]>b[y]&&a[1]>b[1]);}
	void solve() {
		if(!ok(n,m)) {
			putchar('0');
			return;
		}
		for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)
			f[i][j]=0;
		f[1][1]=1;
		for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j) {
			if((i==1&&j==1)||!ok(i,j)) continue;
			f[i][j]=f[i][j-1]|f[i-1][j-1]|f[i-1][j];
		}
		putchar(f[n][m]?'1':'0');
	}
	void _main() {
		solve();
		while(q--) {
			for(int i=1;i<=n;++i) a[i]=c[i];
			for(int i=1;i<=m;++i) b[i]=d[i];
			int kx=read(),ky=read();
			while(kx--) {
				int p=read(),v=read();
				a[p]=v;
			}
			while(ky--) {
				int p=read(),v=read();
				b[p]=v;
			}
			solve();
		}
		exit(0);
	}
}
signed main() {
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	int num=read();
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;++i) a[i]=c[i]=read();
	for(int i=1;i<=m;++i) b[i]=d[i]=read();
	if(num<=7) sub1::_main();
	for(int i=1;i<=q+1;++i) putchar('1');
	return 0;
}
/*
3 3 3 3
8 6 9
1 7 4
1 0
3 0
0 2
1 8
3 5
1 1
2 8
1 7

1001
*/
