#include<bits/stdc++.h>
#define N 500005
using namespace std;
int n,m,x[N],y[N],a[N],b[N];
int lsx[N],rsx[N],lsy[N],rsy[N];
int hd,st[N];
int mxx[N],mny[N];
void dfsx(int u){
	mxx[u]=a[u];
	if(lsx[u]){
		dfsx(lsx[u]);
		mxx[u]=max(mxx[u],mxx[lsx[u]]);
	}
	if(rsx[u]){
		dfsx(rsx[u]);
		mxx[u]=max(mxx[u],mxx[rsx[u]]);
	}
}
void dfsy(int u){
	mny[u]=b[u];
	if(lsy[u]){
		dfsy(lsy[u]);
		mny[u]=min(mny[u],mny[lsy[u]]);
	}
	if(rsy[u]){
		dfsy(rsy[u]);
		mny[u]=min(mny[u],mny[rsy[u]]);
	}
}
bool dfsL(int u,int v,int bl){
	if(bl==0){
		int mn=b[v];
		if(lsy[v]) mn=min(mn,mny[lsy[v]]); 
		if(a[u]>=mn) return 0;
		if(u==1) return 1;
		if(a[lsx[u]]>=mn) return 0;
		while(lsx[u]&&a[lsx[u]]<mn) u=lsx[u];
		return dfsL(u,v,bl^1);
	}
	int mx=a[u];
	if(lsx[u]) mx=max(mx,mxx[lsx[u]]);
	if(b[v]<=mx) return 0;
	if(v==1) return 1;
	if(b[lsy[v]]<=mx) return 0;
	while(lsy[v]&&b[lsy[v]]>mx) v=lsy[v];
	return dfsL(u,v,bl^1);
}
bool dfsR(int u,int v,int bl){
	if(bl==0){
		int mn=b[v];
		if(rsy[v]) mn=min(mn,mny[rsy[v]]); 
		if(a[u]>=mn) return 0;
		if(u==n) return 1;
		if(a[rsx[u]]>=mn) return 0;
		while(rsx[u]&&a[rsx[u]]<mn) u=rsx[u];
		return dfsR(u,v,bl^1);
	}
	int mx=a[u];
	if(rsx[u]) mx=max(mx,mxx[rsx[u]]);
	if(b[v]<=mx) return 0;
	if(v==m) return 1;
	if(b[rsy[v]]<=mx) return 0;
	while(rsy[v]&&b[rsy[v]]>mx) v=rsy[v];
	return dfsR(u,v,bl^1);
}
void solve(){
	bool flag=0;
	for(int i=1;i<=n;i++) lsx[i]=rsx[i]=0;
	for(int i=1;i<=m;i++) lsy[i]=rsy[i]=0;
	if(a[1]>b[1]){
		swap(a,b);
		swap(n,m);
		flag=1;
	}
	hd=0;
	for(int i=1;i<=n;i++){
		int lst=0;
		while(hd&&a[st[hd]]>a[i]){
			rsx[st[hd]]=lst;
			lst=st[hd];
			hd--;
		}
		lsx[i]=lst;
		st[++hd]=i;
	}
	while(hd>1){
		rsx[st[hd-1]]=st[hd];
		hd--;
	}
	int rtx=st[1];
	hd=0;
	for(int i=1;i<=m;i++){
		int lst=0;
		while(hd&&b[st[hd]]<b[i]){
			rsy[st[hd]]=lst;
			lst=st[hd];
			hd--;
		}
		lsy[i]=lst;
		st[++hd]=i;
	}
	while(hd>1){
		rsy[st[hd-1]]=st[hd];
		hd--;
	}
	int rty=st[1];
	dfsx(rtx);
	dfsy(rty);
	int r1=dfsL(rtx,rty,0);
	int r2=dfsL(rtx,rty,1);
	int r3=dfsR(rtx,rty,0);
	int r4=dfsR(rtx,rty,1);
	int ans=((r1|r2)&(r3|r4));
	printf("%d",ans);
	if(flag) swap(n,m);
}
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	int c,q;
	scanf("%d%d%d%d",&c,&n,&m,&q);
	for(int i=1;i<=n;i++) scanf("%d",&x[i]),a[i]=x[i];
	for(int i=1;i<=m;i++) scanf("%d",&y[i]),b[i]=y[i];
	solve();
	while(q--){
		for(int i=1;i<=n;i++) a[i]=x[i];
		for(int j=1;j<=m;j++) b[j]=y[j];
		int kx,ky;
		scanf("%d%d",&kx,&ky);
		for(int i=1;i<=kx;i++){
			int p,v;
			scanf("%d%d",&p,&v);
			a[p]=v;
		}
		for(int i=1;i<=ky;i++){
			int p,v;
			scanf("%d%d",&p,&v);
			b[p]=v;
		}
		solve();
	}
}
