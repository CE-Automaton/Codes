#include<bits/stdc++.h>
#define N 200005 
using namespace std;
const long long inf=1e18;
struct sgt{
	long long tre[4*N],lz[4*N];
	void build(int q,int l,int r){
		tre[q]=0;
		lz[q]=0;
		if(l==r) return;
		int mid=(l+r)/2;
		build(q*2,l,mid);
		build(q*2+1,mid+1,r);
	}
	void update(int q,long long x){
		lz[q]=max(-inf,lz[q]+x);
		tre[q]=max(-inf,tre[q]+x);
	} 
	void push_down(int q){
		if(lz[q]!=0){
			update(q*2,lz[q]);
			update(q*2+1,lz[q]);
			lz[q]=0;
		}
	}
	void add(int q,int l,int r,int x,int y,long long z){
		if(x<=l&&r<=y){
			update(q,z);
			return;
		}
		push_down(q);
		int mid=(l+r)/2;
		if(x<=mid) add(q*2,l,mid,x,y,z);
		if(mid<y) add(q*2+1,mid+1,r,x,y,z);
		tre[q]=max(tre[q*2],tre[q*2+1]); 
	} 
	void modify(int q,int l,int r,int x,long long y){
		if(l==r){
			tre[q]=y;
			return;
		}
		push_down(q);
		int mid=(l+r)/2;
		if(x<=mid) modify(q*2,l,mid,x,y);
		else modify(q*2+1,mid+1,r,x,y);
		tre[q]=max(tre[q*2],tre[q*2+1]);
	} 
	long long query(int q,int l,int r,int x,int y){
		if(x<=l&&r<=y) return tre[q];
		push_down(q);
		int mid=(l+r)/2;
		long long res=-inf;
		if(x<=mid) res=max(res,query(q*2,l,mid,x,y));
		if(mid<y) res=max(res,query(q*2+1,mid+1,r,x,y));
		return res;
	}
}T;
int m;
long long n,k,d,srt[N];
struct node{long long L,R,V;}ch[N];
vector<node > R[N];
void solve(){
	//li san hua
	scanf("%lld%d%lld%lld",&n,&m,&k,&d);
	int cnt=1;
	srt[1]=0;
	for(int i=1;i<=m;i++){
		long long x,y;
		scanf("%lld%lld%lld",&x,&y,&ch[i].V);
		ch[i].R=x;
		ch[i].L=x-y;
		srt[++cnt]=ch[i].L;
		srt[++cnt]=ch[i].R;
	}
	sort(srt+1,srt+cnt+1);
	cnt=unique(srt+1,srt+cnt+1)-srt-1;
	for(int i=1;i<=m;i++){
		ch[i].L=lower_bound(srt+1,srt+cnt+1,ch[i].L)-srt;
		ch[i].R=lower_bound(srt+1,srt+cnt+1,ch[i].R)-srt;
		R[ch[i].R].push_back(ch[i]);
	}
	T.build(1,1,cnt);
	long long ans=0;
	for(int i=2;i<=cnt;i++){
		long long f=T.query(1,1,cnt,1,i-1);
		T.modify(1,1,cnt,i,f);
		T.add(1,1,cnt,1,i-1,-d*(srt[i]-srt[i-1]));
		if(srt[i]-k>0){
			int pos=lower_bound(srt+1,srt+cnt+1,srt[i]-k)-srt-1;
			T.add(1,1,cnt,1,pos,-inf);
		}
		for(node CH:R[i])
			T.add(1,1,cnt,1,CH.L,CH.V);
		ans=max(ans,T.tre[1]);
	}
	printf("%lld\n",ans);
	for(int i=1;i<=cnt;i++) R[i].clear();
}
int main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	int c,t;
	scanf("%d%d",&c,&t);
	while(t--) solve();
} 
