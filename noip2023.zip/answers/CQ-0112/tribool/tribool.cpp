#include<bits/stdc++.h>
#define N 300005
using namespace std;
int n,m,id[N];
int fa[N],yh[N],un[N];
int getfa(int u){
	if(fa[u]==u) return u;
	int f=getfa(fa[u]);
	yh[u]=(yh[fa[u]]^yh[u]);
	return fa[u]=f;
}
void merge(int x,int y,int b){
	int fx=getfa(x),fy=getfa(y);
	if(fx==fy){
		if((b^yh[x]^yh[y])==1) un[fx]=1;
		return;
	}
	fa[fy]=fx;
	un[fx]=(un[fx]|un[fy]);
	yh[fy]=(b^yh[x]^yh[y]);
}
char s[5];
void solve(){
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n+m+5;i++) fa[i]=i,yh[i]=un[i]=0;
	for(int i=1;i<=n;i++) id[i]=i;
	int tot=n+3;
	//T=n+1,F=n+2,U=n+3;
	merge(n+1,n+2,1);un[n+3]=1;
	for(int i=1;i<=m;i++){
		int x,y;
		scanf("%s%d",s,&x);
		tot++;
		if(s[0]=='T') merge(n+1,tot,0);
		else if(s[0]=='F') merge(n+2,tot,0);
		else if(s[0]=='U') merge(n+3,tot,0); 
		else{
			scanf("%d",&y);
			if(s[0]=='+') merge(id[y],tot,0);
			else merge(id[y],tot,1);
		}
		id[x]=tot;
	}
	for(int i=1;i<=n;i++) merge(i,id[i],0);
	int ans=0;
	for(int i=1;i<=n;i++)
		if(un[getfa(i)]==1) ans++;
	printf("%d\n",ans);
}
int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	int c,t;
	scanf("%d%d",&c,&t);
	while(t--) solve();
}
