#include<bits/stdc++.h>
#define N 6005
using namespace std;
char s[N];
struct node{
	int id,num[27];
}p[N];
int n,m;
bool cmp(node p1,node p2){
	int now1,now2,ad1,ad2;
	if(p1.id<=n) now1=0,ad1=1;
	else now1=25,ad1=-1;
	if(p2.id<=n) now2=0,ad2=1;
	else now2=25,ad2=-1;
	while(1){
		while(now1>=0&&now1<=25&&p1.num[now1]==0) now1+=ad1;
		if(now1<0||now1>25) return p1.id<p2.id;
		while(now2>=0&&now2<=25&&p2.num[now2]==0) now2+=ad2;
		if(now2<0||now2>25) return p1.id<p2.id;
		if(now1!=now2) return now1<now2;
		int mn=min(p1.num[now1],p2.num[now2]);
		p1.num[now1]-=mn;
		p2.num[now2]-=mn;
	}
	return p1.id<p2.id;
}
int ans[N];
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("%s",s);
		p[i].id=i;
		p[i+n].id=i+n;
		for(int j=0;j<m;j++){
			p[i].num[s[j]-'a']++;
			p[i+n].num[s[j]-'a']++;
		}
	}
	sort(p+1,p+2*n+1,cmp);
	for(int i=1;i<=2*n;i++){
		if(p[i].id>n) break;
		ans[p[i].id]=1;
	}
	for(int i=1;i<=n;i++) printf("%d",ans[i]);
}
