#include<bits/stdc++.h>
#define fi first
#define se second
#define DEBUG(...) fprintf(stderr, __VA_ARGS__)
template<typename Ty>
Ty read() {
	Ty x = 0; char c = getchar();
	while (! isdigit(c)) {c = getchar();}
	while (isdigit(c)) {x = x * 10 + c - '0', c = getchar();}
	return x;
}
using i64 = long long;
const i64 inf = 0x3f3f3f3f3f3f3f3f;
namespace main1 {
	const int maxn = 1e3 + 10;
	i64 f[maxn], g[maxn];
	std::vector<std::pair<int, i64> > v[maxn];
	void solve() {
		int n, m, k; i64 d;
		scanf("%d%d%d%lld", &n, &m, &k, &d);
		for (int i = 1; i <= n; i++) {v[i].clear();}
		while (m--) {
			int x, y; i64 w;
			scanf("%d%d%lld", &x, &y, &w);
			if (y > k) {continue;}
			v[x].emplace_back(y, w);
		}
		for (int i = 0; i <= k; i++) {f[i] = -inf;}
		f[0] = 0;
		for (int i = 1; i <= n; i++) {
			i64 mx = -inf;
			for (int j = 0; j <= k; j++) {mx = std::max(mx, f[j]);}
			for (int j = k; j; j--) {f[j] = f[j - 1] - d;}
			f[0] = mx;
			for (int j = 0; j <= k; j++) {g[j] = 0;}
			for (auto tot : v[i]) {g[tot.fi] += tot.se;}
			for (int j = 0; j <= k; j++) {g[j] += (j ? g[j - 1] : 0), f[j] += g[j];}
		}
		i64 ans = -inf;
		for (int i = 0; i <= k; i++) {ans = std::max(ans, f[i]);}
		printf("%lld\n", ans);
	}
}
namespace main2 {
	const int maxn = 1e5 + 10;
	struct segtr {
		struct node {
			i64 mx, tag;
		} a[maxn * 8];
		int n;
		void pushup(int k) {a[k].mx = std::max(a[k << 1].mx, a[k << 1 | 1].mx);}
		void build(int k, int l, int r) {
			a[k].tag = 0;
			if (l == r) {a[k].mx = -inf; return ;}
			int mid = (l + r) >> 1;
			build(k << 1, l, mid), build(k << 1 | 1, mid + 1, r);
			pushup(k);
		}
		void init(int _n) {
			n = _n;
			build(1, 1, n);
		}
		void upd(int k, i64 x) {a[k].mx += x, a[k].tag += x;}
		void pushdown(int k) {
			if (a[k].tag) {
				upd(k << 1, a[k].tag), upd(k << 1 | 1, a[k].tag);
				a[k].tag = 0;
			}
		}
		void update(int k, int l, int r, int x, int y, i64 v) {
			if (x <= l && r <= y) {upd(k, v); return ;}
			pushdown(k);
			int mid = (l + r) >> 1;
			if (x <= mid) {update(k << 1, l, mid, x, y, v);}
			if (mid < y) {update(k << 1 | 1, mid + 1, r, x, y, v);}
			pushup(k);
		}
		void update(int x, int y, i64 v) {update(1, 1, n, x, y, v);}
		void change(int k, int l, int r, int x, i64 v) {
			if (l == r) {a[k].mx = v; return ;}
			pushdown(k);
			int mid = (l + r) >> 1;
			if (x <= mid) {change(k << 1, l, mid, x, v);}
			else {change(k << 1 | 1, mid + 1, r, x, v);}
			pushup(k);
		}
		void change(int x, i64 v) {change(1, 1, n, x, v);}
		i64 qry() {return a[1].mx;}
	} f;
	std::vector<std::pair<int, i64> > v[maxn];
	void solve() {
		int n = read<int>(), m = read<int>(), k = read<int>(); i64 d = read<i64>();
		for (int i = 1; i <= n; i++) {v[i].clear();}
		while (m--) {
			int x = read<int>(), y = read<int>(); i64 w = read<i64>();
			if (y > k) {continue;}
			v[x].emplace_back(y, w);
		}
		f.init(n + k + 1);
		int R = n + k + 1, L = n + 1;
		f.change(L, 0);
		for (int i = 1; i <= n; i++) {
			i64 mx = f.qry(); f.change(R, -inf);
			R--, L--;
			f.update(L, R, -d), f.change(L, mx);
			for (auto tot : v[i]) {f.update(L + tot.fi, R, tot.se);}
		}
		printf("%lld\n", f.qry());
	}
}
namespace main3 {
	void solve() {
		int n = read<int>(), m = read<int>(), k = read<int>(); i64 d = read<i64>();
		i64 ans = 0;
		while (m--) {
			int x = read<int>(), y = read<int>(); i64 w = read<i64>();
			if (y > k) {continue;}
			ans += std::max(0ll, w - 1ll * d * y);
		}
		printf("%lld\n", ans);
	}
}
namespace main4 {
	const int maxn = 2e5 + 10, maxk = 1e2 + 10;
	struct {int x, y; i64 w;} qr[maxn];
	int p[maxn];
	i64 f[maxk];
	std::vector<std::pair<int, i64> > v[maxn];
	void solve() {
		int n = read<int>(), m = read<int>(), k = read<int>(); i64 d = read<i64>();
		int tot = 0;
		for (int i = 1; i <= m; i++) {
			qr[i].x = read<int>(), qr[i].y = read<int>(), qr[i].w = read<i64>();
			p[++tot] = qr[i].x, p[++tot] = qr[i].x - qr[i].y + 1;
		}
		std::sort(p + 1, p + tot + 1);
		int _tot = std::unique(p + 1, p + tot + 1) - p - 1;
		tot = _tot;
		for (int i = 1; i <= tot; i++) {v[i].clear();}
		for (int i = 1; i <= m; i++) {
			qr[i].x = std::lower_bound(p + 1, p + tot + 1, qr[i].x) - p;
			v[qr[i].x].emplace_back(qr[i].y, qr[i].w);
		}
		int lst = 0;
		for (int i = 0; i <= k; i++) {f[i] = -inf;}
		f[0] = 0;
		for (int i = 1; i <= tot; i++) {
			i64 mx = -inf;
			for (int j = 0; j <= k; j++) {mx = std::max(mx, f[j]);}
			for (int j = k; j >= p[i] - lst; j--) {f[j] = f[j - (p[i] - lst)] - 1ll * d * (p[i] - lst);}
			for (int j = 0; j < p[i] - lst && j <= k; j++) {f[j] = mx - d * j;}
			for (auto Q : v[i]) {
				for (int j = Q.fi; j <= k; j++) {f[j] += Q.se;}
			}
			lst = p[i];
		}
		i64 ans = -inf;
		for (int i = 0; i <= k; i++) {ans = std::max(ans, f[i]);}
		printf("%lld\n", ans);
	}
}
namespace main5 {
	const int maxn = 1e5 + 10;
	int l[maxn], r[maxn]; i64 S[maxn];
	i64 f[maxn], g[maxn];
	void solve() {
		int n = read<int>(), _m = read<int>(), k = read<int>(); i64 d = read<i64>();
		int m = 0;
		while (_m--) {
			int x = read<int>(), y = read<int>(); i64 w = read<i64>();
			if (y > k) {continue;}
			m++, l[m] = x - y + 1, r[m] = x, S[m] = S[m - 1] + w; 
		}
		int hd = 0;
		std::deque<std::pair<int, i64> > q;
		for (int i = 1; i <= m; i++) {
			while (hd + 1 <= m && r[hd + 1] + 1 < l[i]) {hd++;}
			i64 val = - S[i - 1] + 1ll * d * l[i] + g[hd];
			while (q.size() && val >= q.back().se) {q.pop_back();}
			q.emplace_back(i, val);
			while (q.size() && r[i] - l[q.front().fi] + 1 > k) {q.pop_front();}
			f[i] = q.front().se + S[i] - 1ll * d * (r[i] + 1), g[i] = std::max(g[i - 1], f[i]);
		}
		printf("%lld\n", g[m]);
	}
}
int main() {
	freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);
	int c = read<int>(), T = read<int>();
	while (T--) {
		if (c <= 14) {
			main2::solve();
		} else if (c == 17 || c == 18) {
			main3::solve();
		} else if (c == 15 || c == 16) {
			main4::solve();
		} else if (c == 19 || c == 20 || c == 21) {
			main5::solve();
		}
	}
	return 0;
} 
