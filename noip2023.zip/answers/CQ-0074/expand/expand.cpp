#include<bits/stdc++.h>
template<typename Ty>
Ty read() {
	Ty x = 0; char c = getchar();
	while (! isdigit(c)) {c = getchar();}
	while (isdigit(c)) {x = x * 10 + c - '0', c = getchar();}
	return x;
}
namespace main1 {
	const int maxn = 2e3 + 10;
	int n, m;
	std::bitset<maxn> f[maxn];
	int A[maxn], B[maxn], a[maxn], b[maxn];
	int calc() {
		if (a[1] == b[1]) {return 0;}
		bool cmp = a[1] > b[1];
		f[0][0] = 1;
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= m; j++) {
				f[i][j] = (cmp ? a[i] > b[j] : a[i] < b[j]) & (f[i - 1][j] | f[i - 1][j - 1] | f[i][j - 1]);
			}
		}
		return int(f[n][m]);
	}
	void solve() {
		n = read<int>(), m = read<int>(); int q = read<int>();
		for (int i = 1; i <= n; i++) {a[i] = A[i] = read<int>();}
		for (int i = 1; i <= m; i++) {b[i] = B[i] = read<int>();}
		printf("%d", calc());
		while (q--) {
			int kx = read<int>(), ky = read<int>();
			for (int i = 1; i <= n; i++) {a[i] = A[i];}
			for (int i = 1; i <= m; i++) {b[i] = B[i];}
			while (kx--) {
				int w = read<int>(), v = read<int>();
				a[w] = v;
			}
			while (ky--) {
				int w = read<int>(), v = read<int>();
				b[w] = v;
			}
			printf("%d", calc());
		}
	}
}
int main() {
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);
	int c = read<int>();
	if (c <= 7) {
		main1::solve();
	}
	return 0;
}