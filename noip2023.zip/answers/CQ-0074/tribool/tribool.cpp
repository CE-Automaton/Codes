#include<bits/stdc++.h>
#define fi first
#define se second
const int maxn = 1e5 + 10;
struct {int fa, val;} a[maxn];
int val[maxn];
std::vector<std::pair<int, int> > E[maxn];
std::vector<int> G[maxn];
int ID[maxn], siz[maxn]; bool vis[maxn];
int col[maxn];
void dfs(int u, bool &f, int &sz) {
	sz += siz[u];
	for (auto v : G[u]) {
		if (col[v] == -1) {
			col[v] = col[u] ^ 1;
			dfs(v, f, sz);
		} else {
			f &= col[v] != col[u];
		}
	}
}
void solve() {
	int n, m;
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; i++) {a[i] = {i, 0};}
	while (m--) {
		char opt[5];
		scanf("%s", opt);
		if (opt[0] == 'T') {
			int x;
			scanf("%d", &x);
			a[x] = {0, 0};
		} else if (opt[0] == 'F') {
			int x;
			scanf("%d", &x);
			a[x] = {0, 1};
		} else if (opt[0] == 'U') {
			int x;
			scanf("%d", &x);
			a[x] = {0, 2};
		} else if (opt[0] == '+') {
			int x, y;
			scanf("%d%d", &x, &y);
			a[x] = a[y];
		} else if (opt[0] == '-') {
			int x, y;
			scanf("%d%d", &x, &y);
			a[x] = a[y];
			if (a[x].val != 2) {a[x].val ^= 1;}
		}
	}
	for (int i = 1; i <= n; i++) {val[i] = -1, E[i].clear();}
	std::queue<int> bq;
	for (int i = 1; i <= n; i++) {
		if (a[i].fa == 0) {
			val[i] = a[i].val, bq.push(i);
		} else {
			E[a[i].fa].emplace_back(i, a[i].val), E[i].emplace_back(a[i].fa, a[i].val);
		}
	}
	int cnt = 0;
	while (bq.size()) {
		int u = bq.front(); bq.pop();
		cnt += val[u] == 2;
		for (auto i : E[u]) {
			int v = i.fi, w = i.se;
			if (val[v] == -1) {
				val[v] = val[u];
				if (w && val[v] != 2) {val[v] ^= 1;}
				bq.push(v);
			}
		}
	}
	for (int i = 1; i <= n; i++) {G[i].clear();}
	for (int i = 1; i <= n; i++) {
		if (val[i] == -1 && a[i].val == 0) {
			G[i].push_back(a[i].fa), G[a[i].fa].push_back(i);
		}
	}
	int tot = 0;
	for (int i = 1; i <= n; i++) {vis[i] = 0, ID[i] = 0, siz[i] = 0;}
	for (int i = 1; i <= n; i++) {
		if (val[i] == -1 && ! vis[i]) {
			tot++; bq.push(i); vis[i] = 1;
			while (bq.size()) {
				int u = bq.front(); bq.pop();
				ID[u] = tot, siz[tot]++;
				for (auto v : G[u]) {
					if (! vis[v]) {vis[v] = 1, bq.push(v);}
				}
			}
		}
	}
	for (int i = 1; i <= n; i++) {G[i].clear();}
	for (int i = 1; i <= n; i++) {
		if (val[i] == -1 && a[i].val == 1) {
			int x = ID[i], y = ID[a[i].fa];
			G[x].push_back(y), G[y].push_back(x);
		}
	}
	for (int i = 1; i <= n; i++) {col[i] = -1;}
	for (int i = 1; i <= tot; i++) {
		if (col[i] == -1) {
			bool f = 1; int sz = 0;
			col[i] = 0, dfs(i, f, sz);
			if (! f) {cnt += sz;}
		}
	}
	printf("%d\n", cnt);
}
int main() {
	freopen("tribool.in", "r", stdin);
	freopen("tribool.out", "w", stdout);
	int c, T;
	scanf("%d%d", &c, &T);
	while (T--) {solve();}
	return 0;
} 
