#include<bits/stdc++.h>
const int maxn = 3e3 + 10;
char s[maxn];
int mx[maxn], mn[maxn];
int cnt[26];
int main() {
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);
	int n, m;
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; i++) {
		scanf("%s", s + 1);
		memset(cnt, 0, sizeof(cnt));
		for (int j = 1; j <= m; j++) {cnt[s[j] - 'a']++;}
		for (mx[i] = 25; ! cnt[mx[i]]; mx[i]--);
		for (mn[i] = 0; ! cnt[mn[i]]; mn[i]++);
	}
	for (int i = 1; i <= n; i++) {
		bool flg = 1;
		for (int j = 1; j <= n; j++) {
			if (i != j) {flg &= mn[i] < mx[j];}
		}
		printf("%d", int(flg));
	}
	return 0;
}
