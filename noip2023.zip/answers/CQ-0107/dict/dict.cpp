#include<bits/stdc++.h>
using namespace std;
char ch[3003];
int num[3003][30],maxn[3003],minn[3003];
int tot[3003];
int n,m;
int main()
{
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%s",ch+1);
		for(int j=1;j<=m;j++)
		{
			num[i][ch[j]-'a'+1]++;
		}
		for(int j=1;j<=26;j++)
		{
			if(num[i][j]!=0)
			{
				minn[i]=j;break;
			}
		}
		for(int j=26;j>=1;j--)
		{
			if(num[i][j]!=0)
			{
				maxn[i]=j;break;
			}
		}
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			if(i==j)continue;
			if(minn[i]<maxn[j])
			{
				tot[i]++;continue;
			}
		}
	}
	for(int i=1;i<=n;i++)
	{
		if(tot[i]==n-1)printf("1");
		else printf("0");
	}
	printf("\n");
	return 0;
}

