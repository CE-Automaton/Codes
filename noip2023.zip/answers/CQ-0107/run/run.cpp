#include<bits/stdc++.h>
using namespace std;

char *p1,*p2,buf[100000];
#define nc() (p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++)

inline int read()
{
	int x=0;char ch=nc();
	while(ch<'0' or ch>'9')ch=nc();
	while(ch>='0' and ch<='9')x=(x<<3)+(x<<1)+ch-'0',ch=nc();
	return x;
}
int C,t;
int n,m,k;
long long d;
struct asd
{
	int l,r;
	long long x;
}a[1000001];
int numx[1000001],tot0;
map<int,int> adm;
long long c[4001];

bool cmp(asd qw,asd qe)
{
	if(qw.l==qe.l)return qw.r<qe.r;
	return qw.l<qe.l;
}
long long cs[2002][2002];
long long f[100001];
int main()
{
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	C=read();t=read();
	while(t--)
	{
		memset(f,0,sizeof(f));
		n=read();m=read();k=read();d=read();
		for(int i=1;i<=m;i++)
		{
			int x=read(),y=read(),v=read();
			a[i].l=x-y+1,a[i].r=x;a[i].x=v;
			numx[i*2-1]=a[i].l-1;
			numx[i*2]=a[i].r;
		}
		numx[m*2+1]=0;
		sort(numx+1,numx+2+m*2);
		tot0=unique(numx+1,numx+2+m*2)-(numx+1);
		adm.clear();
		for(int i=1;i<=tot0;i++)adm[numx[i]]=i;
		for(int i=1;i<=m;i++)
		{
			a[i].l=adm[a[i].l-1];
			a[i].r=adm[a[i].r];
		}
		sort(a+1,a+1+m,cmp);
		for(int i=1;i<=m;i++)
		{
			if(a[i].l==a[i-1].l)continue;
			memset(c,0,sizeof(c));
			for(int j=i;j<=m;j++)c[a[j].r]+=a[j].x;
			for(int j=a[i].l;j<=tot0;j++)c[j]+=c[j-1];
			for(int j=a[i].l+1;j<=tot0;j++)cs[a[i].l+1][j]=c[j];
		}
		long long ans=0;
		for(int i=1;i<=tot0;i++)
		{
			for(int j=i-1;j>=0;j--)
			{
				if(numx[i]-numx[j]<=k)f[i]=max(f[i],f[j]-1ll*(numx[i]-numx[j])*d+cs[j+1][i]);
				f[i]=max(f[i],f[j]);
			}
			ans=max(ans,f[i]);
		}
		printf("%lld\n",ans);
	}
	return 0;
}

