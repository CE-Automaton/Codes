#include<bits/stdc++.h>
using namespace std;

char *p1,*p2,buf[100000];
#define nc() (p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++)

inline int read()
{
	int x=0;char ch=nc();
	while(ch<'0' or ch>'9')ch=nc();
	while(ch>='0' and ch<='9')x=(x<<3)+(x<<1)+ch-'0',ch=nc();
	return x;
}
int c,n,m,q;
int x[1000001],y[1000001];
int nx[1000001],ny[1000001];
int px[1000001],py[1000001];
bool f[2002][2002];
char ans[1000001];
int main()
{
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	c=read();n=read();m=read();q=read();
	for(int i=1;i<=n;i++)x[i]=read();
	for(int i=1;i<=m;i++)y[i]=read();
	f[0][0]=1;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			f[i][j]=((f[i-1][j]|f[i][j-1])&(x[i]>y[j]));
			f[i][j]=(f[i][j]|(f[i-1][j-1]&(x[i]>y[j])));
		}
	}
	for(int i=1;i<=n;i++)nx[i]=x[i];
	for(int i=1;i<=m;i++)ny[i]=y[i];
	ans[0]=f[n][m]+'0';
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			f[i][j]=((f[i-1][j]|f[i][j-1])&(x[i]<y[j]));
			f[i][j]=(f[i][j]|(f[i-1][j-1]&(x[i]<y[j])));
		}
	}
	ans[0]=((ans[0]-'0')|f[n][m])+'0';
	for(int k=1;k<=q;k++)
	{
		int kx=read(),ky=read();
		for(int i=1;i<=kx;i++)
		{
			px[i]=read();int x0=read();
			x[px[i]]=x0;
		}
		for(int i=1;i<=ky;i++)
		{
			py[i]=read();int x0=read();
			y[py[i]]=x0;
		}
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			{
				f[i][j]=((f[i-1][j]|f[i][j-1])&(x[i]>y[j]));
				f[i][j]=(f[i][j]|(f[i-1][j-1]&(x[i]>y[j])));
			}
		}
		ans[k]=f[n][m]+'0';
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=m;j++)
			{
				f[i][j]=((f[i-1][j]|f[i][j-1])&(x[i]<y[j]));
				f[i][j]=(f[i][j]|(f[i-1][j-1]&(x[i]<y[j])));
			}
		}
		ans[k]=((ans[k]-'0')|f[n][m])+'0';
		for(int i=1;i<=kx;i++)x[px[i]]=nx[px[i]];
		for(int i=1;i<=ky;i++)y[py[i]]=ny[py[i]];
	}
	printf("%s",ans);
	return 0;
}

