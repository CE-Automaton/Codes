#include<bits/stdc++.h>
using namespace std;

char *p1,*p2,buf[100000];
#define nc() (p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++)

inline int read()
{
	int x=0;char ch=nc();
	while(ch<'0' or ch>'9')ch=nc();
	while(ch>='0' and ch<='9')x=(x<<3)+(x<<1)+ch-'0',ch=nc();
	return x;
}
struct edg
{
	int nxt,to;
}e[1000001];
int head[201002],cnt;
inline void add(int u,int v){e[++cnt].nxt=head[u];head[u]=cnt;e[cnt].to=v;}
int num[1000001];
bool mark[1000001][2];
int mark2[1000001];
int c,t;
int n,m;
int tot[1000001];
int tot0;
inline void dfs(int u,int op,int x)
{
	if(!mark[u][1] and !mark[u][0])tot0++;
	if(mark[u][op-1])return;
	mark[u][op-1]=1;
	if(op==1)
	{
		if(mark2[-u+n+1]==x)tot[x]=1;
		if(mark2[u+n+1]==x)return ;
		mark2[u+n+1]=x;
	}
	if(op==2)
	{
		if(mark2[u+n+1]==x)tot[x]=1;
		if(mark2[-u+n+1]==x)return ;
		mark2[-u+n+1]=x;
	}
	for(int i=head[u+n+1];i;i=e[i].nxt)
	{
		int v=e[i].to-n-1;
		if(v==0)tot[x]=1;
		else if(abs(v)>n)continue;
		else
		{
			if(v>0)
			{
				if(op==1)dfs(v,op,x);
				else dfs(v,2,x);
			}
			else
			{
				if(op==1)dfs(-v,2,x);
				else dfs(-v,1,x);
			}
		}
	}
	
}
int main()
{
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	c=read();t=read();
	while(t--)
	{
		n=read();m=read();
		int ans=0;
		for(int i=1;i<=n;i++)num[i]=i;
		for(int i=1;i<=m;i++)
		{
			char ch=nc();
			while(ch!='-' and ch!='+' and ch!='T' and ch!='F' and ch!='U')ch=nc();
			if(ch=='+')
			{
				int i=read(),j=read();
				num[i]=num[j];continue;
			}
			if(ch=='-')
			{
				int i=read(),j=read();
				num[i]=-num[j];
				continue;
			}
			if(ch=='T')
			{
				int i=read();
				num[i]=n+1;continue;
			}
			if(ch=='F')
			{
				int i=read();
				num[i]=-n-1;continue;
			}
			if(ch=='U')
			{
				int i=read();
				num[i]=0;continue;
			}
		}
		for(int i=0;i<=n+n+1;i++)tot[i]=0,mark[i][0]=mark[i][1]=0,mark2[i]=0;
		cnt=0;memset(head,0,sizeof(head));
		for(int i=1;i<=n;i++)
		{
			add(i+n+1,num[i]+n+1);
			add(num[i]+n+1,i+n+1);
			add(-i+n+1,-num[i]+n+1);
			add(-num[i]+n+1,-i+n+1);
		}
		int x=0;
		for(int i=1;i<=n;i++)
		{
			if(!mark[i][0])
			{
				x++;
				tot0=0;
				dfs(i,1,x);
				if(tot[x]==1)
				{
					ans+=tot0;
				}
			}
			if(!mark[i][1])
			{
				x++;
				tot0=0;
				dfs(i,2,x);
				if(tot[x]==1)
				{
					ans+=tot0;
				}
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}

