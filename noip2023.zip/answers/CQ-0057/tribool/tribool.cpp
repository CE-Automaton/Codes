#include<bits/stdc++.h>
#define inlint inline int
#define inloid inline void
#define inbool inline bool
#define MAXN 100005
#define pii pair<int, int>
using namespace std;

namespace _MAIN {
	inlint read() {
		int nega = 1, num = 0, c = getchar();
		for(; ~c &&!isdigit(c); c = getchar()) if(c == '-') nega = -1;
		for(; ~c && isdigit(c); c = getchar()) (num *= 10) += c - '0';
		return nega * num;
	}
	int n, m, cc, tt;
} using namespace _MAIN;

namespace _SOLV {

} using namespace _SOLV;

namespace _Alice_Margatroid {
	int seq[MAXN];
	pii revcon[MAXN];
	char op[MAXN][2];
	int opp[MAXN][2];
	int col[MAXN], tg[MAXN], dis[MAXN], vis[MAXN];	
	inloid subtask12() {
		int minu = 0x3f3f3f3f;
		for(int nu = 0, len = pow(3, n); nu < len; nu++) {
			int cu = nu, ucn = 0;
			for(int i = 1; i <= n; i++) seq[i] = col[i] = cu % 3, cu /= 3, ucn += (seq[i] == 2);
			for(int i = 1; i <= m; i++) {
				if(op[i][0] == 'T') col[opp[i][0]] = 0;
				else if(op[i][0] == 'F') col[opp[i][0]] = 1;
				else if(op[i][0] == 'U') col[opp[i][0]] = 2;
				else {
					int a = opp[i][0], b = opp[i][1];
					if(op[i][0] == '+') {
						col[a] = col[b];
					} else {
						col[a] = 1 - col[b];
						if(col[b] == 2) col[a] = 2;
					}
				}
			}
			int flag = 1;
			for(int i = 1; i <= n; i++) if(col[i] != seq[i]) flag = 0;
			if(flag) minu = min(minu, ucn);
		}
		cout << minu << "\n";
	}
	inloid subtask34() {
		for(int i = 1; i <= m; i++) {
			if(op[i][0] == 'T') col[opp[i][0]] = 1;
			else if(op[i][0] == 'F') col[opp[i][0]] = 2;
			else col[opp[i][0]] = 3;
		}
		int ans = 0;
		for(int i = 1; i <= n; i++) if(col[i] == 3) ans++;
		cout << ans << "\n";
	}
	inlint dfs(int cu) {
		int to = revcon[cu].first, ed = revcon[cu].second;
		if(cu > n) return dis[cu] = 0, cu;
		vis[cu] = 1;
		if(dis[to] && dis[to] != dis[cu] * ed){
			return revcon[cu] = pii(cu, -1), dis[cu] = 0, cu;
		} else if(!vis[to]) dis[to] = dis[cu] * ed, revcon[cu].first = dfs(to);
		else revcon[cu].first = revcon[to].first;
		return dis[cu] = 0, cu;
	}
	inloid subtaskoth() {
	for(int i = 1; i <= n; i++) revcon[i] = pii(i, 1), col[i] = tg[i] = dis[i] = vis[i] = 0;
	col[n + 3] = -1;
	for(int i = 1; i <= m; i++) {
		if(op[i][0] == 'T' || op[i][0] == 'F' || op[i][0] == 'U') {
			int a = opp[i][0];
			if(op[i][0] == 'T') revcon[a] = pii(n + 1, 1);
			else if(op[i][0] == 'F') revcon[a] = pii(n + 2, 1);
			else revcon[a] = pii(n + 3, 1), col[a] = -1;
		} else {
			int a = opp[i][0], b = opp[i][1];
			if(op[i][0] == '+') {
				revcon[a] = pii(revcon[b].first, revcon[b].second * 1);
			} else {
				revcon[a] = pii(revcon[b].first, revcon[b].second * -1);
			}
		}
	}
	for(int i = 1; i <= n; i++) if(!vis[i]) dis[i] = 1, dfs(i);
	for(int i = 1; i <= n; i++) {
		if((revcon[i].first == i && revcon[i].second == -1) || revcon[i].first == n + 3) col[i] = -1; 
	}
	int ans = 0;
	while(true) {
		int flag = 0;
		for(int i = 1; i <= n; i++) {
			if((col[revcon[i].first] == -1 || col[i] == -1) && !tg[i]) ans++, col[i] = -1, tg[i] = 1, flag = 1;
		}	
		if(!flag) break;
	}
	cout << ans << "\n";
	}
signed main() {
	freopen("tribool.in", "r", stdin), freopen("tribool.out", "w", stdout);
	int cc = read(), tt = read();
	while(tt--){
		n = read(), m = read();
		for(int i = 1; i <= m; i++) {
			scanf("%s", op[i]);
			if(op[i][0] == '+' || op[i][0] == '-') opp[i][0] = read(), opp[i][1] = read();
			else opp[i][0] = read();
		}
	if(cc <= 2) subtaskoth();
	else if(cc <= 4) subtask34();
	else subtaskoth();
}
	return fclose(stdin), fclose(stdout), 0;
}
}

/*
Bless and Punishment. Fortune and Misery.
I'm played as a marionette, while they still bless me.
*/

signed main(void) {
	_Alice_Margatroid::main();
}

