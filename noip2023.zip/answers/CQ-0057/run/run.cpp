#include<bits/stdc++.h>
#define inlint inline int
#define inloid inline void
#define inbool inline bool
#define MAXN 1005
#define int long long
using namespace std;

namespace _MAIN {
	inlint read() {
		int nega = 1, num = 0, c = getchar();
		for(; ~c &&!isdigit(c); c = getchar()) if(c == '-') nega = -1;
		for(; ~c && isdigit(c); c = getchar()) (num *= 10) += c - '0';
		return nega * num;
	}
	int n, m, cc, tt, k, d;
} using namespace _MAIN;

namespace _SOLV {
	
} using namespace _SOLV;

namespace _Alice_Margatroid {
	int x[MAXN], y[MAXN], v[MAXN];
	int f[MAXN][2];
	vector<int> clg[MAXN];
	inbool cmp(int a, int b) {
		return y[a] < y[b];
	}
	inlint ask(int a, int b) {
		int res = 0;
		for(int i = 1; a + i - 1 <= b; i++) {
			res -= d;
			for(int cl : clg[a + i - 1]) {
				if(y[cl] <= i) res += v[cl];
				else break; 
			}
		}
		return max(res, 0ll);
	}
signed main() {
	freopen("run.in", "r", stdin), freopen("run.out", "w", stdout);
	cc = read(), tt = read();
while(tt--) {
	memset(f, 0, sizeof(f));
	n = read(), m = read(), k = read(), d = read();
	for(int i = 1; i <= n; i++) clg[i].clear();
	for(int i = 1; i <= m; i++) {
		x[i] = read(), y[i] = read(), v[i] = read();
		clg[x[i]].push_back(i);
	}
	for(int i = 1; i <= n; i++) sort(clg[i].begin(), clg[i].end(), cmp);
	for(int i = 1; i <= n; i++) {
		for(int j = i; j >= i - k + 1 && j - 1 >= 0; j--) {
			f[i][1] = max(f[i][1], f[j - 1][0] + ask(j, i));
			f[i][0] = max(f[i - 1][0], f[i - 1][1]);
		}
	}
	cout << max(f[n][1], f[n][0]) << "\n";
}
	return fclose(stdin), fclose(stdout), 0;
}
}

/*
Bless and Punishment. Fortune and Misery.
I'm played as a marionette, while they still bless me.
*/

signed main(void) {
	_Alice_Margatroid::main();
}

