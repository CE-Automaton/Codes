#include<bits/stdc++.h>
#define inlint inline int
#define inloid inline void
#define inbool inline bool
#define MAXN 100005
using namespace std;

namespace _MAIN {
	inlint read() {
		int nega = 1, num = 0, c = getchar();
		for(; ~c &&!isdigit(c); c = getchar()) if(c == '-') nega = -1;
		for(; ~c && isdigit(c); c = getchar()) (num *= 10) += c - '0';
		return nega * num;
	}
	int n;
} using namespace _MAIN;

namespace _SOLV {

} using namespace _SOLV;

namespace _Alice_Margatroid {
signed main() {
	freopen("expand.in", "r", stdin), freopen("expand.out", "w", stdout);
	n = read(), n = read(), n = read(), n = read();
	for(int i = 1; i <= n; i++) cout << 0;
	return fclose(stdin), fclose(stdout), 0;
}
}

/*
Bless and Punishment. Fortune and Misery.
I'm played as a marionette, while they still bless me.
*/

signed main(void) {
	_Alice_Margatroid::main();
}

