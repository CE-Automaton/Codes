#include <bits/stdc++.h>
	
using namespace std;
const int N = 3005;
int c, n, m, q;
int a[N], b[N], ta[N], tb[N];
int ans[N], f[N][N];
void yzhcopy() {
	for (int i = 1; i <= n; i++) {
		a[i] = ta[i];
	}
	for (int i = 1; i <= m; i++) {
		b[i] = tb[i];
	}
}
int sol() {
	if (a[1] == b[1]) return 0;
	if (a[1] < b[1]) swap(a, b);
	f[0][0] = 1;
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= m; j++) {
			f[i][j] = 0;
			if (a[i] > b[j]) {
				f[i][j] = 
		 f[i - 1][j] | f[i][j - 1] | f[i - 1][j - 1];
			}
		}
	}
	return f[n][m];
}
int main() {
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);
	scanf("%d%d%d%d", &c, &n, &m, &q);
	for (int i = 1; i <= n; i++) {
		scanf("%d", &a[i]), ta[i] = a[i];
	}
	for (int i = 1; i <= m; i++) {
		scanf("%d", &b[i]), tb[i] = b[i];
	}
	yzhcopy();
	ans[0] = sol();
	for (int i = 1; i <= q; i++) {
		yzhcopy();
		int kx, ky, px, py, vx, vy;
		scanf("%d%d", &kx, &ky);
//		if (i == 3) {
//			printf("%d %d\n", kx, ky);
//		}
		for (int j = 1; j <= kx; j++) {
			scanf("%d%d", &px, &vx);
//			if (i == 3) {
//				printf("%d %d\n", px, vx);
//			}
			a[px] = vx;
		}
		for (int j = 1; j <= ky; j++) {
			scanf("%d%d", &py, &vy);
//			if (i == 3) {
//				printf("%d %d\n", py, vy);
//			}
			b[py] = vy;
		}
		ans[i] = sol();
	}
	for (int i = 0; i <= q; i++) {
		printf("%d", ans[i]);
	}
	return 0;
}
