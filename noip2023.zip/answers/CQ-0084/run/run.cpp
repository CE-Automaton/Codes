#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const int N = 3e3 + 5;
int c, t;
int cnt;


int n, m, k, d;

int l[N], r[N], v[N], b[N];
ll tr[N][N], f[N];
void add(int l, int r, int v) {
	l = cnt - l + 1;
	for (int i = l; i <= cnt; i += i & -i) {
		for (int j = r; j <= cnt; j += j & -j) {
			tr[i][j] += v;
		}
	}
}
ll ask(int l, int r) {
	ll res = 0;
	l = cnt - l + 1;
	for (int i = l; i; i -= i & -i) {
		for (int j = r; j; j -= j & -j) {
			res += tr[i][j];
		}
	}
	return res;
}
void sol() {
	scanf("%d%d%d%d", &n, &m, &k, &d);
	cnt = 0;
	for (int i = 1; i <= m; i++) {
		
		scanf("%d%d%d", &r[i], &l[i], &v[i]);
		l[i] = r[i] - l[i] + 1;
		b[++cnt] = l[i];
		b[++cnt] = r[i];
	}
	sort(b + 1, b + 1 + cnt);
	cnt = unique(b + 1, b + 1 + cnt) - b - 1;
	for (int i = 1; i <= m; i++) {
		l[i] = lower_bound(b + 1, b + 1 + cnt, l[i]) - b;
		r[i] = lower_bound(b + 1, b + 1 + cnt, r[i]) - b;
		add(l[i], r[i], v[i]);
	}
	b[cnt + 1] = 1e9 + 5;
	for (int i = 0; i <= cnt + 1; i++) {
		f[i] = 0;
	}
	for (int i = 1; i <= cnt; i++) {
		ll now = 0;
		for (int j = i; j; j--) {
			if (b[i] - b[j] + 1 > k) break;
			ll val = ask(j, i);
			val -= (b[i] - b[j] + 1ll) * d;
			now = max(now, f[j] + val);
		}
		now = max(now, f[i]);
		for (int j = cnt + 1; j; j--) {
			if (b[j] <= b[i] + 1) break;
			f[j] = max(f[j], now);
		}
	}
	for (int i = 1; i <= m; i++) {
		add(l[i], r[i], -v[i]);
	}
	printf("%lld\n", f[cnt + 1]);
}
int main() {
	freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);
	scanf("%d%d", &c, &t);
	while (t--) sol();
	return 0;
}
