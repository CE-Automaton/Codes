#include <bits/stdc++.h>

using namespace std;
const int T = 200001, F = T + 1, U = F + 1;
const int N = 2e5 + 5;

int _Test_Id, _Test_Num;
int n, m;
int a[N], fa[N], v[N];
int zfys[500]; /*�ַ�ӳ��*/

inline int rev(int x) {
	if (x == T) return F;
	if (x == F) return T;
	if (x == U) return U;
	return x <= n? x + n: x - n;
}
int get(int x) {
	return x == fa[x]? x: (fa[x] = get(fa[x]));
}
void merge(int x, int y) {
	int r1 = get(x), r2 = get(y);
	if (1 <= r1 && r1 <= n << 1
	 && 1 <= r2 && r2 <= n << 1) {
		if (r1 != r2) 
			fa[r1] = r2;
	}
	// �᲻��̫���� 
}

void sol() {
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; i++) {
		a[i] = i;
		fa[i] = i, v[i] = 0;
		fa[i + n] = i + n, v[i + n] = 0;
	}
	for (int cs = 1; cs <= m; cs++) {
		char tv[5];
		int i, j;
		scanf("%s", tv);
		if (tv[0] == 'T' || tv[0] == 'F'
		 || tv[0] == 'U') {
			scanf("%d", &i);
			a[i] = zfys[(int)(tv[0])];
		} else if (tv[0] == '+') {
			scanf("%d%d", &i, &j);
			a[i] = a[j];
		} else { // if (tv[0] == '-')
			scanf("%d%d", &i, &j);
			a[i] = rev(a[j]);
		}
	}
	for (int i = 1; i <= n; i++) {
		if (a[i] == T || a[i] == F || a[i] == U) {
			int ii = get(i), _i = get(i + n);
			if (v[ii] != 0 && v[ii] != a[i]) {
				v[ii] = v[_i] = U;
			} else v[ii] = a[i], v[_i] = rev(a[i]);
		}
		 else 
		 {
			int j1 = a[i]
			, j2 = rev(j1);
			merge(i, j1);
			merge(i + n, j2);
			int ii = get(i), _i = get(i + n);
			if (ii == _i) v[ii] = U;
		}
	}
	int ans = 0;
	for (int i = 1; i <= n; i++) {
		if (get(i) == get(i + n)) v[get(i)] = U;
		ans += v[get(i)] == U;
	}
	printf("%d\n", ans);
}

int main() {
	freopen("tribool.in", "r", stdin);
	freopen("tribool.out", "w", stdout);
	scanf("%d%d", &_Test_Id, &_Test_Num);
	
	zfys['T'] = T;
	zfys['F'] = F;
	zfys['U'] = U;
	while (_Test_Num--) {
		sol();
	}
	
	return 0;
}
