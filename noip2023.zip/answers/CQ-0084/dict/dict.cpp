#include <bits/stdc++.h>

using namespace std;
const int N = 3005, N2 = 6005;
int n, m;
char s[N][N], t[N], mn[N];
// s1 > s2 : 1
// s1 = s2: 0
// s1 < s2: -1
int check(char *s1, char *s2) {
	for (int i = 1; i <= m; i++) {
		if (s1[i] < s2[i]) return -1;
		if (s1[i] > s2[i]) return 1;
	}
	return 0;
}
void to(char *s1, char *s2) {
	for (int i = 1; i <= m; i++) s1[i] = s2[i];
}
int main() {
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= m; i++) {
		mn[i] = 'z' + 1;
	}
	for (int i = 1; i <= n; i++) {
		scanf("%s", s[i] + 1);
		to(t, s[i]);
		sort(t + 1, t + 1 + m, greater<char>());
		if (check(t, mn) < 0) to(mn, t);
	}
	for (int i = 1; i <= n; i++) {
		sort(s[i] + 1, s[i] + 1 + m);
		if (check(s[i], mn) <= 0) {
			printf("1");
		} else {
			printf("0");
		}
	}
	return 0;
}
