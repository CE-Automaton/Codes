#include<bits/stdc++.h>
#define ll long long
#define pii pair<int,ll>
#define fir first
#define sec second
#define ls (p<<1)
#define rs (p<<1|1)
#define mid (l+r>>1)
using namespace std;
int N,M,Sub,K,D,L[100005],R[100005];
int Bpos[100005],Epos[100005],tot1,tot2;
ll W[100005],pmx[100005];
const ll inf=1e18;
vector<pii>qr[100005];
ll mx[400005],tag[400005];
bool Era[400005];
void build(int p,int l,int r){
	mx[p]=-inf;tag[p]=Era[p]=0;if(l==r)return;
	build(ls,l,mid);build(rs,mid+1,r);
}
void pushup(int p){mx[p]=max(mx[ls],mx[rs]);}
void Del(int p){
	mx[p]=-inf;
	tag[p]=0;
	Era[p]=1;
}
void pd(int p){
	if(Era[p]){
		Del(ls),Del(rs);
		Era[p]=0;
	}
	if(tag[p]!=0){
		tag[ls]+=tag[p],tag[rs]+=tag[p];
		mx[ls]+=tag[p],mx[rs]+=tag[p];
		tag[p]=0;
	}
}
void cv(int p,int l,int r,int a,int b){
	if(a<=l&&r<=b){Del(p);return;}pd(p);
	if(a<=mid)cv(ls,l,mid,a,b);if(b>mid)cv(rs,mid+1,r,a,b);
	pushup(p);
}
void cg(int p,int l,int r,int pos,ll v){
	if(l==r){mx[p]=v;tag[p]=0;Era[p]=0;return;}
	pd(p);if(pos<=mid)cg(ls,l,mid,pos,v);else cg(rs,mid+1,r,pos,v);
	pushup(p);
}
void add(int p,int l,int r,int a,int b,ll v){
	if(a<=l&&r<=b){mx[p]+=v,tag[p]+=v;return;}
	pd(p);if(a<=mid)add(ls,l,mid,a,b,v);if(b>mid)add(rs,mid+1,r,a,b,v);
	pushup(p);
}
void solve(){
    tot1=tot2=0;
    scanf("%d%d%d%d",&N,&M,&K,&D);
    for(int i=1;i<=M;++i){
    	scanf("%d%d%lld",&R[i],&L[i],&W[i]);
    	L[i]=R[i]-L[i]+1;
    	Bpos[++tot1]=L[i];Epos[++tot2]=R[i];
    }
	sort(Bpos+1,Bpos+tot1+1);
    tot1=unique(Bpos+1,Bpos+tot1+1)-Bpos-1;
    sort(Epos+1,Epos+tot2+1);
    tot2=unique(Epos+1,Epos+tot2+1)-Epos-1;
    int now=1;
    for(int i=1;i<=tot2;++i)qr[i].clear();
    for(int i=1;i<=M;++i){
    	int posr=lower_bound(Epos+1,Epos+tot2+1,R[i])-Epos;
    	int posl=lower_bound(Bpos+1,Bpos+tot1+1,L[i])-Bpos;
    	qr[posr].push_back(make_pair(posl,W[i]));
	}
	ll res=0;pmx[0]=0;build(1,1,tot1);int hd=1;
    for(int i=1;i<=tot2;++i){
		if(now>1)add(1,1,tot1,1,now-1,-1ll*(Epos[i]-Epos[i-1])*D);
		while(now<=tot1&&Bpos[now]>Epos[i-1]&&Bpos[now]<=Epos[i])
    	{
    		ll Add=0,valnow;
    		if(i>1&&Bpos[now]==Epos[i-1]+1)Add=pmx[i-2];else Add=pmx[i-1];
    		valnow=-1ll*(Epos[i]-Bpos[now]+1)*D+Add;
			cg(1,1,tot1,now,valnow);
    		++now;
		}
		while(hd<=tot1&&Epos[i]-Bpos[hd]+1>K)++hd;
		if(hd>1)cv(1,1,tot1,1,hd-1);
		for(auto v:qr[i])add(1,1,tot1,1,v.fir,v.sec);
		res=max(res,mx[1]);pmx[i]=res;
	}
	res=max(res,mx[1]);cout<<res<<endl;
}
int main() {
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	int t;cin>>Sub>>t;
	while(t--)solve();
	return 0;
}
