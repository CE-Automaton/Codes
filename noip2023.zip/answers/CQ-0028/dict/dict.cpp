#include<bits/stdc++.h>
using namespace std;
int N,M;
string mn,smn,Snow;
char str1[3005],str2[3005];
char t[3005][3005];
bool cmp(string a,string b){
	for(int i=0;i<=M;++i)
	  if(a[i]<b[i])return 1;
	  else if(a[i]>b[i])return 0;
	return 1;
}
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	scanf("%d%d",&N,&M);
	for(int i=0;i<=M;++i)mn=mn+(char)('x'),smn=smn+(char)('x');
	for(int i=1;i<=N;++i){
		scanf("%s",str1+1);sort(str1+1,str1+M+1);Snow="0";
		for(int j=1;j<=M;++j)Snow=Snow+str1[M-j+1],t[i][j]=str1[j];
	    if(cmp(Snow,mn))smn=mn,mn=Snow;else if(cmp(Snow,smn))smn=Snow;
	}
	if(N==1){putchar('1');puts("");return 0;}
	for(int i=1;i<=N;++i){
		bool flag=1,fl;
		for(int j=1;j<=M;++j)flag&=(t[i][j]==mn[M-j+1]);
		if(!flag){
			fl=0;
			for(int j=1;j<=M;++j){
				if(mn[j]<t[i][j]){fl=0;break;}
				else if(mn[j]>t[i][j]){fl=1;break;}
			}
		}else{
			fl=0;
			for(int j=1;j<=M;++j){
				if(smn[j]<t[i][j]){fl=0;break;}
				else if(smn[j]>t[i][j]){fl=1;break;}
			}
		}
		if(fl)putchar('1');else putchar('0');
	} puts("");
	return 0;
}
