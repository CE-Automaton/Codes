#include<bits/stdc++.h>
#define pii pair<int,int>
#define fir first
#define sec second
using namespace std;
int N,M,Sub,opt[100005],From[100005],fa[100005];
void init(){for(int i=1;i<=N;++i)fa[i]=i;}
int find(int r){return r==fa[r]?r:(fa[r]=find(fa[r]));}
bool mark[100005];int dis[100005];
vector<pii>road[100005];
vector<int>vec[100005];
void dfs(int u){
	for(pii v:road[u]){
		if(mark[v.fir])continue;
		mark[v.fir]=1;dis[v.fir]=(dis[u]^v.sec);
		dfs(v.fir);
	}
}
void solve(){
	scanf("%d%d",&N,&M);init();
    for(int i=1;i<=N;++i)opt[i]=0,From[i]=i,mark[i]=0,dis[i]=0,vec[i].clear(),road[i].clear();
    for(int i=1;i<=M;++i){
    	char ch=getchar();
    	while(ch!='T'&&ch!='+'&&ch!='-'&&ch!='F'&&ch!='U')ch=getchar();
    	if(ch!='+'&&ch!='-'){
    		int Now;scanf("%d",&Now);
    		if(ch=='T')From[Now]=-1;
    		else if(ch=='F')From[Now]=-2;
    		else From[Now]=0;
		}else{
			int Now1,Now2;scanf("%d%d",&Now1,&Now2);
			if(ch=='+')From[Now1]=From[Now2],opt[Now1]=opt[Now2];
			else {
				if(From[Now2]<=0){
					if(From[Now2]==0)From[Now1]=0;
					else From[Now1]=-3-From[Now2];
				}else From[Now1]=From[Now2],opt[Now1]=(opt[Now2]^1);
			}
		}
	}
	for(int i=1;i<=N;++i){
		if(From[i]<=0)continue;
		fa[find(From[i])]=find(i);
		road[i].push_back(make_pair(From[i],opt[i]));
		road[From[i]].push_back(make_pair(i,opt[i]));
	}
	for(int i=1;i<=N;++i)vec[find(i)].push_back(i);
	int res=0;
	for(int i=1;i<=N;++i)
	  if(find(i)==i){
	  	bool flag=0;
	  	for(int v:vec[i])if(From[v]<=0)flag=1;
	  	if(flag){
	  	 	for(int v:vec[i])if(From[v]==0)flag=0;
	  	 	if(!flag)res+=(int)vec[i].size();
		}else{
			dis[i]=0;dfs(i);flag=1;
			for(int v:vec[i])
			  if((dis[v]^dis[From[v]])!=opt[v])flag=0;
			if(!flag)res+=(int)vec[i].size();
		}
	  }
	printf("%d\n",res);
}
int main() {
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	int t;
	cin>>Sub>>t;
	while(t--)solve();
	return 0;
}
