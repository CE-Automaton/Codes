#include<bits/stdc++.h>
using namespace std;
int Sub,N,M,Q,A[500005],B[500005];
namespace br{
	bool f[2005][2005];
    int Va[2005],Vb[2005];
    bool chk(){
    	for(int i=1;i<=N;++i)for(int j=1;j<=M;++j)f[i][j]=0;
		f[1][1]=1;if(Va[1]==Vb[1])return 0;
        if(Va[1]>Vb[1]){
        	if(Va[N]<=Vb[M])return 0;
			for(int i=1;i<=N;++i)
        	  for(int j=1;j<=M;++j){
        	  	if(!f[i][j])continue;
        	  	if(i<N&&Va[i+1]>Vb[j])f[i+1][j]=1;
        	  	if(j<M&&Va[i]>Vb[j+1])f[i][j+1]=1;
			  }
			return f[N][M];
		}else {
			if(Va[N]>=Vb[M])return 0;
		    for(int i=1;i<=N;++i)
        	  for(int j=1;j<=M;++j){
        	  	if(!f[i][j])continue;
        	  	if(i<N&&Va[i+1]<Vb[j])f[i+1][j]=1;
        	  	if(j<M&&Va[i]<Vb[j+1])f[i][j+1]=1;
			  }
			return f[N][M];
		}
	}
    void solve(){
    	for(int i=1;i<=N;++i)Va[i]=A[i];
    	for(int i=1;i<=M;++i)Vb[i]=B[i];
    	if(chk())putchar('1');else putchar('0');
    	while(Q--){
		    for(int i=1;i<=N;++i)Va[i]=A[i];
    	    for(int i=1;i<=M;++i)Vb[i]=B[i];
    	    int cntx,cnty;scanf("%d%d",&cntx,&cnty);
    	    while(cntx--){
    	    	int Pos,Val;
    	    	scanf("%d%d",&Pos,&Val);
    	    	Va[Pos]=Val;
			}
			while(cnty--){
				int Pos,Val;
				scanf("%d%d",&Pos,&Val);
				Vb[Pos]=Val;
			}
			if(chk())putchar('1');else putchar('0');
		} puts("");
	}
}
int Va[500005],Vb[500005];
bool chk1(){
    int x=1,y=1;
    if(Va[1]>Vb[1]){
    	while(x<N||y<M){
    		if(x<N&&Va[x+1]>Vb[y]){
    			++x;
			}else if(x<N&&y<M&&Va[x+1]>Vb[y+1]){
				++x,++y;
			} 
			else if(y<M&&Va[x]>Vb[y+1]){
					++y;
			}else return 0;
		} return 1;
	}else{
		while(x<N||y<M){
    		if(x<N&&Va[x+1]<Vb[y]){
    			++x;
			}else if(x<N&&y<M&&Va[x+1]<Vb[y+1]){
				++x,++y;
			} 
			else if(y<M&&Va[x]<Vb[y+1]){
				++y;
			}else return 0;
		} return 1;
	}
}
bool chk2(){
	int x=1,y=1;
    if(Va[1]>Vb[1]){
    	while(x<N||y<M){
    	    if(y<M&&Va[x]>Vb[y+1]){
				++y;
			}else if(x<N&&y<M&&Va[x+1]>Vb[y+1]){
				++x,++y;
			}else if(x<N&&Va[x+1]>Vb[y]){
    			++x;
			}
			else return 0;
		} return 1;
	}else{
		while(x<N||y<M){
    		if(y<M&&Va[x]<Vb[y+1]){
				++y;
			}else if(x<N&&y<M&&Va[x+1]<Vb[y+1]){
				++x,++y;
			}else if(x<N&&Va[x+1]<Vb[y]){
    			++x;
			}else return 0;
		} return 1;
	}
}
bool chk(){
	if(Va[1]==Vb[1])return 0;
	return (chk1()||chk2());
}
int main() {
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
    cin>>Sub>>N>>M>>Q;
    for(int i=1;i<=N;++i)scanf("%d",&A[i]);
    for(int i=1;i<=M;++i)scanf("%d",&B[i]);
    if(N<=2000&&M<=2000){br::solve();return 0;}
    for(int i=1;i<=N;++i)Va[i]=A[i];
    for(int i=1;i<=M;++i)Vb[i]=B[i];
    if(chk())putchar('1');else putchar('0');
    while(Q--){
		for(int i=1;i<=N;++i)Va[i]=A[i];
    	for(int i=1;i<=M;++i)Vb[i]=B[i];
    	int cntx,cnty;scanf("%d%d",&cntx,&cnty);
    	while(cntx--){
    	    int Pos,Val;
    	    scanf("%d%d",&Pos,&Val);
    	    Va[Pos]=Val;
		}
		while(cnty--){
			int Pos,Val;
			scanf("%d%d",&Pos,&Val);
			Vb[Pos]=Val;
		}
		if(chk())putchar('1');else putchar('0');
	} puts("");
	return 0;
}
