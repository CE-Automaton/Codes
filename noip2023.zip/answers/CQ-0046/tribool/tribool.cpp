/*
�׿����ֵȷ����x,ʣ�µľͻ��γ�dsu,dsu����xi->(0)xi'���γɼ�����ͨ��,һ����ֻҪ������ͻ���һ��U,Ȼ���ȫ��ΪU��.
*/
#include<bits/stdc++.h>
using namespace std;
int n,m,id[100010],fa[200010],val[200010],valid[1010],tot;
int fr(int u){
   if(fa[u]<=0)return u;
   int rt=fr(fa[u]);
   val[u]^=val[fa[u]];
   return fa[u]=rt;
}
void mg(int x,int y,int w){
   int rx=fr(x),ry=fr(y);w^=val[x]^val[y];
   if(rx==ry)fa[rx]|=w?-1:0;
   else fa[ry]|=fa[rx],fa[rx]=ry,val[rx]=w;
}
//namespace bfUplus{
//   int fr(int u){return fa[u]==u?u:fa[u]=fr(fa[u]);}
//   struct opt_t{
//      char c;int i,j;
//   };
//   void solve(){
//      cin>>n>>m;
//      for(int i=0;i<=n+m;i++)fa[i]=i;
//      for(int i=1;i<=n;i++)id[i]=i;tot=n;
//      char c;
//      vector<opt_t>qwq;
//      for(int i,j;m--;){
//         scanf(" %c%d",&c,&i);id[i]=++tot;
//         if(c=='U')fa[fr(id[i])]=0,qwq.push_back({c,i,0});
//         else scanf("%d",&j),fa[fr(id[i])]=fr(id[j]),qwq.push_back({c,i,j});
//      }int ans=0;
//      for(int i=1;i<=n;i++)fa[fr(i)]=fr(id[i]);
//      for(int i=1;i<=n;i++)ans+=!fr(i),val[i]=!fr(i);
//      vector<int>sval(val,val+n+1);
//      for(auto x:qwq)
//      if(x.c=='U')sval[x.i]=1;
//      else sval[x.i]=sval[x.j];
//      int f=0;
//      for(int i=1;i<=n;i++)
//      if(val[i]!=sval[i])printf("QWQ%d!=%d\n",val[i],sval[i]),f=1;
//      for(auto x:qwq)
//      if(val[x.i]!=sval[x.i])printf("AAA?%c %d %d\n",x.c,x.i,x.j);
//      for(int i=1;i<=n;i++)cerr<<fr(i)<<' ';cerr<<endl;
//      if(f)exit(-1);
//      cout<<ans<<endl;
//   }
//}
void solve(){
   cin>>n>>m;
   for(int i=1;i<=n+m+3;i++)fa[i]=0,val[i]=0;
   for(int i=1;i<=n;i++)id[i]=i;tot=n;
   valid['T']=n+m+1,valid['F']=n+m+2,valid['U']=n+m+3;fa[n+m+3]=-1;
   char c;
   for(int i,j;m--;){
      scanf(" %c%d",&c,&i);
      
      if(!valid[c]){
         scanf("%d",&j);int x=id[j];//i==j����bug(����һ��ſ�����qwq)
         mg(id[i]=++tot,x,c=='+'?0:1);
      }else mg(id[i]=++tot,valid[c],0);
   }
   for(int i=1;i<=n;i++)mg(id[i],i,0);
   int ans=0;
   for(int i=1;i<=n;i++)ans+=fa[fr(i)]==-1;
   cout<<ans<<endl;
}
int main(){
   freopen("tribool.in","r",stdin);
   freopen("tribool.out","w",stdout);
   int T;for(scanf("%*d%d",&T);T--;)solve();
   return 0;
}
