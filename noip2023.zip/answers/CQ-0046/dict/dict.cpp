#include<bits/stdc++.h>
using namespace std;
int n,m;
char str[3010][3010],mi[3010],mx[3010];
int main(){
   freopen("dict.in","r",stdin);
   freopen("dict.out","w",stdout);
   cin>>n>>m;
   for(int i=1;i<=n;i++){
      scanf("%s",str[i]+1);
      mi[i]='z',mx[i]='a';
      for(int j=1;j<=m;j++)
      mi[i]=min(mi[i],str[i][j]),mx[i]=max(mx[i],str[i][j]);
   }for(int i=1;i<=n;i++){
      char ans='1';
      for(int j=1;j<=n;j++)
      if(i!=j&&mx[j]<=mi[i])ans='0';
      putchar(ans);
   }
   return 0;
}
