#include <bits/stdc++.h>
#define fi first 
#define se second 

using std :: cin; 
using std :: max; 
using std :: min; 
using std :: cout; 
using std :: vector; 

constexpr int M = 2e5 + 5; 
constexpr long long INF = 1e18; 

typedef long long ll; 
typedef unsigned long long ull; 
typedef double db; 
typedef std :: pair < int, ll > pii; 

inline int read() {
	int f = 1, s = 0; char ch = getchar(); 
	while(!isdigit(ch)) (ch == '-') && (f = -1), ch = getchar(); 
	while(isdigit(ch)) s = s * 10 + ch - '0', ch = getchar(); 
	return f * s; 
}

namespace Solver {
	char _st; 
	int typ, T, n, m, K, D; 
	vector < pii > P[M];
	int rt, tot;
	struct treap {
		int l, r, rnd, sz; ll v, tg, mx;  
	} t[M << 2];
	inline int new_node(ll v) {
		++tot; t[tot].l = t[tot].r = 0, t[tot].rnd = rand(), t[tot].sz = 1, t[tot].v = t[tot].mx = v, t[tot].tg = 0; 
		return tot; 
	}
	inline void ptg(int p, ll d) {if(!p) return ; t[p].tg += d, t[p].v += d, t[p].mx += d;}
	inline void pusd(int p) {if(t[p].tg) ptg(t[p].l, t[p].tg), ptg(t[p].r, t[p].tg), t[p].tg = 0;}
	inline void pus(int p) {t[p].sz = 1 + t[t[p].l].sz + t[t[p].r].sz, t[p].mx = max(t[p].v, max(t[t[p].l].mx, t[t[p].r].mx));}
	inline void split(int now, int &x, int &y, int k) {
		if(!now) return x = y = 0, void(); pusd(now);
		if(t[t[now].l].sz + 1 <= k) x = now, split(t[x].r, t[x].r, y, k - t[t[x].l].sz - 1); 
		else y = now, split(t[y].l, x, t[y].l, k); pus(now); 
	}
	inline int merge(int x, int y) {
		if(!x || !y) return x | y; pusd(x), pusd(y);
		if(t[x].rnd < t[y].rnd) return t[x].r = merge(t[x].r, y), pus(x), x; 
		return t[y].l = merge(x, t[y].l), pus(y), y; 
	}
	int x, y, z; 
	inline void del() {split(rt, x, y, K + 1), rt = x; }
	inline void push(int k, ll v) {
		split(rt, x, z, k), ptg(z, v), rt = merge(x, z); 
	}
	inline void sb1() {
		for(int i = 1; i <= n; ++i) P[i].clear(); tot = 0; 
		for(int i = 1, x, y, z; i <= m; ++i) x = read(), y = read(), z = read(), P[x].push_back(pii(y, z));
		rt = new_node(0);
		for(int i = 1; i <= n; ++i) {
			ll v = t[rt].mx; ptg(rt, -D), rt = merge(new_node(v), rt);
			if(t[rt].sz > K + 1) del(); 
			for(auto &it : P[i]) push(it.fi, it.se); 
		}
		cout << t[rt].mx << '\n'; 
	}
	struct que {
		int x, y, z;
		que(int x = 0, int y = 0, int z = 0) : x(x), y(y), z(z) {}
	} qu[M]; 
	int tmp[M], pq, ln[M]; 
	inline int get(int x) {return std :: lower_bound(tmp + 1, tmp + pq + 1, x) - tmp;}
	char _ed; 
	inline void solve() {
		n = read(), m = read(), K = read(), D = read();
		if(typ <= 14) return sb1(), void(); 
		pq = tot = 0; tmp[++pq] = 0; 
		for(int i = 1, x, y, z; i <= m; ++i) x = read(), y = read(), z = read(), qu[i] = que(x, y, z), tmp[++pq] = x, tmp[++pq] = x - y; 
		std :: sort(tmp + 1, tmp + pq + 1), pq = std :: unique(tmp + 1, tmp + pq + 1) - tmp - 1; 
		for(int i = 1; i <= pq; ++i) ln[i] = tmp[i] - tmp[i - 1]; 
		for(int i = 1; i <= m; ++i) P[get(qu[i].x)].emplace_back(qu[i].x - qu[i].y, qu[i].z); 
		rt = new_node(0); 
		for(int i = 2, j = 2; i <= pq; ++i) {
			ll v = t[rt].mx; ptg(rt, (ll)-ln[i] * D), rt = merge(new_node(v), rt);  
			while(j <= pq && tmp[i] - tmp[j - 1] > K) ++j; 
			int cur = i - j + 1; 
			if(t[rt].sz > cur + 1) split(rt, x, y, cur + 1), rt = x; 
			for(auto &it : P[i]) {
				int p = std :: upper_bound(tmp + 1, tmp + pq + 1, it.fi) - tmp - 1; 
				push(i - p, it.se); 
			}
			P[i].clear() ;
		}
		cout << t[rt].mx << '\n'; 
	}
	inline void mian() {
		srand((unsigned)time(NULL)); 
//		fprintf(stderr, "%d\n", (&_st - &_ed) >> 20);
		typ = read(), T = read(); t[0].mx = -INF; 
		while(T --) solve(); 
	}
} ;

int main()
{
	freopen("run.in", "r", stdin); 
	freopen("run.out", "w", stdout); 
	Solver :: mian(); 
	return 0; 
}
