#include <bits/stdc++.h>
#define fi first 
#define se second 

using std :: cin; 
using std :: min; 
using std :: max; 
using std :: cout; 
using std :: vector; 

constexpr int M = 5e5 + 5; 
constexpr int INF = 0x3f3f3f3f; 

typedef long long ll; 
typedef unsigned long long ull; 
typedef double db; 
typedef std :: pair < int, int > pii;

inline int read() {
	int f = 1, s = 0; char ch = getchar(); 
	while(!isdigit(ch)) (ch == '-') && (f = -1), ch = getchar(); 
	while(isdigit(ch)) s = s * 10 + ch - '0', ch = getchar(); 
	return f * s; 
}

namespace Solver {
	char _st; 
	int typ, n, m, q, lim; 
	int a[M], b[M], A[M], B[M], as[M], sgn; 
    int dp[2][3005], nx[M], tf[3005]; 
    inline bool cal() {
    	int p = 0, q = 1; memset(dp, 0, sizeof(dp));
    	if(A[1] <= B[1]) return 0; int z = 1; while(z <= m && A[1] > B[z]) ++z; for(int i = 1; i < z; ++i) dp[p][i] = 1; 
    	for(int i = 2; i <= n; ++i, std :: swap(p, q), memset(dp[q], 0, sizeof(dp[q]))) {
    		nx[m + 1] = 0; for(int j = m; j; --j) nx[j] = A[i] > B[j] ? max(j, nx[j + 1]) : 0, tf[j] = 0; 
    		for(int j = m; j; --j) if(dp[p][j]) {
    			if(nx[j] >= j) tf[j] ++, tf[nx[j] + 1] --;
    			if(nx[j + 1] >= j + 1) tf[j + 1] ++, tf[nx[j + 1] + 1] --; 
			}
			for(int j = 1; j <= m; ++j) tf[j] += tf[j - 1], dp[q][j] = !!tf[j]; 
		}
		return dp[p][m]; 
	}
    inline void sb1() {
    	as[sgn] = cal(); 
        if(as[sgn]) return ; 
        std :: swap(n, m); 
        for(int i = 1; i <= lim; ++i) std :: swap(A[i], B[i]);
        as[sgn] = cal(); 
        std :: swap(n, m); 
	} 
	int st[M][20][2], lg[M];
	inline int Q(int l, int r, int o) {
		int k = lg[r - l + 1]; 
		return o ? max(st[l][k][o], st[r - (1 << k) + 1][k][o]) : min(st[l][k][o], st[r - (1 << k) + 1][k][o]); 
	}
	inline int Gpos0(int l, int v) {
		if(B[l] >= v) return -1; 
		for(int k = 19; ~k; --k) if(l + (1 << k) - 1 <= m && st[l][k][1] < v) l += (1 << k);  
		return l - 1; 
	}
	inline int Gpos1(int l, int v) {
		if(B[l] < v) return -1; 
		for(int k = 19; ~k; --k) if(l + (1 << k) - 1 <= m && st[l][k][0] >= v) l += (1 << k); 
		return l - 1; 
	}
    int C[M]; 
    inline int g2() {
		if(A[1] <= B[1] || A[n] <= B[m]) return 0;
	    for(int i = 1; i <= m; ++i) st[i][0][0] = st[i][0][1] = B[i]; 
		for(int j = 1; (1 << j) <= m; ++j) for(int i = 1; i + (1 << j) - 1 <= m; ++i) st[i][j][0] = min(st[i][j - 1][0], st[i + (1 << j - 1)][j - 1][0]), st[i][j][1] = max(st[i][j - 1][1], st[i + (1 << j - 1)][j - 1][1]);
		int j = 1; 
		for(int i = 1; i <= n; ++i) {
			int o = 0;
			if(j <= m && B[j] < A[i]) {
			    o = 1;
				for(int l = 19; ~l; --l) if(j + (1 << l) - 1 < m && st[j][l][1] < A[i]) j += (1 << l) - 1;
				while(j <= m && B[j] < A[i]) ++j; 	
			}
			if(!o) {
				--j; if(A[i] > B[j]) {++j; continue ;}
				for(int l = 19; ~l; --l) if(j >= (1 << l) && st[j - (1 << l) + 1][l][0] >= A[i]) j -= (1 << l) - 1;  
				while(j && B[j] >= A[i]) --j;
				if(!j) return 0; ++j; 
			}
		}
		return j == m + 1; 
	}
	inline void sb2() {
		as[sgn] = g2(); if(as[sgn]) return ; std :: swap(n, m); 
		for(int i = 1; i <= lim; ++i) std :: swap(A[i], B[i]);
		as[sgn] = g2(), std :: swap(n, m); 
	}
	inline void calc() {
		++sgn;
		if(typ <= 7) return sb1(), void(); 
		if(typ <= 20) return sb2(), void(); 
 	}
 	char _ed; 
	inline void mian() {
//		fprintf(stderr, "%d\n", (&_st - &_ed) >> 20); 
		typ = read(), n = read(), m = read(), q = read(), lim  = max(n, m); 
		for(int i = 1; i <= n; ++i) a[i] = read(); 
		for(int i = 1; i <= m; ++i) b[i] = read(); 
		lg[0] = -1; for(int i = 1; i <= lim; ++i) lg[i] = lg[i >> 1] + 1; 
		memcpy(A, a, sizeof(a)), memcpy(B, b, sizeof(b));
	    calc(); 
	    while(q --) {
	    	for(int i = 1; i <= n; ++i) A[i] = a[i]; for(int i = 1; i <= m; ++i) B[i] = b[i]; 
	    	int k1 = read(), k2 = read(), x, y; 
			while(k1 --) x = read(), y = read(), A[x] = y;
		    while(k2 --) x = read(), y = read(), B[x] = y; 
		    calc(); 
		}
		for(int i = 1; i <= sgn; ++i) putchar(as[i] + '0'); 
	}
} ;

int main()
{
	freopen("expand.in", "r", stdin); 
	freopen("expand.out", "w", stdout); 
	Solver :: mian(); 
	return 0; 
}
