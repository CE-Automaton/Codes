#include <bits/stdc++.h>
#define fi first 
#define se second 

using std :: cin; 
using std :: min; 
using std :: max; 
using std :: cout; 
using std :: vector; 

constexpr int M = 2e5 + 5; 
constexpr int INF = 0x3f3f3f3f; 

typedef long long ll; 
typedef unsigned long long ull; 
typedef double db; 
typedef std :: pair < int, int > pii; 

inline int read() {
	int f = 1, s = 0; char ch = getchar(); 
	while(!isdigit(ch)) (ch == '-') && (f = -1), ch = getchar(); 
	while(isdigit(ch)) s = s * 10 + ch - '0', ch = getchar(); 
	return f * s; 
}

namespace Solver {
	int typ, T, n, m;
	struct que {
	    int x, y, op; 
	} qu[M]; 
	char str[M];
	int is[M], ans, fs[M], go[3][2]; 
	inline void ck() {
		int ok = 1; 
		for(int i = 1; i <= n; ++i) fs[i] = is[i]; 
		for(int i = 1; i <= m; ++i) {
			if(~qu[i].y) {
				int x = qu[i].x, y = qu[i].y; 
			    fs[x] = go[fs[y]][qu[i].op]; 
			}
			else fs[qu[i].x] = qu[i].op; 
		}
		for(int i = 1; i <= n; ++i) ok &= fs[i] == is[i]; if(!ok) return ;
		int s = 0; for(int i = 1; i <= n; ++i) s += fs[i] == 2;
		ans = min(ans, s); 
	}
	inline void dfs(int x) {
		if(x == n + 1) return ck(), void(); 
		for(int i = 0; i < 3; ++i) is[x] = i, dfs(x + 1); 
	}
	inline void sb1() {
		ans = n, dfs(1); 
		cout << ans << '\n'; 
	}
	int vis[M], f[M << 1];  pii to[M]; 
	inline int find(int x) {return f[x] == x ? x : f[x] = find(f[x]);}
	inline void merge(int x, int y) {x = find(x), y = find(y); f[x] = y;}
	inline void sb4() {
		for(int i = 1; i <= n; ++i) to[i] = pii(i, 1), f[i] = i, f[i + n] = i + n; 
		for(int i = 1; i <= m; ++i) {
			int x = qu[i].x, y = qu[i].y;
		    to[x] = pii(to[y].fi, to[y].se ^ qu[i].op ^ 1); 
		}
		for(int x = 1; x <= n; ++x) {
			int z = to[x].fi, o = to[x].se;
			if(o) merge(x, z), merge(x + n, z + n); 
			else merge(x, z + n), merge(x + n, z); 
		}
		int s = 0; 
		for(int i = 1; i <= n; ++i) if(find(i) == find(i + n)) ++s; 
		cout << s << '\n'; 
	}
	int stk[M], in[M], sgn, dfn[M], low[M], tp, bl[M], cc; 
	vector < int > adj[M]; 
	inline void tarjan(int x) {
		dfn[x] = low[x] = ++sgn, in[stk[++tp] = x] = 1; 
		for(int &y : adj[x]) if(!dfn[y]) tarjan(y), low[x] = min(low[x], low[y]); 
		else if(in[y]) low[x] = min(low[x], dfn[y]); 
		if(low[x] == dfn[x]) {
			int z; ++cc; 
			do {z = stk[tp --], bl[z] = cc, in[z] = 0;} while(z ^ x); 
		}
	}
	inline void sb5() {
		for(int i = 1; i <= n; ++i) to[i] = pii(i, 1); 
		for(int i = 1; i <= 2 * n; ++i) adj[i].clear(), dfn[i] = low[i] = 0; 
		for(int i = 1; i <= m; ++i) {
			int op = qu[i].op; 
			if(~qu[i].y) {
				int x = qu[i].x, y = qu[i].y; 
				if(~to[y].se) to[x] = pii(to[y].fi, to[y].se ^ op ^ 1);
				else to[x] = pii(go[to[y].fi][op], -1); 
			}
			else to[qu[i].x] = pii(op, -1); 
		}
		for(int x = 1; x <= n; ++x) {
			if(~to[x].se) {
				int z = to[x].fi, o = to[x].se;  
			    adj[x].push_back(z + (!o) * n), adj[x + n].push_back(z + o * n);
			    adj[z].push_back(x + (!o) * n), adj[z + n].push_back(x + o * n); 
			}
			else {
				if(to[x].fi == 2) adj[x].push_back(x + n), adj[x + n].push_back(x); 
			    if(to[x].fi == 1) adj[x + n].push_back(x); 
			    if(to[x].fi == 0) adj[x].push_back(x + n); 
			}
		}
		sgn = cc = 0; 
		for(int i = 1; i <= 2 * n; ++i) if(!dfn[i]) tarjan(i);
		int s = 0; 
		for(int i = 1; i <= n; ++i) s += bl[i] == bl[i + n];
		cout << s << '\n';
	}
	inline void solve() {
		n = read(), m = read(); 
		for(int i = 1; i <= m; ++i) {
			scanf("%s", str + 1);
			if(str[1] != '+' && str[1] != '-') qu[i].y = -1, qu[i].x = read(), qu[i].op = (str[1] == 'U' ? 2 : str[1] == 'F' ? 0 : 1); 
			else qu[i].x = read(), qu[i].y = read(), qu[i].op = str[1] == '+' ? 1 : 0; 
		}
		if(typ <= 2) return sb1(), void();
		if(7 <= typ && typ <= 8) return sb4(), void();  
		return sb5(), void(); 
	}
	inline void mian() {
		typ = read(), T = read(); 
		go[0][0] = 1, go[0][1] = 0, go[1][0] = 0, go[1][1] = 1, go[2][0] = go[2][1] = 2;  
		while(T --) solve(); 
	}
} ;

int main()
{
	freopen("tribool.in", "r", stdin); 
	freopen("tribool.out", "w", stdout); 
	Solver :: mian(); 
	return 0; 
}
