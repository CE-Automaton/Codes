#include <bits/stdc++.h>
#define fi first 
#define se second 

using std :: cin; 
using std :: cout; 
using std :: vector; 

constexpr int M = 3005; 
constexpr int INF = 0x3f3f3f3f; 

typedef long long ll; 
typedef unsigned long long ull; 
typedef double db; 
typedef std :: pair < int, int > pii; 

inline int read() {
	int f = 1, s = 0; char ch = getchar(); 
	while(!isdigit(ch)) (ch == '-') && (f = -1), ch = getchar(); 
	while(isdigit(ch)) s = s * 10 + ch - '0', ch = getchar(); 
	return f * s; 
}

namespace Solver {
	int n, m;
	char str[M]; int cnt[M][26]; pii mx[M], mn[M]; 
	inline void mian() {
		n = read(), m = read(); 
		for(int i = 1; i <= n; ++i) {
			scanf("%s", str + 1); 
			for(int j = 1; j <= m; ++j) cnt[i][str[j] - 'a'] ++; 
			for(int j = 0; j < 26; ++j) if(cnt[i][j]) {mn[i].fi = j, mn[i].se = cnt[i][j]; break;}
			for(int j = 25; ~j; --j) if(cnt[i][j]) {mx[i].fi = j, mx[i].se = cnt[i][j]; break ;}
		}
		for(int i = 1; i <= n; ++i) {
			int ok = 1; 
			for(int j = 1; j <= n; ++j) if(j ^ i) {
				if(mn[i].fi < mx[j].fi) continue ;
				if(mn[i].fi > mx[j].fi) {ok = 0; break ;}
				ok = 0; break;
			}
			putchar(ok + '0'); 
		}
	}
} ;

int main()
{
	freopen("dict.in", "r", stdin); 
	freopen("dict.out", "w", stdout); 
	Solver :: mian(); 
	return 0; 
}
