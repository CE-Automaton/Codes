#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int res=0;
	char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9') res=(res<<1)+(res<<3)+(ch^'0'),ch=getchar();
	return res;
}
const int N=5e5+5;
int c,n,m,q,x[N],y[N],X[N],Y[N],dp[2005][2005];
bool flg;
bool dfs(int nowx,int nowy){
	if(nowx==n&&nowy==m) return 1;
	if(~dp[nowx][nowy]) return dp[nowx][nowy];
	if(flg){
		if(nowx==n){
			if(x[nowx]<y[nowy+1]&&dfs(nowx,nowy+1)) return dp[nowx][nowy]=1;
			return dp[nowx][nowy]=0;
		} else if(nowy==m){
			if(x[nowx+1]<y[nowy]&&dfs(nowx+1,nowy)) return dp[nowx][nowy]=1;
			return dp[nowx][nowy]=0;
		} else{
			if(x[nowx]<y[nowy+1]&&dfs(nowx,nowy+1)) return dp[nowx][nowy]=1;
			if(x[nowx+1]<y[nowy]&&dfs(nowx+1,nowy)) return dp[nowx][nowy]=1;
			if(x[nowx+1]<y[nowy+1]&&dfs(nowx+1,nowy+1)) return dp[nowx][nowy]=1;
			return dp[nowx][nowy]=0;
		}
	} else{
		if(nowx==n){
			if(x[nowx]>y[nowy+1]&&dfs(nowx,nowy+1)) return dp[nowx][nowy]=1;
			return dp[nowx][nowy]=0;
		} else if(nowy==m){
			if(x[nowx+1]>y[nowy]&&dfs(nowx+1,nowy)) return dp[nowx][nowy]=1;
			return dp[nowx][nowy]=0;
		} else{
			if(x[nowx]>y[nowy+1]&&dfs(nowx,nowy+1)) return dp[nowx][nowy]=1;
			if(x[nowx+1]>y[nowy]&&dfs(nowx+1,nowy)) return dp[nowx][nowy]=1;
			if(x[nowx+1]>y[nowy+1]&&dfs(nowx+1,nowy+1)) return dp[nowx][nowy]=1;
			return dp[nowx][nowy]=0;
		}
	}
}
inline bool solve(){
	if(x[1]==y[1]) return 0;
	flg=(x[1]<y[1]);
	if(flg&&x[n]>=y[m]) return 0;
	if(!flg&&x[n]<=y[m]) return 0;
	memset(dp,-1,sizeof(dp));
	return dfs(1,1);
}
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	c=read(),n=read(),m=read(),q=read();
	for(int i=1;i<=n;++i) X[i]=read();
	for(int i=1;i<=m;++i) Y[i]=read();
	for(int i=1;i<=n;++i) x[i]=X[i];
	for(int i=1;i<=m;++i) y[i]=Y[i];
	putchar(solve()?'1':'0');	
	while(q--){
		for(int i=1;i<=n;++i) x[i]=X[i];
		for(int i=1;i<=m;++i) y[i]=Y[i];
		int kx=read(),ky=read();
		while(kx--){
			int p=read(),v=read();
			x[p]=v;
		}
		while(ky--){
			int p=read(),v=read();
			y[p]=v;
		}
		putchar(solve()?'1':'0');
	}
	return 0;
}
