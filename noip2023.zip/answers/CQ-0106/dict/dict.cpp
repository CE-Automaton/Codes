#include<bits/stdc++.h>
using namespace std;
const int N=3e3+5;
int n,m,END=1,cnt[26];
string s[N],t[N];
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	cin>>n>>m;
	for(int i=1;i<=n;++i){
		cin>>s[i];
		sort(s[i].begin(),s[i].end(),greater<char>()); 
	}
	for(int i=1;i<=n;++i) for(int j=1;j<=n;++j){
		if(i==j) continue;
		if(t[i].empty()) t[i]=s[j];
		else t[i]=min(t[i],s[j]);
	}
	for(int i=1;i<=n;++i) reverse(s[i].begin(),s[i].end());
	for(int i=1;i<=n;++i)
		if(s[i]<t[i]) cout<<'1';
		else cout<<'0';
	return 0;
}
