#include<bits/stdc++.h>
#define int long long
#define ls p<<1
#define rs p<<1|1
using namespace std;
const int N=1e3+5;
inline int read(){
	int res=0;
	char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9') res=(res<<1)+(res<<3)+(ch^'0'),ch=getchar();
	return res;
}
void write(int x){
	if(x>=10) write(x/10);
	putchar((x%10)^'0');
}
int c,n,m,k,d,dp[N][N],t[N][N<<2];
void update(int k,int p,int l,int r,int pos,int w){
	if(l==r){
		t[k][p]+=w;
		return;
	}
	int mid=l+r>>1;
	if(pos<=mid) update(k,ls,l,mid,pos,w);
	else update(k,rs,mid+1,r,pos,w);
	t[k][p]=t[k][ls]+t[k][rs];
}
int query(int k,int p,int l,int r,int pos){
	if(r<=pos) return t[k][p];
	int mid=l+r>>1;
	if(mid<pos) return t[k][ls]+query(k,rs,mid+1,r,pos);
	return query(k,ls,l,mid,pos);
}
int dfs(int now,int cnt){
	if(~dp[now][cnt]) return dp[now][cnt];
	int res=0,ans=res;
	if(cnt) ans=res=query(now,1,1,k,cnt);
	if(now<n){
		ans=max(ans,res+dfs(now+1,0));
		if(cnt<k) ans=max(ans,res+dfs(now+1,cnt+1)-d);
	}
	return dp[now][cnt]=ans;
}
signed main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	int T;
	c=read(),T=read();
	while(T--){
		n=read(),m=read(),k=read(),d=read();
		if(c<=9){
			memset(t,0,sizeof(t));
			for(int i=1;i<=m;++i){
				int x=read(),y=read(),w=read();
				update(x,1,1,k,y,w);
			}
			memset(dp,-1,sizeof(dp));
			write(dfs(0,0));
			putchar('\n');
		} else{
			int ans=0;
			for(int i=1;i<=m;++i){
				int x=read(),y=read(),w=read();
				if(y<=k) ans+=max(w-y*d,0ll);
			}
			write(ans);
			putchar('\n');
		}
	}
	return 0;
}
