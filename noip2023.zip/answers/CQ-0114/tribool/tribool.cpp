#include<bits/stdc++.h>
using namespace std;
namespace READ{
char buf[1<<23],*p1,*p2;
//#define getchar() ((p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2))?EOF:*p1++)
template<class T>
void read(T &x)
{
	x=0;
	int f=1;
	char ch=getchar();
	while(!isdigit(ch))
	{
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(isdigit(ch))x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	x*=f;
}
template<class T,class... U>
void read(T &x,U&... y)
{
	read(x);
	read(y...);
}
}
namespace CODE{
using READ::read;
const int N=1e5;
struct Edge{
	int self,next;
}edge[N+5];
int to[N+5],o;
int n,m;
int s[N+5];
int answer,siz;
bool vis[N+5];
int st[N+5],top;
bool inst[N+5];
void add_edge(int x,int y)
{
	edge[++o].self=y;
	edge[o].next=to[x];
	to[x]=o;
}
void dfs(int x)
{
	vis[x]=true;
	++siz;
	for(int i=to[x];i;i=edge[i].next)
	{
		int y=edge[i].self;
		if(!vis[y])dfs(y);
	}
}
signed main()
{
	freopen("tribool.in","r",stdin);
//	freopen("tribool4.in","r",stdin);
	freopen("tribool.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	int type,T;
	cin>>type>>T;
	while(T--)
	{
		answer=0;
		memset(vis,0,sizeof(vis));
		memset(to,0,sizeof(to));
		o=0;
		cin>>n>>m;
		++n;
		for(int i=2;i<=n;++i)s[i]=i;
		while(m--)
		{
			char ch;
			cin>>ch;
			if(ch=='+'||ch=='-')
			{
				int a,b;
				cin>>a>>b;
				++a,++b;
				if(ch=='+')s[a]=s[b];
				else s[a]=-s[b];
			}
			else
			{
				int x;
				cin>>x;
				++x;
				s[x]=ch=='T'?1:(ch=='F'?-1:0);
			}
		}
		for(int i=2;i<=n;++i)
		{
			if(abs(s[i])>1)add_edge(abs(s[i]),i);
		}
		for(int i=2;i<=n;++i)
		{
			if(!vis[i])
			{
				int x=i;
				while(1)
				{
					st[++top]=x;
					inst[x]=true;
					int fa=abs(s[x]);
					if(fa<=1)
					{
						while(top)inst[st[top--]]=false;
						siz=0;
						dfs(x);
						if(fa==0)answer+=siz;
						break;
					}
					else if(inst[fa])
					{
						int cnt=1;
						do{
							if(s[st[top]]<0)cnt=-cnt;
							inst[st[top]]=false;
						}while(st[top--]!=fa);
						while(top)inst[st[top--]]=false;
						siz=0;
						dfs(fa);
						if(cnt==-1)answer+=siz;
						break;
					}
					else x=fa;
				}
			}
		}
		cout<<answer<<'\n';
	}
	return 0;
}
}
signed main()
{
	CODE::main();
	return 0;
}
