#include<bits/stdc++.h>
using namespace std;
namespace READ{
char buf[1<<23],*p1,*p2;
//#define getchar() ((p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2))?EOF:*p1++)
template<class T>
void read(T &x)
{
	x=0;
	int f=1;
	char ch=getchar();
	while(!isdigit(ch))
	{
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(isdigit(ch))x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	x*=f;
}
template<class T,class... U>
void read(T &x,U&... y)
{
	read(x);
	read(y...);
}
}
namespace CODE{
using READ::read;
int n,m;
string ss[3005];
int lessor(string &a,string &b)
{
	for(int j=0;j<m;++j)
	{
		if(a[j]!=b[j])return a[j]<b[j];
	}
	return -1;
}
signed main()
{
	freopen("dict.in","r",stdin);
//	freopen("dict4.in","r",stdin);
	freopen("dict.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	cin>>n>>m;
	string last,s;
	int la=0;
	for(int i=1;i<=n;++i)
	{
		cin>>s;
		sort(s.begin(),s.end(),greater<char>());
		ss[i]=s;
		if(i==1)last=s,la=1;
		else
		{
			int tp=lessor(s,last);
			if(tp==-1)++la;
			if(tp==1)last=s,la=1;
		}
	}
	for(int i=1;i<=n;++i)
	{
		reverse(ss[i].begin(),ss[i].end());
		int tp=lessor(ss[i],last);
		if(tp==1||(tp==-1&&la==1))cout<<1;
		else cout<<0;
	}
	return 0;
}
}
signed main()
{
	CODE::main();
	return 0;
}
