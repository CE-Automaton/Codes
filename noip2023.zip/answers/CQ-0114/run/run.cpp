#include<bits/stdc++.h>
using namespace std;
namespace READ{
char buf[1<<23],*p1,*p2;
#define getchar() ((p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2))?EOF:*p1++)
template<class T>
void read(T &x)
{
	x=0;
	int f=1;
	char ch=getchar();
	while(!isdigit(ch))
	{
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(isdigit(ch))x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	x*=f;
}
template<class T,class... U>
void read(T &x,U&... y)
{
	read(x);
	read(y...);
}
}
namespace Subtask1{
using READ::read;
const int N=3000;
int n,m,k,v;
long long dp[N+5],d[N+5][N+5];
signed main()
{
	int T;
	read(T);
	while(T--)
	{
		read(n,m,k,v);
		memset(dp,0,sizeof(dp));
		memset(d,0,sizeof(d));
		while(m--)
		{
			int l,r,v;
			read(r,l,v);
			l=r-l+1;
			d[l][r]+=v;
		}
		for(int len=2;len<=n;++len)
		{
			for(int l=1;;++l)
			{
				int r=l+len-1;
				if(r>n)break;
				d[l][r]+=d[l+1][r]+d[l][r-1]-d[l+1][r-1];
			}
		}
		for(int i=1;i<=n;++i)
		{
			for(int j=max(0,i-k);j<=i;++j)
			{
				dp[i+1]=max(dp[i+1],dp[j]+d[j+1][i]-v*(i-j));
			}
		}
		cout<<dp[n+1]<<'\n';
	}
	return 0;
}
}
namespace CODE{
using READ::read;
signed main()
{
	freopen("run.in","r",stdin);
//	freopen("run3.in","r",stdin);
	freopen("run.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	int type,T;
	read(type);
	if(type<=9)Subtask1::main();
	return 0;
}
}
signed main()
{
	CODE::main();
	return 0;
}
