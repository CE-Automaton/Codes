#include<bits/stdc++.h>
using namespace std;
namespace READ{
char buf[1<<23],*p1,*p2;
#define getchar() ((p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<21,stdin),p1==p2))?EOF:*p1++)
template<class T>
void read(T &x)
{
	x=0;
	int f=1;
	char ch=getchar();
	while(!isdigit(ch))
	{
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(isdigit(ch))x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
	x*=f;
}
template<class T,class... U>
void read(T &x,U&... y)
{
	read(x);
	read(y...);
}
}
namespace CODE{
using READ::read;
const int N=5e5;
int type,n,m,q;
int _n,_m;
int a[N+5],b[N+5];
int _a[N+5],_b[N+5];
int st1[N+5],top1,st2[N+5],top2;
int qlog2[N+5];
int mi[20][N+5],ma[20][N+5];
int s[N+5],tsr;
int rmi(int l,int r)
{
	int k=qlog2[r-l+1];
	return min(mi[k][l],mi[k][r-(1<<k)+1]);
}
int rma(int l,int r)
{
	int k=qlog2[r-l+1];
	return max(ma[k][l],ma[k][r-(1<<k)+1]);
}
bool calc()
{
	if(a[1]==b[1])return false;
	if(a[1]>b[1])swap(a,b),swap(n,m);
	int last=0x3f3f3f3f,f=0;
	s[tsr=0]=0;
	for(int i=1;i<=m;++i)ma[0][i]=mi[0][i]=b[i];
	for(int i=1;i<=qlog2[m];++i)
	{
		for(int x=1;x<=m;++x)
		{
			ma[i][x]=max(ma[i-1][x],(x+(1<<i-1)>m?0:ma[i-1][x+(1<<i-1)]));
			mi[i][x]=min(mi[i-1][x],(x+(1<<i-1)>m?0x3f3f3f3f:mi[i-1][x+(1<<i-1)]));
		}
	}
	for(int i=1;i<=n;++i)
	{
		if(f==0)
		{
			if(a[i]<=last)last=a[i];
			else
			{
				int r=s[tsr],nr=r;
				int cnt=0;
				while(1)
				{
					if(nr+(1<<cnt)>m||rmi(r+1,nr+(1<<cnt))<=last)break;
					++cnt;
				}
				while(--cnt>=0)
				{
					if(nr+(1<<cnt)<=m&&rmi(r+1,nr+(1<<cnt))>last)nr+=1<<cnt;
				}
				if(nr!=r)s[++tsr]=nr;
				f=1;
				last=a[i];
			}
		}
		else
		{
			if(a[i]>=last)last=a[i];
			else
			{
				while(tsr)
				{
					int r=s[tsr],l=s[tsr-1]+1;
					int nr=r,cnt=0;
					if(rma(l,r)<=last)
					{
						--tsr;
						continue;
					}
					if(rma(r,r)>last)break;
					while(1)
					{
						if(nr-(1<<cnt)<l||rma(nr-(1<<cnt),r)>last)break;
						++cnt;
					}
					while(--cnt>=0)
					{
						if((nr-(1<<cnt)>=l)&&rma(nr-(1<<cnt),r)<=last)nr-=(1<<cnt);
					}
					s[tsr]=nr-1;
					break;
				}
				if(tsr==0)return false;
				f=0;
				last=a[i];
			}
		}
	}
	if(f==0)
	{
		int r=s[tsr],nr=r;
				int cnt=0;
				while(1)
				{
					if(nr+(1<<cnt)>m||rmi(r+1,nr+(1<<cnt))<=last)break;
					++cnt;
				}
				while(--cnt>=0)
				{
					if(nr+(1<<cnt)<=m&&rmi(r+1,nr+(1<<cnt))>last)nr+=1<<cnt;
				}
				if(nr!=r)s[++tsr]=nr;
	}
	else
	{
		while(tsr)
				{
					int r=s[tsr],l=s[tsr-1]+1;
					int nr=r,cnt=0;
					if(rma(l,r)<=last)
					{
						--tsr;
						continue;
					}
					if(rma(r,r)>last)break;
					while(1)
					{
						if(nr-(1<<cnt)<l||rma(nr-(1<<cnt),r)>last)break;
						++cnt;
					}
					while(--cnt>=0)
					{
						if((nr-(1<<cnt)>=l)&&rma(nr-(1<<cnt),r)<=last)nr-=(1<<cnt);
					}
					s[tsr]=nr-1;
					break;
				}
				if(tsr==0)return false;
	}
	if(s[tsr]==m)return true;
	return false;
}
signed main()
{
	freopen("expand.in","r",stdin);
//	freopen("expand5.in","r",stdin);
	freopen("expand.out","w",stdout);
	qlog2[1]=0;
	for(int i=2;i<=N;++i)qlog2[i]=qlog2[i>>1]+1;
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	read(type,n,m,q);
	_n=n,_m=m;
	for(int i=1;i<=n;++i)read(a[i]);
	for(int i=1;i<=m;++i)read(b[i]);
	memcpy(_a,a,sizeof(a));
	memcpy(_b,b,sizeof(b));
	cout<<calc();
	for(int __=1;__<=q;++__)
	{
		if(__==48)
		{
			int ___=1;
			++___;
		}
		memcpy(a,_a,sizeof(_a));
		memcpy(b,_b,sizeof(_b));
		n=_n,m=_m;
		int ka,kb;
		read(ka,kb);
		while(ka--)
		{
			int x,v;
			read(x,v);
			a[x]=v;
		}
		while(kb--)
		{
			int x,v;
			read(x,v);
			b[x]=v;
		}
		cout<<calc();
	}
	return 0;
}
}
signed main()
{
	CODE::main();
	return 0;
}
