#include<cstdlib>
#include<cstdio>
#include<cctype>
typedef long long ll;
namespace IO{
	inline char read_t(){
		char s;while(s=getchar(),s!='+'&&s!='-'&&s!='T'&&s!='F'&&s!='U');return s;
	}
	inline char read_c(){
		char s;while(!isalpha(s=getchar()));return s;
	}
	inline ll read(){
		ll n(0);char s;bool f(false);while(!isdigit(s=getchar()))if(s=='-')f=true;
		while(n=n*10+(s^48),isdigit(s=getchar()));return f?-n:n;
	}
	inline void write(ll n){
		static char s[30];int top(0);if(n<0)putchar('-'),n=-n;
		while(s[++top]=n%10^48,n/=10);while(putchar(s[top]),--top);
	}
}
namespace SOLVE{
	using namespace IO;
	const int M=1e5+5;
	int T,n,m,v,tot,dfe=1,h[M],t[M],id[M],val[M],w[M<<1];bool vis[M];
	struct Edge{
		int v,w,nx;
	}e[M<<1];
	inline void Add(const int&u,const int&v,const int&w){
		e[++dfe]=(Edge){v,w,h[u]};h[u]=dfe;
		e[++dfe]=(Edge){u,w,h[v]};h[v]=dfe;
	}
	inline void clear(){
		for(int i=1;i<=n;++i)h[i]=t[i]=id[i]=val[i]=0,vis[i]=false;for(int i=1;i<=tot;++i)w[i]=0;n=m=0;dfe=1;
	}
	inline int tr(const int&x){
		return x==1?2:x==2?1:3;
	}
	inline void DFS1(const int&u,const int&fa){
		vis[u]=true;
		for(int E=h[u];E;E=e[E].nx)if((E^fa)!=1){
			if(vis[e[E].v]){
				w[v=u]=val[u]^val[e[E].v]^e[E].w?3:1;return;
			}
			val[e[E].v]=val[u]^e[E].w;DFS1(e[E].v,E);if(v)return;
		}
	}
	inline void DFS2(const int&u){
		for(int E=h[u];E;E=e[E].nx)if(!w[e[E].v])w[e[E].v]=e[E].w?tr(w[u]):w[u],DFS2(e[E].v);
	}
	inline void main(){
		read();T=read();
		while(T--){
			int cnt(0);n=read();m=read();tot=n;for(int i=1;i<=n;++i)id[i]=i;
			for(int i=1;i<=m;++i){
				char opt=read_t();
				if(opt=='+'){
					int x=read(),y=read();t[x]=t[y];id[x]=id[y];
				}
				if(opt=='-'){
					int x=read(),y=read();t[x]=t[y]^1;id[x]=id[y];
				}
				if(opt=='T'){
					int x=read();w[id[x]=++tot]=1;
				}
				if(opt=='F'){
					int x=read();w[id[x]=++tot]=2;
				}
				if(opt=='U'){
					int x=read();w[id[x]=++tot]=3;
				}
			}
			for(int i=1;i<=n;++i)if(id[i]>n)w[i]=t[i]?tr(w[id[i]]):w[id[i]];else Add(id[i],i,t[i]);
			for(int i=1;i<=n;++i)if(id[i]>n)DFS2(i);
			for(int i=1;i<=n;++i)if(!w[i])DFS1(i,0),DFS2(v?v:i),v=0;
			for(int i=1;i<=n;++i)if(w[i]==3)++cnt;write(cnt);putchar('\n');clear();
		}
	}
}
signed main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	SOLVE::main();
}
