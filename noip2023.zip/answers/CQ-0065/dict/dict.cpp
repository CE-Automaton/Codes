#include<cstdlib>
#include<cstdio>
#include<cctype>
typedef long long ll;
namespace IO{
	inline char read_c(){
		char s;while(!isalpha(s=getchar()));return s;
	}
	inline ll read(){
		ll n(0);char s;bool f(false);while(!isdigit(s=getchar()))if(s=='-')f=true;
		while(n=n*10+(s^48),isdigit(s=getchar()));return f?-n:n;
	}
	inline void write(ll n){
		static char s[30];int top(0);if(n<0)putchar('-'),n=-n;
		while(s[++top]=n%10^48,n/=10);while(putchar(s[top]),--top);
	}
}
namespace SOLVE{
	using namespace IO;
	const int M=3005;
	int n,m,mx[M],mi[M],cnt[M][30];char s[M];
	inline bool check(const int&x,const int&y){
		if(mi[x]>mx[y])return false;if(mi[x]<mx[y])return true;
		if(cnt[x][mi[x]]==m&&cnt[x][mx[y]]==m)return false;
	}
	inline void main(){
		n=read();m=read();
		for(int i=1;i<=n;++i)for(int j=1;j<=m;++j)++cnt[i][read_c()-'a'];
		for(int i=1;i<=n;++i){
			for(int c=0;c<=26;++c)if(cnt[i][c]){mi[i]=c;break;}
			for(int c=25;c>=0;--c)if(cnt[i][c]){mx[i]=c;break;}
		}
		for(int i=1;i<=n;++i){
			bool f(true);for(int j=1;j<=n;++j)if(i!=j&&!check(i,j))f=false;write(f);
		}
	}
}
signed main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	SOLVE::main();
}
