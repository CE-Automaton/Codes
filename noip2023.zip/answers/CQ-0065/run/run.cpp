//�������ƴ���������ҪС�����������µ�������ŵ 
#include<algorithm>
#include<cstdlib>
#include<cstdio>
#include<cctype>
typedef long long ll;
namespace IO{
	inline char read_c(){
		char s;while(!isalpha(s=getchar()));return s;
	}
	inline ll read(){
		ll n(0);char s;bool f(false);while(!isdigit(s=getchar()))if(s=='-')f=true;
		while(n=n*10+(s^48),isdigit(s=getchar()));return f?-n:n;
	}
	inline void write(ll n){
		static char s[30];int top(0);if(n<0)putchar('-'),n=-n;
		while(s[++top]=n%10^48,n/=10);while(putchar(s[top]),--top);
	}
}
namespace SOLVE{
	using namespace IO;
	const int M=1e5+5;const ll INF=9e18;
	int T,m,n,k,d,rt,l[M],r[M],id[M];ll w[M],dp[M];
	int tot,ls[M*100],rs[M*100];ll tag[M*100],val[M*100],mi[M*100],mx[M*100];
	inline ll max(const ll&a,const ll&b){
		return a>b?a:b;
	}
	inline ll min(const ll&a,const ll&b){
		return a>b?b:a;
	}
	inline void update(const int&u,const int&L,const int&R){
		const int&mid=L+R>>1;
		if(!ls[u])val[ls[u]=++tot]=1ll*mid*d,mx[u]=mi[u]=0;if(!rs[u])val[rs[u]=++tot]=1ll*R*d,mx[u]=mi[u]=0;
		val[u]=tag[u]+max(val[ls[u]],val[rs[u]]);mi[u]=min(mi[ls[u]],mi[rs[u]]);mx[u]=max(mx[ls[u]],mx[rs[u]]);
	}
	inline void Add(int&u,const int&l,const int&r,const ll&w,const int&L=1,const int&R=m){
		if(l>R||L>r)return;if(!u)val[u=++tot]=1ll*R*d,mx[u]=0,mi[u]=0;
		if(l<=L&&R<=r)return val[u]+=w,tag[u]+=w,void();
		const int&mid=L+R>>1;Add(ls[u],l,r,w,L,mid);Add(rs[u],l,r,w,mid+1,R);update(u,L,R);
	}
	inline void Mdf(int&u,const int&l,const int&r,const ll&w,const int&L=1,const int&R=m){
		if(l>R||L>r)return;if(!u)val[u=++tot]=1ll*R*d,mx[u]=0,mi[u]=0;if(w<=mi[u])return;
		if(l<=L&&R<=r&&w>=mx[u])return val[u]+=w-mx[u],tag[u]+=w-mx[u],mx[u]=mi[u]=w,void();
		const int&mid=L+R>>1;Mdf(ls[u],l,r,w,L,mid);Mdf(rs[u],l,r,w,mid+1,R);update(u,L,R);
	}
	inline ll Qry(int&u,const int&l,const int&r,const int&L=1,const int&R=m){
		if(l>R||L>r)return-INF;if(!u)val[u=++tot]=1ll*R*d,mx[u]=0,mi[u]=0;if(l<=L&&R<=r)return val[u];
		const int&mid=L+R>>1;return tag[u]+max(Qry(ls[u],l,r,L,mid),Qry(rs[u],l,r,mid+1,R));
	}
	inline void clear(){
		for(int i=0;i<=n;++i)l[i]=r[i]=w[i]=dp[i]=w[i]=0;rt=n=k=d=0;
		while(tot)ls[tot]=rs[tot]=mi[tot]=mx[tot]=val[tot]=tag[tot]=0,--tot;
	}
	inline void main(){
		read();T=read();
		while(T--){
			m=read();n=read();k=read();d=read();rt=++tot;val[rt]=1ll*m*d;mx[rt]=0;mi[rt]=0;
			for(int i=1;i<=n;++i)r[i]=read(),l[i]=r[i]-read()+1,w[i]=read(),id[i]=i;
			std::sort(id+1,id+n+1,[](const int&x,const int&y){return r[x]==r[y]?l[x]>l[y]:r[x]<r[y];});
			for(int i=1;i<=n;++i){
				const int&x=id[i];
				if(r[x]-l[x]+1>k){dp[i]=dp[i-1];continue;}
				Add(rt,1,l[x],w[x]);
				dp[i]=max(dp[i-1],-1ll*(r[x]+1)*d+Qry(rt,r[x]+1>k?r[x]-k+1:1,l[x]));
				if(r[x]+2<=m)Mdf(rt,r[x]+2,m,dp[i]);
			}
			write(dp[n]);putchar('\n');clear();
		}
	}
}
signed main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	SOLVE::main();
}
/*
0 1
10 5 10 100
5 5 1000
6 5 500
9 7 700
6 3 25
5 2 10
*/
