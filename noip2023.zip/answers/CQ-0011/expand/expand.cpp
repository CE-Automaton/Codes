#include<bits/stdc++.h>
using namespace std;
#define ll long long
//bool mst;
int a[500005], b[500005], ta[500005], tb[500005];
int amx[500005], bmi[500005];
int ami[500005], bmx[500005]; //15MB
bool solve(int *a, int *b, int n, int m){
	//a1>b1
	int x=1, y=1;
	amx[n+1]=0, ami[n+1]=1e9;
	for(int i=n; i>=1; --i){
		amx[i]=max(amx[i+1], a[i]);
		ami[i]=min(ami[i+1], a[i]);
	}
	bmi[m+1]=1e9, bmx[m+1]=0;
	for(int i=m; i>=1; --i){
		bmi[i]=min(bmi[i+1], b[i]);
		bmx[i]=max(bmx[i+1], b[i]);
	}
	int cx=1, cy=1;
	while(amx[x]>a[x]||bmi[y]<b[y]){
		int tag=0;
		while(cx<n&&a[cx+1]>b[y]){
			tag=1;
			cx++;
			if(a[cx]>a[x]) x=cx;
		}
		while(cy<m&&b[cy+1]<a[x]){
			tag=1;
			cy++;
			if(b[cy]<b[y]) y=cy;
		}
		if(!tag) return 0;
	}
	while(cx<n&&a[cx+1]>b[y]) cx++;
	while(cy<m&&b[cy+1]<a[x]) cy++;
	if(cx!=n||cy!=m) return 0;
//	if(TAG) puts("B");
	while(x<n||y<m){
		if(bmx[y+1]<amx[x+1]){
			x++;
			while(a[x]!=amx[x]) x++;
			continue;
		}
		if(ami[x+1]>bmi[y+1]){
			y++;
			while(b[y]!=bmi[y]) y++;
			continue;
		}
		return 0;
	}
	return 1;
}
int c, n, m, q;
bool Solve(){
	if(ta[1]<tb[1]){
		return solve(tb, ta, m, n);
	}else if(ta[1]>tb[1]){
		return solve(ta, tb, n, m);
	}else{
		return 0;
	}
}
void read(int &x){
	x=0; char c(getchar());
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9'){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
}
//bool med;
//void mcheck(){
//	cerr << (&mst-&med)/1024.0/1024 << '\n';
//}

int main(){
//	mcheck();
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);
	read(c), read(n), read(m), read(q);
	for(int i=1; i<=n; ++i){
		read(a[i]);
		ta[i]=a[i];
	}
	for(int i=1; i<=m; ++i){
		read(b[i]);
		tb[i]=b[i];
	}
	putchar(Solve()+'0');
	for(int i=1; i<=q; ++i){
		int k1, k2;
		read(k1), read(k2);
		for(int j=1; j<=n; ++j){
			ta[j]=a[j];
		}
		for(int j=1; j<=m; ++j){
			tb[j]=b[j];
		}
		for(int j=1; j<=k1; ++j){
			int x, y;
			read(x), read(y);
			ta[x]=y;
		}
		for(int j=1; j<=k2; ++j){
			int x, y;
			read(x), read(y);
			tb[x]=y;
		}
		putchar(Solve()+'0');
	}
	return 0;
}

