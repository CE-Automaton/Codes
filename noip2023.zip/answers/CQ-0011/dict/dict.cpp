#include<bits/stdc++.h>
using namespace std;
#define ll long long
//bool mst;
int n, m;
char w[3005][3005];
int ct[3005][26];
int s1[3005][26], s2[3005][26]; //ǰ��׺ MIN  ����ֵ��� 
//10MB
bool cmp1(int *x, int *y){
	// MAX x < MAX y
	for(int i=25; i>=0; --i){
		if(x[i]>y[i]) return 0;
		if(x[i]<y[i]) return 1;
	}
	return 0;
}
bool cmp2(int *x, int *y){
	// MIN x < MAX y
	int mi=0, mx=25;
	while(!x[mi]) mi++;
	while(!y[mx]) mx--;
	if(mi<mx) return 1;
	if(mi>mx) return 0;
	return 0;
}
//bool med;
//void mcheck(){
//	cerr << (&mst-&med)/1024.0/1024 << '\n';
//}
int main(){
//	mcheck();
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);
	scanf("%d%d", &n, &m);
	if(n==1){
		puts("1");
		return 0;
	}
	for(int i=1; i<=n; ++i){
		scanf("%s", w[i]+1);
		for(int j=1; j<=m; ++j){
			ct[i][w[i][j]-'a']++;
		}
	}
	s1[0][25]=m, s2[n+1][25]=m;
	for(int i=1; i<=n; ++i){
		if(cmp1(ct[i], s1[i-1])){
			for(int j=0; j<26; ++j){
				s1[i][j]=ct[i][j];
			}
		}else{
			for(int j=0; j<26; ++j){
				s1[i][j]=s1[i-1][j];
			}
		}
	}
	for(int i=n; i>=1; --i){
		if(cmp1(ct[i], s2[i+1])){
			for(int j=0; j<26; ++j){
				s2[i][j]=ct[i][j];
			}
		}else{
			for(int j=0; j<26; ++j){
				s2[i][j]=s2[i+1][j];
			}
		}
	}
	for(int i=1; i<=n; ++i){
		if(cmp2(ct[i], s1[i-1])&&cmp2(ct[i], s2[i+1])){
			putchar('1');
		}else{
			putchar('0');
		}
	}
	putchar('\n');
	return 0;
}
