#include<bits/stdc++.h>
using namespace std;
#define ll long long
//bool mst;
int a[200005], fa[400005];
int find_fa(int x){
	return fa[x]==x?x:fa[x]=find_fa(fa[x]);
}
void hb(int x, int y){
	x=find_fa(x), y=find_fa(y);
	fa[y]=x;
}
//bool med;
//void mcheck(){
//	cerr << (&mst-&med)/1024.0/1024 << '\n';
//}
int main(){
//	mcheck();
	freopen("tribool.in", "r", stdin);
	freopen("tribool.out", "w", stdout);
	ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
	int c, t;
	cin >> c >> t;
	while(t--){
		int n, m;
		cin >> n >> m;
		for(int i=1; i<=n; ++i){
			a[i]=i;
		}
		for(int i=1; i<=2*n+4; ++i){
			fa[i]=i;
		}
		/*
		T n+1
		F -n-1
		U (n+2)|-(n+2)
		*/
		hb(n+2, 2*n+4);
		for(int i=1; i<=m; ++i){
			char op; int x, y;
			cin >> op >> x;
			if(op=='+'){
				cin >> y;
				a[x]=a[y];
			}else if(op=='-'){
				cin >> y;
				a[x]=-a[y];
			}else if(op=='T'){
				a[x]=n+1;
			}else if(op=='F'){
				a[x]=-(n+1);
			}else if(op=='U'){
				a[x]=n+2;
			}
		}
		for(int i=1; i<=n; ++i){
			if(a[i]>0){
				hb(i, a[i]);
				hb(i+(n+2), a[i]+(n+2));
			}else{
				hb(i, -a[i]+(n+2));
				hb(i+(n+2), -a[i]);
			}
		}
		int ans=0;
		for(int i=1; i<=n; ++i){
			if(find_fa(i)==find_fa(i+(n+2))){
				ans++;
			}
		}
		cout << ans << '\n';
	}
	return 0;
}

