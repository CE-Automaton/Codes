#include <bits/stdc++.h>
using namespace std;
const int N = 500010;
int c, n, m, q, x[N], y[N], sx[N], sy[N];
int n1, n2;
struct node {int pos, val;} u[N], v[N];
bool f[2010][2010];
inline void force()
{
	if(x[1] == y[1]) {cout << 0; return ;}
	else if(x[1] > y[1])
	{
		f[1][1] = true;
		for(int i = 1; i <= n; ++i)
		{
			for(int j = 1; j <= m; ++j)
			{
				if(i == 1 && j == 1) continue;
				f[i][j] = (x[i] > y[j]);
				f[i][j] = (f[i][j] && (f[i - 1][j] || f[i][j - 1] || f[i - 1][j - 1]));
			}
		}
	}
	else
	{
		f[1][1] = true;
		for(int i = 1; i <= n; ++i)
		{
			for(int j = 1; j <= m; ++j)
			{
				if(i == 1 && j == 1) continue;
				f[i][j] = (x[i] < y[j]);
				f[i][j] = (f[i][j] && (f[i - 1][j] || f[i][j - 1] || f[i - 1][j - 1]));
			}
		}
	}
	cout << (int)f[n][m]; 
}
int rec1[N], rec2[N];
struct SGT
{
	int rt[N], idx;
	struct SGTnode
	{
		int ls, rs, sum;
		#define ls(x) tree[x].ls
		#define rs(x) tree[x].rs
		#define sum(x) tree[x].sum
	}tree[N * 24];
	inline void pushup(int now) {sum(now) = sum(ls(now)) + sum(rs(now));}
	inline void insert(int &now, int his, int l, int r, int pos, int num)
	{
		if(!now) now = ++idx;
		ls(now) = ls(his), rs(now) = rs(his), sum(now) = sum(his);
		if(l == r) {sum(now) += num; return ;}
		int mid = (l + r) >> 1;
		if(pos <= mid) insert(ls(now), ls(his), l, mid, pos, num);
		else insert(rs(now), rs(his), mid + 1, r, pos, num);
		pushup(now);
	}
	inline int ask1(int now, int l, int r, int L, int R)
	{
		if(sum(now) == 0) return -1;
		if(l == r) return l;
		int mid = (l + r) >> 1;
		if(mid < R)
		{
			int ans = ask1(rs(now), mid + 1, r, L, R);
			if(ans != -1) return ans;
		}
		return ask1(ls(now), l, mid, L, R);
	}
	inline int ask2(int now, int l, int r, int L, int R)
	{
		if(sum(now) == r - l + 1) return -1;
		if(l == r) return l;
		int mid = (l + r) >> 1;
		if(L <= mid)
		{
			int ans = ask2(ls(now), l, mid, L, R);
			if(ans != -1) return ans;
		}
		return ask2(rs(now), mid + 1, r, L, R);
	}
};
SGT T1, T2;
struct nd2 {int pos, val;} rx[N], ry[N];
inline bool cmp(nd2 x, nd2 y) {return x.val < y.val;}
inline void solve()
{
	for(int i = 1; i <= T1.idx; ++i) T1.tree[i].ls = T1.tree[i].rs = T1.tree[i].sum = 0;
	for(int i = 1; i <= T2.idx; ++i) T2.tree[i].ls = T2.tree[i].rs = T2.tree[i].sum = 0;
	memset(T1.rt, 0, sizeof(T1.rt)); T1.idx = 0;
	memset(T2.rt, 0, sizeof(T2.rt)); T2.idx = 0;
	for(int i = 1; i <= n; ++i) rx[i].pos = i, rx[i].val = x[i];
	for(int i = 1; i <= m; ++i) ry[i].pos = i, ry[i].val = y[i];
	sort(rx + 1, rx + n + 1, cmp);
	sort(ry + 1, ry + m + 1, cmp);
	int p1 = 1, p2 = m, lst = 0;
	for(int i = 1; i <= n; ++i)
	{
		while(p1 <= m && ry[p1].val < rx[i].val)
			T1.insert(T1.rt[rx[i].pos], lst, 1, n, ry[p1].pos, 1), ++p1, lst = T1.rt[rx[i].pos];
		rec1[rx[i].pos] = lst;
	}
	lst = 0;
	for(int i = n; i >= 1; --i)
	{
		while(p2 >= 1 && ry[p2].val > rx[i].val)
			T2.insert(T2.rt[rx[i].pos], lst, 1, n, ry[p2].pos, 1), --p2, lst = T2.rt[rx[i].pos];
		rec2[rx[i].pos] = lst;
	}
		
	int ps1 = 0, ps2 = 0;
	bool o1 = true, o2 = true;
	for(int i = 1; i <= n; ++i)
	{
		int c1, c2;
		c1 = T1.ask1(rec1[i], 1, n, 1, min(n, ps1 + 1));
		c2 = T2.ask1(rec2[i], 1, n, 1, min(n, ps2 + 1));
		ps1 = c1, ps2 = c2;
		if(ps1 < 0) o1 = false, ps1 = 0;
		if(ps2 < 0) o2 = false, ps2 = 0;
		c1 = T1.ask2(rec1[i], 1, n, ps1 + 1, n);
		c2 = T2.ask2(rec2[i], 1, n, ps2 + 1, n);
		if(c1 == -1) c1 = n + 1;
		if(c2 == -1) c2 = n + 1;
		ps1 = c1 - 1, ps2 = c2 - 1;
	}
	if((o1 && ps1 == m) || (o2 && ps2 == m)) cout << 1;
	else cout << 0;
}
int main()
{
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	cin >> c >> n >> m >> q;
	for(int i = 1; i <= n; ++i) cin >> x[i], sx[i] = x[i];
	for(int i = 1; i <= m; ++i) cin >> y[i], sy[i] = y[i];
	if(n <= 2000 && m <= 2000)
	{
		force();
		for(int i = 1; i <= q; ++i)
		{
			cin >> n1 >> n2;
			for(int j = 1; j <= n1; ++j) cin >> u[j].pos >> u[j].val, x[u[j].pos] = u[j].val;
			for(int j = 1; j <= n2; ++j) cin >> v[j].pos >> v[j].val, y[v[j].pos] = v[j].val;
			force();
			for(int j = 1; j <= n1; ++j) x[u[j].pos] = sx[u[j].pos];
			for(int j = 1; j <= n2; ++j) y[v[j].pos] = sy[v[j].pos];
		}
		return 0;
	}
	solve();
	for(int i = 1; i <= q; ++i)
	{
		cin >> n1 >> n2;
		for(int j = 1; j <= n1; ++j) cin >> u[j].pos >> u[j].val, x[u[j].pos] = u[j].val;
		for(int j = 1; j <= n2; ++j) cin >> v[j].pos >> v[j].val, y[v[j].pos] = v[j].val;
		solve();
		for(int j = 1; j <= n1; ++j) x[u[j].pos] = sx[u[j].pos];
		for(int j = 1; j <= n2; ++j) y[v[j].pos] = sy[v[j].pos];
	}
	return 0;
}
