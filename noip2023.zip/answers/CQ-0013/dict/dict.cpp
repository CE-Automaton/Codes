#include <bits/stdc++.h>
using namespace std;
int n, m, p1, p2, tong[512];
string s[3010], t, t1, t2;
int main()
{
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	cin >> n >> m;
	t1 = "{", t2 = "{";
	for(int i = 1; i <= n; ++i)
	{
		cin >> s[i];
		t = "";
		for(int j = 'a'; j <= 'z'; ++j) tong[j] = 0;
		for(int j = 0; j < m; ++j) ++tong[(int)s[i][j]];
		for(int j = 'z'; j >= 'a'; --j)
			for(int k = 1; k <= tong[j]; ++k)
				t += (char)j;
		if(t < t1) t2 = t1, p2 = p1, t1 = t, p1 = i;
		else if(t < t2) t2 = t, p2 = i;
		s[i] = "";
		for(int j = 'a'; j <= 'z'; ++j)
			for(int k = 1; k <= tong[j]; ++k)
				s[i] += (char)j;
	}
	if(n == 1) cout << 1;
	else
	{
		for(int i = 1; i <= n; ++i)
		{
			if(i == p1)
			{
				if(s[i] < t2) cout << 1;
				else cout << 0;
			}
			else
			{
				if(s[i] < t1) cout << 1;
				else cout << 0;
			}
		}
	}
	return 0;
}
