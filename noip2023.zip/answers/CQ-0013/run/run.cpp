#include <bits/stdc++.h>
using namespace std;
const int N = 100010;
int c, t;
int n, m, k, d;
long long f[N];
struct node {int l, r; long long val;} s[N];
inline bool cmp(node x, node y) {return x.r < y.r;}
int rt, idx;
struct SGT
{
	int ls, rs; long long sum, tag;
	#define ls(x) tree[x].ls
	#define rs(x) tree[x].rs
	#define sum(x) tree[x].sum
	#define tag(x) tree[x].tag
}tree[N * 4];
inline void pushup(int now)
{sum(now) = max(sum(ls(now)), sum(rs(now)));}
inline void pushdown(int now)
{
	if(tag(now))
	{
		if(ls(now)) sum(ls(now)) += tag(now), tag(ls(now)) += tag(now);
		if(rs(now)) sum(rs(now)) += tag(now), tag(rs(now)) += tag(now);
		tag(now) = 0;
	}
}
inline void build(int &now, int l, int r)
{
	if(!now) now = ++idx, ls(now) = rs(now) = sum(now) = tag(now) = 0;
	if(l == r) return ;
	int mid = (l + r) >> 1;
	if(l <= mid) build(ls(now), l, mid);
	if(mid < r) build(rs(now), mid + 1, r);
}
inline void insert(int now, int l, int r, int L, int R, long long num)
{
	if(L > R) return ;
	if(L <= l && r <= R) {sum(now) += num, tag(now) += num; return ;}
	pushdown(now); int mid = (l + r) >> 1;
	if(L <= mid) insert(ls(now), l, mid, L, R, num);
	if(mid < R) insert(rs(now), mid + 1, r, L, R, num);
	pushup(now);
}
inline void sol()
{
	cin >> n >> m >> k >> d;
	for(int i = 1; i <= m; ++i)
	{
		int x, y, v; cin >> x >> y >> v;
		s[i].l = x - y + 1, s[i].r = x, s[i].val = v;
	}
	if(n <= 1e5)
	{
		sort(s + 1, s + m + 1, cmp);
		int at = 1;
		rt = 0, idx = 0;
		build(rt, 0, n + 1);
		for(int i = 1; i <= n + 1; ++i)
		{
			if(i >= 2) insert(rt, 0, n + 1, 0, i - 2, -d);
			if(i - k - 2 >= 0) insert(rt, 0, n + 1, i - k - 2, i - k - 2, -2e16);
			f[i] = max(sum(rt), 0ll);
			insert(rt, 0, n + 1, i, i, f[i]);
			while(at <= m && s[at].r == i)
				insert(rt, 0, n + 1, 0, s[at].l - 1, s[at].val), ++at;
		}
		cout << f[n + 1] << '\n';
		return ;
	}
	if(c == 17 || c == 18)
	{
		long long ans = 0;
		for(int i = 1; i <= m; ++i)
			ans += max(0ll, s[i].val - 1ll * (s[i].r - s[i].l + 1) * d);
		cout << ans << '\n';
		return ;
	}
}
int main()
{
	freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	cin >> c >> t;
	while(t--) sol();
	return 0;
}
