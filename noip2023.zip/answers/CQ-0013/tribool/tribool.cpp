#include <bits/stdc++.h>
using namespace std;
const int N = 200010, tr = 1013453;
int c, t, n, m, a[N], h[N], cnt, fin[N], ans;
struct edge {int to, next, val;} e[N * 3];
inline void add(int x, int y, int z)
{e[++cnt].to = y, e[cnt].next = h[x], e[cnt].val = z, h[x] = cnt;}
inline void dfs(int now)
{
	for(int i = h[now]; i; i = e[i].next)
	{
		int to = e[i].to;
		if(fin[to] != 2) continue;
		if(e[i].val == 0) fin[to] = fin[now];
		else fin[to] = -fin[now];
		dfs(to);
	}
}
int prt[N], siz[N];
inline int find(int x)
{
	if(prt[x] == x) return x;
	prt[x] = find(prt[x]);
	return prt[x];
}
inline void merge(int x, int y)
{
	int u = find(x), v = find(y);
	if(u != v)
	{
		if(siz[u] > siz[v]) swap(u, v);
		prt[u] = v, siz[v] += siz[u], siz[u] = 0;
	}
}
inline void sol()
{
	cin >> n >> m;
	ans = cnt = 0;
	for(int i = 1; i <= n; ++i) a[i] = i, h[i] = 0;
	for(int i = 1; i <= 2 * n; ++i) prt[i] = i, siz[i] = 1;
	for(int i = 1; i <= m; ++i)
	{
		char opt; int x, y;
		cin >> opt;
		if(opt == 'T') {cin >> x; a[x] = tr;}
		if(opt == 'F') {cin >> x; a[x] = -tr;}
		if(opt == 'U') {cin >> x; a[x] = 0;}
		if(opt == '+')
		{
			cin >> x >> y;
			a[x] = a[y];
		}
		if(opt == '-')
		{
			cin >> x >> y;
			a[x] = -a[y];
		}
	}
	for(int i = 1; i <= n; ++i)
	{
		if(a[i] == tr) fin[i] = 1;
		else if(a[i] == -tr) fin[i] = -1;
		else if(a[i] == 0) fin[i] = 0;
		else
		{
			fin[i] = 2;
			if(a[i] > 0) add(i, a[i], 0), add(a[i], i, 0);
			else add(i, -a[i], 1), add(-a[i], i, 1);
		}
	}
	for(int i = 1; i <= n; ++i) if(fin[i] != 2) dfs(i);
	for(int i = 1; i <= n; ++i)
	{
		if(fin[i] != 2) continue;
		for(int j = h[i]; j; j = e[j].next)
		{
			int to = e[j].to;
			if(fin[to] != 2) continue;
			if(e[j].val == 0) merge(i, to), merge(i + n, to + n);
			else merge(i + n, to), merge(i, to + n);
		}
	}
	for(int i = 1; i <= n; ++i)
		if(fin[i] == 0 || find(i) == find(i + n))
			++ans;
	cout << ans << '\n'; 
}
int main()
{
	freopen("tribool.in", "r", stdin);
	freopen("tribool.out", "w", stdout);
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	cin >> c >> t;
	while(t--) sol();
	return 0;
}
