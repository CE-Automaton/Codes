#include <bits/stdc++.h>
#define reg register
#define rep(i, l, r) for (reg int i = l; i <= r; i++)
#define per(i, r, l) for (reg int i = r; i >= l; i--)
using namespace std;
typedef long long ll;
typedef unsigned long long llu;
namespace io {
inline ll read(){
    reg ll s = 0, f = 1;
    reg char ch = getchar();
    while (ch < '0' || ch > '9') { if (ch == '-') f = -1; ch = getchar(); }
    while (ch >= '0' && ch <= '9') s = (s << 1) + (s << 3) + (ch ^ '0'), ch = getchar();
    return s * f;
}
inline void write(reg ll x){
    if (x < 0) putchar('-'), x = -x;
    if (x > 9) write(x / 10); putchar(x % 10 ^ '0');
}
inline void write(reg ll x, reg char c){
    write(x); putchar(c);
}
} // namespace io
using namespace io;
const int N = 3005;
int n, m;
string s[N], t[N], f[2];
int main(){
    freopen("dict.in", "r", stdin);
    freopen("dict.out", "w", stdout);
    cin.tie(0)->sync_with_stdio(0);
    cin >> n >> m;
    rep(i, 1, n) cin >> s[i];
    if (n == 1) return cout << "1", 0;
    rep(i, 1, m) f[0].push_back('z'), f[1].push_back('z');
    rep(i, 1, n) {
        sort(s[i].begin(), s[i].end());
        t[i] = s[i]; reverse(t[i].begin(), t[i].end());
        if (t[i] < f[0]) f[1] = f[0], f[0] = t[i];
        else if (t[i] < f[1]) f[1] = t[i];
    }
    rep(i, 1, n) {
        if (t[i] != f[0]) cout << (s[i] < f[0]) ? '1' : '0';
        else cout << (s[i] < f[1]) ? '1' : '0';
    }
    cout << endl;
    return 0;
}