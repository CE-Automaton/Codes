#include <bits/stdc++.h>
#define reg register
#define rep(i, l, r) for (reg int i = l; i <= r; i++)
#define per(i, r, l) for (reg int i = r; i >= l; i--)
using namespace std;
typedef long long ll;
typedef unsigned long long llu;
namespace io {
inline ll read(){
    reg ll s = 0, f = 1;
    reg char ch = getchar();
    while (ch < '0' || ch > '9') { if (ch == '-') f = -1; ch = getchar(); }
    while (ch >= '0' && ch <= '9') s = (s << 1) + (s << 3) + (ch ^ '0'), ch = getchar();
    return s * f;
}
inline void write(reg ll x){
    if (x < 0) putchar('-'), x = -x;
    if (x > 9) write(x / 10); putchar(x % 10 ^ '0');
}
inline void write(reg ll x, reg char c){
    write(x), putchar(c);
}
} // namespace io
using namespace io;
const int N = 4e5 + 10;
int c, t, n, m, ncnt, T, F, U, pos[N], fa[N];
char op;
inline int find(int x) { return fa[x] == x ? x : fa[x] = find(fa[x]); }
inline void merge(int x, int y){
    int p = find(x), q = find(y);
    if (p == q) return;
    fa[p] = q;
}
int main(){
    freopen("tribool.in", "r", stdin);
    freopen("tribool.out", "w", stdout);
    c = read(), t = read();
    while (t--){
        n = read(), m = read();
        ncnt = n; rep(i, 1, n) pos[i] = i;
        int all = n + m, T = all * 2 + 1, F = all * 2 + 2, U = all * 2 + 3;
        rep(i, 1, U) fa[i] = i;
        rep(i, 1, m) {
            cin >> op;
            if (op == 'T' || op == 'F' || op == 'U'){
                int x = read(); pos[x] = ++ncnt; x = pos[x];
                if (op == 'T') merge(x, T), merge(x + all, F);
                if (op == 'F') merge(x, F), merge(x + all, T);
                if (op == 'U') merge(x, U), merge(x + all, U);
            } else if (op == '+') {
                int x = read(), y = read(); 
                y = pos[y]; pos[x] = ++ncnt; x = pos[x];
                merge(x, y), merge(x + all, y + all);
            } else if (op == '-'){
                int x = read(), y = read(); 
                y = pos[y]; pos[x] = ++ncnt; x = pos[x];
                merge(x, y + all), merge(x + all, y);
            }
        }
        rep(i, 1, n) merge(i, pos[i]), merge(i + all, pos[i] + all);
        rep(i, 1, n) {
            int x = find(i), y = find(i + all);
            if (x == y) merge(i, U), merge(i + all, U);
        }
        int ans = 0;
        rep(i, 1, n) ans += (find(i) == find(i + all));
        write(ans, '\n');
    }
    return 0;
}