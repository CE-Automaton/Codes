#include <bits/stdc++.h>
#define reg register
#define rep(i, l, r) for (reg int i = l; i <= r; i++)
#define per(i, r, l) for (reg int i = r; i >= l; i--)
using namespace std;
typedef long long ll;
typedef unsigned long long llu;
namespace io {
inline ll read(){
    reg ll s = 0, f = 1;
    reg char ch = getchar();
    while (ch < '0' || ch > '9') { if (ch == '-') f = -1; ch = getchar(); }
    while (ch >= '0' && ch <= '9') s = (s << 1) + (s << 3) + (ch ^ '0'), ch = getchar();
    return s * f;
}
inline void write(reg ll x){
    if (x < 0) putchar('-'), x = -x;
    if (x > 9) write(x / 10); putchar(x % 10 ^ '0');
}
inline void write(reg ll x, reg char c){
    write(x); putchar(c);
}
} // namespace io
using namespace io;
const int N = 2e5 + 5, D = 30;
struct seg{
    int x, y; ll v;
    bool operator <(const seg &t) const{
        return x < t.x;
    }
}a[N];
struct node{
    ll cnt, sum;
    node *lc, *rc;
    node(){
        cnt = sum = 0;
        lc = rc = nullptr;
    }
}tree[N * D];
node *ncnt = &tree[0], *root[N];
int c, t, n, m, k, tot, buc[N], pre[N];
int head, tail, Q[N];
ll dp[N], d, ans;
inline void build(node * &p, int l, int r){
    p = ++ncnt; p->cnt = p->sum = 0;
    if (l == r) return;
    int mid = l + r >> 1;
    build(p->lc, l, mid), build(p->rc, mid + 1, r);
}
inline void insert(node * &x, node * y, int l, int r, int p, ll v){
    x = ++ncnt; *x = *y; ++x->cnt, x->sum += v;
    if (l == r) return;
    int mid = l + r >> 1;
    if (p <= mid) insert(x->lc, y->lc, l, mid, p, v);
    else insert(x->rc, y->rc, mid + 1, r, p, v);
}
inline ll ask(node * x, node * y, int l, int r, int p, int q){
    if (p <= l && r <= q) return x->sum - y->sum;
    int mid = l + r >> 1; ll res = 0;
    if (p <= mid) res += ask(x->lc, y->lc, l, mid, p, q);
    if (r > mid) res += ask(x->rc, y->rc, mid + 1, r, p, q);
    return res;
}
inline ll calc(int j, int i){
    int pre = (buc[j] == buc[j - 1] + 1) ? max(0, j - 2) : j - 1;
    return dp[pre] - d * (buc[i] - buc[j] + 1) + ask(root[i], root[j - 1], 1, tot, j, tot);
}
int main(){
    freopen("run.in", "r", stdin);
    freopen("run.out", "w", stdout);
    c = read(), t = read();
    while (t--){
        tot = ans = 0; ncnt = &tree[0];
        memset(dp, 0, sizeof dp);
        n = read(), m = read(), k = read(), d = read();
        rep(i, 1, m) {
            a[i].x = read(), a[i].y = a[i].x - read() + 1, a[i].v = read();
            buc[++tot] = a[i].x, buc[++tot] = a[i].y;
        }
        sort(buc + 1, buc + tot + 1);
        tot = unique(buc + 1, buc + tot + 1) - buc - 1;
        rep(i, 1, m) {
            a[i].x = lower_bound(buc + 1, buc + tot + 1, a[i].x) - buc;
            a[i].y = lower_bound(buc + 1, buc + tot + 1, a[i].y) - buc;
        }
        sort(a + 1, a + m + 1);
        build(root[0], 1, tot);
        reg int lst = 1;
        rep(i, 1, tot) {
            root[i] = root[i - 1];
            for (lst; a[lst].x <= i && lst <= m; lst++){
                node *tmp = root[i];
                insert(root[i], tmp, 1, tot, a[lst].y, a[lst].v);
            }
        }
        rep(i, 1, tot) {
            dp[i] = dp[i - 1];
            int l = lower_bound(buc + 1, buc + tot + 1, buc[i] - k + 1) - buc;
            rep(j, l, i) dp[i] = max(dp[i], calc(j, i));
            ans = max(ans, dp[i]);
        }
        write(ans, '\n');
    }
    return 0;
}