#include <bits/stdc++.h>
#define reg register
#define rep(i, l, r) for (reg int i = l; i <= r; i++)
#define per(i, r, l) for (reg int i = r; i >= l; i--)
using namespace std;
typedef long long ll;
typedef unsigned long long llu;
namespace io {
inline ll read(){
    reg ll s = 0, f = 1;
    reg char ch = getchar();
    while (ch < '0' || ch > '9') { if (ch == '-') f = -1; ch = getchar(); }
    while (ch >= '0' && ch <= '9') s = (s << 1) + (s << 3) + (ch ^ '0'), ch = getchar();
    return s * f;
}
inline void write(reg ll x){
    if (x < 0) putchar('-'), x = -x;
    if (x > 9) write(x / 10); putchar(x % 10 ^ '0');
}
inline void write(reg ll x, reg char c){
    write(x); putchar(c);
}
} // namespace io
using namespace io;
const int N = 2005;
int c, n, m, q, kx, ky, x[N], y[N], a[N], b[N], p, v, mem[N][N];
inline bool dfs(int i, int j){
    if (i == n && j == m) return 1; 
    if (~mem[i][j]) return mem[i][j];
    if (i < n && j < m && a[i + 1] > b[j + 1]) if (dfs(i + 1, j + 1)) return mem[i][j] = 1;
    if (a[i + 1] > b[j]) if (dfs(i + 1, j)) return mem[i][j] = 1;
    if (j < m && a[i] > b[j + 1]) if (dfs(i, j + 1)) return mem[i][j] = 1;
    return mem[i][j] = 0;
}
int main(){
    freopen("expand.in", "r", stdin);
    freopen("expand.out", "w", stdout);
    c = read(), n = read(), m = read(), q = read();
    rep(i, 1, n) a[i] = x[i] = read();
    rep(i, 1, m) b[i] = y[i] = read();
    if (1ll * (a[1] - b[1]) * (a[n] - b[m]) <= 0) putchar('0');
    else {
        bool rev = 0;
        if (a[1] < b[1]) swap(a, b), swap(n, m), rev = 1;
        memset(mem, -1, sizeof mem);
        putchar(dfs(1, 1) ? '1' : '0');
        if (rev) swap(n, m);
    }
    while (q--){
        kx = read(), ky = read();
        rep(i, 1, n) a[i] = x[i];
        rep(i, 1, m) b[i] = y[i];
        while (kx--) p = read(), v = read(), a[p] = v;
        while (ky--) p = read(), v = read(), b[p] = v;
        if ((a[1] - b[1]) * (a[n] - b[m]) <= 0) { putchar('0'); continue; }
        bool rev = 0;
        if (a[1] < b[1]) swap(a, b), swap(n, m), rev = 1;
        memset(mem, -1, sizeof mem);
        putchar(dfs(1, 1) ? '1' : '0');
        if (rev) swap(n, m);
    }
    return 0;
}