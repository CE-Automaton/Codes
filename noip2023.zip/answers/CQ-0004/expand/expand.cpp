#include<bits/stdc++.h>
#define For(i,a,b) for(int i=a,i##end=b;i<=i##end;i++)
#define Rof(i,a,b) for(int i=a,i##end=b;i>=i##end;i--)
#define rep(i  ,b) for(int i=1,i##end=b;i<=i##end;i++)
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<20,stdin),p1==p2)?EOF:*p1++)
using namespace std;
bool ppp;
char buf[1<<21],*p1,*p2;
const int N=5e5+9;
void chmn(int &x,int y){(x>y)&&(x=y);}
void chmx(int &x,int y){(x<y)&&(x=y);}
int read(){
	int f=0,x=0;
	char ch=getchar();
	while(!isdigit(ch)){f|=(ch=='-');ch=getchar();}
	while(isdigit(ch)){x=x*10+ch-'0';ch=getchar();}
	return f?-x:x;
}
int C,n,m,q;
int A[N],B[N],a[N],b[N];
namespace brute{
	void RE(){
		rep(i,n)a[i]=A[i];
		rep(i,m)b[i]=B[i];
	}
	bool dp[2010][2010];
	void work(){
		if(a[n]==b[m]){putchar('0');return;}
		dp[0][0]=1;
		int op=a[n]>b[m]?1:-1;
		rep(i,n)rep(j,m)
			dp[i][j]=(op*(a[i]-b[j])>0)&(dp[i-1][j]|dp[i][j-1]|dp[i-1][j-1]);
		putchar(dp[n][m]?'1':'0');
	}
	void solve(){
		RE();work();
		while(q--){
			RE();int kx=read(),ky=read();
			while(kx--){int p=read();a[p]=read();}
			while(ky--){int p=read();b[p]=read();}
			work();
		}
	}
}
namespace BRUTE{
	struct node1{
		int x,id,sz;
		bool operator<(const node1&X)const{
			return x>X.x;
		}
	};priority_queue<node1>q1;
	struct node2{
		int x,id,sz;
		bool operator<(const node2&X)const{
			return x<X.x;
		}
	};priority_queue<node2>q2;
	int DX[2*N],DY[2*N];
	int fa[N*2],sz[N*2];
	void RE(){
		rep(i,n)a[i]=A[i];
		rep(i,m)b[i]=B[i];
		rep(i,n+m)sz[i]=1,fa[i]=i;
	}
	int get(int x){return fa[x]==x?x:fa[x]=get(fa[x]);}
	void merge(int x,int y){
		int all=-DX[x]+DY[x]-DX[y]+DY[y];
		DX[x]=(DX[x]>DX[x]-DY[x]+DX[y]?DX[x]:DX[x]-DY[x]+DX[y]);
		DY[x]=all+DX[x];
		sz[x]+=sz[y];
	}
	void push(int rt){
		if(DX[rt]<=DY[rt])q1.push(node1{DX[rt],rt,sz[rt]});
		else q2.push(node2{DY[rt],rt,sz[rt]});
	}
	void work(){
		For(i,2,n)if((a[i]>a[i-1]?1:0)^(a[1]<b[1]))DX[i]=0,DY[i]=abs(a[i]-a[i-1]);
		else DY[i]=0,DX[i]=abs(a[i]-a[i-1]);
		For(i,2,m)if((b[i]>b[i-1]?1:0)^(a[1]>b[1]))DX[i+n]=0,DY[i+n]=abs(b[i]-b[i-1]);
		else DY[i+n]=0,DX[i+n]=abs(b[i]-b[i-1]);
		rep(i,n)push(i);
		rep(i,m)push(i+n);
		DX[0]=DY[0]=0;
		while(!q1.empty()||!q2.empty()){
			if(!q1.empty()){
				auto x=q1.top();q1.pop();
				if(x.sz!=sz[x.id]){continue;}
				if(x.id==n+2||x.id==2||get(x.id-1)==0){
					merge(0,x.id);
					fa[x.id]=0;
				}else{
					int rt=get(x.id-1);
					merge(rt,x.id);
					push(rt);
					fa[x.id]=x.id-1;
				}
			}
			else{
				auto x=q2.top();q2.pop();
				if(x.sz!=sz[x.id]){continue;}
				if(x.id==n+2||x.id==2||get(x.id-1)==0){
					merge(0,x.id);
					fa[x.id]=0;
				}else{
					int rt=get(x.id-1);
					merge(rt,x.id);
					push(rt);
					fa[x.id]=x.id-1;
				}
			}
		}
		putchar(abs(a[1]-b[1])-DX[0]>0?'1':'0');
	}
	void solve(){
		RE();work();
		while(q--){
			RE();int kx=read(),ky=read();
			while(kx--){int p=read();a[p]=read();}
			while(ky--){int p=read();b[p]=read();}
			work();
		}
	}
}
bool pppp;
int main(){
//	printf("%.5lf\n",(&pppp-&ppp)/1024.0/1024.0);
//	system("fc expand.out expand3.ans");return 0;
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	C=read(),n=read(),m=read(),q=read();
	rep(i,n)A[i]=read();
	rep(i,m)B[i]=read();
	if(C<=7){brute::solve();return 0;}
	BRUTE::solve();
	return 0;
}

