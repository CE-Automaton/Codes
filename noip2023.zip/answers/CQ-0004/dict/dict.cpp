#include<bits/stdc++.h>
#define For(i,a,b) for(int i=a,i##end=b;i<=i##end;i++)
#define Rof(i,a,b) for(int i=a,i##end=b;i>=i##end;i--)
#define rep(i  ,b) for(int i=1,i##end=b;i<=i##end;i++)
using namespace std;
const int N=3e3+9;
void chmn(int &x,int y){(x>y)&&(x=y);}
void chmx(int &x,int y){(x<y)&&(x=y);}
int read(){
	int f=0,x=0;
	char ch=getchar();
	while(!isdigit(ch)){f|=(ch=='-');ch=getchar();}
	while(isdigit(ch)){x=x*10+ch-'0';ch=getchar();}
	return f?-x:x;
}
int n,m,mx,sx;
char s[N][N];
bool sml(int i,int j){
	rep(k,m)if(s[i][k]>s[j][k])return 0;
	else if(s[i][k]<s[j][k])return 1;
	return 0;
}
int main(){
//	printf("%.5lf\n",(&pppp-&ppp)/1024.0/1024.0);
//	system("fc dict.out dict4.ans");return 0;
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	n=read(),m=read();
	if(n==1){puts("1");return 0;}
	rep(i,n){
		scanf("%s",s[i]+1);
		sort(s[i]+1,s[i]+1+m,[&](char a,char b){return a>b;});
		if(!mx){mx=i;continue;}
		if(sml(i,mx))sx=mx,mx=i;
		else if((!sx)||sml(i,sx))sx=i;
	}
	rep(i,n){
		reverse(s[i]+1,s[i]+1+m);
		if(i==mx)putchar(sml(i,sx)?'1':'0');
		else putchar(sml(i,mx)?'1':'0');
		reverse(s[i]+1,s[i]+1+m);
	}
	return 0;
}

