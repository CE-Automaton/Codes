#include<bits/stdc++.h>
#define For(i,a,b) for(int i=a,i##end=b;i<=i##end;i++)
#define Rof(i,a,b) for(int i=a,i##end=b;i>=i##end;i--)
#define rep(i  ,b) for(int i=1,i##end=b;i<=i##end;i++)
using namespace std;
const int N=2e5+9;
void chmn(int &x,int y){(x>y)&&(x=y);}
void chmx(int &x,int y){(x<y)&&(x=y);}
int read(){
	int f=0,x=0;
	char ch=getchar();
	while(!isdigit(ch)){f|=(ch=='-');ch=getchar();}
	while(isdigit(ch)){x=x*10+ch-'0';ch=getchar();}
	return f?-x:x;
}
int C,T,n,m;
int fa[N],val[N];
int R(int x){
	if(x==2*n+3)return x;
	if(x>2*n)return ((x+1)^1)-1;
	return (x>n?x-n:x+n);
}
int get(int x){return fa[x]==x?x:fa[x]=get(fa[x]);}
vector<int>H[N];int vis[N],sta[N],top;
int main(){
//	system("fc tribool4.ans tribool.out");return 0;
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	C=read(),T=read();
	while(T--){
		n=read(),m=read();int ans=0;
		rep(i,2*n+3)fa[i]=i,val[i]=i,H[i].clear(),vis[i]=0;
		while(m--){
			char c;c=getchar();
			switch(c){
				case 'T':{int i=read();val[i]=2*n+1;break;}
				case 'F':{int i=read();val[i]=2*n+2;break;}
				case 'U':{int i=read();val[i]=2*n+3;break;}
			}
			if(c=='+'){int x=read(),y=read();val[x]=val[y];}
			if(c=='-'){int x=read(),y=read();val[x]=R(val[y]);}
		}
		rep(i,n){
			int x=get(i),y=get(val[i]);
			fa[x]=y;
			x=get(R(i)),y=get(R(val[i]));
			fa[x]=y;
		}
		rep(i,2*n+3)H[get(i)].push_back(i);
		
		if(get(2*n+1)==get(2*n+2))sta[++top]=get(2*n+1);
		sta[++top]=get(2*n+3);
		rep(i,n)if(get(i)==get(i+n))sta[++top]=get(i);
		
		while(top){
			int x=sta[top--];
			if(vis[x])continue;
			for(int y:H[x]){
				if(y<=2*n)sta[++top]=R(y);
				if(y<=n)ans++;
				vis[y]=1;
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}

