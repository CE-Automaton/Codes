#include<bits/stdc++.h>
#define int long long
#define For(i,a,b) for(int i=a,i##end=b;i<=i##end;i++)
#define Rof(i,a,b) for(int i=a,i##end=b;i>=i##end;i--)
#define rep(i  ,b) for(int i=1,i##end=b;i<=i##end;i++)
#define getchar() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<20,stdin),p1==p2)?EOF:*p1++)
using namespace std;
bool ppp;
char buf[1<<21],*p1,*p2;
const int N=2e5+9;
void chmn(int &x,int y){(x>y)&&(x=y);}
void chmx(int &x,int y){(x<y)&&(x=y);}
int read(){
	int f=0,x=0;
	char ch=getchar();
	while(!isdigit(ch)){f|=(ch=='-');ch=getchar();}
	while(isdigit(ch)){x=x*10+ch-'0';ch=getchar();}
	return f?-x:x;
}
int C,cases;
vector<int>A;
int n,m,k,d;
int L[N],R[N],V[N];
struct tree{
	#define ls p<<1
	#define rs p<<1|1
	int nl,tag[N<<3],mx[N<<3];
	void f(int p,int v){tag[p]+=v,mx[p]+=v;}
	void push_down(int p){f(ls,tag[p]);f(rs,tag[p]);tag[p]=0;}
	void add(int p,int l,int r,int v){
		if(A[r-1]<=nl){f(p,v);return;}
		int mid=(l+r)>>1;push_down(p);
		add(ls,l,mid,v);
		if(A[mid-1]<nl)add(rs,mid+1,r,v);
		mx[p]=mx[ls]>mx[rs]?mx[ls]:mx[rs];
		return;
	}
	void clear(){
		memset(tag,0,sizeof tag);
		memset(mx,0xc0,sizeof mx);
	}
	void change(int p,int l,int r,int v){
		if(l==r){mx[p]=v;return;}
		int mid=(l+r)>>1;push_down(p);
		if(mid>=nl)change(ls,l,mid,v);
		else change(rs,mid+1,r,v);
		mx[p]=mx[ls]>mx[rs]?mx[ls]:mx[rs];
		return;
	}
}T;
int id[N];
bool pppp;
signed main(){
//	printf("%.5lf\n",(&pppp-&ppp)/1024.0/1024.0);
//	system("fc run.out run6.ans");return 0;
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	C=read(),cases=read();while(cases--){
		n=read(),m=read(),k=read(),d=read();
		rep(i,m){R[i]=read(),L[i]=R[i]-read()+1,V[i]=read();}
		A.clear();
		rep(i,m){
			A.push_back(L[i]);
			A.push_back(R[i]+1);
			id[i]=i;
		}
		sort(id+1,id+1+m,[&](int i,int j){return R[i]<R[j];});
		sort(A.begin(),A.end());
		A.resize(unique(A.begin(),A.end())-A.begin());
		int mx=0;
		int l=1,j=1;
		T.clear();
		rep(i,A.size()){
			T.nl=i;T.change(1,1,A.size(),mx+d*A[i-1]);
			while(l<=A.size()&&A[i-1]-A[l-1]>k){
				T.nl=l;
				T.change(1,1,A.size(),-1e18);
				l++;//delete
			}
			while(j<=m&&R[id[j]]<A[i-1]){//update
				T.nl=L[id[j]];
				T.add(1,1,A.size(),V[id[j]]);
				j++;
			}
			chmx(mx,T.mx[1]-A[i-1]*d);
		}
		cout<<mx<<endl;
	}
	return 0;
}

