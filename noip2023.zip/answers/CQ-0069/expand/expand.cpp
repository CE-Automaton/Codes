#include<bits/stdc++.h>
using namespace std;
inline int read(){
	char ch=getchar();
	int f=1,x=0;
	while(ch<'0'||ch>'9'){
		if(ch=='-')
			f=-f;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+ch-'0';
		ch=getchar();
	}
	return f*x;
}
inline void work(int k){
	if(k<0){
		k=-k;
		putchar('-');
	}
	if(k>9)
		work(k/10);
	putchar(k%10+'0');
}
/*
�ܳ���
��ͷ��ĩβ��ȿ϶��޽�,���x1<y1,�������xn<yn,��ô��չ�����п϶���fi<gi,��֮��Ȼ
����֤�����xi����ȵ�һ��,��ô��ʱyi�϶���ÿ������ֻ��һ��
�������ǿ���dp,��dp[i][j]��ʾ��ǰx������i,y������j�Ƿ���ڷ���
dp[i][j]|=(dp[i-1][k]|dp[j-1][k])���Ҵ�С��ϵ��ͬ,����һ��O(n^3)�� 
ע�⵽�޸ĵĴ����Ǻ��ٵĿ������������ 
*/
int c,n,m,q,x[500005],y[500005],dp[2005][2005],ans[500005],now,now1;
vector<int> g[2];
struct node{
	int val[2000005];
	void change(int k,int l,int r,int x,int v){
		if(l>x||r<x)
			return ;
		if(l>=x&&r<=x){
			val[k]=v;
			return ;
		}
		int mid=(l+r)>>1;
		change(2*k,l,mid,x,v);
		change(2*k+1,mid+1,r,x,v);
		val[k]=min(val[2*k],val[2*k+1]);
	}
	void change1(int k,int l,int r,int x,int v){
		if(l>x||r<x)
			return ;
		if(l>=x&&r<=x){
			val[k]=v;
			return ;
		}
		int mid=(l+r)>>1;
		change1(2*k,l,mid,x,v);
		change1(2*k+1,mid+1,r,x,v);
		val[k]=max(val[2*k],val[2*k+1]);
	}
	int query(int k,int l,int r,int x,int y){
		if(l>y||r<x)
			return 1e9;
		if(l>=x&&r<=y)
			return val[k];
		int mid=(l+r)>>1;
		return min(query(2*k,l,mid,x,y),query(2*k+1,mid+1,r,x,y));
	}
	int query1(int k,int l,int r,int x,int y){
		if(l>y||r<x)
			return 0;
		if(l>=x&&r<=y)
			return val[k];
		int mid=(l+r)>>1;
		return max(query1(2*k,l,mid,x,y),query1(2*k+1,mid+1,r,x,y));
	}
}tree,tree1,tree2,tree3;
void solve(){
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			dp[i][j]=0;
		}
	}
	if(now==now1)
		return ;
	dp[0][0]=1;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			for(int k=j-1;k>=0;k--){
				if(now<now1){
					if(tree2.query(1,1,m,k+1,j)<=tree.query(1,1,n,i,i))
						break;
				}
				else{
					if(tree3.query1(1,1,m,k+1,j)>=tree.query(1,1,n,i,i))
						break;
				}
				dp[i][j]|=dp[i-1][k];
				if(dp[i][j])
					break;
			}
			for(int k=i-1;k>=0;k--){
				if(now<now1){
					if(tree1.query1(1,1,n,k+1,i)>=tree2.query(1,1,m,j,j))
						break;
				}
				else{
					if(tree.query(1,1,n,k+1,i)<=tree2.query(1,1,m,j,j))
						break;
				}
				dp[i][j]|=dp[k][j-1];
				if(dp[i][j])
					break;
			}
		}
	}
}
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	c=read();
	n=read();
	m=read();
	q=read();
	for(int i=1;i<=n;i++){
		x[i]=read();
		tree.change(1,1,n,i,x[i]);
		tree1.change1(1,1,n,i,x[i]);
	}
	for(int i=1;i<=m;i++){
		y[i]=read();
		tree2.change(1,1,m,i,y[i]);
		tree3.change1(1,1,m,i,y[i]);
	}
	now=x[1];
	now1=y[1];
	if(x[1]==y[1])
		ans[0]=0;
	else{
		solve();
		ans[0]=dp[n][m];
	}
	for(int u=1;u<=q;u++){
		int kx,ky;
		kx=read();
		ky=read();
		for(int i=1,id,v;i<=kx;i++){
			id=read();
			v=read();
			if(id==1)
				now=v;
			tree.change(1,1,n,id,v);
			tree1.change1(1,1,n,id,v);
			g[0].emplace_back(id);
		} 
		for(int i=1,id,v;i<=ky;i++){
			id=read();
			v=read();
			if(id==1)
				now1=v;
			tree2.change(1,1,m,id,v);
			tree3.change1(1,1,m,id,v);
			g[1].emplace_back(id);
		}
		solve();
		ans[u]=dp[n][m];
		for(auto i:g[0]){
			tree.change(1,1,n,i,x[i]);
			tree1.change1(1,1,n,i,x[i]);
		}
		for(auto i:g[1]){
			tree2.change(1,1,m,i,y[i]);
			tree3.change1(1,1,m,i,y[i]);
		}
		now=x[1];
		now1=y[1];
		g[0].clear();
		g[1].clear();
	} 
	for(int i=0;i<=q;i++){
		work(ans[i]);
	}
	return 0;
}
