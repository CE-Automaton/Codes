#include<bits/stdc++.h>
using namespace std;
const int maxn=5e5+5,maxm=2e3+5;
mt19937 RDom(time(0));
int c,n,m,q,X[maxn],Y[maxn],waptag,topX,topY;
bool f[maxm][maxm];//Case For 1~7 Used
pair<int,int> StackX[maxn],StackY[maxn];
bool memdp();//Case For 1~7 Used 
bool tanxin();
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	ios_base::sync_with_stdio(false),cin.tie(nullptr),cout.tie(nullptr);
	cin>>c>>n>>m>>q;
	for(int i=1;i<=n;i++)cin>>X[i];
	for(int i=1;i<=m;i++)cin>>Y[i];
	if(c<=7){
		if(X[1]<Y[1]){
			swap(X,Y),swap(n,m),waptag=1;
		}
		cout<<memdp();
		if(waptag){
			swap(X,Y),swap(n,m),waptag=0;
		}	
		while(q--){
			int kx,ky;
			cin>>kx>>ky;
			for(int i=1,p,v;i<=kx;i++){
				cin>>p>>v,StackX[++topX]=make_pair(p,X[p]),X[p]=v;
			}
			for(int i=1,p,v;i<=ky;i++){
				cin>>p>>v,StackY[++topY]=make_pair(p,Y[p]),Y[p]=v;
			}
			if(X[1]<Y[1]){
				swap(X,Y),swap(n,m),waptag=1;
			}
			cout<<memdp();
			if(waptag){
				swap(X,Y),swap(n,m),waptag=0;
			}
			while(topX){
				X[StackX[topX].first]=StackX[topX].second,topX--;
			}
			while(topY){
				Y[StackY[topY].first]=StackY[topY].second,topY--;
			}
		}
		return 0;
	}else if(c<=14){
		cout<<tanxin();
		while(q--){
			int kx,ky;
			cin>>kx>>ky;
			for(int i=1,p,v;i<=kx;i++){
				cin>>p>>v,StackX[++topX]=make_pair(p,X[p]),X[p]=v;
			}
			for(int i=1,p,v;i<=ky;i++){
				cin>>p>>v,StackY[++topY]=make_pair(p,Y[p]),Y[p]=v;
			}
			cout<<tanxin();
			while(topX){
				X[StackX[topX].first]=StackX[topX].second,topX--;
			}
			while(topY){
				Y[StackY[topY].first]=StackY[topY].second,topY--;
			}
		}
		return 0;
	}else{
		cout<<1;while(q--)cout<<1;
	} 
	return 0;
}
bool memdp(){
	for(int i=0;i<=n+1;i++)for(int j=0;j<=m+1;j++)f[i][j]=false;
	f[0][0]=true;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(X[i]>Y[j]){
				if(X[i-1]>Y[j]){
					f[i][j]|=f[i-1][j];
				}
				if(X[i]>Y[j-1]){
					f[i][j]|=f[i][j-1];
				}
				f[i][j]|=f[i-1][j-1];
			}
		}
	}
	return f[n][m];
}
bool tanxin(){
	return false;
}
