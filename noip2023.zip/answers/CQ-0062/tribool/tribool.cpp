#include<bits/stdc++.h>
using namespace std;
#define endl "\n" 
const int maxn=1e5+5;
int CaseKind,T,n,m,val[maxn<<1],vis[maxn<<1];
void DFSVAL(int u,int fan);
int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	ios_base::sync_with_stdio(false),cin.tie(nullptr),cout.tie(nullptr);
	cin>>CaseKind>>T;
	while(T--){
		cin>>n>>m;
		for(int i=1;i<=(n<<1);i++){
			val[i]=i,vis[i]=0;
		}
		while(m--){
			char op;cin>>op;while(op!='-'&&op!='+'&&op!='T'&&op!='F'&&op!='U')cin>>op;
			int a,b;
			if(op=='-'){
				cin>>a>>b;
				if(a!=b)val[a]=val[b+n],val[a+n]=val[b];
				else{
					swap(val[a],val[a+n]);//����Ǹ���� 
				}
			}
			if(op=='+'){
				cin>>a>>b;
				val[a]=val[b],val[a+n]=val[b+n];
			}
			if(op=='T'){
				cin>>a;
				val[a]=-2,val[a+n]=-1;
			}
			if(op=='F'){
				cin>>a;
				val[a]=-1,val[a+n]=-2;
			}
			if(op=='U'){
				cin>>a;
				val[a]=val[a+n]=0;
			}
		}
		int ans=0;
		for(int i=1;i<=n;i++){
			DFSVAL(i,1);
			if(val[i]==0){
				ans++;
			}
		}
		cout<<ans<<endl;
	}
	return 0;
}
void DFSVAL(int u,int fan){//��ǰ��u�Žڵ㲢���Ͻڵ����ʼ�����/�½ڵ���ͨ 
	if(val[u]<=0){
		return;
	}
	if(vis[u]!=0){
		if(vis[u]!=fan){
			val[u]=val[u+n]=0;
		}else{
			val[u]=-1,val[u+n]=-2;
		}
		return;
	}
	vis[u]=fan;
	if(val[u]<=n){
		int v=val[u];
		DFSVAL(v,fan),val[u]=val[v],val[u+n]=val[v+n];
	}else{
		int v=val[u]-n,fanv=(fan==1?2:1);
		DFSVAL(v,fanv),val[u]=val[v+n],val[u+n]=val[v];//���ﲻ��swap����Ϊ���v��u����ˣ������Ƿ��ŵģ���ôvalһ����U 
	}
}
