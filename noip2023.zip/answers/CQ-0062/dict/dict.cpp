#include<bits/stdc++.h>
using namespace std;
const int maxn=3e3+5;
int n,m;
string s[maxn],Min1,Min2;
bool cmp(char a,char b);
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	ios_base::sync_with_stdio(false),cin.tie(nullptr),cout.tie(nullptr);
	cin>>n>>m,Min1.resize(m),Min2.resize(m);
	for(int i=0;i<m;i++){
		Min1[i]=Min2[i]='z'+1;
	}
	for(int i=1;i<=n;i++){
		cin>>s[i],sort(s[i].begin(),s[i].end(),cmp);
		if(s[i]<=Min1){
			Min2=Min1,Min1=s[i];
		}else if(s[i]<Min2){
			Min2=s[i];
		}
		sort(s[i].begin(),s[i].end());
	}
	for(int i=1;i<=n;i++){
		if(s[i]>Min1||(s[i]==Min1&&s[i]==Min2)){
			cout<<0;
		}else{
			cout<<1;
		}
	}
	return 0;
}
bool cmp(char a,char b){
	return a>b;
}
