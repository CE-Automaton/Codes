#include<bits/stdc++.h>
using namespace std;
const long long maxn=1e5+5,maxm=2e3+5;
struct Chal{
	long long l,r,v;
}a[maxn];
long long c,t,n,m,k,d,lisa[maxn],Cnt,f[maxn],valsum[maxm][maxm];
int main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	ios_base::sync_with_stdio(false),cin.tie(nullptr),cout.tie(nullptr);
	cin>>c>>t;
	while(t--){
		cin>>n>>m>>k>>d,Cnt=0;
		for(long long i=1;i<=m;i++){
			cin>>a[i].r>>a[i].l>>a[i].v,a[i].l=a[i].r-a[i].l+1,lisa[++Cnt]=a[i].l,lisa[++Cnt]=a[i].r;
		}
		sort(lisa+1,lisa+1+Cnt),Cnt=unique(lisa+1,lisa+1+Cnt)-(lisa+1);
		for(long long i=0;i<=Cnt;i++){
			for(long long j=0;j<=Cnt;j++){
				valsum[i][j]=0;
			}
			f[i]=0;
		}
		for(long long i=1;i<=m;i++){
			a[i].l=lower_bound(lisa+1,lisa+1+Cnt,a[i].l)-lisa,a[i].r=lower_bound(lisa+1,lisa+1+Cnt,a[i].r)-lisa,valsum[a[i].l][a[i].r]+=a[i].v;
		}
		for(long long i=Cnt;i>=1;i--){
			for(long long j=i;j<=Cnt;j++){
				valsum[i][j]+=valsum[i+1][j]+valsum[i][j-1]-valsum[i+1][j-1];
			}
		}
		lisa[0]=-114514;
		for(long long i=1;i<=Cnt;i++){
			for(long long j=1;j<=i;j++){
				if(lisa[i]-lisa[j]+1>k)continue;
				if(lisa[j-1]+1==lisa[j]){
					f[i]=max(f[i],f[j-2]+valsum[j][i]-d*(lisa[i]-lisa[j]+1));
				}else{
					f[i]=max(f[i],f[j-1]+valsum[j][i]-d*(lisa[i]-lisa[j]+1));
				}
			}
			f[i]=max(f[i],f[i-1]);
		}
		cout<<f[Cnt]<<endl;
	}
	return 0;
}
