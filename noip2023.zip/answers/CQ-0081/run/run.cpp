#include<bits/stdc++.h>
#define ll long long
using namespace std;
namespace noipshik{
	const int N=2e5+5;
	int l[N],r[N],v[N],a[N];
	ll f[N],ma[N];
	vector<int>p[N];
	inline char gc()
	{
		static char buf[1<<16],*S,*T;
		if(S==T)
		{
			T=(S=buf)+fread(buf,1,1<<16,stdin);
			if(S==T)return EOF;
		}
		return *(S++);
	}
	#define getchar gc
	inline ll read()
	{
		char h=getchar();
		ll y=0;int q=1;
		while(h<'0'||h>'9'){if(h=='-')q=-1;h=getchar();}
		while(h>='0'&&h<='9')y=y*10+h-'0',h=getchar();
		return y*q;
	}
	namespace seg 
	{
		struct node{
			int l,r;ll v,f;
		}q[N<<2];
		#define lc (x<<1)
		#define rc ((x<<1)|1)
		inline void pushup(int x){q[x].v=max(q[lc].v,q[rc].v);}
		void build(int x,int l,int r)
		{
			q[x].l=l;q[x].r=r;q[x].v=q[x].f=0;
			if(l==r)return;
			int m=(l+r)>>1;
			build(lc,l,m);build(rc,m+1,r);
		}
		inline void ad(int x,ll v){q[x].v+=v;q[x].f+=v;}
		inline void pushdown(int x)
		{
			if(q[x].f)ad(lc,q[x].f),ad(rc,q[x].f),q[x].f=0;
		}
		void modify(int x,int p,ll v)
		{
			if(q[x].r<p||q[x].l>p)return;
			if(q[x].l==q[x].r)return (void)(q[x].v=v);
			pushdown(x);
			modify(lc,p,v);modify(rc,p,v);
			pushup(x);
		}
		void add(int x,int l,int r,ll v)
		{
			if(q[x].r<l||q[x].l>r)return;
			if(q[x].l>=l&&q[x].r<=r)return (void)ad(x,v);
			pushdown(x);
			add(lc,l,r,v);add(rc,l,r,v);
			pushup(x);
		}
		ll query(int x,int l,int r)
		{
			if(q[x].r<l||q[x].l>r)return 0;
			if(q[x].l>=l&&q[x].r<=r)return q[x].v;
			pushdown(x);
			return max(query(lc,l,r),query(rc,l,r));
		}
	}
	int main()
	{
//		freopen("run5.in","r",stdin);
//		freopen("run6.in","r",stdin);
		freopen("run.in","r",stdin);
		freopen("run.out","w",stdout);
		read();int t=read();
		while(t--)
		{//�ǵ���� 
		//��д��min(n,m) min(n,m,k)�ı��� 
		//�Ż�ֱ���߶��������� ?
			read();int n=read(),lim=read(),d=read();//ԭ���n���ã����Բ����ˣ�ԭ���m�������n 
			for(int i=1;i<=n;i++)r[i]=read(),l[i]=read(),v[i]=read(),l[i]=r[i]-l[i]+1,a[i]=l[i],a[i+n]=r[i];
//			for(int i=1;i<=n;i++)cout<<l[i]<<" "<<r[i]<<" "<<v[i]<<"!!\n";
			sort(a+1,a+1+(n<<1));
			int m=unique(a+1,a+1+(n<<1))-a-1;
			for(int i=1;i<=n;i++)l[i]=lower_bound(a+1,a+1+m,l[i])-a,r[i]=lower_bound(a+1,a+1+m,r[i])-a,p[r[i]].push_back(i);
			seg::build(1,1,m);
			for(int i=1;i<=m;i++)
			{
				seg::modify(1,i,(i==1?0:(a[i]==a[i-1]+1?ma[i-2]:ma[i-1]))+1ll*(a[i]-1)*d);
				for(int j=0;j<p[i].size();j++)seg::add(1,1,l[p[i][j]],v[p[i][j]]);
				int p=lower_bound(a+1,a+1+i,a[i]+1-lim)-a;
				f[i]=max(0ll,seg::query(1,p,i)-1ll*a[i]*d);
				ma[i]=max(ma[i-1],f[i]);
//				cout<<i<<" "<<f[i]<<"!!\n";
			}
			cout<<ma[m]<<"\n";
			for(int i=1;i<=m;i++)f[i]=ma[i]=0,p[i].clear();
		}
		return 0;
	}
}
int main(){return noipshik::main();}
/*
0 1
114 4 114 1
3 2 2
6 2 2
7 1 3
9 1 4

5


fc F:\CQ-0081\run.out F:\CQ-0081\run1.ans
*/
