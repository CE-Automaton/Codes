#include<bits/stdc++.h>
#define ll long long
using namespace std;
namespace noipshik{
	const int N=5e5+5,inf=1e9;
	int ya[N],yb[N],a[N],b[N],f[N],g[N],sf[N],sg[N],st1[N],st2[N];
	vector<int>ans;
	inline char gc()
	{
		static char buf[1<<16],*S,*T;
		if(S==T)
		{
			T=(S=buf)+fread(buf,1,1<<16,stdin);
			if(S==T)return EOF;
		}
		return *(S++);
	}
	#define getchar gc
	inline ll read()
	{
		char h=getchar();
		ll y=0;int q=1;
		while(h<'0'||h>'9'){if(h=='-')q=-1;h=getchar();}
		while(h>='0'&&h<='9')y=y*10+h-'0',h=getchar();
		return y*q;
	}
	inline bool check2(int n,int m)
	{
		if(n==0)return 1;
		if(f[1]<=g[1])return 0;
		sf[0]=sg[0]=inf;
		for(int i=1;i<=n;i++)sf[i]=min(sf[i-1],f[i]);
		for(int i=1;i<=m;i++)sg[i]=min(sg[i-1],g[i]);
		int t1=0,t2=0;
		for(int i=n;i;i--)
		{
			while(t1&&f[i]>=f[st1[t1]])t1--;
			st1[++t1]=i;
		}
		for(int i=m;i;i--)
		{
			while(t2&&g[i]>=g[st2[t2]])t2--;
			st2[++t2]=i;
		}
//		for(int i=1;i<=n;i++)cout<<f[i]<<" ";cout<<"!!\n";
//		for(int i=1;i<=m;i++)cout<<g[i]<<" ";cout<<"!!\n";
		reverse(st1+1,st1+t1+1);reverse(st2+1,st2+t2+1);
//		for(int i=1;i<=t2;i++)cout<<st2[i]<<" ";cout<<"!****\n";
		st2[t2+1]=m+1;
		for(int i=1,j=1;i<t1;i++)//������f1<=g1,���Կ���ֱ��j=1 
		{
			while(j<=t2&&g[st2[j]]<f[st1[i]])j++;
//			cout<<st1[i]<<" "<<j<<" "<<st2[j]-1<<"!!\n";
			if(sf[st1[i+1]-1]<=sg[st2[j]-1])return 0;
		}
		return 1;
	}
	inline bool check(int Nn,int Mm)
	{
		int ma1=0,ma2=0,n,m;
		for(int i=1;i<=Nn;i++)ma1=max(ma1,f[i]=a[i]);
		for(int i=1;i<=Mm;i++)ma2=max(ma2,g[i]=b[i]);
		if(ma1==ma2)return 0;
		if(ma1>ma2)n=Nn,m=Mm;
		else
		{
			n=Mm,m=Nn;
			for(int i=1;i<=n;i++)f[i]=b[i];
			for(int i=1;i<=m;i++)g[i]=a[i];
		}
//		for(int i=1;i<=n;i++)cout<<f[i]<<" ";cout<<"!!\n";
//		for(int i=1;i<=m;i++)cout<<g[i]<<" ";cout<<"!!\n";
		int p=1;
		for(int i=2;i<=n;i++)if(f[i]>f[p])p=i;
		bool fl=check2(p,m);
		if(!fl)return 0;
		reverse(f+1,f+1+n);reverse(g+1,g+1+m);
		return check2(n-p+1,m);
	}
	int main()
	{
//		freopen("expand4.in","r",stdin);
		freopen("expand.in","r",stdin);
		freopen("expand.out","w",stdout);
		read();int n=read(),m=read();int q=read();
		for(int i=1;i<=n;i++)ya[i]=a[i]=read();
		for(int i=1;i<=m;i++)yb[i]=b[i]=read();
		ans.push_back(check(n,m));
		while(q--)
		{
			int x=read(),y=read(),z;
			for(int i=1;i<=n;i++)a[i]=ya[i];
			for(int i=1;i<=m;i++)b[i]=yb[i];
			while(x--)z=read(),a[z]=read();
			while(y--)z=read(),b[z]=read();
//			if(ans.size()==1)
//			{
//				for(int i=1;i<=n;i++)cout<<a[i]<<" ";cout<<"!!\n";
//				for(int i=1;i<=m;i++)cout<<b[i]<<" ";cout<<"!!\n";
//			}
			ans.push_back(check(n,m));
		}
		for(int i=0;i<ans.size();i++)cout<<ans[i];
		return 0;
	}
}
int main(){return noipshik::main();}
/*
7 10 1 9 5 3 
8 11 2 12 4 6

1


10 7 4 12 2 5
6 8 1 11 9 3

0




3 6 11 1 9 5
8 4 12 2 7 10

195982977 303897138 437154869 81559605 365511323 302808478
342942401 297976421 445071632 83871721 304067809 427239638

1
*/
