#include<bits/stdc++.h>
#define ll long long
using namespace std;
namespace noipshik{
	const int N=3005,M=30;
	int a[N][N],b[N],s[N][M];
	int m;
	inline char gc()
	{
		static char buf[1<<16],*S,*T;
		if(S==T)
		{
			T=(S=buf)+fread(buf,1,1<<16,stdin);
			if(S==T)return EOF;
		}
		return *(S++);
	}
	#define getchar gc
	inline ll read()
	{
		char h=getchar();
		ll y=0;int q=1;
		while(h<'0'||h>'9'){if(h=='-')q=-1;h=getchar();}
		while(h>='0'&&h<='9')y=y*10+h-'0',h=getchar();
		return y*q;
	}
	inline int readc()
	{
		char h=getchar();
		while(h<'a'||h>'z')h=getchar();
		return h-'a'+1;
	}
	inline bool cmp(int a[],int b[])//�ж��Ƿ�a<b 
	{
		for(int i=1;i<=m;i++)if(a[i]!=b[i])return a[i]<b[i];
		return 0;
	}
	int main()
	{
//		freopen("dict4.in","r",stdin);
		freopen("dict.in","r",stdin);
		freopen("dict.out","w",stdout);
		int n=read();m=read();
		for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)s[i][readc()]++;
		for(int i=1;i<=n;i++)
		{
			int t=0;
			for(int j=26;j;j--)
			for(int z=1;z<=s[i][j];z++)a[i][++t]=j;
		}
		int p=1;
		for(int i=2;i<=n;i++)if(cmp(a[i],a[p]))p=i;
		for(int i=1;i<=m;i++)b[i]=a[p][i];
		for(int i=1;i<=n;i++)
		{
			int t=0;
			for(int j=1;j<=26;j++)
			for(int z=1;z<=s[i][j];z++)a[i][++t]=j;
			cout<<(i==p||cmp(a[i],b));
		}
		return 0;
	}
}
int main(){return noipshik::main();}
