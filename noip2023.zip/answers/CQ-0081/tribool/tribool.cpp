#include<bits/stdc++.h>
#define ll long long
using namespace std;
namespace noipshik{
	const int N=1e5+5;
	inline char gc()
	{
		static char buf[1<<16],*S,*T;
		if(S==T)
		{
			T=(S=buf)+fread(buf,1,1<<16,stdin);
			if(S==T)return EOF;
		}
		return *(S++);
	}
	#define getchar gc
	inline ll read()
	{
		char h=getchar();
		ll y=0;int q=1;
		while(h<'0'||h>'9'){if(h=='-')q=-1;h=getchar();}
		while(h>='0'&&h<='9')y=y*10+h-'0',h=getchar();
		return y*q;
	}
	inline char readc()
	{
		char h=getchar();
		while(h!='T'&&h!='F'&&h!='U'&&h!='+'&&h!='-')h=getchar();
		return h;
	}
	struct ty{
		int a,b;//a=0:b   a=1:!b   a=2/3/4:T/F/U
	}a[N];
	inline ty nt(ty x)
	{
		if(x.a<=3)return (ty){x.a^1,x.b};
		else return x;
	}
	struct edge{
		int x,y,z;
	}g[N];
	int k[N],fa[N];
	bool v[N],v2[N];
	int su=0,s=0;
	inline void add(int a,int b,int c){g[++su]=(edge){k[a],b,c};k[a]=su;}
	void dfs1(int x)
	{
		s++;v[x]=1;
		for(int i=k[x];i;i=g[i].x)if(!v[g[i].y])dfs1(g[i].y);
	}
	int main()
	{
//		freopen("tribool4.in","r",stdin);
		freopen("tribool.in","r",stdin);
		freopen("tribool.out","w",stdout);
		read();int t=read();
		while(t--)
		{//�ǵ���� 
			int n=read(),m=read(),ans=0;
			for(int i=1;i<=n;i++)a[i]=(ty){0,i};
			for(int i=1;i<=n;i++)v[i]=v2[i]=0;
			while(m--)
			{
				char v=readc();int x=read();
				if(v=='T')a[x]=(ty){2,0};
				else if(v=='F')a[x]=(ty){3,0};
				else if(v=='U')a[x]=(ty){4,0};
				else if(v=='+')a[x]=a[read()];
				else a[x]=nt(a[read()]);
			}
			for(int i=1;i<=n;i++)if(a[i].a<=1)add(fa[i]=a[i].b,i,a[i].a);
			for(int i=1;i<=n;i++)if(a[i].a>1)s=0,dfs1(i),ans+=s*(a[i].a!=4);
			for(int i=1;i<=n;i++)if(!v[i])
			{
				int x=fa[i],st,cnt=0;v2[i]=1;
				while(!v2[x])v2[x]=1,x=fa[x];
				st=x;cnt+=a[x].a;x=fa[x];
				while(x!=st)cnt+=a[x].a,x=fa[x];
				s=0;dfs1(st);
				if((cnt&1)==0)ans+=s;
			}
			cout<<n-ans<<"\n";
			for(int i=1;i<=n;i++)k[i]=0;
			su=0;
		}
		return 0;
	}
}
int main(){return noipshik::main();}
/*
fc F:\CQ-0081\tribool.out F:\CQ-0081\tribool2.ans
*/ 
