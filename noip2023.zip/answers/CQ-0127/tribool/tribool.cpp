#include <bits/stdc++.h>
#define ll long long
using namespace std;

namespace IO{
	template<typename T>
	inline void qread(T &x){
		x=0;char ch;bool f=0;
		while((ch=getchar())&&(ch<'0'||ch>'9')) if(ch=='-') f=1;x=(ch^48);
		while((ch=getchar())&&(ch<='9'&&ch>='0')) x=(x<<1)+(x<<3)+(ch^48);
		x=f?-x:x;
	}
	template<typename T>
	inline void write(T x){
		if(x<0) putchar('-'),x=-x;
		if(x>9) write(x/10);
		putchar('0'+x%10);
	}
}
using namespace IO;

/*
ͼ����ؼ������ݽṹά��

Ӧ���� 2-SAT ���߲��鼯֮��� 

���漰�˷������Կ� int 

���� Tid ������ƭ�֣���ð� 

����ȷ����ͼ�ۣ��ͻ��й�ϵ 
*/ 

const int Maxn=1e5+7;
int Tid,T;
int n,Q,col[Maxn];
vector<pair<int,int> >e[Maxn];
struct node{
	char opt;
	int x,y;
}a[Maxn];

bool suki;
int sz=0;

void DFSCOL(int u,int cl){
	sz++;
	if(col[u]){if(col[u]!=cl)suki=1;}
	col[u]=cl;
	for(auto i:e[u]){
		int v=i.first,w=i.second;	
		if(!col[v]&&w){
			int nxtcl=cl==1?2:1;
			DFSCOL(v,nxtcl);
		}
		else if(!col[v]&&!w){
			DFSCOL(v,cl);
		}
		else if(w){
			if(col[v]==col[u]) suki=1;
		}
		else if(!w){
			if(col[v]!=col[u]) suki=1;
		}
	}
}

inline void init(){
	memset(a,0,sizeof a);
	memset(col,0,sizeof col);
	for(int i=0;i<=Maxn-7;i++) e[i].resize(0);
}


int ccpp[30],ccy,copy_ccpp[30];

inline int To(int x){
	if(x==3) return 3;
	if(x==1) return 2;
	return 1;
}

inline void doit(int mp[]){
	for(int i=1;i<=Q;i++){
		if(a[i].opt=='+') mp[a[i].x]=mp[a[i].y];
		else if(a[i].opt=='-') mp[a[i].x]=To(mp[a[i].y]);
		else{
			if(a[i].opt=='U') mp[a[i].x]=3;
			if(a[i].opt=='F') mp[a[i].x]=1;
			if(a[i].opt=='T') mp[a[i].x]=2;
		}
	}
}

inline int GetANS(){
	for(int i=1;i<=n;i++) copy_ccpp[i]=ccpp[i];
	doit(copy_ccpp);
	for(int i=1;i<=n;i++) if(copy_ccpp[i]!=ccpp[i]) return 1e9;
	int pp=0;
	for(int i=1;i<=n;i++) if(copy_ccpp[i]==3) ++pp;
	return pp;
}


int ans,fff[Maxn],root;

inline int qfind(int key){
	return key==fff[key]?key:fff[key]=qfind(fff[key]);
}
inline void Merge(int x,int y){
	int qx=qfind(x),qy=qfind(y);
	if(qx==qy) return ;
	if(qx==root)fff[qy]=qx;
	else if(qy==root)fff[qx]=qy;
	else fff[qx]=qy;
}

void DFS_ans(int ps){
	if(ps>n){
		ans=min(ans,GetANS());
		return ;
	}
	for(int i=1;i<=3;i++){
		ccpp[++ccy]=i;
		DFS_ans(ps+1);
		--ccy;
	}
}

int jini[Maxn];

int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);

	scanf("%d%d",&Tid,&T);
	
	while(T--){
		scanf("%d%d",&n,&Q);
		
		init();
		// ����ռ�����
		
		
		for(int i=1;i<=Q;i++){
			cin>>a[i].opt;
			scanf("%d",&a[i].x);
			if(a[i].opt=='-'||a[i].opt=='+') scanf("%d",&a[i].y);
		}
		
		if(Tid>=1&&Tid<=2){
			ans=1e9;
			DFS_ans(1);
			printf("%d\n",ans);
		}
		if(Tid>=3&&Tid<=4){
			for(int i=1;i<=n;i++) jini[i]=0;
			for(int i=1;i<=Q;i++){
				if(a[i].opt=='U') jini[a[i].x]=1;
			}
			ans=0;
			for(int i=1;i<=n;i++) if(jini[i]) ans++;
			printf("%d\n",ans);
		}
		if(Tid>=5&&Tid<=6){
			for(int i=1;i<=n;i++) fff[i]=i,jini[i]=0;
			
			root=0;
			
			for(int i=1;i<=Q;i++){
				if(a[i].opt=='U'){
					jini[a[i].x]=1;
				}
				else{
					jini[a[i].x]=jini[a[i].y];
				}
			}
			
			ans=0;
			for(int i=1;i<=n;i++){
				if(jini[i]) ans++;
			}
			printf("%d\n",ans);
		}
		if(Tid>=7){
			for(int i=Q;i;i--){
				if(a[i].opt=='+'){
					bool flg=0;
					for(auto v:e[a[i].x]) if(v.first==a[i].y) flg=1;
					if(!flg) e[a[i].x].emplace_back(a[i].y,0),e[a[i].y].emplace_back(a[i].x,0);
				}
				if(a[i].opt=='-'){
					bool flg=0;
					for(auto v:e[a[i].x]) if(v.first==a[i].y) flg=1;
					if(!flg) e[a[i].x].emplace_back(a[i].y,1),e[a[i].y].emplace_back(a[i].x,1);
				}
			}
			ans=0;
			for(int i=1;i<=n;i++)
				if(!col[i]){
					suki=0;sz=0;//cout<<"hel\n";
					DFSCOL(i,1);
					
					if(suki) ans+=sz;
				}
			printf("%d\n",ans);		
		}
		
		
		
	
	}
	

	return 0;
}

/*
1 3
3 3
- 2 1
- 3 2
+ 1 3
3 3
- 2 1
- 3 2
- 1 3
2 2
T 2
U 2

1 1
4 5
- 2 1
+ 3 2
- 1 3
- 2 4
+ 1 4

*/
