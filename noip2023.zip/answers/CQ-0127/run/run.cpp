#include <bits/stdc++.h>
#define ll long long
using namespace std;

namespace IO{
	template<typename T>
	inline void qread(T &x){
		x=0;char ch;bool f=0;
		while((ch=getchar())&&(ch<'0'||ch>'9')) if(ch=='-') f=1;x=(ch^48);
		while((ch=getchar())&&(ch<='9'&&ch>='0')) x=(x<<1)+(x<<3)+(ch^48);
		x=f?-x:x;
	}
	template<typename T>
	inline void write(T x){
		if(x<0) putchar('-'),x=-x;
		if(x>9) write(x/10);
		putchar('0'+x%10);
	}
}
using namespace IO;

/*
Ӧ�ÿ��������һ�°�

ģ���˻� 
*/

const ll Maxn=1e5+7;
ll Tid,T;
ll n,m,k,d,ans;
ll cyt[20];

struct node{
	int x,y,v;
}a[Maxn];

int main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	
	scanf("%lld%lld",&Tid,&T);
	
	while(T--){
		scanf("%lld%lld%lld%lld",&n,&m,&k,&d);
		
		for(int i=1;i<=m;i++) scanf("%lld%lld%lld",&a[i].x,&a[i].y,&a[i].v);
		
		if(Tid<=2){
			ll res=0;
			for(ll i=0;i<(1<<n);i++){
				res=0;
				bool flg=0;
				for(ll j=0;j<n;j++){
					if(i>>j&1) cyt[j+1]=1,res-=d;
					else cyt[j+1]=0;
				}
				for(ll j=1;j<=n;j++){
					if(cyt[j-1]==1) cyt[j]+=cyt[j-1];
					if(cyt[j]>k) flg=1;
				}
				if(flg) continue;
//				cout<<"test\n";
//				for(ll j=1;j<=n;j++) cout<<cyt[j]<<" ";
//				cout<<endl;
				
				for(ll j=1;j<=m;j++){
					if(cyt[a[j].x]>=a[j].y) res+=a[j].v;
				}
				//cout<<i<<' '<<res<<endl;
				ans=max(ans,res);
			}
			printf("%lld\n",ans);
		}
		else{
			ans=0;
			for(int i=1;i<=m;i++){
				if(a[i].y>k) continue;
				ans+=max(0ll,a[i].v-a[i].y*d);
			}
			printf("%lld\n",ans);
		}
		
	}
	
	return 0;
}
/*
1 1
3 2 2 1
2 2 4
3 2 3

*/
