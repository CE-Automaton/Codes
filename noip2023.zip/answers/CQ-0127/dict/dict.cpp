#include <bits/stdc++.h>
#define ll long long
using namespace std;

namespace IO{
	template<typename T>
	inline void qread(T &x){
		x=0;char ch;bool f=0;
		while((ch=getchar())&&(ch<'0'||ch>'9')) if(ch=='-') f=1;x=(ch^48);
		while((ch=getchar())&&(ch<='9'&&ch>='0')) x=(x<<1)+(x<<3)+(ch^48);
		x=f?-x:x;
	}
	template<typename T>
	inline void write(T x){
		if(x<0) putchar('-'),x=-x;
		if(x>9) write(x/10);
		putchar('0'+x%10);
	}
}
using namespace IO;

/*
Ӧ����ֱ��ģ�� 

�� int ���� 

�ܵ��̰�ģ���������� 
*/

const int Maxn=3e3+7;
int n,m;
string S[Maxn];
inline bool cmp1(char x,char y){
	return x<y;
}
inline bool cmp2(char x,char y){
	return x>y;
}

int cnt;
struct node{
	string s;
	int id;
	bool flg;
}t[Maxn<<1];

inline bool cmp3(node x,node y){
	if(x.s==y.s){
		return x.flg<y.flg;
	}
	return x.s<y.s;
}

bool ans[Maxn];

int main(){
	//freopen("dict.in","r",stdin);
	//freopen("dict.out","w",stdout);
	
	//freopen("love.in","r",stdin);
	//freopen("love.out","w",stdout); 
	
	//frepen("dict.in","r",stdin);
	//freopen("dict.out","w",stdout);
	
	//frepoen("dict.in","r",stdin);
	//freopen("dict.out","w",stdout);
	
	//freopen("dict.in","r",stdin);
	//freopen("dict.out","w",stdout);
	
	//freopen("dict.in","r",stdin);
	//freopen("dict.out","w",stdout);
	
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		cin>>S[i];
		string x=S[i];
		sort(x.begin(),x.end(),cmp1);
		t[++cnt]=(node){x,i,0};
		sort(x.begin(),x.end(),cmp2);
		t[++cnt]=(node){x,i,1};
	}
	
	sort(t+1,t+cnt+1,cmp3);
	
	/*
	��ÿ���ַ�������һ�飬ʱ�临�Ӷ� O(n)�������ϴ� 
	*/
	
//	printf("test\n");
//	for(int i=1;i<=n;i++){
//		 cout <<"catch "<< t[i].s<<endl;
//	}
	
	int i=cnt,res=0;
	for(;i;i--){
		res+=t[i].flg;
		if(res==n) break;
	}
	for(i=i-1;i;i--){
		if(t[i].flg==0) ans[t[i].id]=1;
	}
	
	for(int i=1;i<=n;i++){
		cout<<ans[i];
	}
	
	return 0;
} 


/*
4 7
abandon
bananaa
baannaa
notnotn

15 2
zx
qn
wn
nd
pl
pd
vm
ff
mh
ql
zi
yv
md
ji
oc

*/
