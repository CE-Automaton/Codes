#include <bits/stdc++.h>
#define ll long long
using namespace std;

namespace IO{
	template<typename T>
	inline void qread(T &x){
		x=0;char ch;bool f=0;
		while((ch=getchar())&&(ch<'0'||ch>'9')) if(ch=='-') f=1;x=(ch^48);
		while((ch=getchar())&&(ch<='9'&&ch>='0')) x=(x<<1)+(x<<3)+(ch^48);
		x=f?-x:x;
	}
	template<typename T>
	inline void write(T x){
		if(x<0) putchar('-'),x=-x;
		if(x>9) write(x/10);
		putchar('0'+x%10);
	}
}
using namespace IO;

/*
���������� poly(log) �Ķ�����Ӧ����ĳ����������ݽṹ

�������������̯ʱ�临�Ӷ� 

Ӧ���Ǳ����޸ģ�ֱ�� O(n) ������ϣ�������� O(nlog n) 

�������еĳ��Ȳ��ᳬ�� 2(n+m) 

ʱ�临�Ӷ� O((n+m)q) 
*/


const int Maxn=5e5+7;
int c,n,m,q,x[Maxn],y[Maxn],yuanx[Maxn],yuany[Maxn];
int premax[Maxn],premin[Maxn];

inline void init(){
	for(int i=1;i<=n;i++) premax[i]=premin[i]=0;
	for(int i=1;i<=n;i++){
		premax[i]=premax[i-1];
		if(x[premax[i]]<x[i]) premax[i]=i;
	}
	x[0]=1e9;
	for(int i=1;i<=n;i++){
		premin[i]=premin[i-1];
		if(x[premin[i]]>x[i]) premin[i]=i;
	}
	x[0]=0;
}

inline void solve(void){
	if(x[1]>y[1]){
		int j=1;
		for(int i=1;i<=n;i++){
			if(j>m) j=m; 
			if(x[i]>y[j]){
				++j;
				continue;
			}
			if(x[i]<=y[j]){
				if(x[i-1]>y[j]){
					i--,j++;
				}
//				else if(x[premax[i]]>y[j]){
//					i=premax[i];
//					j++;
//				}
				else{
					printf("0");
					return ;
				}
			}
		}
		printf("1");
	}
	if(x[1]<y[1]){
		int j=1;
		for(int i=1;i<=n;i++){
			if(j>m) j=m;
			if(x[i]<y[j]){
				++j;
				continue;
			}
			if(x[i]>=y[j]){
				if(x[i-1]<y[j]){
					i--,j++;
				}
//				else if(x[premin[i]]<y[j]){
//					i=premin[i];
//					j++;
//				}
				else{
					printf("0");
					return ;
				}
			}
		}	
		printf("1"); 
	}
	if(x[1]==y[1]){
		printf("0");
	}
	return ;
}

inline void Slovr(){
	for(int i=1;i<=n;i++) premax[i]=0;
	for(int i=1;i<=m;i++){
		premax[i]=max(premax[i-1],y[i]);
	}
	bool flg=1;
	for(int i=1;i<=m;i++) if(y[i]<=x[n]){
		flg=0;
		break;
	}
	for(int i=1;i<=n;i++){
		if(x[i]<y[i]) continue;
		if(x[i]<premax[i]) continue;
		flg=0;
	}
	cout<<flg;
	
}

int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);

	scanf("%d%d%d%d",&c,&n,&m,&q);
	for(int i=1;i<=n;i++){
		scanf("%d",&x[i]);
		yuanx[i]=x[i];
	}
	for(int i=1;i<=m;i++){
		scanf("%d",&y[i]);
		yuany[i]=y[i];
	}
	
	if(c<=7||c>=15){
		 init();
	
	solve();
	while(q--){
		int kx,ky;
		scanf("%d%d",&kx,&ky);
		while(kx--){
			int p,v;
			scanf("%d%d",&p,&v);
			x[p]=v;
		}
		while(ky--){
			int p,v;
			scanf("%d%d",&p,&v);
			y[p]=v;
		}
		
		init();
//		cout<<endl;
//		for(int i=1;i<=n;i++) cout<<x[i]<<" ";
//		cout<<endl;
		solve();
		for(int i=1;i<=n;i++) x[i]=yuanx[i];
		
		for(int j=1;j<=m;j++) y[j]=yuany[j];
	}
	return 0;
	}
	else{
		Slovr();
		while(q--){
		int kx,ky;
		scanf("%d%d",&kx,&ky);
		while(kx--){
			int p,v;
			scanf("%d%d",&p,&v);
			x[p]=v;
		}
		while(ky--){
			int p,v;
			scanf("%d%d",&p,&v);
			y[p]=v;
		}
		
		Slovr(); 

		for(int i=1;i<=n;i++) x[i]=yuanx[i];
		
		for(int j=1;j<=m;j++) y[j]=yuany[j];
	}
	return 0;
	}
	
	return 0;
}


/*
3 3 3 3
8 6 9
1 7 4
1 0
3 0
0 2
1 8
3 5
1 1
2 8
1 7

*/
