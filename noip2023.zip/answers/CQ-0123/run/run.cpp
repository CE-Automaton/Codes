#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
const int N=2e5+10,M=1010;
int ID,T,n,m,k,d,b[N];
ll f[M][M];
struct node{
	int l,r,v;
}a[N];
bool cmp(node x,node y){
	return x.r==y.r?x.l>y.l:x.r<y.r;
}
int main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	scanf("%d%d",&ID,&T);
	while(T--){
		scanf("%d%d%d%d",&n,&m,&k,&d);
		k=min(k,n);
		int tot=0;
		ll sum=0;
		for(int i=1,l,r;i<=m;++i){
			ll v;
			scanf("%d%d%lld",&r,&l,&v);
			if(l<=k){
				++tot;
				a[tot].v=v;
				a[tot].r=r;
				a[tot].l=l;
				if(a[tot].v>0) sum+=a[tot].v;
			}
		}
		if(ID==17||ID==18){
			printf("%lld\n",sum);
			continue;
		}
		m=tot;
		sort(a+1,a+1+m,cmp);
		if(ID<=7){
			memset(f,-0x3f,sizeof f);
			f[0][0]=0;
			int px=1;
//			for(int i=1;i<=m;++i) cout<<a[i].l<<" "<<a[i].r<<" "<<a[i].v<<"\n";
			for(int i=1;i<=n;++i){
				ll s=0;
				f[i][0]=f[i-1][0];
				for(int j=1;j<=k;++j){
					while(px<=m&&a[px].r==i&&a[px].l<=j){
						s+=a[px].v;
						++px;
					}
					f[i][0]=max(f[i][0],f[i-1][j]);
					f[i][j]=f[i-1][j-1]-d+s;
//					cout<<i<<" "<<j<<" "<<f[i][j]<<"\n";
				}
			}
			ll ans=0;
			for(int i=0;i<=k;++i) ans=max(ans,f[n][i]);
			printf("%lld\n",ans);
			continue;
		}
	}
	return 0;
}
