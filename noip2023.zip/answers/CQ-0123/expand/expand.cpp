#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
const int N=5e5+10,M=2010,inf=1e9;
int ID,n,m,q,f[M][M],ma[20][N],mb[20][N],lg[N],la[N],lb[N],aa[N],bb[N];
struct node{
	int x,la,y;
}dta[N],dtb[N];
int aska(int l,int r){
	int p=lg[r-l+1];
	return max(ma[p][l],ma[p][r-(1<<p)+1]);
}
int askb(int l,int r){
	int p=lg[r-l+1];
	return min(mb[p][l],mb[p][r-(1<<p)+1]);
}
bool dp(int a[],int b[],int n,int m){
//	for(int i=1;i<=n;++i) cout<<a[i]<<" ";
//	puts("");
//	for(int i=1;i<=m;++i) cout<<b[i]<<" ";
//	puts("");
	if(a[1]==b[1]||a[n]==b[m]||(a[1]<b[1]&&a[n]>b[m])) return 0;
	for(int i=1;i<=n;++i) ma[0][i]=a[i];
	for(int i=1;1<<i<=n;++i){
		for(int j=1;j+(1<<i)<=n+1;++j){
			ma[i][j]=max(ma[i-1][j],ma[i-1][j+(1<<i-1)]);
		}
	}
	for(int i=1;i<=m;++i) mb[0][i]=b[i];
//	puts("");,cout<<b[i]<<" "
	for(int i=1;1<<i<=m;++i){
		for(int j=1;j+(1<<i)<=m+1;++j){
			mb[i][j]=min(mb[i-1][j],mb[i-1][j+(1<<i-1)]);
//			cout<<i<<" "<<j<<" "<<mb[i][j]<<" "<<mb[i-1][j]<<" "<<mb[i-1][j+(1<<i-1)]<<"\n";
		}
	}
	for(int i=1;i<=n;++i) la[i]=-inf;
	for(int i=1;i<=m;++i) lb[i]=-inf;
	f[0][0]=1;
	la[0]=lb[0]=0;
	for(int i=1;i<=n;++i){
		for(int j=1;j<=m;++j){
			f[i][j]=0;
			int l=1,r=j,res=inf;
			while(l<=r){
				int mid=l+r>>1;
//				cout<<mid<<" "<<j<<" "<<askb(mid,j)<<"\n";
				if(askb(mid,j)>a[i]) res=mid,r=mid-1;
				else l=mid+1;
			}
//			cout<<i<<" "<<j<<" "<<res<<" "<<la[i-1]<<"---"<<"\n";
			if(res<=la[i-1]+1) f[i][j]=1,la[i]=max(la[i],j),lb[j]=max(lb[j],i);
			l=1,r=i,res=inf;
			while(l<=r){
				int mid=l+r>>1;
				if(aska(mid,i)<b[j]) res=mid,r=mid-1;
				else l=mid+1;
			}
			if(res<=lb[j-1]+1) f[i][j]=1,la[i]=max(la[i],j),lb[j]=max(lb[j],i);
//			cout<<res<<" "<<lb[j-1]<<" "<<f[i][j]<<"\n";
		}
	}
	return f[n][m];
}
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	scanf("%d%d%d%d",&ID,&n,&m,&q);
	lg[0]=-1;
	for(int i=1;i<=max(n,m);++i) lg[i]=lg[i>>1]+1;
	for(int i=1;i<=n;++i){
		scanf("%d",&aa[i]);
	}
	for(int i=1;i<=m;++i){
		scanf("%d",&bb[i]);
	}
	if(aa[1]<bb[1]) putchar(dp(aa,bb,n,m)?'1':'0');
	else putchar(dp(bb,aa,m,n)?'1':'0');
//		puts("--");
	while(q--){
		int kx,ky;
		scanf("%d%d",&kx,&ky);
		for(int i=1;i<=kx;++i){
			scanf("%d%d",&dta[i].x,&dta[i].y);
			dta[i].la=aa[dta[i].x];
			aa[dta[i].x]=dta[i].y;
		}
		for(int i=1;i<=ky;++i){
			scanf("%d%d",&dtb[i].x,&dtb[i].y);
			dtb[i].la=bb[dtb[i].x];
			bb[dtb[i].x]=dtb[i].y;
		}
		if(aa[1]<bb[1]) putchar(dp(aa,bb,n,m)?'1':'0');
		else putchar(dp(bb,aa,m,n)?'1':'0');
//		puts("--");
		for(int i=1;i<=kx;++i){
			aa[dta[i].x]=dta[i].la;
		}
		for(int i=1;i<=ky;++i){
			bb[dtb[i].x]=dtb[i].la;
		}
	}
	return 0;
}
