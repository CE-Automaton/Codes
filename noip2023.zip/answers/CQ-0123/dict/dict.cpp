#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
const int N=3010;
int n,m,cnt[30],p[30][2];
char a[N][N],b[N][N];
bool cmp(int x,int y){
	if(!y) return 1;
	for(int i=1;i<=m;++i){
		if(b[x][i]<b[y][i]) return 1;
		if(b[x][i]>b[y][i]) return 0;
	}
	return 0;
}
bool cmp1(int x,int y){
	if(!x) return 0;
	for(int i=1;i<=m;++i){
		if(b[x][i]<a[y][i]) return 1;
		if(b[x][i]>a[y][i]) return 0;
	}
	return 1;
}
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n==1){
		puts("1");
		return 0;
	}
	for(int i=1;i<=n;++i){
		scanf("%s",a[i]+1);
		for(int j=0;j<=25;++j) cnt[j]=0;
		for(int j=1;j<=m;++j){
			++cnt[a[i][j]-'a'];
		}
		int num=0;
		for(int j=0;j<=25;++j){
			for(int k=1;k<=cnt[j];++k){
				a[i][++num]=j+'a';
			}
		}
		num=0;
		for(int j=25;~j;--j){
			for(int k=1;k<=cnt[j];++k){
				b[i][++num]=j+'a';
			}
		}
		int px=b[i][1]-'a';
		if(cmp(i,p[px][0])){
			p[px][1]=p[px][0];
			p[px][0]=i;
		}
		else if(cmp(i,p[px][1])){
			p[px][1]=i;
		}
	}
	for(int i=1;i<=n;++i){
		bool fg=1;
		int px=a[i][1]-'a';
		for(int j=0;j<px;++j){
			if(p[j][0]&&p[j][0]!=i){
				fg=0;
				break;
			}
		}
		if(!fg){
			putchar('0');
			continue;
		}
		if((p[px][0]&&p[px][0]!=i&&cmp1(p[px][0],i))||(p[px][1]&&p[px][1]!=i&&cmp1(p[px][1],i))){
			putchar('0');
		}
		else putchar('1');
	}
	return 0;
}
