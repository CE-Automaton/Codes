#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
const int N=1e5+10;
int n,m,a[N],b[N],ans;
struct node{
	int op,x,y;
}ask[N];
void dfs(int x,int cnt){
	if(cnt>=ans) return ;
	if(x>n){
		for(int i=1;i<=n;++i) b[i]=a[i];
		for(int i=1;i<=m;++i){
			if(ask[i].op==1){
				b[ask[i].x]=1;
			}
			else if(ask[i].op==2){
				b[ask[i].x]=0;
			}
			else if(ask[i].op==3){
				b[ask[i].x]=2;
			}
			else if(ask[i].op==4){
				b[ask[i].x]=b[ask[i].y];
			}
			else{
				b[ask[i].x]=b[ask[i].y]==2?2:b[ask[i].y]^1;
			}
		}
		for(int i=1;i<=n;++i){
			if(a[i]!=b[i]) return ;
		}
		ans=cnt;
		return ;
	}
	a[x]=0;
	dfs(x+1,cnt);
	a[x]=1;
	dfs(x+1,cnt);
	a[x]=2;
	dfs(x+1,cnt+1);
}
int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	int ID,T;
	scanf("%d%d",&ID,&T);
	while(T--){
		scanf("%d%d",&n,&m);
		for(int i=1;i<=m;++i){
			char ch[2];
			scanf("%s%d",ch,&ask[i].x);
			if(*ch=='T') ask[i].op=1;
			else if(*ch=='F') ask[i].op=2;
			else if(*ch=='U') ask[i].op=3;
			else if(*ch=='+'){
				ask[i].op=4;
				scanf("%d",&ask[i].y);
			}
			else{
				ask[i].op=5;
				scanf("%d",&ask[i].y);
			}
		}
		if(ID<=2){
			ans=n;
			dfs(1,0);
			printf("%d\n",ans);
		}
		else if(ID<=4){
			memset(b,0,sizeof b);
			for(int i=1;i<=m;++i){
				if(ask[i].op==1){
					b[ask[i].x]=1;
				}
				else if(ask[i].op==2){
					b[ask[i].x]=0;
				}
				else if(ask[i].op==3){
					b[ask[i].x]=2;
				}
				else if(ask[i].op==4){
					b[ask[i].x]=b[ask[i].y];
				}
				else{
					b[ask[i].x]=b[ask[i].y]==2?2:b[ask[i].y]^1;
				}
			}
			ans=0;
			for(int i=1;i<=n;++i){
				if(b[i]==2) ++ans;
			}
			printf("%d\n",ans);
		}
		else if(ID<=6){
			memset(b,0,sizeof b);
			for(int i=1;i<=m;++i){
				if(ask[i].op==1){
					b[ask[i].x]=1;
				}
				else if(ask[i].op==2){
					b[ask[i].x]=0;
				}
				else if(ask[i].op==3){
					b[ask[i].x]=2;
				}
				else if(ask[i].op==4){
					b[ask[i].x]=b[ask[i].y];
				}
				else{
					b[ask[i].x]=b[ask[i].y]==2?2:b[ask[i].y]^1;
				}
			}
			for(int i=1;i<=m;++i){
				if(ask[i].op==1){
					b[ask[i].x]=1;
				}
				else if(ask[i].op==2){
					b[ask[i].x]=0;
				}
				else if(ask[i].op==3){
					b[ask[i].x]=2;
				}
				else if(ask[i].op==4){
					b[ask[i].x]=b[ask[i].y];
				}
				else{
					b[ask[i].x]=b[ask[i].y]==2?2:b[ask[i].y]^1;
				}
			}
			ans=0;
			for(int i=1;i<=n;++i){
				if(b[i]==2) ++ans;
			}
			printf("%d\n",ans);
		}
	}
	return 0;
}
