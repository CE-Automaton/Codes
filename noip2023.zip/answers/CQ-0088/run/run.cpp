#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAXN = 1e5 + 5;
int n,m,k;
ll d,v[MAXN],maxn;
int X[MAXN],Y[MAXN],a[MAXN];		
void dfs(int x,int num)
{
	if(num > k)return;
	if(x > n)
	{
		ll ans = 0;
		for(int i = 1;i <= m; i++)
		{
			bool flag = true;
			if(Y[i] <= 0)continue;
			for(int j = X[i];j <= Y[i]; j++)
			{
				if(a[j] == 0)
				{
					flag = false;
					break;
				}
			}
			if(flag)ans += v[i];
		}
		for(int i = 1;i <= n; i++)
			if(a[i] == 1)ans -= d;
		maxn = max(maxn,ans);
		return;
	}
	a[x] = 1;
	dfs(x + 1,num + 1);
	a[x] = 0;
	dfs(x + 1,0);
}
int main()
{
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	int c,t;
	scanf("%d %d", &c, &t);
	if(c <= 2)
	{
		while(t--)
		{
			maxn = 0;
			scanf("%d %d %d %lld", &n, &m, &k, &d);
			for(int i = 1;i <= m; i++)
			{
				scanf("%d %d %lld", &X[i], &Y[i], &v[i]);
				swap(X[i],Y[i]);
				Y[i] = X[i] - Y[i] + 1;
				swap(X[i],Y[i]);
			}
			dfs(1,0);
			printf("%lld\n", maxn);
		}
	}
	else
	{
		ll dd = 0;
		while(t--)
		{
			scanf("%d %d %d %lld", &n, &m, &k, &d);
			for(int i = 1;i <= m; i++)
			{
				scanf("%d %d %lld", &X[i], &Y[i], &v[i]);
				dd += v[i];
			}
			printf("%lld\n", dd);
		}
	}
	return 0;
}
