#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAXN = 3005;
string s[MAXN],Min,Minn;
int pos;
vector <int> ans;
inline bool cmp(char a,char b)
{
	return a > b;
}
int main()
{
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	int n,m;
	scanf("%d %d", &n, &m);
	for(int i = 1;i <= n; i++)
	{
		for(int j = 1;j <= m; j++)
		{
			char c = getchar();
			while(c < 'a' || c > 'z')c = getchar();
			s[i] += c;
		}
		sort(s[i].begin(),s[i].end(),cmp);
		if(Min == "" || s[i] < Min)
		{
			Minn = Min;
			Min = s[i];
			pos = i;
		}
		else if(Minn == "" || s[i] < Minn)
			Minn = s[i];
	}
	for(int i = 1;i <= n; i++)
	{
		sort(s[i].begin(),s[i].end());
		if(i == pos && s[i] < Minn)ans.push_back(1);
		else if(i != pos && s[i] < Min)ans.push_back(1);
		else ans.push_back(0);
	}
	for(int x : ans)printf("%d", x);
	return 0;
}
