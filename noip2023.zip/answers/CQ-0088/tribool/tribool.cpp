#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAXN = 4e5 + 5;
int low[MAXN],dfn[MAXN],Time,Bel[MAXN],scc;
bool instack[MAXN];
stack <int> S;
int Last[MAXN],End[MAXN],Next[MAXN],cnt;
void add(int x,int y)
{
	End[++cnt] = y;Next[cnt] = Last[x];Last[x] = cnt;
}
void Tarjan(int x)
{
	if(!dfn[x])dfn[x] = low[x] = ++Time,S.push(x),instack[x] = true;
	for(int i = Last[x];i;i = Next[i])
	{
		int y = End[i];
		if(!dfn[y])
		{
			Tarjan(y);
			low[x] = min(low[x],dfn[y]);
		}
		else if(instack[y])
			low[x] = min(low[x],low[y]);
	}
	if(dfn[x] == low[x])
	{
		int y;
		scc++;
		do
		{
			y = S.top();
			S.pop();
			Bel[y] = scc;
			instack[y] = false;
		}
		while(y != x);
	}
}
int x[MAXN],y[MAXN],cir[MAXN],pos[MAXN],From[MAXN],dep[MAXN];
char ss;
void read(int &x)
{
	x = 0;char ch = getchar();
	while(ch < '0' || ch > '9')ch = getchar();
	while('0' <= ch && ch <= '9')x = (x << 1) + (x << 3) + (ch ^ 48),ch = getchar();
}
int main()
{
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	int c,t;
	read(c),read(t);
	while(t--)
	{
		int n,m;
		read(n),read(m);
		for(int i = 1;i <= m; i++)cir[i] = -1,From[i] = 0,dep[i] = 0,x[i] = 0,y[i] = 0;
		for(int i = 1;i <= n; i++)pos[i] = 0;
		for(int i = 1;i <= m; i++)
		{
			ss = getchar();
			while(ss != '+' && ss != '-' && ss != 'U' && ss != 'T' && ss != 'F')ss = getchar();
			if(ss == '+')
			{
				read(x[i]),read(y[i]);
				int fa = pos[y[i]];
				if(fa)cir[i] = cir[fa];
				dep[i] = dep[fa];
				if(From[fa] == 0)From[i] = y[i];
				else if(fa) From[i] = From[fa];
				pos[x[i]] = i;
			}
			else if(ss == '-')
			{
				read(x[i]),read(y[i]);
				int fa = pos[y[i]];
				if(cir[i] == 1 || cir[i] == 0)cir[i] = (cir[fa] ^ 1);
				else if(fa) cir[i] = cir[fa];
				dep[i] = (dep[fa] ^ 1);
				if(From[fa] == 0)From[i] = y[i];
				else From[i] = From[fa];
				pos[x[i]] = i;
			}
			else 
			{
				read(x[i]);
				if(ss == 'T')cir[i] = 1;
				else if(ss == 'F')cir[i] = 0;
				else if(ss == 'U')cir[i] = 2;
				dep[i] = 0;
				y[i] = cir[i];
				pos[x[i]] = i;
				From[i] = x[i];
			}
//			printf("sc:%d %d %d %d\n", i, From[i], cir[i], dep[i]);
		}
		Time = 0,cnt = 0;scc = 0;
		for(int i = 1;i <= 2 * n; i++)Last[i] = 0,dfn[i] = low[i] = 0,Bel[i] = 0;
		for(int i = 1;i <= m; i++)
		{
			if(pos[x[i]] != i)continue;
			if(cir[i] == -1)
			{
				int s = x[i],t = From[i];
				if(dep[i] == 0)
				{
					add(s,t);add(t,s);
					add(s + n,t + n);add(t + n,s + n);
				}
				else 
				{
					add(s,t + n);add(t,s + n);
					add(s + n,t);add(t + n,s);
				}
			}
			else if(cir[i] == 2)
			{
				add(x[i],x[i] + n);
				add(x[i] + n,x[i]);
			}
			else if(cir[i] == 0)
				add(x[i] + n,x[i]);
			else if(cir[i] == 1)
				add(x[i],x[i] + n);
		}
		for(int i = 1;i <= 2 * n; i++)
			if(!dfn[i])Tarjan(i);
		int ans = 0;
		for(int i = 1;i <= n; i++)
			if(Bel[i] == Bel[i + n])ans++;
		printf("%d\n", ans);
	}
	return 0;
}
