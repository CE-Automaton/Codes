#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAXN = 5e3 + 5;
int x[MAXN],y[MAXN];
int px[MAXN],vx[MAXN],nx[MAXN],py[MAXN],vy[MAXN],ny[MAXN];
int Max[MAXN];
vector <int> ans;
int c,n,m,q;
bool dp[2005][2005];
bool solve1()
{
	if(x[1] > y[1])
	{
		for(int i = 0;i <= n; i++)
			for(int j = 0;j <= m; j++)
				dp[i][j] = 0;
		dp[1][1] = 1;
		for(int i = 1;i <= n; i++)
			for(int j = 1;j <= m; j++)
			{
				if(!dp[i][j])continue;
				if(x[i + 1] > y[j + 1])dp[i + 1][j + 1] = dp[i][j];
				if(x[i + 1] > y[j])dp[i + 1][j] = dp[i][j];
				if(x[i] > y[j + 1])dp[i][j + 1] = dp[i][j];
			}
		return dp[n][m];
	}
	else if(x[1] < y[1])
	{
		for(int i = 0;i <= n; i++)
			for(int j = 0;j <= m; j++)
				dp[i][j] = 0;
		dp[1][1] = 1;
		for(int i = 1;i <= n; i++)
			for(int j = 1;j <= m; j++)
			{
				if(!dp[i][j])continue;
				if(x[i + 1] < y[j + 1])dp[i + 1][j + 1] = dp[i][j];
				if(x[i + 1] < y[j])dp[i + 1][j] = dp[i][j];
				if(x[i] < y[j + 1])dp[i][j + 1] = dp[i][j];
			}
		return dp[n][m];
	}
	return false;
}
bool solve2()
{
	int Min = 1e9,Max = 0;
	for(int i = 1;i <= min(n,m); i++)
	{
		if(i <= m)Min = min(Min,y[i]);
		if(i <= n)Max = max(Max,x[i]);
		if(x[i] == Max && Min == y[i] && i != 1)
			return false;
	}
	return true;
}
void read(int &x)
{
	x = 0;char ch = getchar();
	while(ch < '0' || ch > '9')ch = getchar();
	while('0' <= ch && ch <= '9')x = (x << 1) + (x << 3) + (ch ^ 48),ch = getchar();
}
int main()
{
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	read(c),read(n),read(m),read(q);
	if(c <= 7)
	{
		for(int i = 1;i <= n; i++)read(x[i]);
		for(int i = 1;i <= m; i++)read(y[i]);
		ans.push_back(solve1());
		while(q--)
		{
			int kx,ky;
			read(kx),read(ky);
			for(int i = 1;i <= kx; i++)read(px[i]),read(vx[i]),nx[i] = x[px[i]],x[px[i]] = vx[i];
			for(int i = 1;i <= ky; i++)read(py[i]),read(vy[i]),ny[i] = y[py[i]],y[py[i]] = vy[i];
//			printf("cd:\n");
//			for(int i = 1;i <= n; i++)printf("%d ", x[i]);
//			puts("");
//			for(int i = 1;i <= m; i++)printf("%d ", y[i]);
//			puts("");
			ans.push_back(solve1());
			for(int i = kx;i >= 1; i--)x[px[i]] = nx[i];
			for(int i = ky;i >= 1; i--)y[py[i]] = ny[i];
			
		}
		for(int x : ans)printf("%d", x);
	}
	else 
	{
		for(int i = 1;i <= n; i++)read(x[i]);
		for(int i = 1;i <= m; i++)read(y[i]);
		ans.push_back(solve2());
		while(q--)
		{
			int kx,ky;
			read(kx),read(ky);
			for(int i = 1;i <= kx; i++)read(px[i]),read(vx[i]),nx[i] = x[px[i]],x[px[i]] = vx[i];
			for(int i = 1;i <= ky; i++)read(py[i]),read(vy[i]),ny[i] = y[py[i]],y[py[i]] = vy[i];
//			printf("cd:\n");
//			for(int i = 1;i <= n; i++)printf("%d ", x[i]);
//			puts("");
//			for(int i = 1;i <= m; i++)printf("%d ", y[i]);
//			puts("");
			ans.push_back(solve2());
			for(int i = kx;i >= 1; i--)x[px[i]] = nx[i];
			for(int i = ky;i >= 1; i--)y[py[i]] = ny[i];
			
		}
		for(int x : ans)printf("%d", x);
	}
	return 0;
}
