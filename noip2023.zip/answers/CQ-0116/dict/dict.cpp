#include<bits/stdc++.h>
using namespace std;
#define N 3050
int n,m;
char a[N][N];
bool cmp(const char a[],const char b[]){
	for(int i=1;i<=m;i++){
		if(a[i]<b[i])return true;
		else if(a[i]>b[i])return false;
	}
	return false;
}
struct node{
	int id;
	char x[N];
	bool operator<(const node b)const {
		return cmp(x,b.x);	
	} 
}b[N];
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++)cin>>a[i][j];
		sort(a[i]+1,a[i]+m+1);
		b[i].id=i;
		for(int j=1;j<=m;j++)b[i].x[j]=a[i][m-j+1];
	}
	sort(b+1,b+n+1);
	for(int i=1;i<=n;i++){
		int tag=1;
		for(int j=1;j<=n;j++){
			if(b[j].id==i)continue;
			if(!cmp(a[i],b[j].x))tag=0;
			break;
		}
		if(tag)cout<<"1";
		else cout<<"0";
	}
	return 0;
}
