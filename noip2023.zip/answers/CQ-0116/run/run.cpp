#include<bits/stdc++.h>
using namespace std;
#define N 505050
#define ll long long
#define int long long
int n,m,k;
ll d,s[N],f[N],inf=0x3f3f3f3f3f3f,b[N];
struct node{
	int l,r,w;
	bool operator<(const node b)const {
		return r==b.r?(l==b.l?w>b.w:l<b.l):r<b.r;
	}
}a[N];
int read(){
	int x=0,w=1;
	char ch=getchar();
	while(ch>'9'||ch<'0'){
		if(ch=='-')w*=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<3)+(x<<1)+(ch^48);
		ch=getchar();
	}
	return x*w;
}

signed main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	int C=read(),T=read();
	while(T--){
		n=read(),m=read(),k=read(),d=read(); 
		for(int i=1;i<=m;i++){
			int x,y,w;x=read();y=read();w=read();
			a[i].l=x-y+1;a[i].r=x;a[i].w=w;
		}
		sort(a+1,a+m+1);int ans=0;
		if(C==17||C==18){
			for(int i=1;i<=m;i++){
				if(a[i].r-a[i].l+1>k)continue;
				ans+=max(0ll,a[i].w-(a[i].r-a[i].l+1)*d);
			}
			cout<<ans<<"\n";continue;
		} 
		for(int i=0;i<(1<<n);i++){
			for(int j=0;j<n;j++)b[j+1]=(i>>j)&1;
			int lst=1,tag=1,res=0;
			for(int j=1;j<=n;j++){
				if(!b[j]){
					lst=j+1;continue; 
				}
				if(j-lst+1>k){
					tag=0;break;
				}
			}
			if(tag){
//				for(int j=1;j<=n;j++)cout<<b[j]<<" ";
//				cout<<"\n";
				for(int j=1;j<=m;j++){
					int l=a[j].l,r=a[j].r,flag=1;
					for(int k=l;k<=r;++k)if(!b[k])flag=0;
					res+=flag*a[j].w;
				}
				for(int j=1;j<=n;j++)if(b[j])res-=d;
			}
			ans=max(ans,res);
//			if(res>0||i==3)cout<<res<<" "<<i<<"\n";
		}
		cout<<ans<<"\n";
	}
}
