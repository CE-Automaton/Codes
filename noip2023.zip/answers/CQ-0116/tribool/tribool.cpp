/*
����:
100+80+70+? 
*/
#include<bits/stdc++.h>
using namespace std;
int read(){
	int x=0,w=1;
	char ch=getchar();
	while(ch>'9'||ch<'0'){
		if(ch=='-')w*=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<3)+(x<<1)+(ch^48);
		ch=getchar();
	}
	return x*w;
}
#define N 505050
int n,m,a[N],c[N];
int pw[N];
struct node{
	int opt,x,y;
}b[N];
void solve(){
	for(int i=1;i<=m;i++){
		char x;cin>>x;
		if(x=='+'){
			b[i].opt=1;cin>>b[i].x>>b[i].y;
		}
		else if(x=='-'){
			b[i].opt=2;cin>>b[i].x>>b[i].y;
		}
		else if(x=='T'){
			b[i].opt=3;cin>>b[i].x;
		}
		else if(x=='F'){
			b[i].opt=4;cin>>b[i].x;
		}
		else if(x=='U'){
			b[i].opt=5;cin>>b[i].x;
		}
		b[i].x--,b[i].y--;
	}
	pw[0]=1;
	for(int i=1;i<=n;i++)pw[i]=pw[i-1]*3;
	int ans=n;
	for(int i=0;i<pw[n];i++){
		int t=i;
		for(int j=0;j<n;j++)a[j]=c[j]=t%3,t/=3;
		for(int j=1;j<=m;j++){
			if(b[j].opt==1)c[b[j].x]=c[b[j].y];
			if(b[j].opt==2)c[b[j].x]=(c[b[j].y]==2?2:(c[b[j].y]^1));
			if(b[j].opt==3)c[b[j].x]=1;
			if(b[j].opt==4)c[b[j].x]=0;
			if(b[j].opt==5)c[b[j].x]=2;
		}
		int tag=1;
		for(int j=0;j<n;j++)if(c[j]!=a[j])tag=0;
		if(tag){
			int res=0;
			for(int j=0;j<n;j++)res+=(c[j]==2);
			ans=min(ans,res);
		}
	}
	cout<<ans<<"\n";
}
void solve1(){//TFU
	for(int i=1;i<=n;i++)a[i]=-1;
	while(m--){
		char x;cin>>x;
		int id;cin>>id;
		if(x=='T')a[id]=1;
		if(x=='F')a[id]=2;
		if(x=='U')a[id]=3;
	}
	int res=0;
	for(int i=1;i<=n;i++)res+=(a[i]==3);
	cout<<res<<"\n";
} 
int lst[N];
vector<int>e[N];
void dfs(int x){
	if(a[x])return ;a[x]=1;
	for(auto v:e[x]){
		dfs(v);
	}
}
int fa[N],siz[N],ch[N];
int find(int x){
//	cout<<x<<"\n";
	return x==fa[x]?x:fa[x]=find(fa[x]); 
}
void solve2(){
	for(int i=1;i<=n;i++)fa[i]=i,a[i]=ch[i]=0;
	for(int i=1;i<=m;i++){
		char opt;cin>>opt;
		if(opt=='+')cin>>b[i].x>>b[i].y,b[i].opt=1;
		else {
			cin>>b[i].x;b[i].opt=2;
		}
	}
	int ans=0;
	while(1){	
		for(int i=1;i<=m;i++){
			int opt=b[i].opt;
			if(opt==1){
				int x=b[i].x,y=b[i].y;
				a[x]=a[y];
			}
			else {
				int x=b[i].x;
				a[x]=1;
			}
		}
		int res=0;
		for(int i=1;i<=n;i++)res+=a[i];
		if(ans==res)break;
		else ans=res;
	}
	cout<<ans<<"\n";
}
set<int>f[N],g[N];
int rp[N],val[N],rt[N]; 
void ins(int x,int y){
	if(rp[x]==2)f[y].insert(x),g[y].insert(x);
	else if(rp[x])g[y].insert(x);
	else f[y].insert(x);
}
void del(int x,int y){
	if(rp[x]==2)f[y].erase(x),g[y].erase(x);
	else if(rp[x])g[y].erase(x);
	else f[y].erase(x);
}
void solve3(){
	for(int i=1;i<=n;i++)f[i].clear(),g[i].clear();
	for(int i=1;i<=n;i++)f[i].insert(i),rp[i]=0,rt[i]=i;
	while(m--){
		char opt;int x,y;
		cin>>opt>>x>>y;
		if(opt=='-'&&x==rt[y]){
			f[x].insert(x);g[x].insert(x);continue;
		}
		if(opt=='+'){
			del(x,rt[x]);
			rp[x]=rp[y];rt[x]=rt[y];
			if(rp[x])g[rt[y]].insert(x);
			else f[rt[y]].insert(x);
		}
		else {
			del(x,rt[x]);
			rp[x]=rp[y]^1;rt[x]=rt[y];
			if(rp[x])g[rt[y]].insert(x);
			else f[rt[y]].insert(x);
		}
	}
	int res=0;
	for(int i=1;i<=n;i++)if(g[rt[i]].find(rt[i])!=g[rt[i]].end()){
		if(f[rt[i]].find(rt[i])!=f[rt[i]].find(rt[i])){
			++res;
		}
	}
	cout<<res<<"\n";
}
int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	ios::sync_with_stdio(false);
	int C,T;cin>>C>>T;
	while(T--){
		cin>>n>>m;
		if(C<=2)solve();
		else if(C<=4)solve1();
		else if(C<=6)solve2();
		else solve3(); 
	}
}
