#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using ci = const int;

const int N = 5e5 + 5;

int C, n, m, q, a[N], b[N];
stack<pair<int, int>> px, py;
bool dp[2005][2005];

void ret() {
	pair<int, int> s;
	while (!px.empty()) {
		s = px.top(); px.pop();
		a[s.first] = s.second;
	}
	while (!py.empty()) {
		s = py.top(); py.pop();
		b[s.first] = s.second;
	}
}

bool work() {
	memset(dp, 0, sizeof dp);
	dp[0][0] = 1;
	for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= m; ++j) {
			if (b[j] > a[i]) dp[i][j] = dp[i - 1][j] | dp[i][j - 1] | dp[i - 1][j - 1];
		}
	}
	if (dp[n][m]) return 1;
	memset(dp, 0, sizeof dp);
	dp[0][0] = 1;
	for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= m; ++j) {
			if (b[j] < a[i]) dp[i][j] = dp[i - 1][j] | dp[i][j - 1] | dp[i - 1][j - 1];
		}
	}
	return dp[n][m];
}

void solve1() {
	putchar(work() ? '1' : '0'); ret();
	while (q--) {
		int kx, ky;
		scanf("%d %d", &kx, &ky);
		for (int i = 1, p, x; i <= kx; ++i)
			scanf("%d %d", &p, &x), px.push({p, a[p]}), a[p] = x;
		for (int i = 1, p, x; i <= ky; ++i)
			scanf("%d %d", &p, &x), py.push({p, b[p]}), b[p] = x;
		putchar(work() ? '1' : '0'); ret();
	}
}

int main() {
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);

	scanf("%d %d %d %d", &C, &n, &m, &q);
	for (int i = 1; i <= n; ++i) scanf("%d", &a[i]);
	for (int i = 1; i <= m; ++i) scanf("%d", &b[i]);
	solve1();

	return 0;
}