#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using ci = const int;

const int N = 1e5 + 5;
const ll inf = 1ll << 60;

mt19937 Rnd(time(0));

int C, T;
int n, m, k, d;
vector<pair<int, int>> e[N];

struct Node {
	ll mx, v, s, lz;
	unsigned key;
	Node *ch[2];
	Node(ll x) : mx(x), v(x), s(1), lz(0), key(Rnd()) { ch[0] = ch[1] = nullptr; }
	void pushup() {
		mx = v, s = 1;
		if (ch[0]) mx = max(mx, ch[0]->mx), s += ch[0]->s;
		if (ch[1]) mx = max(mx, ch[1]->mx), s += ch[1]->s;
	}
	void cha(ll x) {
		mx += x, v += x, lz += x;
	}
	void pushdown() {
		if (!lz) return;
		if (ch[0]) ch[0]->cha(lz);
		if (ch[1]) ch[1]->cha(lz);
		lz = 0;
	}
} *rt = nullptr;

void split(Node *p, int x, Node *&pl, Node *&pr) {
	if (!p) return void(pl = pr = nullptr);
	p->pushdown();
	int ls = p->ch[0] ? p->ch[0]->s : 0;
	if (ls >= x) pr = p, split(p->ch[0], x, pl, p->ch[0]);
	else pl = p, split(p->ch[1], x - ls - 1, p->ch[1], pr);
	p->pushup();
}

Node *merge(Node *p, Node *q) {
	if (!p) return q;
	if (!q) return p;
	if (p->key < q->key) return p->pushdown(), p->ch[1] = merge(p->ch[1], q), p->pushup(), p;
	return q->pushdown(), q->ch[0] = merge(p, q->ch[0]), q->pushup(), q;
}

void ins(ll v) {
	Node *x;
	x = new Node(v);
	rt = merge(x, rt);
}
void ers() {
	Node *x, *y;
	split(rt, k + 1, x, y);
	rt = x;
}

void add(int l, ll v) {
	Node *x, *y;
	split(rt, l, x, y);
	if (y) y->cha(v);
	rt = merge(x, y);
}

void work() {
	scanf("%d %d %d %d", &n, &m, &k, &d);
	vector<pair<int, pair<int, int>>> E;
	for (int i = 1, x, y, v; i <= m; ++i) {
		scanf("%d %d %d", &x, &y, &v);
		E.push_back({x, {y, v}});
		e[x].push_back({y, v});
	}
	ins(0);
	for (int i = 1; i <= n; ++i) {
		ins(rt->mx);
		if (i > k) ers();
		add(1, -d);
		for (const auto &x : e[i]) add(x.first, x.second);
	}
	for (const auto &x : E) e[x.first].clear();
	E.clear();
	printf("%lld\n", rt->mx); rt = nullptr;
}

int main() {
	freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);

	scanf("%d %d", &C, &T);
	if (C > 14) return 0;
	while (T--) work();

	return 0;
}