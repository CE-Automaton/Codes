#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using ci = const int;

const int N = 3005;

int n, m, tot;
string s[N], mn, t;

int main() {
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);

	ios_base::sync_with_stdio(false);

	cin.tie(0);
	cout.tie(0);
	cerr.tie(0);

	cin >> n >> m;
	for (int i = 1; i <= n; ++i) cin >> s[i];
	for (int i = 1; i <= n; ++i) {
		sort(s[i].begin(), s[i].begin() + m);
		reverse(s[i].begin(), s[i].begin() + m);
	}
	mn = s[1], tot = 1;
	for (int i = 2; i <= n; ++i)
		if (mn > s[i]) tot = 1, mn = s[i];
	for (int i = 1; i <= n; ++i) {
		reverse(s[i].begin(), s[i].begin() + m);
		cout << ((s[i] < mn) || (tot == 1 && s[i] == mn) ? '1' : '0');
	}

	return 0;
}