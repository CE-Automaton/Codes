#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using ci = const int;

const int N = 1e5 + 5;

int C, T, n, m, a[N], fa[N << 1];
int fd(int x) { return fa[x] == x ? x : (fa[x] = fd(fa[x])); }
inline void mg(int x, int y) { fa[fd(x)] = fd(y); }

void solve1() {
    memset(a, 0, sizeof a);
    scanf("%d %d\n", &n, &m);
    char c;
	for (int i = 1, x, y; i <= m; ++i) {
		scanf("%c", &c);
		switch (c) {
			case 'T' : scanf("%d\n", &x); a[x] = 1; break;
			case 'F' : scanf("%d\n", &x); a[x] = 2; break;
			case 'U' : scanf("%d\n", &x); a[x] = 3; break;
		}
	}
    int tot = 0;
    for (int i = 1; i <= n; ++i) if (a[i] == 3) ++tot;
    printf("%d\n", tot);
}

void solve2() {
    memset(a, 0, sizeof a);
    scanf("%d %d\n", &n, &m);
    char c;
	for (int i = 1, x, y; i <= m; ++i) {
		scanf("%c", &c);
		switch (c) {
			case 'U' : scanf("%d\n", &x); a[x] = 1; break;
            case '+' : scanf("%d %d\n", &x, &y), a[x] = a[y]; break;
		}
	}
    int tot = 0;
    for (int i = 1; i <= n; ++i) if (a[i]) ++tot;
    printf("%d\n", tot);
}

void solve3() {
    scanf("%d %d\n", &n, &m);
	for (int i = 1; i <= 2 * n; ++i) fa[i] = i;
    char c;
	for (int i = 1, x, y; i <= m; ++i) {
		scanf("%c", &c);
		switch (c) {
            case '+' : scanf("%d %d\n", &x, &y), mg(x, y), mg(x + n, y + n); break;
            case '-' : scanf("%d %d\n", &x, &y), mg(x + n, y), mg(x, y + n); break;
		}
	}
    int tot = 0;
	for (int i = 1; i <= n; ++i) if (fd(i) == fd(i + n)) ++tot;
	printf("%d\n", tot);
}

int main() {
	freopen("tribool.in", "r", stdin);
	freopen("tribool.out", "w", stdout);

	scanf("%d %d", &C, &T);
	if (C == 3 || C == 4) while (T--) solve1();
    else if (C == 5 || C == 6) while (T--) solve2();
	else if (C == 7 || C == 8) while (T--) solve3();
	return 0;
}