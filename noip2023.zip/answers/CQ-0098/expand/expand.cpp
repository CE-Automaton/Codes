#include <bits/stdc++.h>
using namespace std;
const int N=5e5+5;
const int M=2e3+5;
mt19937 rnd(time(0));
template<typename T> inline void read(T &x){
	char ch=getchar();
	T op=1;
	while(ch<'0'||ch>'9'){
		if(ch=='-'){
			op=-1;
		}
		ch=getchar();
	}
	x=0;
	while(ch>='0'&&ch<='9'){
		x=x*10+ch-'0';
		ch=getchar();
	}
	x*=op;
}
template<typename T,typename ...L> inline void read(T &x,L &...l){
	read(x),read(l...);
}
template<typename T> inline void write(T x){
	if(x==0){
		putchar('0');
	}else{
		if(x<0){
			putchar('-');
			x=-x;
		}
		int top=0,stk[30];
		while(x){
			stk[++top]=x%10;
			x/=10;
		}
		while(top){
			putchar(stk[top--]+'0');
		}
	}
}
template<typename T,typename ...L> inline void write(T x,L ...l){
	write(x),putchar(' '),write(l...);
}
int c,n,m,q,x[N],y[N],tx[N],ty[N];
vector<int> opx,opy;
bool dp[M][M];
bool solve(){
	if(n<=2000&&m<=2000){
		memset(dp,0,sizeof(dp));
		if(x[1]<y[1]){
			dp[1][1]=1;
			for(int i=1;i<=n;i++){
				for(int j=1;j<=m;j++){
					if(dp[i][j]){
						if(x[i+1]<y[j]){
							dp[i+1][j]=1;
						}
						if(x[i]<y[j+1]){
							dp[i][j+1]=1;
						}
					}
				}
			}
		}else if(x[1]>y[1]){
			dp[1][1]=1;
			for(int i=1;i<=n;i++){
				for(int j=1;j<=m;j++){
					if(dp[i][j]){
						if(x[i+1]>y[j]){
							dp[i+1][j]=1;
						}
						if(x[i]>y[j+1]){
							dp[i][j+1]=1;
						}
					}
				}
			}
		}
		return dp[n][m];
	}else{
		bool res=0;
		int c=10;
		while(c--){
			bool flag=1;
			if(x[1]<y[1]){
				int i=1,j=1;
				while(i<n||j<m){
					if(rnd()&1){
						if(i<n&&x[i+1]<y[j]){
							i++;
						}else if(j<m&&x[i]<y[j+1]){
							j++;
						}else{
							flag=0;
							break;
						}
					}else{
						if(j<m&&x[i]<y[j+1]){
							j++;
						}else if(i<n&&x[i+1]<y[j]){
							i++;
						}else{
							flag=0;
							break;
						}
					}
				}
			}else if(x[1]>y[1]){
				int i=1,j=1;
				while(i<n||j<m){
					if(rnd()&1){
						if(i<n&&x[i+1]>y[j]){
							i++;
						}else if(j<m&&x[i]>y[j+1]){
							j++;
						}else{
							flag=0;
							break;
						}
					}else{
						if(j<m&&x[i]>y[j+1]){
							j++;
						}else if(i<n&&x[i+1]>y[j]){
							i++;
						}else{
							flag=0;
							break;
						}
					}
				}
			}else{
				flag=0;
			}
			res|=flag;
		}
		return res;
	}
}
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	read(c,n,m,q);
	for(int i=1;i<=n;i++){
		read(x[i]);
		tx[i]=x[i];
	}
	for(int i=1;i<=m;i++){
		read(y[i]);
		ty[i]=y[i];
	}
	write(solve());
	while(q--){
		int kx,ky;
		read(kx,ky);
		for(int i=1;i<=kx;i++){
			int p,v;
			read(p,v);
			x[p]=v;
			opx.push_back(p);
		}
		for(int i=1;i<=ky;i++){
			int p,v;
			read(p,v);
			y[p]=v;
			opy.push_back(p);
		}
		write(solve());
		for(int i=0;i<int(opx.size());i++){
			x[opx[i]]=tx[opx[i]];
		}
		opx.clear();
		for(int i=0;i<int(opy.size());i++){
			y[opy[i]]=ty[opy[i]];
		}
		opy.clear();
	}
	return 0;
}
