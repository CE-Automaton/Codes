#include <bits/stdc++.h>
using namespace std;
const int N=3e3+5;
template<typename T> inline void read(T &x){
	char ch=getchar();
	T op=1;
	while(ch<'0'||ch>'9'){
		if(ch=='-'){
			op=-1;
		}
		ch=getchar();
	}
	x=0;
	while(ch>='0'&&ch<='9'){
		x=x*10+ch-'0';
		ch=getchar();
	}
	x*=op;
}
template<typename T,typename ...L> inline void read(T &x,L &...l){
	read(x),read(l...);
}
template<typename T> inline void write(T x){
	if(x==0){
		putchar('0');
	}else{
		if(x<0){
			putchar('-');
			x=-x;
		}
		int top=0,stk[30];
		while(x){
			stk[++top]=x%10;
			x/=10;
		}
		while(top){
			putchar(stk[top--]+'0');
		}
	}
}
template<typename T,typename ...L> inline void write(T x,L ...l){
	write(x),putchar(' '),write(l...);
}
int n,m,mn[N],mx[N];
char s[N][N];
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	read(n,m);
	for(int i=1;i<=n;i++){
		scanf("%s",s[i]+1);
		mn[i]=25;
		mx[i]=0;
		for(int j=1;j<=m;j++){
			if(mn[i]>s[i][j]-'a'){
				mn[i]=s[i][j]-'a';
			}
			if(mx[i]<s[i][j]-'a'){
				mx[i]=s[i][j]-'a';
			}
		}
	}
	for(int i=1;i<=n;i++){
		bool flag=1;
		for(int j=1;j<=n;j++){
			if(j!=i){
				if(mn[i]>=mx[j]){
					flag=0;
					break;
				}
			}
		}
		write(flag);
	}
	return 0;
}
