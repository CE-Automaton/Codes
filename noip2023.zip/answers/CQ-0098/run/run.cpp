#include <bits/stdc++.h>
#define fi first
#define se second
#define ll long long
#define pii pair<int,int>
using namespace std;
const int N=1e5+5;
template<typename T> inline void read(T &x){
	char ch=getchar();
	T op=1;
	while(ch<'0'||ch>'9'){
		if(ch=='-'){
			op=-1;
		}
		ch=getchar();
	}
	x=0;
	while(ch>='0'&&ch<='9'){
		x=x*10+ch-'0';
		ch=getchar();
	}
	x*=op;
}
template<typename T,typename ...L> inline void read(T &x,L &...l){
	read(x),read(l...);
}
template<typename T> inline void write(T x){
	if(x==0){
		putchar('0');
	}else{
		if(x<0){
			putchar('-');
			x=-x;
		}
		int top=0,stk[30];
		while(x){
			stk[++top]=x%10;
			x/=10;
		}
		while(top){
			putchar(stk[top--]+'0');
		}
	}
}
template<typename T,typename ...L> inline void write(T x,L ...l){
	write(x),putchar(' '),write(l...);
}
int c,t,n,m,k,d,len,x[N],y[N],v[N];
ll f[2*N];
int lsh[2*N];
vector<pii> seg[2*N];
struct SGT{
	struct Node{
		int l,r;
		ll mx,tag;
	}tree[8*N];
	void pushup(int p){
		tree[p].mx=max(tree[p<<1].mx,tree[p<<1|1].mx);
	}
	void pushdown(int p){
		tree[p<<1].mx+=tree[p].tag;
		tree[p<<1].tag+=tree[p].tag;
		tree[p<<1|1].mx+=tree[p].tag;
		tree[p<<1|1].tag+=tree[p].tag;
		tree[p].tag=0;
	}
	void build(int p,int l,int r){
		tree[p]={l,r,0,0};
		if(l<r){
			int mid=(l+r)/2;
			build(p<<1,l,mid);
			build(p<<1|1,mid+1,r);
		}
	}
	void modify(int p,int l,int r,ll v){
		int l1=tree[p].l,r1=tree[p].r;
		if(l<=l1&&r1<=r){
			tree[p].mx+=v;
			tree[p].tag+=v;
		}else{
			pushdown(p);
			int mid=(l1+r1)>>1;
			if(l<=mid){
				modify(p<<1,l,r,v);
			}
			if(r>mid){
				modify(p<<1|1,l,r,v);
			}
			pushup(p);
		}
	}
	ll query(int p,int l,int r){
		ll res=0;
		int l1=tree[p].l,r1=tree[p].r;
		if(l<=l1&&r1<=r){
			res=tree[p].mx;
		}else{
			pushdown(p);
			int mid=(l1+r1)>>1;
			if(l<=mid){
				res=max(res,query(p<<1,l,r));
			}
			if(r>mid){
				res=max(res,query(p<<1|1,l,r));
			}
		}
		return res;
	}
}tr;
int main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	read(c,t);
	while(t--){
		for(int i=1;i<=len;i++){
			seg[i].clear();
		}
		read(n,m,k,d);
		for(int i=1;i<=m;i++){
			read(x[i],y[i],v[i]);
			lsh[2*i-1]=x[i];
			lsh[2*i]=x[i]-y[i];
		}
		sort(lsh,lsh+2*m+1);
		len=unique(lsh,lsh+2*m+1)-lsh;
		for(int i=1;i<=m;i++){
			if(y[i]<=k){
				int r=lower_bound(lsh,lsh+len,x[i])-lsh+1;
				int l=lower_bound(lsh,lsh+len,x[i]-y[i])-lsh+1;
				seg[r].push_back({l,v[i]});
			}
		}
		tr.build(1,1,len);
		for(int i=1;i<=len;i++){
			int pos=lsh[i-1];
			tr.modify(1,i,i,f[i-1]+1ll*pos*d);
			if(seg[i].size()){
				for(int j=0;j<int(seg[i].size());j++){
					tr.modify(1,1,seg[i][j].fi,seg[i][j].se);
				}
				f[i]=tr.query(1,lower_bound(lsh,lsh+len,pos-k)-lsh+1,i)-1ll*pos*d;
			}else{
				f[i]=f[i-1];
			}
		}
		write(f[len]);
		putchar('\n');
	}
	return 0;
}
