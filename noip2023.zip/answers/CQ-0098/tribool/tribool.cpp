#include <bits/stdc++.h>
using namespace std;
const int N=1e5+5;
template<typename T> inline void read(T &x){
	char ch=getchar();
	T op=1;
	while(ch<'0'||ch>'9'){
		if(ch=='-'){
			op=-1;
		}
		ch=getchar();
	}
	x=0;
	while(ch>='0'&&ch<='9'){
		x=x*10+ch-'0';
		ch=getchar();
	}
	x*=op;
}
template<typename T,typename ...L> inline void read(T &x,L &...l){
	read(x),read(l...);
}
template<typename T> inline void write(T x){
	if(x==0){
		putchar('0');
	}else{
		if(x<0){
			putchar('-');
			x=-x;
		}
		int top=0,stk[30];
		while(x){
			stk[++top]=x%10;
			x/=10;
		}
		while(top){
			putchar(stk[top--]+'0');
		}
	}
}
template<typename T,typename ...L> inline void write(T x,L ...l){
	write(x),putchar(' '),write(l...);
}
int c,t,n,m,val[N],fa[2*N],ans;
int find(int x){
	return fa[x]!=x?fa[x]=find(fa[x]):fa[x];
}
void merge(int a,int b){
	a=find(a);
	b=find(b);
	fa[b]=a;
}
int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	read(c,t);
	while(t--){
		ans=0;
		read(n,m);
		for(int i=1;i<=n;i++){
			val[i]=i;
		}
		for(int i=1;i<=m;i++){
			char ch=getchar();
			int x,y;
			while(ch!='T'&&ch!='F'&&ch!='U'&&ch!='+'&&ch!='-'){
				ch=getchar();
			}
			switch(ch){
				case 'T':{
					read(x);
					val[x]=n+1;
					break;
				}
				case 'F':{
					read(x);
					val[x]=-n-1;
					break;
				}
				case 'U':{
					read(x);
					val[x]=0;
					break;
				}
				case '+':{
					read(x,y);
					val[x]=val[y];
					break;
				}
				case '-':{
					read(x,y);
					val[x]=-val[y];
					break;
				}
			}
		}
		for(int i=0;i<=2*n+2;i++){
			fa[i]=i;
		}
		for(int i=1;i<=n;i++){
			merge(i+n+1,val[i]+n+1);
			merge(-i+n+1,-val[i]+n+1);
		}
		for(int i=1;i<=n;i++){
			if(find(i+n+1)==find(-i+n+1)){
				ans++;
			}
		}
		write(ans);
		putchar('\n');
	}
	return 0;
}
