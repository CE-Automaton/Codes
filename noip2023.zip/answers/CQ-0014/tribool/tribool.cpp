#include<bits/stdc++.h>
using namespace std;

const int N = 2e5 + 10;
int n, m, tot, ans[N], cnt;

int fa[N], mo[N], w[N];
int getfather(int x)
{
	if(fa[x] != x)
	{
		int t = getfather(fa[x]);
		w[x] ^= w[fa[x]];
		fa[x] = t;
	}
	return fa[x];
}

int main()
{
	freopen("tribool.in", "r", stdin);
	freopen("tribool.out", "w", stdout);
	
	int T;
	cin >> n >> T;
	while(T--)
	{
		memset(ans, 0, sizeof(ans));
		cnt = 0;
		
		cin >> n >> m;
		tot = n + 3;
		for(int i = 1; i <= n + 3; i++) fa[i] = mo[i] = i, w[i] = 0;
		
		while(m--)
		{
			char op[2];
			int x, y;
			scanf("%s%d", op, &x);
			if(op[0] == '+' || op[0] == '-')
			{
				scanf("%d", &y);
				fa[++tot] = mo[y], mo[x] = tot, w[tot] = op[0] == '-';
			}
			else
				mo[x] = ++tot, fa[tot] = op[0] == 'T' ? n + 1 : op[0] == 'F' ? n + 2 : n + 3, w[tot] = 0;
		}
		
		ans[n + 1] = 1, ans[n + 2] = 2, ans[n + 3] = 3;
		for(int i = 1; i <= n; i++)
			if(getfather(mo[i]) != i) fa[i] = mo[i];
		for(int i = 1; i <= n; i++)
			if(!ans[getfather(i)] && (getfather(i), w[i]) != (getfather(mo[i]), w[mo[i]]))
				ans[getfather(i)] = 3;
				
		for(int i = 1; i <= n; i++)
			if(ans[getfather(i)] == 3)
				cnt++, ans[i] = 3;
		cout << cnt << endl;
	}
	return 0;
}

