#include<bits/stdc++.h>
using namespace std;

const int N = 2010;
int n, m, q, a[N], b[N];
int kx, ky, xp[N], xnum[N], yp[N], ynum[N];

bool f[N][N][2];
void work()
{
	f[0][0][0] = f[0][0][1] = 1;
	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= m; j++)
		{
			f[i][j][0] = f[i][j][1] = 0;
			if(a[i] < b[j]) f[i][j][0] = f[i - 1][j - 1][0] | f[i - 1][j][0] | f[i][j - 1][0];
			if(a[i] > b[j]) f[i][j][1] = f[i - 1][j - 1][1] | f[i - 1][j][1] | f[i][j - 1][1];
		}
	printf("%d", f[n][m][0] | f[n][m][1]);
}

int main()
{
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);
	
	cin >> n >> n >> m >> q;
	for(int i = 1; i <= n; i++) scanf("%d", &a[i]);
	for(int i = 1; i <= m; i++) scanf("%d", &b[i]);
	work();
	
	while(q--)
	{
		scanf("%d%d", &kx, &ky);
		for(int i = 1, x; i <= kx; i++)
		{
			scanf("%d%d", &xp[i], &x);
			xnum[i] = a[xp[i]], a[xp[i]] = x;
		}
		for(int i = 1, x; i <= ky; i++)
		{
			scanf("%d%d", &yp[i], &x);
			ynum[i] = b[yp[i]], b[yp[i]] = x;
		}
		work();
		for(int i = 1, x; i <= kx; i++) a[xp[i]] = xnum[i];
		for(int i = 1, x; i <= ky; i++) b[yp[i]] = ynum[i];
	}
	return 0;
}

