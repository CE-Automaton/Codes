#include<bits/stdc++.h>
using namespace std;
#define LL long long

const int N = 2e5 + 10;
int n, m, k, d;
LL ans;
struct node
{
	int l, r, d;
}x[N];
vector<int> ids;
struct tree
{
	int l, r;
	LL maxn;
	LL lazy;
}a[N * 4];
vector<node> change[N];

void pushup(int p)
{
	a[p].maxn = max(a[p << 1].maxn, a[p << 1 | 1].maxn);
}
void pushdown(int p)
{
	if(a[p].lazy != 0)
	{
		a[p << 1].maxn += a[p].lazy, a[p << 1 | 1].maxn += a[p].lazy;
		a[p << 1 | 1].lazy += a[p].lazy, a[p << 1 | 1].lazy += a[p].lazy, a[p].lazy = 0;
	}
}

void maketree(int p, int l, int r)
{
	a[p].l = l, a[p].r = r, a[p].maxn = a[p].lazy = 0;
	if(l != r)
	{
		int mid = l + r >> 1;
		maketree(p << 1, l, mid);
		maketree(p << 1 | 1, mid + 1, r);
	}
}

void modify(int p, int l, int r, LL d)
{
	if(l > r) return;
	if(l <= a[p].l && a[p].r <= r)
	{
		a[p].maxn += d, a[p].lazy += d;
		return;
	}
	
	pushdown(p);
	int mid = a[p].l + a[p].r >> 1;
	if(l <= mid) modify(p << 1, l, r, d);
	if(r > mid) modify(p << 1 | 1, l, r, d);
	pushup(p);
}

LL getmax(int p, int l, int r)
{
	if(l > r) return 0;
	if(l <= a[p].l && a[p].r <= r)
		return a[p].maxn;
	
	pushdown(p);
	int mid = a[p].l + a[p].r >> 1;
	LL maxn = 0;
	if(l <= mid) maxn = max(maxn, getmax(p << 1, l, r));
	if(r > mid) maxn = max(maxn, getmax(p << 1 | 1, l, r));
	return maxn;
}

int main()
{
	freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);
	
	int T;
	cin >> n >> T;
	while(T--)
	{
		ans = 0;
		ids.clear();
		
		cin >> n >> m >> k >> d;
		for(int i = 1; i <= m; i++)
		{
			scanf("%d%d%d", &x[i].r, &x[i].l, &x[i].d);
			x[i].l = x[i].r - x[i].l + 1;
			ids.push_back(x[i].l - 1), ids.push_back(x[i].r);
		}
		sort(ids.begin(), ids.end());
		ids.erase(unique(ids.begin(), ids.end()), ids.end());
		for(int i = 1; i <= m; i++)
		{
			x[i].l = lower_bound(ids.begin(), ids.end(), x[i].l - 1) - ids.begin() + 1;
			x[i].r = lower_bound(ids.begin(), ids.end(), x[i].r) - ids.begin();
			change[x[i].r].push_back({0, x[i].l - 2, x[i].d});
		}
		
		maketree(1, 0, ids.size() - 1);
		for(int i = 1; i < ids.size(); i++)
		{
			for(node j : change[i]) modify(1, j.l, j.r, j.d);
			change[i].clear();
			modify(1, 0, i - 1, -1ll * d * (ids[i] - ids[i - 1]));
			int l = 1, r = i + 1;
			while(l < r)
			{
				int mid = l + r >> 1;
				if(ids[i] - ids[mid - 1] <= k) r = mid;
				else l = mid + 1;
			}
			LL t = getmax(1, l - 1, i - 1);
			ans = max(ans, t), modify(1, i, i, ans);
		}
		
		cout << ans << endl;
	}
	return 0;
}

