#include<bits/stdc++.h>
using namespace std;
#define u64 unsigned long long

const int N = 6010, P = 13331;
int n, m, ans[N];
struct node
{
	string s;
	int id;
	u64 h;
	bool operator<(const node &t) const
	{
		return s < t.s;
	}
}a[N];
bool flag[N];

u64 get(string s)
{
	u64 res = 0;
	for(int i = 0; i < s.size(); i++)
		res = res * P + s[i];
	return res;
}

int main()
{
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);
	
	cin >> n >> m;
	for(int i = 1; i <= n; i++)
	{
		cin >> a[2 * i - 1].s; a[2 * i - 1].id = a[2 * i].id = i;
		sort(a[2 * i - 1].s.begin(), a[2 * i - 1].s.end());
		a[2 * i].s = a[2 * i - 1].s;
		reverse(a[2 * i].s.begin(), a[2 * i].s.end());
		a[2 * i - 1].h = get(a[2 * i - 1].s), a[2 * i].h = get(a[2 * i].s);
	}
	sort(a + 1, a + 2 * n + 1);
	
	memset(ans, -1, sizeof(ans));
	for(int i = 1; i <= 2 * n; i++)
		if(ans[a[i].id] == -1)
		{
			memset(flag, 0, sizeof(flag));
			for(int j = 2 * n; j > i; j--)
				if(a[i].h != a[j].h) flag[a[j].id] = 1;
			for(int j = 1; j <= n; j++)
				if(a[i].id != j && !flag[j])
				{
					ans[a[i].id] = 0;
					break;
				}
			if(ans[a[i].id] == -1) ans[a[i].id] = 1;
		}
	
	for(int i = 1; i <= n; i++)
		printf("%d", ans[i]);
	return 0;
}

