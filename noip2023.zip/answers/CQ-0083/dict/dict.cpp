#include <bits/stdc++.h>
using namespace std;
const int N = 3005;
const int inf = 1e9;
int a[N][N], b[N][N], n, m, suf[N], pre[N][N], cnt[N];
char s[N];
bool ans[N];
int main() {
    freopen("dict.in", "r", stdin);
    freopen("dict.out", "w", stdout);

    scanf("%d%d", &n, &m);
    for(int j = 1; j <= m; j++) {pre[0][j] = suf[j] = inf;}
    for(int i = 1; i <= n; i++) {
        scanf("%s", s + 1);
        for(int j = 0; j < 26; j++) cnt[j] = 0;
        for(int j = 1; j <= m; j++) { cnt[s[j] - 'a']++;}
        int k = 1; for(int j = 25; j >= 0; j--) {while(cnt[j]) {a[i][k++] = j; cnt[j]--;}}
        assert(k == m + 1);
        // for(int j = 1; j <= m; j++) a[i][j] = s[j] - 'a';
        // sort(a[i] + 1, a[i] + 1 + m, [&](int u, int v) {return u > v;});
        for(int j = 1; j <= m; j++) b[i][j] = a[i][m - j + 1];
        bool flag = 0;
        for(int j = 1; j <= m; j++) {
            if(pre[i - 1][j] == a[i][j]) continue;
            else {flag = pre[i - 1][j] > a[i][j]; break;}
        }
        for(int j = 1; j <= m; j++) pre[i][j] = flag ? a[i][j] : pre[i - 1][j];
    }
    for(int i = n; i; i--) {
        bool flag = 0;
        for(int j = 1; j <= m; j++) {
            if(pre[i - 1][j] == suf[j]) continue;
            else {flag = pre[i - 1][j] > suf[j]; break;}
        }
        ans[i] = 0;
        for(int j = 1; j <= m; j++) {
            int c = (flag == 1) ? suf[j] : pre[i - 1][j];
            if(b[i][j] == c) continue;
            else {ans[i] = c > b[i][j]; break;}
        }
        flag = 0;
        for(int j = 1; j <= m; j++) {
            if(suf[j] == a[i][j]) continue;
            else {flag = suf[j] > a[i][j]; break;}
        }
        if(flag == 1) {for(int j = 1; j <= m; j++) suf[j] = a[i][j];}
    }
    for(int i = 1; i <= n; i++) printf("%d", ans[i]);
    return 0;
}