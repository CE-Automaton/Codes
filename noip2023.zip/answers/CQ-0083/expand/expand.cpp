#include <bits/stdc++.h>
using namespace std;
const int N = 2005;
int X[N], Y[N], x[N], y[N], sx[N], sy[N], dx, n, m;
bool f[N][N];
inline bool check(int x, int y) {if(x == y) return 0; return (x < y) == dx;}
void solve() {
    if(X[1] == Y[1] || X[n] == Y[m]) {putchar('0'); return;}
    for(int i = 0; i <= n; i++) for(int j = 0; j <= m; j++) f[i][j] = 0;
    f[1][1] = 1; dx = X[1] < Y[1];
    if(!check(X[n], Y[m])) {putchar('0'); return;}
    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= m; j++) {
            if(!check(X[i], Y[j])) {continue;}
            f[i][j] |= f[i - 1][j] | f[i][j - 1] | f[i - 1][j - 1];
        }
    }
    putchar(f[n][m] ? '1' : '0');
}
int main() {
    freopen("expand.in", "r", stdin);
    freopen("expand.out", "w", stdout);

    int cid, q; scanf("%d%d%d%d", &cid, &n, &m, &q);
    for(int i = 1; i <= n; i++) {scanf("%d", &X[i]); x[i] = X[i];}
    for(int i = 1; i <= m; i++) {scanf("%d", &Y[i]); y[i] = Y[i];}
    solve();
    // printf("!");
    while(q--) {
        int tx, ty;
        scanf("%d%d", &tx, &ty);
        for(int i = 1; i <= tx; i++) {int p, v; scanf("%d%d", &p, &v); X[p] = v; sx[i] = p;}
        for(int i = 1; i <= ty; i++) {int p, v; scanf("%d%d", &p, &v); Y[p] = v; sy[i] = p;}
        solve();
        // for(int i = 1; i <= n; i++) X[i] = x[i], Y[i] = y[i];
        for(int i = 1; i <= tx; i++) X[sx[i]] = x[sx[i]];
        for(int i = 1; i <= ty; i++) Y[sy[i]] = y[sy[i]];
    }
    return 0;
}