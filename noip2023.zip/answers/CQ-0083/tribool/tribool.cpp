#include <bits/stdc++.h>
using namespace std;
const int N = 1e6 + 5;
const int inf = 1e9;
struct query {
    int op; int x, y;
}Q[N];
inline int Abs(int x) {return x > 0 ? x : -x;}
inline int Sign(int x) {return x > 0 ? 1 : 0;}
int Z[N], n, m, z[N], ans = inf, F = inf, T = inf + 1, bl[N];
void dfs1(int dep) {
    if(dep > n) {
        int t0 = 0; for(int i = 1; i <= n; i++) z[i] = Z[i], t0 += (Z[i] == 0);
        for(int i = 1; i <= m; i++) {
            if(Q[i].op == 2) {z[Q[i].x] = z[Q[i].y];}
            else if(Q[i].op == 3) {z[Q[i].x] = -z[Q[i].y];}
            else z[Q[i].x] = Q[i].op;
        }
        for(int i = 1; i <= n; i++) if(z[i] != Z[i]) {return;}
        ans = min(ans, t0);
        return;
    }
    Z[dep] = 1; dfs1(dep + 1);
    Z[dep] = 0; dfs1(dep + 1);
    Z[dep] = -1; dfs1(dep + 1);
}
bool mark[N];
int main() {
    freopen("tribool.in", "r", stdin);
    freopen("tribool.out", "w", stdout);

    int cid, tt; scanf("%d%d", &cid, &tt);
    while(tt--) {
        scanf("%d%d", &n, &m);
        // printf("!n=%d m=%d\n", n, m);
        for(int i = 1; i <= m; i++) {
            char ch[3]; int x = 0, y = 0; 
            scanf("%s", ch);
            if(ch[0] == '+' || ch[0] == '-') {scanf("%d%d", &x, &y); Q[i].op = (ch[0] == '+') ? 2 : 3;} 
            else {
                scanf("%d", &x);
                Q[i].op = (ch[0] == 'T') ? 1 : (ch[0] == 'F' ? -1 : 0);
            }
            Q[i].x = x; Q[i].y = y;
        }
        if(cid <= 2 || (n <= 10 && m <= 10)) {
            ans = 1e9; dfs1(1);
            printf("%d\n", ans);
        }
        else {
            for(int i = 1; i <= n; i++) bl[i] = i + n, mark[i] = 0;
            for(int i = 1; i <= m; i++) {
                if(Q[i].op == 2) {bl[Q[i].x] = bl[Q[i].y];}
                else if(Q[i].op == 3) {bl[Q[i].x] = -bl[Q[i].y];}
                else {bl[Q[i].x] = Q[i].op;}
            }
            ans = 0;
            for(int i = 1; i <= n; i++) {
                if(bl[i] == 0) {ans++; mark[i] = 1;}
                int val = Abs(bl[i]) - n;
                if(val < 1 || val != i) continue; mark[i] = !Sign(bl[i]);
            }
            for(int i = 1; i <= n; i++) {
                int val = Abs(bl[i]) - n;
                if(val < 1) continue; 
                ans += mark[val];
            }
            printf("%d\n", ans);
        }
    }
    return 0;
}