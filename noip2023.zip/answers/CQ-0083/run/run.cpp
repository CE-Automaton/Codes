#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll inf = 1e18;
const int N = 1e3 + 5;
ll f[N][N], val[N][N], g[N];
int main() {
    freopen("run.in", "r", stdin);
    freopen("run.out", "w", stdout);

    int cid, T; scanf("%d%d", &cid, &T);
    while(T--) {
        int n, m, K; ll d; scanf("%d%d%d%lld", &n, &m, &K, &d);
        for(int i = 0; i <= n; i++) for(int j = 0; j <= K; j++) val[i][j] = 0, f[i][j] = -inf;
        for(int i = 1; i <= m; i++) {int x, y; ll v; scanf("%d%d%lld", &x, &y, &v); val[x][y] += v;}
        for(int i = 1; i <= n; i++) for(int j = 1; j <= K; j++) val[i][j] += val[i][j - 1];
        f[0][0] = 0;
        for(int i = 1; i <= n; i++) {
            g[i] = f[i][0] = g[i - 1];
            for(int j = 1, up = min(i, K); j <= up; j++) {
                g[i] = max(g[i], f[i][j] = f[i - 1][j - 1] + val[i][j] - d);
                // printf("f(%d,%d)=%lld\n", i, j, f[i][j]);
            }
        }
        printf("%lld\n", g[n]);
    }
    return 0;
}