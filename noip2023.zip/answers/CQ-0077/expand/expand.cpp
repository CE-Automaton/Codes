#include<bits/stdc++.h>
using namespace std;
int c,n,m,q; 
const int maxn=5e5+5;
int a[maxn],b[maxn],A[maxn],B[maxn];
int dp[2005][2005];
inline void solve(){
	if(a[1]==b[1]){
		putchar('0');
		return ;
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			dp[i][j]=0;
		}
	}
	if(a[1]>b[1]){
		dp[1][1]=1;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				if(a[i]>b[j])
					dp[i][j]|=( dp[i-1][j-1] | dp[i-1][j] | dp[i][j-1]);
			}
		}
		putchar(dp[n][m]+'0');
	}
	if(a[1]<b[1]){
		dp[1][1]=1;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				if(a[i]<b[j])
					dp[i][j]|=(dp[i-1][j-1]|dp[i-1][j]|dp[i][j-1]);
			}
		}
		putchar(dp[n][m]+'0');
	}
}
inline void solve2(){
	
} 
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	scanf("%d%d%d%d",&c,&n,&m,&q);
	for(int i=1;i<=n;i++) scanf("%d",&A[i]);
	for(int i=1;i<=m;i++) scanf("%d",&B[i]);
	for(int i=1;i<=n;i++) a[i]=A[i];
	for(int i=1;i<=m;i++) b[i]=B[i];
	solve();
	while(q--){
		int kx,ky;
		scanf("%d%d",&kx,&ky);
		for(int i=1;i<=n;i++) a[i]=A[i];
		for(int i=1;i<=m;i++) b[i]=B[i];
		for(int i=1;i<=kx;i++){
			int px,vx;
			scanf("%d%d",&px,&vx);
			a[px]=vx;
		}
		for(int i=1;i<=ky;i++){
			int py,vy;
			scanf("%d%d",&py,&vy);
			b[py]=vy;
		}
		if(c<=7)
			solve();
		else if(c>=8 && c<=14)
			solve2(); 
	}
	return 0;
}
/*
���� F �� G ��С��ϵ��
����һλ��֪���ˡ�
 
*/
