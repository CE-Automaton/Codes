#include<bits/stdc++.h>
using namespace std;
template<typename G>inline void read(G&x) {x=0;G f=1;char ch=getchar();while((ch<'0'||ch>'9')&&ch!='-') ch=getchar();if(ch=='-') f=-1,ch=getchar();while(ch>='0'&&ch<='9') x=x*10+(ch^48),ch=getchar();x*=f;}
const int MAXN=2e3+5,MAXM=5e5+5;
int C,n,m,q;
int a[MAXM],b[MAXM];
int ta[MAXM],tb[MAXM];
bool f[MAXN][MAXN];
signed main() {
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	read(C),read(n),read(m),read(q);
	for(int i=1;i<=n;++i) read(a[i]);
	for(int i=1;i<=m;++i) read(b[i]);
	memcpy(ta,a,sizeof(a)),memcpy(tb,b,sizeof(b));
	if(C<=7) {
		memset(f,0,sizeof(f));f[0][0]=1;
		if(a[1]>b[1]) {
			for(int i=1;i<=n;++i) {
				for(int j=1;j<=m;++j) {
					f[i][j]=(a[i]>b[j]&&(f[i-1][j]||f[i-1][j-1]||f[i][j-1]));
				}
			}
			if(f[n][m]) putchar('1');
			else putchar('0');
		}
		if(a[1]<b[1]) {
			for(int i=1;i<=n;++i) {
				for(int j=1;j<=m;++j) {
					f[i][j]=(a[i]<b[j]&&(f[i-1][j]||f[i-1][j-1]||f[i][j-1]));
				}
			}
			if(f[n][m]) putchar('1');
			else putchar('0');
		}
		if(a[1]==b[1]) putchar('0');
	}
	else {
		int ii=2,jj=2,mn=b[1],mx=a[1],i=1,j=1;
		while(ii<=n&&a[ii]>=a[i]) mx=max(mx,a[ii]),++ii;
		while(jj<=m&&b[jj]<=b[j]) mn=min(mn,b[jj]),++jj;
		while(i<n||j<m) {
			if(j!=m&&a[i]<mn) {
				j=jj;
				mn=b[j],jj=j+1;
				while(jj<=m&&b[jj]<=b[j]) mn=min(mn,b[jj]),++jj;
			}
			else if(i!=n&&b[j]>mx) {
				i=ii;
				mx=a[i],ii=i+1;
				while(ii<=n&&a[ii]>=a[i]) mx=max(mx,a[ii]),++ii;
			}
			else break;
		}
		if(i==n&&j==m) putchar('1');
		else putchar('0');
//		return 0;
	}
	while(q--) {
		memcpy(a,ta,sizeof(a));
		memcpy(b,tb,sizeof(b));
		int kx,ky,x,y;
		read(kx),read(ky);
		for(int i=1;i<=kx;++i) {
			read(x),read(y);
			a[x]=y;
		}
		for(int i=1;i<=ky;++i) {
			read(x),read(y);
			b[x]=y;
		}
		if(C<=7) {
			memset(f,0,sizeof(f));f[0][0]=1;
			if(a[1]>b[1]) {
				for(int i=1;i<=n;++i) {
					for(int j=1;j<=m;++j) {
						f[i][j]=(a[i]>b[j]&&(f[i-1][j]||f[i-1][j-1]||f[i][j-1]));
					}
				}
				if(f[n][m]) putchar('1');
				else putchar('0');
			}
			if(a[1]<b[1]) {
				for(int i=1;i<=n;++i) {
					for(int j=1;j<=m;++j) {
						f[i][j]=(a[i]<b[j]&&(f[i-1][j]||f[i-1][j-1]||f[i][j-1]));
					}
				}
				if(f[n][m]) putchar('1');
				else putchar('0');
			}
			if(a[1]==b[1]) putchar('0');
		}
		else {
			int ii=2,jj=2,mn=b[1],mx=a[1],i=1,j=1;
			while(ii<=n&&a[ii]>=a[i]) mx=max(mx,a[ii]),++ii;
			while(jj<=m&&b[jj]<=b[j]) mn=min(mn,b[jj]),++jj;
			while(i<n||j<m) {
				if(j!=m&&a[i]<mn) {
					j=jj;
					mn=b[j],jj=j+1;
					while(jj<=m&&b[jj]<=b[j]) mn=min(mn,b[jj]),++jj;
				}
				else if(i!=n&&b[j]>mx) {
					i=ii;
					mx=a[i],ii=i+1;
					while(ii<=n&&a[ii]>=a[i]) mx=max(mx,a[ii]),++ii;
				}
				else break;
			}
			if(i==n&&j==m) putchar('1');
			else putchar('0');
		}
	}
	return 0;
}
