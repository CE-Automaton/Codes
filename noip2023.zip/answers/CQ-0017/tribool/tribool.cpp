#include<bits/stdc++.h>
using namespace std;
template<typename G>inline void read(G&x) {x=0;G f=1;char ch=getchar();while((ch<'0'||ch>'9')&&ch!='-') ch=getchar();if(ch=='-') f=-1,ch=getchar();while(ch>='0'&&ch<='9') x=x*10+(ch^48),ch=getchar();x*=f;}
const int MAXN=4e5+20;
int C,T;
int n,m,idx[MAXN];
vector<pair<int,bool> > G[MAXN];
bool vis[MAXN];int col[MAXN];
int ans;
bool flag;
int s[MAXN],top;
void dfs(int u) {
	vis[u]=1,s[++top]=u;
	int rev=(col[u]==2?2:col[u]^1);
	for(auto pii:G[u]) {
		int v=pii.first;bool w=pii.second;
		if(w==0) {
			if(vis[v]) {
				if(col[v]!=col[u]) flag=0;
			}
			else {
				col[v]=col[u];
				dfs(v);
			}
		}
		else {
			if(vis[v]) {
				if(col[v]!=rev) flag=0;
			}
			else {
				col[v]=rev;
				dfs(v);
			}
		}
	}
}
char op;int x,y;
signed main() {
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	read(C),read(T);
	while(T--) {
		read(n),read(m);
		int T=2*(n+m)+2,F=2*(n+m)+3,U=2*(n+m)+4;
		for(int i=2;i<=U;++i) G[i].clear();
		for(int i=1;i<=n;++i) idx[i]=(i<<1);
		for(int i=2;i<=2*(n+m)+2;i+=2) G[i].emplace_back(make_pair(i^1,1)),G[i^1].emplace_back(make_pair(i,1));
		for(int i=1;i<=m;++i) {
			op=getchar();
			while(op!='T'&&op!='F'&&op!='U'&&op!='+'&&op!='-') op=getchar();
			if(op=='+') {
				read(x),read(y);
				int iy=idx[y];
				idx[x]=2*(n+i);
				G[idx[x]].emplace_back(make_pair(iy,0));
				G[iy].emplace_back(make_pair(idx[x],0));
			}
			if(op=='-') {
				read(x),read(y);
				int iy=idx[y];
				idx[x]=2*(n+i);
				G[idx[x]].emplace_back(make_pair(iy^1,0));
				G[iy^1].emplace_back(make_pair(idx[x],0));
			}			
			if(op=='T') {
				read(x);
				idx[x]=2*(n+i);
				G[idx[x]].emplace_back(make_pair(T,0));
				G[T].emplace_back(make_pair(idx[x],0));
			}
			if(op=='F') {
				read(x);
				idx[x]=2*(n+i);
				G[idx[x]].emplace_back(make_pair(F,0));
				G[F].emplace_back(make_pair(idx[x],0));
			}
			if(op=='U') {
				read(x);
				idx[x]=2*(n+i);
				G[idx[x]].emplace_back(make_pair(U,0));
				G[U].emplace_back(make_pair(idx[x],0));
			}
		}
		for(int i=1;i<=n;++i) G[i<<1].emplace_back(make_pair(idx[i],0)),G[idx[i]].emplace_back(make_pair(i<<1,0));
		for(int i=2;i<=U;++i) vis[i]=0;
		ans=0;
		if(!vis[U]) flag=1,col[U]=2,dfs(U);
		if(!vis[F]) flag=1,col[F]=1,dfs(F);
		if(!vis[T]) flag=1,col[T]=0,dfs(T);
		for(int i=2;i<=U;++i) {
			if(!vis[i]) {
				top=0;
				flag=1,col[i]=0,dfs(i);
				if(flag==1) continue;
				while(top) vis[s[top--]]=0;
				flag=1,col[i]=1,dfs(i);
				if(flag==1) continue;
				while(top) vis[s[top--]]=0;
				flag=1,col[i]=2,dfs(i);
//				if(flag==0) assert(0);//assert! 
			}
		}
		for(int i=2;i<=2*n;i+=2) ans+=(col[i]==2);
		printf("%d\n",ans);
	}
	return 0;
}
