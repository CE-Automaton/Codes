#include<bits/stdc++.h>
using namespace std;
#define int long long
template<typename G>inline void read(G&x) {x=0;G f=1;char ch=getchar();while((ch<'0'||ch>'9')&&ch!='-') ch=getchar();if(ch=='-') f=-1,ch=getchar();while(ch>='0'&&ch<='9') x=x*10+(ch^48),ch=getchar();x*=f;}
const int MAXN=1e5+5;
int C,T;
struct Segment_Tree {
	int d[MAXN<<2],lazy[MAXN<<2];
	void pushdown(int p) {
		if(lazy[p]) {
			d[p<<1]+=lazy[p],d[p<<1|1]+=lazy[p];
			lazy[p<<1]+=lazy[p],lazy[p<<1|1]+=lazy[p];
			lazy[p]=0;
		}
	}
	void build(int l,int r,int p) {
		lazy[p]=d[p]=0;
		if(l==r) return;
		int mid=(l+r)>>1;
		build(l,mid,p<<1),build(mid+1,r,p<<1|1);
	}
	void modify(int l,int r,int ql,int qr,int p,int c) {
		if(l>=ql&&r<=qr) {
			d[p]+=c;
			lazy[p]+=c;
			return;
		}
		int mid=(l+r)>>1;pushdown(p);
		if(ql<=mid) modify(l,mid,ql,qr,p<<1,c);
		if(qr>mid) modify(mid+1,r,ql,qr,p<<1|1,c);
		d[p]=max(d[p<<1],d[p<<1|1]);
	}
}SGT;
struct node {
	int x,y,v;
	friend bool operator<(node a,node b) {return a.x<b.x;}
}a[MAXN];
int f[MAXN][105];
int n,m,k,d;
vector<pair<int,int> > M[MAXN];
int x,y,v;
signed main() {
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	read(C),read(T);
	while(T--) {
		read(n),read(m),read(k),read(d);
		if(C<=14) {
			for(int i=1;i<=n;++i) M[i].clear();
			for(int i=1;i<=m;++i) {
				read(x),read(y),read(v);
				M[x].emplace_back(make_pair(y,v));
			}
			SGT.build(1,n,1);
			int mx=0,ans=0,las=0;
			for(int i=1;i<=n;++i) {
				int r=i-k;
				if(r>=1) SGT.modify(1,n,r,r,1,-1e18);
				SGT.modify(1,n,1,i,1,-d);
				SGT.modify(1,n,i,i,1,mx);
				for(auto pii:M[i]) {
					int r=i-pii.first+1;
					if(r>=1) SGT.modify(1,n,1,r,1,pii.second);
				}
				mx=max(mx,las);
				ans=max(ans,SGT.d[1]);las=SGT.d[1];
			}
			printf("%lld\n",ans);
		}
		else {
			for(int i=1;i<=m;++i) {
				read(a[i].x),read(a[i].y),read(a[i].v);
			}
			sort(a+1,a+1+m);int las=0;
			for(int i=1;i<=m;++i) {
				int llas=0;
				for(int j=0;j<=k;++j) {
					if(a[i].x-a[i-1].x<=j) {
						f[i][j]=f[i-1][j-(a[i].x-a[i-1].x)]-d*(a[i].x-a[i-1].x);
						if(j>=a[i].y) f[i][j]+=a[i].v;
					}
					else {
						f[i][j]=las-d*j;
						if(j>=a[i].y) f[i][j]+=a[i].v;
					}
					llas=max(llas,f[i][j]);
				}
				las=llas;
			}
			int ans=0;
			for(int i=0;i<=k;++i) ans=max(ans,f[m][i]);
			printf("%lld\n",ans);
		}
	}
	return 0;
}
