#include<bits/stdc++.h>
using namespace std;
template<typename G>inline void read(G&x) {x=0;G f=1;char ch=getchar();while((ch<'0'||ch>'9')&&ch!='-') ch=getchar();if(ch=='-') f=-1,ch=getchar();while(ch>='0'&&ch<='9') x=x*10+(ch^48),ch=getchar();x*=f;}
const int MAXN=3e3+5;
int n,m;
int le[MAXN],ri[MAXN];
signed main() {
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	read(n),read(m);
	for(int i=1;i<=n;++i) {
		le[i]=25,ri[i]=0;
		for(int j=1;j<=m;++j) {
			char ch=getchar();
			while(ch<'a'||ch>'z') ch=getchar();
			le[i]=min(le[i],ch-'a');
			ri[i]=max(ri[i],ch-'a');
		}
	}
	for(int i=1;i<=n;++i) {
		int sum=0;
		for(int j=1;j<=n;++j) {
			if(j!=i) {
				if(le[i]<ri[j]) ++sum;
			}
		}
		if(sum==n-1) putchar('1');
		else putchar('0');
	}
	return 0;
}
