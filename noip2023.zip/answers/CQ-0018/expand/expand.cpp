#include<algorithm>
#include<cstdio>
#include<vector>
namespace burningContract{
//bool mbeg;
char ibuf[1<<23],*fip,*sip;
char gc(){
	if(fip==sip){
		fip=ibuf,sip=fip+fread(ibuf,1,1<<21,stdin);
		if(fip==sip)return EOF;
	}
	return *fip++;
}
int read(){
	int x=0;
	char ch=gc();
	while(ch>'9'||ch<'0')ch=gc();
	while(ch>='0'&&ch<='9')x=x*10+ch-48,ch=gc();
	return x;
}
const int maxn=5e5+5;
struct xds{
	struct px{
		int mx,mpos;
		friend px operator+(px now,px oth){
			return (px){std::max(now.mx,oth.mx),now.mx>oth.mx?now.mpos:oth.mpos};}
	};
	struct pi{
		int mi,mpos;
		friend pi operator+(pi now,pi oth){
			return (pi){std::min(now.mi,oth.mi),now.mi<oth.mi?now.mpos:oth.mpos};}
	};
	struct node{
		int l,r;
		px mx;
		pi mi;
	}tree[maxn*4];
	void update(int i){
		tree[i].mx=tree[i*2].mx+tree[i*2+1].mx;
		tree[i].mi=tree[i*2].mi+tree[i*2+1].mi;
		return;
	}
	void build(int i,int l,int r,int *v){
		tree[i].l=l,tree[i].r=r;
		if(l==r){
			tree[i].mx=(px){v[l],l},tree[i].mi=(pi){v[l],l};
			return;
		}
		int mid=(l+r)>>1;
		build(i*2,l,mid,v),build(i*2+1,mid+1,r,v);
		update(i);
		return;
	}
	int gmx(int i,int l,int mi){
//		printf("mi=%d,tree[i].l=%d,tree[i].r=%d,tree[i].mi.mi=%d\n",mi,tree[i].l,tree[i].r,tree[i].mi.mi);
		if(tree[i].l==tree[i].r)return tree[i].mi.mi>mi?tree[i].l:-1;
		if(tree[i*2].r>=l){
			int pos=(tree[i*2].mi.mi>mi?tree[i*2].r:gmx(i*2,l,mi));
			if(pos==tree[i*2].r)return tree[i*2+1].mi.mi>mi?tree[i*2+1].r:std::max(pos,gmx(i*2+1,l,mi));
			else return pos;
		}
		return gmx(i*2+1,l,mi);
	}
	int gmi(int i,int l,int mx){
		if(tree[i].l==tree[i].r)return tree[i].mx.mx<mx?tree[i].l:-1;
		if(tree[i*2].r>=l){
			int pos=(tree[i*2].mx.mx<mx?tree[i*2].r:gmi(i*2,l,mx));
			if(pos==tree[i*2].r)return tree[i*2+1].mx.mx<mx?tree[i*2+1].r:std::max(pos,gmi(i*2+1,l,mx));
			else return pos;
		}
		return gmi(i*2+1,l,mx);
	}
	int sgmi(int x,int y){return y==-1?x:std::min(x,y);}
	int igmx(int i,int r,int mi){
		if(tree[i].l==tree[i].r)return tree[i].mi.mi>mi?tree[i].l:-1;
		if(tree[i*2+1].l<=r){
			int pos=(tree[i*2+1].mi.mi>mi?tree[i*2+1].l:igmx(i*2+1,r,mi));
			if(pos==tree[i*2+1].l)return tree[i*2].mi.mi>mi?tree[i*2].l:sgmi(pos,igmx(i*2,r,mi));
			else return pos;
		}
		return igmx(i*2,r,mi);
	}
	int igmi(int i,int r,int mx){
		if(tree[i].l==tree[i].r)return tree[i].mx.mx<mx?tree[i].l:-1;
		if(tree[i*2+1].l<=r){
			int pos=(tree[i*2+1].mx.mx<mx?tree[i*2+1].l:igmi(i*2+1,r,mx));
			if(pos==tree[i*2+1].l)return tree[i*2].mx.mx<mx?tree[i*2].l:sgmi(pos,igmi(i*2,r,mx));
			else return pos;
		}
		return igmi(i*2,r,mx);
	}
	px qmx(int i,int l,int r){
		if(tree[i].l>=l&&tree[i].r<=r)return tree[i].mx;
		if(tree[i*2].r<l)return qmx(i*2+1,l,r);
		if(tree[i*2+1].l>r)return qmx(i*2,l,r);
		return qmx(i*2,l,r)+qmx(i*2+1,l,r);
	}
	pi qmi(int i,int l,int r){
		if(tree[i].l>=l&&tree[i].r<=r)return tree[i].mi;
		if(tree[i*2].r<l)return qmi(i*2+1,l,r);
		if(tree[i*2+1].l>r)return qmi(i*2,l,r);
		return qmi(i*2,l,r)+qmi(i*2+1,l,r);
	}
}f,g;
struct pii{int xpos,ipos;};
pii go(xds &up,xds &dw,int n,int m,int *fv,int *sv){
//	printf("fv[1]=%d,sv[1]=%d\n",fv[1],sv[1]);
	int fp=1,sp=1;
	while(fp!=n||sp!=m){
		if(fp==n){
			int np=dw.gmi(1,sp+1,fv[fp]);
			if(np==-1)return (pii){fp,sp};
			else sp=dw.qmi(1,sp+1,np).mpos;
		}
		else if(sp==m){
			int np=up.gmx(1,fp+1,sv[sp]);
			if(np==-1)return (pii){fp,sp};
			else fp=up.qmx(1,fp+1,np).mpos;
		}
		else{
//			printf("all,fp=%d,sp=%d\n",fp,sp);
			int gsp=dw.gmi(1,sp+1,fv[fp]),gfp=up.gmx(1,fp+1,sv[sp]);
			if(gsp==-1&&gfp==-1)return (pii){fp,sp};
			gsp=(gsp==-1?-1:dw.qmi(1,sp+1,gsp).mpos),gfp=(gfp==-1?-1:up.qmx(1,fp+1,gfp).mpos);
//			printf("gsp=%d,gfp=%d\n",gsp,gfp);
			bool goon=false;
			if(gsp!=-1&&sv[gsp]<=sv[sp])sp=gsp,goon=true;
			if(gfp!=-1&&fv[gfp]>=fv[fp])fp=gfp,goon=true;
			if(!goon)return (pii){fp,sp};
		}
	}
	return (pii){n,m};
}
pii igo(xds &up,xds &dw,int n,int m,int *fv,int *sv){
//	printf("fv[1]=%d,sv[1]=%d\n",fv[1],sv[1]);
	int fp=n,sp=m;
	int allc=0;
	while(fp!=1||sp!=1){
		allc++;
		if(fp==1){
			int np=dw.igmi(1,sp-1,fv[fp]);
			if(np==-1)return (pii){fp,sp};
			else sp=dw.qmi(1,np,sp-1).mpos;
		}
		else if(sp==1){
			int np=up.igmx(1,fp-1,sv[sp]);
			if(np==-1)return (pii){fp,sp};
			else fp=up.qmx(1,np,fp-1).mpos;
		}
		else{
//			printf("all,fp=%d,sp=%d\n",fp,sp);
			int gsp=dw.igmi(1,sp-1,fv[fp]),gfp=up.igmx(1,fp-1,sv[sp]);
			if(gsp==-1&&gfp==-1)return (pii){fp,sp};
			gsp=(gsp==-1?-1:dw.qmi(1,gsp,sp-1).mpos),gfp=(gfp==-1?-1:up.qmx(1,gfp,fp-1).mpos);
//			printf("gsp=%d,gfp=%d\n",gsp,gfp);
			bool goon=false;
			if(gsp!=-1&&sv[gsp]<=sv[sp])sp=gsp,goon=true;
			if(gfp!=-1&&fv[gfp]>=fv[fp])fp=gfp,goon=true;
			if(!goon)return (pii){fp,sp};
		}
	}
	return (pii){1,1};
}
int c,n,m,q;
int fv[maxn],gv[maxn];
int gfp[maxn],gfv[maxn],gsp[maxn],gsv[maxn];
int out[maxn];
void tian(int id){
//	printf("id=%d\n",id);
//	for(int i=1;i<=n;i++)printf("%d%c",fv[i]," \n"[i==n]);
//	for(int i=1;i<=m;i++)printf("%d%c",gv[i]," \n"[i==m]);
	pii fir=(pii){-1,-1},sec=(pii){-1,-1};
	if(fv[1]<gv[1]&&fv[n]<gv[m]){
		fir=go(g,f,m,n,gv,fv);
		if(fir.xpos==m&&fir.ipos==n){
//			fprintf(stderr,"orz\n");
			out[id]=1;
			return;
		}
		sec=igo(g,f,m,n,gv,fv)/*,printf("f<g\n")*/;
	}
	else if(fv[1]>gv[1]&&fv[n]>gv[m]){
		fir=go(f,g,n,m,fv,gv);
		if(fir.xpos==n&&fir.ipos==m){
//			fprintf(stderr,"orz\n");
			out[id]=1;
			return;
		}
		sec=igo(f,g,n,m,fv,gv)/*,printf("g<f\n")*/;
	}
	else return;
//	fprintf(stderr,"fir.xpos=%d,fir.ipos=%d,sec.xpos=%d,sec.ipos=%d\n",fir.xpos,fir.ipos,sec.xpos,sec.ipos);
	out[id]=(fir.xpos>=sec.xpos)&&(fir.ipos>=sec.ipos);
	return;
}
//bool mend;
signed main(){
//	fprintf(stderr,"%lld",&mbeg-&mend);
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	c=read(),n=read(),m=read(),q=read();
	for(int i=1;i<=n;i++)fv[i]=read();
	for(int i=1;i<=m;i++)gv[i]=read();
	f.build(1,1,n,fv),g.build(1,1,m,gv),tian(0);
	for(int i=1;i<=q;i++){
		int kx=read(),ky=read();
//		printf("kx=%d,ky=%d\n",kx,ky);
		for(int j=1;j<=kx;j++){
			int p=read(),v=read();
			gfp[j]=p,gfv[j]=fv[p],fv[p]=v;
		}
		for(int j=1;j<=ky;j++){
			int p=read(),v=read();
			gsp[j]=p,gsv[j]=gv[p],gv[p]=v;
		}
		f.build(1,1,n,fv),g.build(1,1,m,gv),tian(i);
		for(int j=1;j<=kx;j++){
			int p=gfp[j],v=gfv[j];
			fv[p]=v;
		}
		for(int j=1;j<=ky;j++){
			int p=gsp[j],v=gsv[j];
			gv[p]=v;
		}
	}
	for(int i=0;i<=q;i++)printf("%d",out[i]);
	return 0;
}
}
signed main(){return burningContract::main();}
//Wish all of you good luck.
//namespace burningContract
