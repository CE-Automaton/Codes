#include<algorithm>
#include<cstdio>
#include<vector>
namespace burningContract{
//bool mbeg;
char ibuf[1<<23],*fip,*sip;
char gc(){
	if(fip==sip){
		fip=ibuf,sip=fip+fread(ibuf,1,1<<21,stdin);
		if(fip==sip)return EOF;
	}
	return *fip++;
}
const int maxn=3e3+5;
int n,m;
int fid,sid;
int cou[maxn][27];
bool fsml(int x,int p){
	for(int i=26;i;i--)if(cou[x][i]!=cou[p][i])return cou[x][i]<cou[p][i];
	return false;
}
bool ssml(int x,int p){
	int fp=-1,sp=-1;
	for(int i=1;i<=26&&fp==-1;i++)if(cou[x][i])fp=i;
	for(int i=26;i&&sp==-1;i--)if(cou[p][i])sp=i;
	return fp<sp;
}
//bool mend;
signed main(){
//	fprintf(stderr,"%lld",&mbeg-&mend);
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n==1){
		printf("1");
		return 0;
	}
	fid=-1,sid=-1;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			char ch=gc();
			while(ch>'z'||ch<'a')ch=gc();
			cou[i][ch-'a'+1]++;
		}
		if(fid==-1||fsml(i,fid))sid=fid,fid=i;
		else if(sid==-1||fsml(i,sid))sid=i;
	}
//	printf("fid=%d,sid=%d\n",fid,sid);
	for(int i=1;i<=n;i++)putchar(ssml(i,i==fid?sid:fid)?'1':'0');
	return 0;
}
}
signed main(){return burningContract::main();}
//Wish all of you good luck.
//namespace burningContract
