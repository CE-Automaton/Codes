#include<algorithm>
#include<cstdio>
#include<vector>
namespace burningContract{
//bool mbeg;
char ibuf[1<<23],*fip,*sip;
char gc(){
	if(fip==sip){
		fip=ibuf,sip=fip+fread(ibuf,1,1<<21,stdin);
		if(fip==sip)return EOF;
	}
	return *fip++;
}
int read(){
	int x=0;
	char ch=gc();
	while(ch>'9'||ch<'0')ch=gc();
	while(ch>='0'&&ch<='9')x=x*10+ch-48,ch=gc();
	return x;
}
const int maxn=2e5+5;
const int edgm=maxn*4+5;
struct edge{int to,next;}qxx[edgm];
int qxx_cnt,h[maxn];
void add(int x,int y){
	qxx[++qxx_cnt]=(edge){y,h[x]},h[x]=qxx_cnt;
	return;
}
void ad(int x,int y){
	add(x,y),add(y,x);
	return;
}
int bel[maxn],bcnt;
int col[maxn];
bool need[maxn];
void dfs(int x,int c){
	col[x]=c,bel[x]=bcnt;
	for(int i=h[x];i;i=qxx[i].next){
		int v=qxx[i].to;
		if(!col[v])dfs(v,3-c);
		else if(col[x]==col[v])need[bel[x]]=true;
	}
	return;
}
int c,t;
int n,m;
int tp[maxn],tid[maxn];
//bool mend;
signed main(){
//	fprintf(stderr,"%lld\n",&mbeg-&mend);
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	c=read(),t=read();
	for(int wc=1;wc<=t;wc++){
		n=read(),m=read();
		qxx_cnt=bcnt=0;
		for(int i=1;i<=2*n;i++)tp[i]=0,tid[i]=i,bel[i]=0,col[i]=0,need[i]=false,h[i]=0;
		for(int i=1;i<=m;i++){
			char opt=gc();
			while(opt!='T'&&opt!='F'&&opt!='U'&&opt!='+'&&opt!='-')opt=gc();
			if(opt=='T'||opt=='F'||opt=='U'){
				int x=read();
				tp[x]=2,tid[x]=(opt=='T'?0:(opt=='F'?1:2));
			}
			else{
				int x=read(),y=read();
				if(tp[y]==2)tp[x]=2,tid[x]=(tid[y]==2?2:((opt=='+'?0:1)^tid[y]));
				else tp[x]=(opt=='+'?0:1)^tp[y],tid[x]=tid[y];
			}
		}
		for(int i=1;i<=n;i++){
//			printf("i=%d,tp=%d,tid=%d\n",i,tp[i],tid[i]);
			if(tp[i]!=2)ad(i,(1-tp[i])*n+tid[i]);
		}
		for(int i=1;i<=n;i++)ad(i,i+n);
		for(int i=1;i<=n;i++)if(!col[i])bcnt++,dfs(i,1);
		for(int i=1;i<=n;i++)if((tp[i]==2&&tid[i]==2))need[bel[i]]=true;
		int cou=0;
		for(int i=1;i<=n;i++)/*printf("top[%d]=%d\n",i,top(i)),*/cou+=need[bel[i]];
		printf("%d\n",cou);
	}
	return 0;
}
}
signed main(){return burningContract::main();}
/*
1 1
10 10
- 7 6
+ 4 1
+ 6 4
T 1
+ 2 9
- 9 10
U 10
+ 5 5
U 8
T 3
*/
//Wish all of you good luck.
//namespace burningContract
