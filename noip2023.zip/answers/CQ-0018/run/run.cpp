#include<algorithm>
#include<cstdio>
#include<vector>
#include<map>
namespace burningContract{
//bool mbeg;
typedef long long ll;
char ibuf[1<<23],*fip,*sip;
char gc(){
	if(fip==sip){
		fip=ibuf,sip=fip+fread(ibuf,1,1<<21,stdin);
		if(fip==sip)return EOF;
	}
	return *fip++;
}
int read(){
	int x=0;
	char ch=gc();
	while(ch>'9'||ch<'0')ch=gc();
	while(ch>='0'&&ch<='9')x=x*10+ch-48,ch=gc();
	return x;
}
const int maxn=2e5+5;
struct tree_array{
	ll tree[maxn];
	int lim;
	void res(int mx){
		lim=mx;
		for(int i=1;i<=lim;i++)tree[i]=0;
		return;
	}
	int lowbit(int x){return x&-x;}
	void modify(int x,ll v){
		for(int i=x;i<=lim;i+=lowbit(i))tree[i]=std::max(tree[i],v);
		return;
	}
	ll query(int x){
		if(x<0)return 0;
		ll ret=0;
		while(x)ret=std::max(ret,tree[x]),x-=lowbit(x);
		return ret;
	}
}bit;
struct stree_array{
	ll tree[maxn];
	int lim;
	void res(int mx){
		lim=mx;
		for(int i=1;i<=lim;i++)tree[i]=0;
		return;
	}
	int lowbit(int x){return x&-x;}
	void modify(int x,ll v){
		x=std::max(x,0);
		while(x)tree[x]+=v,x-=lowbit(x);
		return;
	}
	ll query(int x){
		x=std::max(x,0);
		ll ret=0;
		for(int i=x;i<=lim;i+=lowbit(i))ret+=tree[i];
		return ret;
	}
}sbit;
int c,t;
int n,m,k,d;
int l[maxn],r[maxn],v[maxn],ts[maxn],tcnt;
ll mx[maxn];
struct pii{int x,v;};
std::vector<pii>inc[maxn];
//bool mend;
signed main(){
//	fprintf(stderr,"%lld\n",&mbeg-&mend);
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	c=read(),t=read();
	for(int wc=1;wc<=t;wc++){
		n=read(),m=read(),k=read(),d=read();
		for(int i=1;i<=maxn-2;i++)inc[i].clear();
		bit.res(maxn-2),sbit.res(maxn-2),tcnt=0;
		for(int i=1;i<=m;i++){
			int x=read(),y=read(),gv=read();
			l[i]=x-y+1,r[i]=x,v[i]=gv,ts[++tcnt]=l[i],ts[++tcnt]=r[i];
//			printf("l=%d,r=%d,v=%d\n",l[i],r[i],v[i]);
		}
		std::sort(ts+1,ts+tcnt+1),tcnt=std::unique(ts+1,ts+tcnt+1)-ts-1;
		for(int i=1;i<=m;i++){
			l[i]=std::lower_bound(ts+1,ts+tcnt+1,l[i])-ts;
			r[i]=std::lower_bound(ts+1,ts+tcnt+1,r[i])-ts;
			inc[r[i]].push_back((pii){l[i],v[i]});
		}
		ll ans=0;
		for(int i=1;i<=tcnt;i++){
			mx[i]=0;
			for(pii now:inc[i])sbit.modify(now.x,now.v)/*,printf("x=%d,v=%d\n",now.x,now.v)*/;
			for(int j=i;j;j--){
				if(ts[i]-ts[j]>=k)break;
//				if(i<=10)printf("i=%d,j=%d,inc=%lld,fv=%lld\n",i,j,sbit.query(ts[j]),bit.query(ts[j]-2));
				mx[i]=std::max(mx[i],sbit.query(j)+bit.query(ts[j]==ts[j-1]+1?j-2:j-1)-1ll*(ts[i]-ts[j]+1)*d);
			}
			bit.modify(i,mx[i]),ans=std::max(ans,mx[i]);
//			printf("ts[%d]=%d,mx=%lld\n",i,ts[i],mx[i]);
		}
		printf("%lld\n",ans);
	}
	return 0;
}
}
signed main(){return burningContract::main();}
//Wish all of you good luck.
//namespace burningContract
