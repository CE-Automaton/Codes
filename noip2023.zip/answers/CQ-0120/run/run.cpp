#include<bits/stdc++.h>
#define lt id<<1
#define rt id<<1|1
using namespace std;
typedef long long ll;
inline int read()
{
    int x=0;char ch=getchar();
    while(!isdigit(ch)) ch=getchar();
    while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
    return x;
}
const int N=2e5+10,M=N<<2;
struct ok{
    int l,r,v;
    bool operator <(const ok &A) const{return r<A.r;}
}ask[N];
int id,T,n,m,k,d;
int cnt,b[M];
ll Mx[M],tag[M];
ll ans,dp[N];
vector<int>ned[N];
inline void Max(ll &x,ll y) {x=x>y?x:y;}
void build(int id,int l,int r)
{
    Mx[id]=tag[id]=0;
    if(l==r) return;
    int mid=(l+r)>>1;
    build(lt,l,mid);
    build(rt,mid+1,r);
}
void inc(int id,ll x) {Mx[id]+=x,tag[id]+=x;}
void push_up(int id) {Mx[id]=max(Mx[lt],Mx[rt]);}
void push_down(int id)
{
    if(!tag[id]) return;
    inc(lt,tag[id]),inc(rt,tag[id]);
    tag[id]=0;
}
void add(int id,int l,int r,int L,int R,ll x)
{
    if(l>R||r<L) return;
    if(L<=l&&r<=R) return inc(id,x);
    push_down(id);
    int mid=(l+r)>>1;
    add(lt,l,mid,L,R,x);
    add(rt,mid+1,r,L,R,x);
    push_up(id);
}
ll query(int id,int l,int r,int L,int R)
{
    if(l>R||r<L) return 0;
    if(L<=l&&r<=R) return Mx[id];
    push_down(id);
    int mid=(l+r)>>1;
    return max(query(lt,l,mid,L,R),query(rt,mid+1,r,L,R));
}
int main()
{
    freopen("run.in","r",stdin);
    freopen("run.out","w",stdout);
    id=read(),T=read();
    while(T--)
    {
        n=read(),m=read(),k=read(),d=read();
        ans=cnt=0;
        for(int i=1,x,y;i<=m;i++)
        {
            x=read(),y=read();
            ask[i]=(ok){x-y+1,x,0};
            ask[i].v=read();
            b[++cnt]=x-y+1;
            b[++cnt]=x;
        }
        sort(ask+1,ask+m+1);
        sort(b+1,b+cnt+1);
        cnt=unique(b+1,b+cnt+1)-b-1;
        for(int i=1;i<=cnt;i++) ned[i].clear();
        for(int i=1,T;i<=m;i++)
        {
            ask[i].l=lower_bound(b+1,b+cnt+1,ask[i].l)-b;
            ask[i].r=lower_bound(b+1,b+cnt+1,ask[i].r)-b;
            ned[ask[i].r].push_back(i);
        }
        build(1,1,cnt);
        ll pre=0;
        for(int i=1,l;i<=cnt;i++)
        {
            dp[i]=0;
            if(b[i-1]+1<b[i]) Max(pre,dp[i-1]);
            for(int x:ned[i])
                add(1,1,cnt,1,ask[x].l,ask[x].v);
            add(1,1,cnt,1,i-1,-1ll*d*(b[i]-b[i-1]));
            add(1,1,cnt,i,i,pre);
            l=upper_bound(b,b+cnt+1,b[i]-k)-b;
            dp[i]=query(1,1,cnt,l,i)-d;
            Max(pre,dp[i-1]);
        }
        for(int i=1;i<=cnt;i++) Max(ans,dp[i]);
        printf("%lld\n",ans);
    }
    fclose(stdin);fclose(stdout);
    return 0;
}