#include<bits/stdc++.h>
using namespace std;
const int N=3010;
const int base=233,mod=1e9+9;
int n,m,cnt,num[30];
int pw[N],h[N][N];
bool ans[N];
char a[N][N],b[N][N];
struct ok{
    int id,h[N];char a[N];bool B;
    bool operator <(const ok &A) const
    {
        int l=1,r=m,mid,res=0;
        while(l<=r)
        {
            mid=(l+r)>>1;
            if(h[mid]==A.h[mid]) res=mid,l=mid+1;
            else r=mid-1;
        }
        if(res==m) return B;
        return a[res+1]<A.a[res+1];
    }
}A[N+N];
inline void Min(int &x,int y) {x=x>y?y:x;}
int main()
{
    freopen("dict.in","r",stdin);
    freopen("dict.out","w",stdout);
    pw[0]=1;
    for(int i=1;i<N;i++) pw[i]=1ll*i*pw[i-1]%mod;
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++) scanf("%s",a[i]+1);
    for(int i=1,T;i<=n;i++)
    {
        for(int j=1;j<=m;j++) ++num[a[i][j]-'a'];
        T=0;
        for(int j=25;~j;j--)
            for(int k=0;k<num[j];k++) b[i][++T]=j+'a';
        T=0;
        for(int j=0;j<26;j++)
            for(int k=0;k<num[j];k++) a[i][++T]=j+'a';
        ++cnt;
        for(int j=1;j<=m;j++) A[cnt].a[j]=a[i][j];
        A[cnt].id=i;
        ++cnt;
        for(int j=1;j<=m;j++) A[cnt].a[j]=b[i][j];
        A[cnt].B=1;A[cnt].id=i;
        for(int j=0;j<26;j++) num[j]=0;
    }
    for(int i=1;i<=cnt;i++)
        for(int j=1;j<=m;j++)
            A[i].h[j]=(1ll*A[i].h[j-1]*base+A[i].a[j])%mod;
    sort(A+1,A+cnt+1);
    for(int i=1,sum=0;i<=cnt;i++)
        if(A[i].B) ++sum;
        else
        {
            bool same=1;
            for(int j=2;j<=m;j++)
                if(A[i].a[j]!=A[i].a[j-1]) same=0;
            ans[A[i].id]=(sum<=same);
        }
    for(int i=1;i<=n;i++) putchar(ans[i]?'1':'0');
    fclose(stdin);fclose(stdout);
    return 0;
}