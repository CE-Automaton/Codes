//About why English->vscode
//sto hua_lian orz
//sto konjakujelly orz
//sto Lisdery orz
//sto lmgoat orz
//sto zuishuai orz
//sto Shadow_YYH orz
//sto Mr_XBJ orz
//sto unreachable orz
//I guess at least 15 persons AK.
//After then,why don't come to Genshin Impact?
#include<bits/stdc++.h>
using namespace std;
inline int read()
{
    int x=0;char ch=getchar();
    while(!isdigit(ch)) ch=getchar();
    while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
    return x;
}
const int N=5e5+10,M=2010;
int id,n,m,q,a[N],b[N],Ia[N],Ib[N],Ta[N],Tb[N];
bool dp[M][M];
inline int check(int x,int y) {return x<y?1:(x>y?2:0);}
void solve()
{
    int ned=check(a[1],b[1]);
    dp[1][1]=1;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)
        {
            if(ned!=check(a[i],b[j])) dp[i][j]=0;
            if(!dp[i][j]) continue;
            dp[i][j+1]=dp[i+1][j]=dp[i+1][j+1]=1;
            if(i!=n||j!=m) dp[i][j]=0;
        }
    putchar(dp[n][m]?'1':'0');
    dp[n][m]=0;
}
int main()
{
    freopen("expand.in","r",stdin);
    freopen("expand.out","w",stdout);
    id=read(),n=read(),m=read(),q=read();
    for(int i=1;i<=n;i++) a[i]=read();
    for(int i=1;i<=m;i++) b[i]=read();
    solve();
    int x,y;
    for(int k=1;k<=q;k++)
    {
        x=read(),y=read();
        for(int i=1;i<=x;i++)
            Ia[i]=read(),Ta[i]=read(),swap(a[Ia[i]],Ta[i]);
        for(int i=1;i<=y;i++)
            Ib[i]=read(),Tb[i]=read(),swap(b[Ib[i]],Tb[i]);
        solve();
        for(int i=1;i<=x;i++) swap(a[Ia[i]],Ta[i]);
        for(int i=1;i<=y;i++) swap(b[Ib[i]],Tb[i]);
    }
    fclose(stdin);fclose(stdout);
    return 0;
}