#include<bits/stdc++.h>
using namespace std;
inline int read()
{
    int x=0;char ch=getchar();
    while(!isdigit(ch)) ch=getchar();
    while(isdigit(ch)) x=(x<<3)+(x<<1)+(ch^48),ch=getchar();
    return x;
}
const int N=1e5+10;
struct ok{
    int v,p;
};
int id,T,n,m,ans,num,col[N];
int p[N],k[N];
bool flag;
map<char,int>ID;
vector<ok>edge[N];
void dfs(int x)
{
    ++num;
    if(x==n+3) flag=1,--num;
    for(ok v:edge[x])
        if(!~col[v.v]) col[v.v]=col[x]^v.p,dfs(v.v);
        else if(col[v.v]!=(col[x]^v.p)) flag=1;
}
int main()
{
    freopen("tribool.in","r",stdin);
    freopen("tribool.out","w",stdout);
    id=read(),T=read();
    char ch;
    int x,y;
    while(T--)
    {
        n=read(),m=read();
        ID['T']=n+1;
        ID['F']=n+2;
        ID['U']=n+3;ans=0;
        for(int i=1;i<=n+3;i++)
            p[i]=0,k[i]=i,col[i]=-1,edge[i].clear();
        while(m--)
        {
            ch=getchar(),x=read();
            if(ch=='+') y=read(),p[x]=p[y],k[x]=k[y];
            else if(ch=='-') y=read(),p[x]=p[y]^1,k[x]=k[y];
            else p[x]=0,k[x]=ID[ch];
        }
        for(int i=1;i<=n;i++)
            edge[i].push_back((ok){k[i],p[i]}),
            edge[k[i]].push_back((ok){i,p[i]});
        for(int i=1;i<=n;i++)
            if(!~col[i])
            {
                num=flag=col[i]=0,dfs(i);
                if(flag) ans+=num;
            }
        printf("%d\n",ans);
    }
    fclose(stdin);fclose(stdout);
    return 0;
}