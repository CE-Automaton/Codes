#include<bits/stdc++.h>
using namespace std;
template<class T>
inline void qr(T&x){
    bool f=(x=0); char c;
    while(c=getchar(),!isdigit(c)) f|=c=='-';
    while(isdigit(c)) x=x*10+(c^48),c=getchar();
    x=f?-x:x;
}
inline void qr(char&c){while(c=getchar(),c==' '||c=='\n'||c=='\r');}
template<class T,class...Args>
inline void qr(T&x,Args&...args){qr(x),qr(args...);}
const int MAXN=1e5+5;
struct imp{
    char op;
    int i,j;
} a[MAXN];
vector<int> node[MAXN];
int tot;
int f[MAXN*4];
inline int anc(int x){return x==f[x]?x:f[x]=anc(f[x]);}
inline void merge(int x,int y){f[anc(x)]=anc(y);}
int main(){
    freopen("tribool.in","r",stdin);
    freopen("tribool.out","w",stdout);
    int C,T;
    qr(C,T);
    while(T--){
        int n,m;
        qr(n,m);
        for(int i=1;i<=m;++i){
            qr(a[i].op);
            if(a[i].op=='+'||a[i].op=='-') qr(a[i].i,a[i].j);
            else qr(a[i].i);
        }
        for(int i=1;i<=n;++i) node[i].clear();
        for(int i=1;i<=n;++i) node[i].push_back(i);
        tot=n;
        for(int i=1;i<=n+n+m+m;++i) f[i]=i;
        auto link=[&](const int &x,const int &y,const int &t)->void {
            if(t==1) merge(x,y),merge(x+n+m,y+n+m);
            else merge(x,y+n+m),merge(x+n+m,y);
        };
        for(int i=m;i>=1;--i){
            if(a[i].op=='+'||a[i].op=='-'){
                int t=a[i].op=='+';
                if(a[i].i!=a[i].j){
                    link(node[a[i].i].back(),node[a[i].j].back(),t);
                    node[a[i].i].push_back(++tot);
                }
                else{
                    link(++tot,node[a[i].i].back(),t);
                    node[a[i].i].push_back(tot);
                }
            }
            else{
                int x=a[i].i;
                if(a[i].op=='U') merge(node[x].back(),node[x].back()+n+m);
                node[x].push_back(++tot);
            }
        }
        for(int i=1;i<=n;++i) link(node[i].front(),node[i].back(),1);
        int ans=0;
        for(int i=1;i<=n;++i){
            int p=anc(node[i].back()),q=anc(node[i].back()+n+m);
            ans+=p==q;
        }
        cout<<ans<<endl;
    }
}