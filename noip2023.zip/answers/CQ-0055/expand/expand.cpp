#include<bits/stdc++.h>
using namespace std;
template<class T>
inline void qr(T&x){
    bool f=(x=0); char c;
    while(c=getchar(),!isdigit(c)) f|=c=='-';
    while(isdigit(c)) x=x*10+(c^48),c=getchar();
    x=f?-x:x;
}
template<class T,class...Args>
inline void qr(T&x,Args&...args){qr(x),qr(args...);}

const int MAXN=5e5+5;
int a[MAXN],b[MAXN],A[MAXN],B[MAXN];
bool dp[2005][2005];
bool solve_1(int n,int m){
    if(a[1]==b[1]) return 0;
    if(a[1]>b[1]){
        for(int i=1;i<=max(n,m);++i){
            swap(a[i],b[i]);
        }
        swap(n,m);
    }
    //a[1]<b[1]
    if(a[n]>=b[m]) return 0;
    dp[1][1]=1;
    for(int i=1;i<=n;++i){
        for(int j=1;j<=m;++j){
            if(i==1&&j==1) continue;
            dp[i][j]=0;
            if(a[i]>=b[j]) continue;
            dp[i][j]=dp[i-1][j]||dp[i][j-1];
        }
    }
    return dp[n][m];
}
bool solve_2(int n,int m){
    return 0;
}
int main(){
    freopen("expand.in","r",stdin);
    freopen("expand.out","w",stdout);
    int c,n,m,q;
    qr(c,n,m,q);
    for(int i=1;i<=n;++i) qr(A[i]),a[i]=A[i];
    for(int i=1;i<=m;++i) qr(B[i]),b[i]=B[i];
    auto solve=[&]()->bool {if(c<=7) return solve_1(n,m); else return solve_2(n,m);};
    printf("%d",solve());
    while(q--){
        for(int i=1;i<=n;++i) a[i]=A[i];
        for(int i=1;i<=n;++i) b[i]=B[i];
        int kx,ky;
        qr(kx,ky);
        while(kx--){int p,i;qr(p,i),a[p]=i;}
        while(ky--){int p,i;qr(p,i),b[p]=i;}
        printf("%d",solve());
    }
}