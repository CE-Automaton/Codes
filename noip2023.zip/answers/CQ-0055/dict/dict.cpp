#include<bits/stdc++.h>
using namespace std;
template<class T>
inline void qr(T&x){
    bool f=(x=0); char c;
    while(c=getchar(),!isdigit(c)) f|=c=='-';
    while(isdigit(c)) x=x*10+(c^48),c=getchar();
    x=f?-x:x;
}
template<class T,class...Args>
inline void qr(T&x,Args&...args){qr(x),qr(args...);}

const int MAXN=3e3+5;
char a[MAXN*2][MAXN];
struct node{
    int cnt[32];
    int rev;
    int id;
    inline bool operator<(const node&o){
        if(rev==0&&o.rev==0){
            for(int i=0;i<26;++i){
                if(cnt[i]!=o.cnt[i]){
                    return cnt[i]>o.cnt[i];
                }
            }
            return 0;
        }
        if(rev==1&&o.rev==1){
            for(int i=25;i>=0;--i){
                if(cnt[i]!=o.cnt[i]){
                    return cnt[i]<o.cnt[i];
                }
            }
            return 0;
        }
        int mx1=0,mn1=0,mx2=0,mn2=0;
        for(int i=0;i<26;++i) if(cnt[i]) mx1=i;
        for(int i=25;i>=0;--i) if(cnt[i]) mn1=i;
        for(int i=0;i<26;++i) if(o.cnt[i]) mx2=i;
        for(int i=25;i>=0;--i) if(o.cnt[i]) mn2=i;
        if(rev==0&&o.rev==1){
            if(mn1>mx2) return 0;
            if(mn1==mx1&&mx1==mn2&&mn2==mx2) return 1;
            if(mn1==mx2) return 0;
            return 1;
        }
        if(rev==1&&o.rev==0){
            if(mx1<mn2) return 1;
            if(mn1==mx1&&mx1==mn2&&mn2==mx2) return 0;
            if(mx1==mn2) return 1;
            return 0;
        }
        assert(0);
    }
} s[MAXN*2];
bool fail[MAXN];
int main(){
    freopen("dict.in","r",stdin);
    freopen("dict.out","w",stdout);
    int n,m;
    qr(n,m);
    for(int i=1;i<=n;++i){
        cin>>a[i]+1;
        for(int j=1;j<=m;++j){
            ++s[i].cnt[a[i][j]-'a'];
            ++s[i+n].cnt[a[i][j]-'a'];
        }
        s[i].id=s[i+n].id=i;
        s[i+n].rev=1;
    }
    // for(int i=1;i<=n*2;++i){
    //     for(int j=1;j<=n*2;++j){
    //         cout<<(s[i]<s[j])<<' ';
    //     }
    //     cout<<endl;
    // }
    sort(s+1,s+n*2+1);
    int id=0;
    for(int i=1;i<=n*2;++i) if(s[i].rev==1) {id=i; break;}
    for(int i=1;i<=n*2;++i){
        if(s[i].rev==0&&!(s[i]<s[id])&&!(s[id]<s[i])){
            fail[s[i].id]=1;
        }
    }
    for(int i=id;i<=n*2;++i) if(s[i].rev==0) fail[s[i].id]=1;
    for(int i=1;i<=n;++i) printf("%d",!fail[i]);
}