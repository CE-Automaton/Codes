#include<bits/stdc++.h>
using namespace std;
template<class T>
inline void qr(T&x){
    bool f=(x=0); char c;
    while(c=getchar(),!isdigit(c)) f|=c=='-';
    while(isdigit(c)) x=x*10+(c^48),c=getchar();
    x=f?-x:x;
}
template<class T,class...Args>
inline void qr(T&x,Args&...args){qr(x),qr(args...);}
#define ll long long 
namespace Subtask1{
    const int MAXN=2e3+5;
    ll mp[MAXN][MAXN];
    ll dp[MAXN];
    ll solve(){
        int n,m,k,d;
        qr(n,m,k,d);
        memset(mp,0,sizeof(mp));
        for(int i=1;i<=m;++i){
            int x,y,v;
            qr(x,y,v);
            int l=x-y+1,r=x;
            mp[1][r]+=v;
            mp[l+1][r]-=v;
        }
        for(int i=1;i<=n;++i){
            for(int j=1;j<=n;++j){
                mp[i][j]=mp[i][j]-mp[i-1][j-1]+mp[i-1][j]+mp[i][j-1];
            }
        }
        dp[1]=max(0ll,mp[1][1]-d);
        for(int i=2;i<=n;++i){
            dp[i]=dp[i-1];
            for(int j=max(i-k+1,1);j<=i;++j){
                dp[i]=max(dp[i],(j==1?0:dp[j-2])+mp[j][i]-(i-j+1)*d);
            }
        }
        return dp[n];
    }
};

namespace SubtaskB{
    const int MAXN=1e5+5;
    
    ll solve(){
        int n,m,k,d;
        qr(n,m,k,d);
        for(int i=1;i<=m;++i){
            int x,y,v;
            qr(x,y,v);

        }
    }
};
int main(){
    freopen("run.in","r",stdin);
    freopen("run.out","w",stdout);
    int C,T;
    qr(C,T);
    while(T--){
        if(C<=9) cout<<Subtask1::solve()<<endl;
        else cout<<0<<endl;
    }
}

/*
估分 100+100+35+45=280。
很惊险。T1 对拍 2k 组出 hack。当时还有 15min。给吓麻了。
然后 T2 也拍出来过 hack。
所以如果我不对拍就是 80pts 了。/jk
有点怕 T1 TLE。随机数据本机是 0.6s。
我去。搞忘去 linux 测效率了。
算了不管了。
感觉这个是中规中矩的分。不知道大家得分怎样。
要是大家都不会 B 我就大 win 特 win 了。
虽然感觉不是很可能。
那我就只是大众分。/ll
要是是春测一样的话我就消愁了。
不过妹妹祝我 rp++ 了。
我肯定会好运的。
祝其他人都挂完分。
哎。
这周回去就全日制学文化课了。
感觉文化课学起来很是受不了。
*/