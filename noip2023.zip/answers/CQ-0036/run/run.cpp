#include<bits/stdc++.h>
using namespace std;
const int N = 3e5+5;
const int P = 1;
template<typename T>inline void read(T &a) {
	a = 0;
	char c = ' ';
	int f = 1;
	while(!isdigit(c)) {
		c = getchar();
		if(c == '-') f = -1;
	}
	while(isdigit(c)) {
		a = a * 10 + c - '0', c = getchar();
	}
	a *= f;
}

template<typename T, typename ...L> inline void read(T &a, L &...l) {
	read(a), read(l...);
}

inline int Add(int a, int b) {
	return a + b >= P ? a + b - P : a + b;
}

inline void Inc(int &a, int b) {
	a = Add(a, b);
}

inline int Mul(int a, int b) {
	return (long long)a * b % P;
}

inline int Sub(int a, int b) {
	return a - b < 0 ? a - b + P : a - b;
}
typedef pair<int, int> pii;
typedef long long ll;

struct Node {
    int l, r;
    ll tag, mx;
}arr[N << 2];

vector<int> alls;
ll dp[N], dp0[N];
int c, T, n, m, k, d, x[N], y[N], v[N];
vector<pii> mdf[N];

void build(int u, int l, int r) {
    arr[u].l = l, arr[u].r = r, arr[u].tag = 0, arr[u].mx = -0x3f3f3f3f3f3f3f3f;
    if(l == r) {
        return;
    }
    int mid = (l + r) >> 1;
    build(u << 1, l, mid), build(u << 1 | 1, mid + 1, r);
}

void pushdown2(Node u, Node &l) {
    l.tag += u.tag;
    l.mx += u.tag;
}

void pushdown(int u) {
    pushdown2(arr[u], arr[u << 1]);
    pushdown2(arr[u], arr[u << 1 | 1]);
    arr[u].tag = 0;
}

void pushup(int u) {
    arr[u].mx = max(arr[u << 1].mx, arr[u << 1 | 1].mx);
}

void add(int u, int l, int r, ll t) {
    if(arr[u].l >= l && arr[u].r <= r) {
        arr[u].tag += t;
        arr[u].mx += t;
        return;
    }
    pushdown(u);
    int mid = (arr[u].l + arr[u].r) >> 1;
    if(l <= mid) {
        add(u << 1, l, r, t);
    }
    if(r > mid) {
        add(u << 1 | 1, l, r, t);
    }
    pushup(u);
    return;
}

void upd(int u, int x) {
    if(arr[u].l == arr[u].r) {
        arr[u].mx = dp0[arr[u].l] + (alls[arr[u].l]) * ll(d);
        return;
    }
    pushdown(u);
    int mid = (arr[u].l + arr[u].r) >> 1;
    if(x <= mid) {
        upd(u << 1, x);
    }
    else {
        upd(u << 1 | 1, x);
    }
    pushup(u);
}

ll query(int u, int l, int r) {
    if(l > r) {
        return -0x3f3f3f3f3f3f3f3f;
    }
    if(arr[u].l >= l && arr[u].r <= r) {
        return arr[u].mx;
    }
    pushdown(u);
    int mid = (arr[u].l + arr[u].r) >> 1;
    ll ans = -0x3f3f3f3f3f3f3f3f;
    if(l <= mid) {
        ans = max(ans, query(u << 1, l, r));
    }
    if(r > mid) {
        ans = max(ans, query(u << 1 | 1, l, r));
    }
    return ans;
}

void solve() {
    alls.clear();
    read(n, m, k, d);
    for(int i = 1; i <= m; i++) {
        read(x[i], y[i], v[i]);
        alls.emplace_back(x[i]);
        alls.emplace_back(x[i] - y[i]);
    }
    alls.emplace_back(0);
    sort(alls.begin(), alls.end());
    alls.erase(unique(alls.begin(), alls.end()), alls.end());
    for(int i = 1; i < int(alls.size()); i++) {
        mdf[i].clear();
    }
    for(int i = 1; i <= m; i++) {
        y[i] = lower_bound(alls.begin(), alls.end(), x[i] - y[i]) - alls.begin();
        x[i] = lower_bound(alls.begin(), alls.end(), x[i]) - alls.begin();
        mdf[x[i]].emplace_back(y[i], v[i]);
    }
    build(1, 0, int(alls.size()) - 1);
    for(int i = 1; i < int(alls.size()); i++) {
        upd(1, i - 1);
        for(auto it:mdf[i]) {
            add(1, 0, it.first, it.second);
        }
        int p = lower_bound(alls.begin(), alls.end(), alls[i] - k) - alls.begin();
        dp[i] = query(1, p, i - 1) - alls[i] * ll(d);
        dp0[i] = max(dp0[i - 1], dp[i - 1]);
    }
    printf("%lld\n", *max_element(dp, dp + int(alls.size())));
}

int main() {
    freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);
    read(c, T);
    while(T--) {
        solve();
    }
	return 0;
}
/*
2023/11/18 12:30
Aked.(if no FST/fn)
OI无悔。
谢谢大家，谢谢。
orz InvisibleWing
orz liuhangxin
orz Ishy
orz yanghanyv
orz yanshanjiahong(shenxian)
orz lisichang
orz chery
orz fire51
orz StayAlone
orz Hooch
orz Shunpower
orz LPhang
orz ChichenURsobeautiful
*/