#include<bits/stdc++.h>
using namespace std;
const int N = 2e5+5;
const int P = 1;
template<typename T>inline void read(T &a) {
	a = 0;
	char c = ' ';
	int f = 1;
	while(!isdigit(c)) {
		c = getchar();
		if(c == '-') f = -1;
	}
	while(isdigit(c)) {
		a = a * 10 + c - '0', c = getchar();
	}
	a *= f;
}

template<typename T, typename ...L> inline void read(T &a, L &...l) {
	read(a), read(l...);
}

inline int Add(int a, int b) {
	return a + b >= P ? a + b - P : a + b;
}

inline void Inc(int &a, int b) {
	a = Add(a, b);
}

inline int Mul(int a, int b) {
	return (long long)a * b % P;
}

inline int Sub(int a, int b) {
	return a - b < 0 ? a - b + P : a - b;
}

int fa[N], szeU[N], n, m, c, T, a, b;//is there u?
typedef pair<int, int> pii;
pii res[N];//first:val, second:TF, first = N - 1:U, first = N - 2:T, first = N - 3:F

char v;
int find(int x) {
    return x == fa[x] ? x : fa[x] = find(fa[x]);
}

void solve() {
    read(n, m);
    for(int i = 1; i <= n * 2; i++) {
        fa[i] = i, szeU[i] = 0, res[i] = make_pair(i, 0);//same with the first
    }
    while(m--) {
        cin>>v;
        if(v == 'T' || v == 'F' || v == 'U') {
            read(a);
            if(v == 'U') {
                res[a] = make_pair(N - 1, 0);
            }
            else if(v == 'T') {
                res[a] = make_pair(N - 2, 0);
            }
            else {
                res[a] = make_pair(N - 3, 0);
            }
        }
        else if(v == '+') {
            read(a, b);
            res[a] = res[b];
        }
        else {
            read(a, b);
            if(res[b].first >= N - 3) {
                res[a] = res[b];
                if(res[a].first == N - 2) res[a].first = N - 3;
                else if(res[a].first == N - 3) res[a].first = N - 2;
            }
            else {
                res[a] = res[b];
                res[a].second ^= 1;
            }
        }
    }
    for(int i = 1; i <= n; i++) {
        if(res[i].first == N - 1) {
            szeU[i] = szeU[i + n] = 1;
        }
    }
    for(int i = 1; i <= n; i++) {
        if(res[i].first < N - 3) {
            if(res[i].second) {
                int u = find(res[i].first), v = find(i + n);
                if(u != v) fa[u] = v, szeU[v] += szeU[u];
                u = find(res[i].first + n), v = find(i);
                if(u != v) fa[u] = v, szeU[v] += szeU[u];
            }
            else {
                int u = find(res[i].first), v = find(i);
                if(u != v) fa[u] = v, szeU[v] += szeU[u];
                u = find(res[i].first + n), v = find(i + n);
                if(u != v) fa[u] = v, szeU[v] += szeU[u];
            }
        }
    }
    int ans = 0;
    for(int i = 1; i <= n; i++) {
        if(szeU[find(i)] || szeU[find(i + n)] || find(i) == find(i + n)) ans++;
    }
    cout<<ans<<endl;
}

int main() {
	freopen("tribool.in", "r", stdin);
	freopen("tribool.out", "w", stdout);
    read(c, T);
    while(T--) {
        solve();//clearclearclearclearclear!!!!!!!!!!!!!!!!!
    }	
	return 0;
}
