#include<bits/stdc++.h>
using namespace std;
const int N = 3005;
const int P = 1;
template<typename T>inline void read(T &a) {
	a = 0;
	char c = ' ';
	int f = 1;
	while(!isdigit(c)) {
		c = getchar();
		if(c == '-') f = -1;
	}
	while(isdigit(c)) {
		a = a * 10 + c - '0', c = getchar();
	}
	a *= f;
}

template<typename T, typename ...L> inline void read(T &a, L &...l) {
	read(a), read(l...);
}

inline int Add(int a, int b) {
	return a + b >= P ? a + b - P : a + b;
}

inline void Inc(int &a, int b) {
	a = Add(a, b);
}

inline int Mul(int a, int b) {
	return (long long)a * b % P;
}

inline int Sub(int a, int b) {
	return a - b < 0 ? a - b + P : a - b;
}

string arr[N], mn[N], mx[N];
int n, m;
int main() {
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);	
    read(n, m);
    for(int i = 1; i <= n; i++) {
        cin>>arr[i];
        mn[i] = arr[i];
    }
    for(int i = 1; i <= n; i++) {
        sort(mn[i].begin(), mn[i].end());
        mx[i] = mn[i];
        reverse(mx[i].begin(), mx[i].end());
    }
    string mm = "~", ss = "~";
    int mnfr = 0;
    for(int i = 1; i <= n; i++) {
        if(mx[i] < mm) {
            ss = mm;
            mm = mx[i];
            mnfr = i;
        }
        else if(mx[i] < ss) {
            ss = mx[i];
        }
    }
    for(int i = 1; i <= n; i++) {
        if(mnfr == i) {
            if(mn[i] < ss) {
                putchar('1');
            }
            else {
                putchar('0');
            }
        }
        else if(mn[i] < mm) {
            putchar('1');
        }
        else {
            putchar('0');
        }
    }
	return 0;
}
