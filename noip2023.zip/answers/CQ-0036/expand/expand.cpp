#include<bits/stdc++.h>
using namespace std;
const int N = 5e5+5;
const int P = 1;
template<typename T>inline void read(T &a) {
	a = 0;
	char c = ' ';
	int f = 1;
	while(!isdigit(c)) {
		c = getchar();
		if(c == '-') f = -1;
	}
	while(isdigit(c)) {
		a = a * 10 + c - '0', c = getchar();
	}
	a *= f;
}

template<typename T, typename ...L> inline void read(T &a, L &...l) {
	read(a), read(l...);
}

inline int Add(int a, int b) {
	return a + b >= P ? a + b - P : a + b;
}

inline void Inc(int &a, int b) {
	a = Add(a, b);
}

inline int Mul(int a, int b) {
	return (long long)a * b % P;
}

inline int Sub(int a, int b) {
	return a - b < 0 ? a - b + P : a - b;
}

//orz InvisibleWing!!!!!
//orz liuhangxin!!!!!
//orz Ishy!!!!!
//orz yanghanyv!!!!!
//orz yanshanjiahong(shenxian)!!!!!
//orz lisichang!!!!!
//orz chery!!!!!
//orz fire51!!!!!
//orz StayAlone!!!!!
//orz Hooch!!!!!
//orz Shunpower!!!!!
//orz LPhang!!!!!
//orz ChickenURsobeautiful!!!!!

int c, n, m, q, x[N], y[N], kx, ky, px, vx, X[N], Y[N], xtot, ytot;
typedef pair<int, int> pii;
pii xrr[N], yrr[N];

bool solve(int n, int m) {
    xtot = ytot = 0;
    int premn = X[1], midmx = -1;
    for(int i = 2; i <= n; i++) {
        if(X[i] < premn) {
            xrr[++xtot] = make_pair(premn, midmx);
            premn = X[i], midmx = -1;
        }
        else {
            midmx = max(midmx, X[i]);
        }
    }
    xrr[++xtot] = make_pair(X[n], -1);
    int premx = Y[1], midmn = 0x3f3f3f3f;
    for(int i = 2; i <= m; i++)  {
        if(Y[i] > premx) {
            yrr[++ytot] = make_pair(premx, midmn);
            premx = Y[i], midmn = 0x3f3f3f3f;
        }
        else {
            midmn = min(midmn, Y[i]);
        }
    }
    yrr[++ytot] = make_pair(Y[m], 0x3f3f3f3f);
    int L = 1, R = 1;
    while(L < xtot || R < ytot) {
        if(L < xtot && xrr[L].second < yrr[R].first) {
            L++;
        }
        else if(R < ytot && yrr[R].second > xrr[L].first) {
            R++;
        }
        else {
            return false;
        }
    }
    return true;
}

int check() {
    int nn = n, mm = m;
    if(X[1] > Y[1]) {
        swap(X, Y), swap(nn, mm);
    }
    if(X[1] >= Y[1] || X[nn] >= Y[mm]) {
        return 0;
    }
    // for(int i = 1; i <= nn; i++) {
    //     cout<<X[i]<<' ';
    // }
    // cout<<endl;
    // for(int i = 1; i <= mm; i++) {
    //     cout<<Y[i]<<' ';
    // }
    // cout<<endl;
    int posy = max_element(Y + 1, Y + mm + 1) - Y;
    int posx = min_element(X + 1, X + nn + 1) - X;
    if(Y[posy] <= X[posx]) return 0;
    if(!solve(posx, posy)) return 0;
    reverse(X + 1, X + nn + 1);
    reverse(Y + 1, Y + mm + 1);
    posx = nn + 1 - posx;
    posy = mm + 1 - posy;
    if(!solve(posx, posy)) return 0;
    return 1;
}

int main() {
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);	
    read(c, n, m, q);
    for(int i = 1; i <= n; i++) {
        read(x[i]);
    }
    for(int i = 1; i <= m; i++) {
        read(y[i]);
    }
    memcpy(X, x, sizeof X);
    memcpy(Y, y, sizeof Y);
    putchar(('0' + check()));
    while(q--) {
        memcpy(X, x, sizeof X);
        memcpy(Y, y, sizeof Y);
        read(kx, ky);
        while(kx--) {
            read(px, vx);
            X[px] = vx;
        }
        while(ky--) {
            read(px, vx);
            Y[px] = vx;
        }
        putchar(('0' + check()));
    }
	return 0;
}
