#include<bits/stdc++.h>
using namespace std;
long long n,m,k,l,a[1000007],b[1000007],q,a1,t=1,n1,n2,a2,c[1000007],ah[1000007],bh[1000007];
bitset<500007> f[2];
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	cin>>a1>>n>>m>>q;
	for(int i=1;i<=n;i++)scanf("%lld",&a[i]),ah[i]=a[i];
	for(int i=1;i<=m;i++)scanf("%lld",&b[i]),bh[i]=b[i];
	t=0;
	if(a[1]>b[1]&&a[n]>b[m])t=-1;
	if(a[1]<b[1]&&a[n]<b[m])t=1;
	if(t){
		f[0][0]=1;
	    for(int i=1;i<=n;i++){
	    	if(i==2)f[0][0]=0;
	    	f[i&1]&=0;
	    	for(int j=1;j<=m;j++){
	    		if(t*a[i]<t*b[j])f[i&1][j]=f[(i-1)&1][j-1]|f[(i-1)&1][j]|f[i&1][j-1];
	    		else f[i&1][j]=0;
			}
	    }
	    if(f[n&1][m]==1)c[0]=1;
	}
	for(int o=1;o<=q;o++){
		scanf("%lld%lld",&n1,&n2);
		for(int i=1;i<=n1;i++){
			scanf("%lld%lld",&a1,&a2);
			a[a1]=a2;
		}
		for(int i=1;i<=n2;i++){
			scanf("%lld%lld",&a1,&a2);
			b[a1]=a2;
		}
		t=0;
		if(a[1]>b[1]&&a[n]>b[m])t=-1;
	    if(a[1]<b[1]&&a[n]<b[m])t=1;
	    if(t){
	    	f[0]&=0;
	    	f[1]&=0;
		    f[0][0]=1;
	        for(int i=1;i<=n;i++){
	        	if(i==2)f[0][0]=0; 
	    	    for(int j=1;j<=m;j++){
	    		    if(t*a[i]<t*b[j])f[i&1][j]=f[(i-1)&1][j-1]|f[(i-1)&1][j]|f[i&1][j-1];
	    		    else f[i&1][j]=0;
	    		    //if(o==19&&i==n)cout<<f[(i-1)&1][j]<<" "<<i<<" "<<j<<endl;
			    }
	        }
	        //if(o==19)cout<<f[n&1][m]<<endl;
	        if(f[n&1][m]==1)c[o]=1;
	    }
	    for(int i=1;i<=n;i++)a[i]=ah[i];
	    for(int i=1;i<=m;i++)b[i]=bh[i];
	}
	for(int i=0;i<=q;i++)printf("%lld",c[i]);
}
