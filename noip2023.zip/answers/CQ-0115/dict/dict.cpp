#include<bits/stdc++.h>
using namespace std;
long long n,m,l,t[3007][27],t1[27],t2[27],s1,s2;
char ch[3007],c;
int bmp(int x,int y){
	if(x==0)return 1;
	for(int i=25;i>=0;i--){
		if(t[x][i]>t[y][i])return 1;
		if(t[y][i]>t[x][i])return 0;
	}
	return 1;
}
int bmp1(int x,int y){
	for(int i=0,j=25;i<=25&&j>=0;){
		while(j!=-1&&!t[y][j])j--;
		while(i<=26&&!t[x][i])i++;
		if(j==-1||i==26)return 1;
		if(j>i)return 0;
		if(i>=j)return 1;
	}
}
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		l=0;
		c=getchar();
		while(c<'a'||c>'z')c=getchar();
		while(c>='a'&&c<='z')t[i][c-'a']++,c=getchar();
	}
	for(int i=1;i<=n;i++){
		if(bmp(s1,i)){
			for(int j=0;j<=25;j++)t2[j]=t1[j];
			swap(s1,s2); 
		    for(int j=0;j<=25;j++)t1[j]=t[i][j];
		    s1=i;
		}
		else{
			if(bmp(s2,i)){
				for(int j=0;j<=25;j++)t2[j]=t[i][j];
		        s2=i;
			}
		}
	}
	for(int j=0;j<=25;j++)t[n+1][j]=t1[j],t[n+2][j]=t2[j]; 
	for(int i=1;i<=n;i++){
		if(s1!=i){
			if(bmp1(i,n+1))printf("0");
			else printf("1");
		}
		else{
			if(s2==0){
				printf("1");
				continue;
			}
			if(bmp1(i,n+2))printf("0");
			else printf("1");
		}
	}
	return 0;
}
