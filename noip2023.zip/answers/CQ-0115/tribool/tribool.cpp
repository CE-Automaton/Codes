#include<bits/stdc++.h>
using namespace std;
long long ts,T,a2,a1,n,m,k,l,f[1000007],k1[1000007],k2[1000007],k3[1000007],a[1000007],cd,t[1000007],ans,fs,si[1000007],b[1000007];
char c;
void DD(int x,int y){
	k1[++cd]=k2[x];
	k2[x]=cd;
	k3[cd]=y;
}
int fg(int x){return x==f[x]?x:fg(f[x]);}
void M(int x,int y){
	int fx=fg(x),fy=fg(y);
	if(fx!=fy)f[fx]=fy,si[fy]+=si[fx];
}
void dfs(int x){
	for(int j=k2[x];j;j=k1[j]){
		int tt=k3[j];
		if(fs)return;
		if(!t[tt]){
			t[tt]=(t[x]&1)+1;
			dfs(tt);
			continue;
		}
		if(t[tt]==t[x]){
			fs=1;
			return;
		}
	}
}
void dfa(int x){
	t[x]=3;
	//if(ts==3)cout<<x<<" "<<si[x]<<endl;
	ans+=si[x];
	for(int j=k2[x];j;j=k1[j]){
		int tt=k3[j];
		if(t[tt]!=3)dfa(tt);
	}
}
int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	cin>>a1>>T;
	for(int u=1;u<=T;u++){
		ts=u;
		cin>>n>>m;
		for(int i=1;i<=n+1;i++)f[i]=a[i]=i,si[i]=1,b[i]=t[i]=k2[i]=0;
		si[n+1]=0;
		fs=ans=cd=0;
		for(int i=1;i<=m;i++){
			c=getchar();
			while(c==' '||c=='\n'||c=='\r')c=getchar();
			if(c=='+'){
				scanf("%lld%lld",&a1,&a2);
				a[a1]=a[a2];
				b[a1]=b[a2];
			}
			if(c=='-'){
				scanf("%lld%lld",&a1,&a2);
				a[a1]=-a[a2];
				b[a1]=b[a2];
			}
			if(c=='T'||c=='F'){
				scanf("%lld",&a1);
				a[a1]=b[a1]=0;
			}
			if(c=='U'){
				scanf("%lld",&a1);
				a[a1]=0,b[a1]=1;
			}
		}
		for(int i=1;i<=n;i++)if(b[i])M(i,n+1);
		for(int i=1;i<=n;i++)if(a[i]>0)M(i,a[i]);
		for(int i=1;i<=n;i++)if(a[i]<0)DD(fg(i),fg(-a[i])),DD(fg(-a[i]),fg(i));
		dfa(fg(n+1));
		for(int i=1;i<=n;i++){
			if(!t[fg(i)]){
				fs=0;
				t[fg(i)]=1;
				dfs(fg(i));
				if(fs)dfa(fg(i));
			}
		}
		
		//if(ts==3)for(int i=1;i<=n;i++)cout<<fg(i)<<endl;
		printf("%lld\n",ans);
	}
}
