#include<bits/stdc++.h>
#define int long long
#define mp make_pair
#define fi first
#define se second
using namespace std;

typedef long long ll;
typedef pair<int,int> pii;

const int N=2e5+5;
const ll inf=1e18;

int id,_,n,m,k,d;
ll f[N][2],dat[4*N],lazy[4*N],C[N];
vector<pii> vt[N];

void modify(int x,int v){for(;x<N;x+=x&-x)C[x]+=v;}
ll query(int x){ll ret=0;for(;x;x-=x&-x)ret+=C[x];return ret;}

#define lson p*2
#define rson p*2+1

void pushup(int p)
{
	dat[p]=max(dat[lson],dat[rson]);
}

void pushdown(int p)
{
	if(lazy[p])
	{
		dat[lson]+=lazy[p];
		dat[rson]+=lazy[p];
		lazy[lson]+=lazy[p];
		lazy[rson]+=lazy[p];
		lazy[p]=0;
	}
}

void build(int p,int l,int r)
{
	dat[p]=-inf,lazy[p]=0;
	if(l==r)return;
	int mid=(l+r)>>1;
	build(lson,l,mid),build(rson,mid+1,r);
}

void update(int p,int lt,int rt,int x,int v)
{
	if(lt==rt)return dat[p]=v,void();
	pushdown(p);
	int mid=(lt+rt)>>1;
	if(x<=mid)update(lson,lt,mid,x,v);
	else update(rson,mid+1,rt,x,v);
	pushup(p);
}

void update(int p,int lt,int rt,int l,int r,int v)
{
	if(l<=lt&&rt<=r)return dat[p]+=v,lazy[p]+=v,void();
	pushdown(p);
	int mid=(lt+rt)>>1;
	if(l<=mid)update(lson,lt,mid,l,r,v);
	if(r>mid)update(rson,mid+1,rt,l,r,v);
	pushup(p);
}

ll query(int p,int lt,int rt,int l,int r)
{
	if(l<=lt&&rt<=r)return dat[p];
	pushdown(p);
	int mid=(lt+rt)>>1;
	ll ret=-inf;
	if(l<=mid)ret=max(ret,query(lson,lt,mid,l,r));
	if(r>mid)ret=max(ret,query(rson,mid+1,rt,l,r));
	return ret;
}

#undef lson
#undef rson

signed main()
{
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	scanf("%lld%lld",&id,&_);
	if(id<=14)
	{
		while(_--)
		{
			memset(C,0,sizeof C);
			for(int i=0;i<N;i++)vt[i].clear();
			scanf("%lld%lld%lld%lld",&n,&m,&k,&d);
			for(int i=1;i<=m;i++)
			{
				int x,y,v;
				scanf("%lld%lld%lld",&x,&y,&v);
				int l,r;
				l=x-y+1;
				r=x;
				vt[r].push_back(mp(l,v));
			}
			build(1,0,100000);
			memset(f,-0x3f,sizeof f);
			f[0][0]=0;
			update(1,0,100000,0,0);
			for(int i=1;i<=n;i++)
			{
				f[i][0]=max(f[i-1][0],f[i-1][1]);
				for(pii x:vt[i])
				{
					if(x.fi<i)update(1,0,100000,x.fi,i-1,-x.se);
					modify(x.fi,x.se);
				}
				int p=max(i-k,0ll);
				f[i][1]=max(f[i][1],query(1,0,100000,p,i-1)-1ll*i*d+query(i));
				update(1,0,100000,i,f[i][0]+1ll*i*d-query(i));
			}
			cout<<max(f[n][0],f[n][1])<<'\n';
		}
		return 0;
	}
	if(17<=id&&id<=18)
	{
		while(_--)
		{
			scanf("%lld%lld%lld%lld",&n,&m,&k,&d);
			ll ans=0;
			for(int i=1;i<=m;i++)
			{
				int x,y,v;
				scanf("%lld%lld%lld",&x,&y,&v);
				int l=x-y+1,r=x;
				if(r-l+1<=k&&1ll*v>1ll*d*(r-l+1))ans+=1ll*v-1ll*d*(r-l+1);
			}
			cout<<ans<<'\n';
		}
		return 0;
	}
	return 0;
}
