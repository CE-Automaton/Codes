#include<bits/stdc++.h>
#define mp make_pair
#define fi first
#define se second
using namespace std;

typedef pair<int,int> pii;

const int N=1e6+5;

int id,_,n,m,top;
int now[N];
bool fl;
bool mark[N],vis[N],ins[N];
pii stk[N];
vector<pii> G[N];

void getmark(int u)
{
	vis[u]=1;
	mark[u]=1;
	for(pii v:G[u])
		if(!mark[v.fi])
			getmark(v.fi);
}

void dfs(int u,int type)
{
	vis[u]=1;
	stk[++top]=mp(u,type);
	ins[u]=1;
	for(pii v:G[u])
	{
		if(ins[v.fi])
		{
			int cnt=0,nowtop=top;
			while(stk[top].fi!=v.fi)
			{
				cnt+=stk[top].se<0;
				top--;
			}
			cnt+=stk[top].se<0;
			cnt+=v.se<0;
			top=nowtop;
			if(cnt&1)
			{
				fl=1;
				return;
			}
		}
		if(!vis[v.fi])
		{
			dfs(v.fi,v.se);
		}
	}
	ins[u]=0;
	top--;
}

int main()
{
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	scanf("%d%d",&id,&_);
	while(_--)
	{
		top=0;
		memset(vis,0,sizeof vis);
		memset(mark,0,sizeof mark);
		memset(ins,0,sizeof ins);
		for(int i=0;i<N;i++)G[i].clear();
		scanf("%d%d",&n,&m);
		int t1=n+1;
		int t2=n+2;
		int t3=n+3;
		for(int i=1;i<=n;i++)now[i]=i;
		while(m--)
		{
			char s[5];
			int x,y;
			scanf("%s%d",s,&x);
			if(s[0]=='T')
			{
				now[x]=t1;
			}
			if(s[0]=='F')
			{
				now[x]=t2;
			}
			if(s[0]=='U')
			{
				now[x]=t3;
			}
			if(s[0]=='+')
			{
				scanf("%d",&y);
				now[x]=now[y];
			}
			if(s[0]=='-')
			{
				scanf("%d",&y);
				now[x]=-now[y];
			}
		}
		mark[t3]=1;
		for(int i=1;i<=n;i++)G[abs(now[i])].push_back(mp(i,(now[i]>0?1:-1)));
		for(int i=1;i<=n;i++)
			if(abs(now[i])==t3&&!mark[i])
				getmark(i);
		for(int i=1;i<=n;i++)if(!vis[i])
		{
			fl=0;
			top=0;
			dfs(i,0);
			if(fl)getmark(i);
		}
		int cnt=0;
		for(int i=1;i<=n;i++)cnt+=mark[i];
		cout<<cnt<<'\n';
	}
	return 0;
}


/*
0 1
10 10
- 9 8
- 8 6
- 6 5
- 5 4
- 4 3
+ 3 9
- 1 2
+ 2 7
+ 7 10
- 10 1
*/


/*
1 3
3 3
- 2 1
- 3 2
+ 1 3
3 3
- 2 1
- 3 2
- 1 3
2 2
T 2
U 2
*/


/*
0 1
10 10
- 1 1
U 1
T 7
U 8
- 9 6
U 3
- 9 3
- 6 3
+ 9 3
- 9 8
*/
