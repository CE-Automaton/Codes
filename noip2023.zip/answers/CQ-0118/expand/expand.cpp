#include<bits/stdc++.h>
using namespace std;

const int N=2005;

int id,n,m,q;
int a[N],b[N],tmpa[N],tmpb[N];
bool f[N][N],g[N][N];

void prepare()
{
	memset(f,0,sizeof f);
	memset(g,0,sizeof g);
	f[0][0]=g[0][0]=1;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			if(a[i]>b[j])
				f[i][j]=f[i][j-1]|f[i-1][j]|f[i-1][j-1];
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			if(a[i]<b[j])
				g[i][j]=g[i][j-1]|g[i-1][j]|g[i-1][j-1];
}

int main()
{
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	scanf("%d%d%d%d",&id,&n,&m,&q);
	if(id<=7)
	{
		for(int i=1;i<=n;i++)scanf("%d",&a[i]),tmpa[i]=a[i];
		for(int i=1;i<=m;i++)scanf("%d",&b[i]),tmpb[i]=b[i];
		prepare();
		putchar((f[n][m]||g[n][m])?'1':'0');
		while(q--)
		{
			int kx,ky;
			scanf("%d%d",&kx,&ky);
			for(int i=1;i<=kx;i++)
			{
				int x,y;
				scanf("%d%d",&x,&y);
				a[x]=y;
			}
			for(int i=1;i<=ky;i++)
			{
				int x,y;
				scanf("%d%d",&x,&y);
				b[x]=y;
			}
			prepare();
			putchar((f[n][m]||g[n][m])?'1':'0');
			for(int i=1;i<=n;i++)a[i]=tmpa[i];
			for(int i=1;i<=m;i++)b[i]=tmpb[i];
		}
		return 0;
	}
	
}
