#include<bits/stdc++.h>
using namespace std;

const int N=3005;

int n,m;
int cnt[N][N],L[N],R[N];
char s[N][N];

int main()
{
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)scanf("%s",s[i]+1);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			cnt[i][s[i][j]-'a']++;
	for(int i=1;i<=n;i++)
	{
		for(int j=0;j<26;j++)
			if(cnt[i][j])
				R[i]=j;
		for(int j=25;j>=0;j--)
			if(cnt[i][j])
				L[i]=j;
	}
	for(int i=1;i<=n;i++)
	{
		bool fl=1;
		for(int j=1;j<=n;j++)if(i!=j)
		{
			if(L[i]<R[j])continue;
			fl=0;
			break;
		}
		putchar(fl?'1':'0');
	}
	return 0;
}
