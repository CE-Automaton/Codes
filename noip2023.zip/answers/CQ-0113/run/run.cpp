#include <bits/stdc++.h>
using namespace std;
using i64 = long long;
const int mod = 1E9 + 7;
int add(int x) {return x;}
int add(int x, int y) {while (x + y >= mod) return x + y - mod; return x + y;}
template <typename T, typename ...L>
int add(T x, L ...y) {return add(x, add(y...));}
int des(int x, int y) {while (x - y < 0) return x - y + mod; return x - y;}
int mul(int x) {return x;}
int mul(int x, int y) {while (1LL * x * y >= mod) return 1LL * x * y % mod; return x * y;}
template <typename T, typename ...L>
int mul(T x, L ...y) {return mul(x, mul(y...));}
const int N = 1e3 + 5;
int id, T, n, m, k, d;
i64 f[N][N];
vector <pair <int, int>> wtf[N];
void solve() {
  cin >> n >> m >> k >> d;
  if (id <= 9) {
    for (int i = 1; i <= n; ++i) wtf[i].clear();
    for (int i = 1; i <= m; ++i) {int x, y, v; cin >> y >> x >> v; wtf[y].emplace_back(x, v);}
    for (int i = 0; i <= n; ++i) {
      for (int j = 0; j <= k; ++j) f[i][j] = -0x3f3f3f3f;
    }
    f[0][0] = 0;
    for (int i = 1; i <= n; ++i) {
      for (int j = 1; j <= k; ++j) {
        f[i][j] = max(f[i][j], f[i - 1][j - 1] - d);
      }
      for (int j = 0; j <= k; ++j) f[i][0] = max(f[i][0], f[i - 1][j]);
      for (int j = 0; j <= k; ++j) {
        for (auto cao : wtf[i]) {
          int x = cao.first, v = cao.second;
          if (j >= x) 
            f[i][j] += v;
        }
      }
    }
    i64 mx = -0x3f3f3f3f;
    for (int i = 0; i <= k; ++i) mx = max(mx, f[n][i]);
    cout << mx << '\n';
  } else {
    i64 ans = 0;
    for (int i = 1; i <= m; ++i) {
      int y, x, v; cin >> y >> x >> v;
      if (x <= k && 1LL * d * x < v) ans += v - 1LL * d * x;
    }
    cout << ans << '\n';
  }
}
signed main(void) {
  freopen("run.in", "r", stdin);
  freopen("run.out", "w", stdout);
  ios :: sync_with_stdio(false);
  cin.tie(0); cout.tie(0);
  id, T; cin >> id >> T;
  while (T--) solve();
}
/*
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
*/