#include <bits/stdc++.h>
using namespace std;
using i64 = long long;
const int mod = 1E9 + 7;
int add(int x) {return x;}
int add(int x, int y) {while (x + y >= mod) return x + y - mod; return x + y;}
template <typename T, typename ...L>
int add(T x, L ...y) {return add(x, add(y...));}
int des(int x, int y) {while (x - y < 0) return x - y + mod; return x - y;}
int mul(int x) {return x;}
int mul(int x, int y) {while (1LL * x * y >= mod) return 1LL * x * y % mod; return x * y;}
template <typename T, typename ...L>
int mul(T x, L ...y) {return mul(x, mul(y...));}
const int N = 3e3 + 5;
string S[N];
signed main(void) {
  freopen("dict.in", "r", stdin);
  freopen("dict.out", "w", stdout);
  ios :: sync_with_stdio(false);
  cin.tie(0); cout.tie(0);
  multiset <string> s;
  int n, m; cin >> n >> m;
  for (int i = 0; i < n; ++i) {
    cin >> S[i];
    sort(S[i].begin(), S[i].end());
    reverse(S[i].begin(), S[i].end());
    s.insert(S[i]);
  }
  for (int i = 0; i < n; ++i) {
    s.erase(s.find(S[i]));
    reverse(S[i].begin(), S[i].end());
    if (n == 1) cout << '1';
    else if (S[i] < *s.begin()) cout << '1';
    else cout << '0';
    reverse(S[i].begin(), S[i].end());
    s.insert(S[i]);
  }
  cout << '\n';
  cerr << 1.0 * clock() / CLOCKS_PER_SEC << '\n';
}
/*
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
*/