#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using i64 = long long;
const int mod = 1E9 + 7;
int add(int x) {return x;}
int add(int x, int y) {while (x + y >= mod) return x + y - mod; return x + y;}
template <typename T, typename ...L>
int add(T x, L ...y) {return add(x, add(y...));}
int des(int x, int y) {while (x - y < 0) return x - y + mod; return x - y;}
int mul(int x) {return x;}
int mul(int x, int y) {while (1LL * x * y >= mod) return 1LL * x * y % mod; return x * y;}
template <typename T, typename ...L>
int mul(T x, L ...y) {return mul(x, mul(y...));}
const int N = 4E4 + 5;
int id, n, m, q;
int a[N], b[N]; 
bitset <N> vis, init;
bool check() {
  if (a[1] <= b[1] || a[n] <= b[m]) return false;
  vis.reset();
  vis[0] = 1;
  for (int j = 1; j <= m; ++j) {
    if (vis[j - 1] && a[1] > b[j]) vis[j] = 1;
  }
  vis[0] = 0;
  for (int i = 2; i <= n; ++i) {
    init = vis;
    vis.reset();
    bool flg = 0;
    for (int j = 1; j <= m; ++j) {
      if ((init[j] || vis[j - 1]) && a[i] > b[j]) vis[j] = 1, flg = 1;
    }
    if (!flg) return false;
  }
  return vis[m];
}
void solve() {
  if (check()) return void(cout << 1);
  swap(a, b);
  swap(n, m);
  if (check()) {
    swap(n, m);
    swap(a, b);
    return void(cout << 1);
  }
  swap(a, b);
  swap(n, m);
  cout << 0;
}
signed main(void) {
  freopen("expand.in", "r", stdin);
  freopen("expand.out", "w", stdout);
  ios :: sync_with_stdio(false);
  cin.tie(0); cout.tie(0);
  cin >> id >> n >> m >> q;
  for (int i = 1; i <= n; ++i) cin >> a[i];
  for (int i = 1; i <= m; ++i) cin >> b[i];
  solve();
  while (q--) {
    int kx, ky; cin >> kx >> ky;
    vector <pair <int, int>> X(kx), Y(ky);
    for (int i = 0; i < kx; ++i) cin >> X[i].first >> X[i].second;
    for (int i = 0; i < ky; ++i) cin >> Y[i].first >> Y[i].second;
    for (int i = 0; i < kx; ++i) swap(a[X[i].first], X[i].second);
    for (int i = 0; i < ky; ++i) swap(b[Y[i].first], Y[i].second);
    solve();
    for (int i = 0; i < kx; ++i) swap(a[X[i].first], X[i].second);
    for (int i = 0; i < ky; ++i) swap(b[Y[i].first], Y[i].second);
  }
  cout << '\n';
  cerr << 1.0 * clock() / CLOCKS_PER_SEC << '\n';
}
/*
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
*/