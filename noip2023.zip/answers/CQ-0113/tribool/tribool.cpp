#include <bits/stdc++.h>
using namespace std;
using i64 = long long;
const int mod = 1E9 + 7;
int add(int x) {return x;}
int add(int x, int y) {while (x + y >= mod) return x + y - mod; return x + y;}
template <typename T, typename ...L>
int add(T x, L ...y) {return add(x, add(y...));}
int des(int x, int y) {while (x - y < 0) return x - y + mod; return x - y;}
int mul(int x) {return x;}
int mul(int x, int y) {while (1LL * x * y >= mod) return 1LL * x * y % mod; return x * y;}
template <typename T, typename ...L>
int mul(T x, L ...y) {return mul(x, mul(y...));}
const int N = 4E5 + 5;
int id, T, tot, n, m, lim = 2E5;
namespace case1 {
  int now[N], state[N], ans = 0x3f3f3f3f, cnt = 0;
  struct QR {
    char opt;
    int x, y;
  } Q[N];
  void check() {
    for (int i = 1; i <= n; ++i) now[i] = state[i];
    for (int i = 1; i <= m; ++i) {
      if (Q[i].opt == '+') now[Q[i].x] = now[Q[i].y];
      else if (Q[i].opt == '-') now[Q[i].x] = (now[Q[i].y] == 2 ? 2 : !now[Q[i].y]);
      else now[Q[i].x] = (Q[i].opt == 'U' ? 2 : Q[i].opt == 'T' ? 1 : 0);
    }
    for (int i = 1; i <= n; ++i) if (now[i] != state[i]) return ;
    ans = cnt;
  }
  void dfs(int step) {
    if (cnt >= ans) return ;
    if (step > n) return check();
    state[step] = 0;
    dfs(step + 1);
    state[step] = 1;
    dfs(step + 1);
    state[step] = 2;
    cnt++;
    dfs(step + 1);
    cnt--;
  }
  void solve() {
    ans = 0x3f3f3f3f;
    cnt = 0;
    for (int i = 1; i <= m; ++i) {
      cin >> Q[i].opt;
      if (Q[i].opt == '+' || Q[i].opt == '-') cin >> Q[i].x >> Q[i].y;
      else cin >> Q[i].x;
    }
    dfs(1);
    cout << ans << '\n';
  }
}
namespace case2 {
  char typ[N];
  void solve() {
    for (int i = 1; i <= n; ++i) typ[i] = 0;
    for (int i = 1; i <= m; ++i) {
      char opt; cin >> opt;
      int x; cin >> x;
      typ[x] = opt;
    }
    int ans = 0;
    for (int i = 1; i <= n; ++i) if (typ[i] == 'U') ++ans;
    cout << ans << '\n';
  }
}
namespace case3 {
  int typ[N];
  vector <int> G[N];
  vector <pair <int, int>> v;
  void solve() {
    for (int i = 1; i <= n; ++i) typ[i] = 0;
    for (int i = 1; i <= m; ++i) {
      char opt; cin >> opt;
      int x; cin >> x;
      if (opt == 'U') typ[x] = 1;
      else typ[x] = 0;
    }
    int ans = 0;
    for (int i = 1; i <= n; ++i) ans += typ[i];
    cout << ans << '\n';
  }
}
void solve() {
  cin >> n >> m;
  if (id <= 2) {
    case1 :: solve();
    return ;
  }
  if (id <= 4) {
    case3 :: solve();
    return ;
  }
  cout << 0 << '\n';
}
signed main(void) {
  freopen("tribool.in", "r", stdin);
  freopen("tribool.out", "w", stdout);
  ios :: sync_with_stdio(false);
  cin.tie(0); cout.tie(0);
  id, T; cin >> id >> T;
  while (T--) solve();
}
/*
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
我爱 CCF
*/