#include <bits/stdc++.h>
using namespace std;
int c, m, k, d;
tuple<int, int, int> a[120000];
vector<int> g;
map<int, long long> s;
struct Node
{
    int l, r;
    long long v;
} t[800000];
void build(int x, int l, int r)
{
    t[x] = {l, r};
    if (l + 1 != r)
        build(x * 2, l, (l + r) / 2), build(x * 2 + 1, (l + r) / 2, r);
}
long long query(int x, int l, int r)
{
    if (g[t[x].l] >= r || g[t[x].r] <= l)
        return 0;
    if (g[t[x].l] >= l && g[t[x].r] <= r)
        return t[x].v;
    return max(query(x * 2, l, r), query(x * 2 + 1, l, r));
}
void update(int x, int p, long long v)
{
    if (g[t[x].l] > p || g[t[x].r] <= p)
        return;
    if (t[x].l + 1 == t[x].r)
    {
        t[x].v = max(t[x].v, v);
        return;
    }
    update(x * 2, p, v);
    update(x * 2 + 1, p, v);
    t[x].v = max(t[x * 2].v, t[x * 2 + 1].v);
}
int main()
{
    freopen("run.in", "r", stdin);
    freopen("run.out", "w", stdout);
    scanf("%*d%d", &c);
    while (c--)
    {
        g.clear();
        s.clear();
        scanf("%*d%d%d%d", &m, &k, &d);
        for (int i = 0; i < m; i++)
            scanf("%d%d%d", &get<0>(a[i]), &get<1>(a[i]), &get<2>(a[i])), g.push_back(get<0>(a[i])), g.push_back(get<1>(a[i]) = get<0>(a[i]) - get<1>(a[i]));
        sort(a, a + m);
        sort(g.begin(), g.end());
        g.erase(unique(g.begin(), g.end()), g.end());
        g.push_back(INT_MAX);
        build(1, 0, g.size() - 1);
        for (int i = 0; i < m; i++)
        {
            int l = get<1>(a[i]), r = get<0>(a[i]), g = 0;
            long long v = get<2>(a[i]);
            auto p = s.end();
            while (r - l <= k)
            {
                update(1, r, query(1, 0, l) + v + 1ll * (l - r) * d);
                if (m > 3000 && ++g >= 2e5 / m)
                    break;
                if (p != s.begin())
                    p--, l = min(l, p->first), v += p->second;
                else
                    break;
            }
            s[get<1>(a[i])] += get<2>(a[i]);
        }
        printf("%lld\n", query(1, 0, INT_MAX));
    }
    cerr << clock();
    return 0;
}