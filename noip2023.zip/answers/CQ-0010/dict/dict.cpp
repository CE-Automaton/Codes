#include <bits/stdc++.h>
using namespace std;
int n, m;
int k[2];
int u[4000], v[4000];
char s[4000];
int main()
{
    freopen("dict.in", "r", stdin);
    freopen("dict.out", "w", stdout);
    scanf("%d%d", &n, &m);
    for (int i = 0; i < n; i++)
    {
        scanf("%s", s);
        u[i] = 25;
        for (int j = 0; j < m; j++)
            u[i] = min(u[i], s[j] - 'a'), v[i] = max(v[i], s[j] - 'a');
    }
    if (n == 1)
    {
        puts("1");
        return 0;
    }
    partial_sort_copy(v, v + n, k, k + 2);
    for (int i = 0; i < n; i++)
        printf("%d", u[i] < k[k[0] == v[i]]);
    puts("");
    return 0;
}