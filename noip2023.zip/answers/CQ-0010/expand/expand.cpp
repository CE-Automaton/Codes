#include <bits/stdc++.h>
using namespace std;
int q, k;
int n[2], g[2];
int a[2][1200000];
stack<pair<int, int>> c[2];
struct Tree
{
    struct Node
    {
        int l, r, min_v, max_v;
    } t[1200000];
    void build(int x, int l, int r, int b)
    {
        t[x].l = l;
        t[x].r = r;
        if (l + 1 == r)
        {
            t[x].max_v = t[x].min_v = a[b][l];
            return;
        }
        build(x * 2, l, (l + r) / 2, b);
        build(x * 2 + 1, (l + r) / 2, r, b);
        t[x].min_v = min(t[x * 2].min_v, t[x * 2 + 1].min_v);
        t[x].max_v = max(t[x * 2].max_v, t[x * 2 + 1].max_v);
    }
    void update(int x, int p, int v, int b)
    {
        if (t[x].l > p || t[x].r <= p)
            return;
        if (t[x].l + 1 == t[x].r)
        {
            t[x].min_v = t[x].max_v = a[b][t[x].l] = v;
            return;
        }
        update(x * 2, p, v, b);
        update(x * 2 + 1, p, v, b);
        t[x].min_v = min(t[x * 2].min_v, t[x * 2 + 1].min_v);
        t[x].max_v = max(t[x * 2].max_v, t[x * 2 + 1].max_v);
    }
    int findr(int x, int l, int v)
    {
        if (t[x].r <= l || (t[x].l >= l && t[x].max_v < v))
            return t[x].r;
        if (t[x].l + 1 == t[x].r)
            return t[x].l;
        int res = findr(x * 2, l, v);
        return res == t[x * 2].r ? findr(x * 2 + 1, l, v) : res;
    }
    int findl(int x, int r, int v)
    {
        if (t[x].l >= r || (t[x].r <= r && t[x].min_v >= v))
            return t[x].l;
        if (t[x].l + 1 == t[x].r)
            return t[x].r;
        int res = findl(x * 2 + 1, r, v);
        return res == t[x * 2 + 1].l ? findl(x * 2, r, v) : res;
    }
} d[2];
void read(int &x)
{
    char c = getchar();
    while (isspace(c))
        c = getchar();
    x = 0;
    while (isdigit(c))
        x = x * 10 + c - '0', c = getchar();
}
int main()
{
    freopen("expand.in", "r", stdin);
    freopen("expand.out", "w", stdout);
    scanf("%*d%d%d%d", &n[0], &n[1], &q);
    for (int b : {0, 1})
    {
        for (int i = 0; i < n[b]; i++)
            scanf("%d", &a[b][i]);
        d[b].build(1, 0, n[b], b);
    }
    for (int i = 0; i <= q; i++)
    {
        if (i)
        {
            scanf("%d%d", &g[0], &g[1]);
            for (int b : {0, 1})
                for (int j = 0, p, v; j < g[b]; j++)
                    read(p), read(v), c[b].emplace(p - 1, a[b][p - 1]), d[b].update(1, p - 1, v, b);
        }
        for (int b : {0, 1})
        {
            for (int j = k = 0; (!j || k) && j < n[b]; j++)
            {
                if (k < n[!b] && a[!b][k] < a[b][j])
                    k = d[!b].findr(1, k, a[b][j]);
                if (k && a[!b][k - 1] >= a[b][j])
                    k = d[!b].findl(1, k, a[b][j]);
            }
            if (k == n[!b])
            {
                putchar('1');
                break;
            }
            if (b)
                putchar('0');
        }
        for (int b : {0, 1})
            while (c[b].size())
                d[b].update(1, c[b].top().first, c[b].top().second, b), c[b].pop();
    }
    puts("");
    cerr << clock() << endl;
    return 0;
}