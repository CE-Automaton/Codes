#include <bits/stdc++.h>
using namespace std;
int t, n, m, cnt, ans;
int f[120000], v[120000];
char c;
bool dfs(int x)
{
    if (!f[x])
        return false;
    if (f[x] == INT_MAX)
        return true;
    if (v[abs(f[x])])
        return f[x] = f[abs(f[x])] && (abs(v[x]) != abs(v[abs(f[x])]) || v[abs(f[x])] == f[x] / abs(f[x]) * v[x]);
    v[abs(f[x])] = f[x] / abs(f[x]) * v[x];
    return f[x] = dfs(abs(f[x]));
}
int main()
{
    freopen("tribool.in", "r", stdin);
    freopen("tribool.out", "w", stdout);
    scanf("%*d%d", &t);
    while (t--)
    {
        scanf("%d%d", &n, &m);
        iota(f, f + n + 1, ans = 0);
        memset(v, 0, sizeof v);
        for (int i = 0, x, y; i < m; i++)
        {
            scanf(" %c%d", &c, &x);
            if (c == '+' || c == '-')
                scanf("%d", &y), f[x] = c == '+' ? f[y] : -f[y];
            else
                f[x] = (c != 'U') * INT_MAX;
        }
        for (int i = 1; i <= n; ans += !f[i++])
            if (!v[i])
                v[i] = ++cnt, dfs(i);
        printf("%d\n", ans);
    }
    return 0;
}