#include<cstring>
#include<algorithm>
#include<fstream>
std::ifstream fin("run.in");
std::ofstream fout("run.out");
struct SegT
{
	struct node
	{
		long long max,lazy;
	}e[2000001];
	void clear(){std::memset(e,0,sizeof(e));}
	void pushdown(int no){e[no<<1].max+=e[no].lazy,e[no<<1|1].max+=e[no].lazy,e[no<<1].lazy+=e[no].lazy,e[no<<1|1].lazy+=e[no].lazy,e[no].lazy=0;}
	void add(int x,int y,long long z,int l,int r,int no)
	{
		if(x>=r||y<=l)
			return;
		if(x<=l&&y>=r)
		{
			e[no].max+=z,e[no].lazy+=z;
			return;
		}
		pushdown(no),add(x,y,z,l,l+r>>1,no<<1),add(x,y,z,l+r>>1,r,no<<1|1),e[no].max=std::max(e[no<<1].max,e[no<<1|1].max);
		return;
	}
	long long max(int x,int y,int l,int r,int no)
	{
		if(x>=r||y<=l)
			return 0;
		if(x<=l&&y>=r)
			return e[no].max;
		pushdown(no);
		return std::max(max(x,y,l,l+r>>1,no<<1),max(x,y,l+r>>1,r,no<<1|1));
	}
}f;
struct cha
{
	int x,y,v;
}e[100001];
int tmp[500001],lt;
long long dp[500001];
int main()
{
	int c,t;
	fin>>c>>t;
	while(t--)
	{
		int n,m,k,d;
		fin>>n>>m>>k>>d,lt=0,tmp[lt++]=-1,tmp[lt++]=0,tmp[lt++]=n;
		for(int i=0;i<m;i++)
			fin>>e[i].x>>e[i].y>>e[i].v,
			tmp[lt++]=e[i].x,
			tmp[lt++]=e[i].x-e[i].y-1,
			e[i].x>k?tmp[lt++]=e[i].x-k-1:0,
			tmp[lt++]=e[i].x-e[i].y+k;
		std::sort(tmp,tmp+lt),lt=std::unique(tmp,tmp+lt)-tmp;
		for(int i=0;i<m;i++)
		{
			int x=e[i].x,y=e[i].y;
			e[i].x=std::lower_bound(tmp,tmp+lt,x-y-1)-tmp+1,e[i].y=std::lower_bound(tmp,tmp+lt,x)-tmp;
		}
		std::sort(e,e+m,[](const cha&a,const cha&b){return a.y<b.y;});
		for(int i=0;i<lt;i++)
			dp[i]=0;
		f.clear();
		for(int i=2,j=0;i<lt;i++)
		{
			for(;j<m&&e[j].y<=i;j++)
				f.add(0,e[j].x,e[j].v,0,lt,1);
			dp[i]=std::max(dp[i-1],f.max(std::lower_bound(tmp,tmp+lt,tmp[i]-k-1)-tmp,std::lower_bound(tmp,tmp+lt,tmp[i]-2)-tmp,0,lt,1)-1ll*tmp[i]*d),
			f.add(i,i+1,dp[i]+1ll*(tmp[i]+1)*d,0,lt,1);
		}
		fout<<dp[lt-1]<<'\n';
	}
	return 0;
}