#include<fstream>
std::ifstream fin("tribool.in");
std::ofstream fout("tribool.out");
bool ans[200005];
int x[100001],dad[200005];
int getdad(int _){return _==dad[_]?_:dad[_]=getdad(dad[_]);}
int main()
{
	int c,t;
	fin>>c>>t;
	while(t--)
	{
		int n,m;
		fin>>n>>m;
		for(int i=0;i<n;i++)
			x[i]=i<<1;
		for(int i=0;i<n+1<<1;i++)
			dad[i]=i,ans[i]=0;
		dad[n+1<<1]=dad[n+1<<1|1]=n+1<<1;
		while(m--)
		{
			char v;
			int i,j;
			fin>>v>>i,i--;
			if(v=='T')
				x[i]=n<<1;
			else if(v=='F')
				x[i]=n<<1|1;
			else if(v=='U')
				x[i]=n+1<<1;
			else if(v=='+')
				fin>>j,x[i]=x[j-1];
			else
				fin>>j,x[i]=x[j-1]^1;
		}
		for(int i=0;i<n;i++)
			dad[getdad(x[i])]=getdad(i<<1),dad[getdad(x[i]^1)]=getdad(i<<1|1);
		for(int i=0;i<n+2;i++)
			if(getdad(i<<1)==getdad(i<<1|1))
				ans[dad[i<<1]]=1;
		int y=0;
		for(int i=0;i<n;i++)
			if(ans[getdad(i<<1)])
				y++;
		fout<<y<<'\n';
	}
	return 0;
}