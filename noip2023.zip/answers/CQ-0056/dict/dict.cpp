#include<fstream>
std::ifstream fin("dict.in"); 
std::ofstream fout("dict.out");
char s[3001][3003],a[3003];
int cnt[3001][27];
int main()
{
	int n,m;
	fin>>n>>m;
	for(int i=0;i<n;i++)
	{
		fin>>s[i],a[i]='1';
		for(int j=0;j<m;j++)
			cnt[i][s[i][j]-'a']++;
	}
	int x=0;
	for(int i=1;i<n;i++)
		for(int j=25;~j;j--)
			if(cnt[x][j]!=cnt[i][j])
			{
				if(cnt[x][j]>cnt[i][j])
					x=i;
				break;
			}
	for(int i=0;i<n;i++)
		if(x!=i)
		{
			int u=0,v=25;
			for(;!cnt[i][u];u++);
			for(;!cnt[x][v];v--);
			if(v<=u)
				a[i]='0';
			u=0,v=25;
			for(;!cnt[x][u];u++);
			for(;!cnt[i][v];v--);
			if(v<=u)
				a[x]='0';
		}
	fout<<a;
	return 0;
}