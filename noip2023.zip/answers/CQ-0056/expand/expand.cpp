#include<fstream>
std::ifstream fin("expand.in");
std::ofstream fout("expand.out");
bool f[2001][2001],g[2001][2001];
int x[1000001],y[1000001],a[1000001],b[1000001];
int main()
{
	int c,n,m,q;
	fin>>c>>n>>m>>q;
	for(int i=0;i<n;i++)
		fin>>x[i];
	for(int i=0;i<m;i++)
		fin>>y[i];
	for(int i=0;i<n;i++)
		a[i]=x[i];
	for(int i=0;i<m;i++)
		b[i]=y[i];
	f[0][0]=a[0]>b[0],g[0][0]=a[0]<b[0];
	for(int i=0;i<n;i++)
		for(int j=0;j<m;j++)
		{
			if(a[i]>b[j])
			{
				if(i)
					f[i][j]|=f[i-1][j];
				if(j)
					f[i][j]|=f[i][j-1];
				if(i&&j)
					f[i][j]|=f[i-1][j-1];
			}
			if(a[i]<b[j])
			{
				if(i)
					g[i][j]|=g[i-1][j];
				if(j)
					g[i][j]|=g[i][j-1];
				if(i&&j)
					g[i][j]|=g[i-1][j-1];
			}
		}
	fout<<(f[n-1][m-1]||g[n-1][m-1]);
	while(q--)
	{
		for(int i=0;i<n;i++)
			a[i]=x[i];
		for(int i=0;i<m;i++)
			b[i]=y[i];
		int kx,ky;
		fin>>kx>>ky;
		while(kx--)
		{
			int p,v;
			fin>>p>>v,a[p-1]=v;
		}
		while(ky--)
		{
			int p,v;
			fin>>p>>v,b[p-1]=v;
		}
		for(int i=0;i<n;i++)
			for(int j=0;j<m;j++)
				f[i][j]=g[i][j]=0;
		f[0][0]=a[0]>b[0],g[0][0]=a[0]<b[0];
		for(int i=0;i<n;i++)
			for(int j=0;j<m;j++)
			{
				if(a[i]>b[j])
				{
					if(i)
						f[i][j]|=f[i-1][j];
					if(j)
						f[i][j]|=f[i][j-1];
					if(i&&j)
						f[i][j]|=f[i-1][j-1];
				}
				if(a[i]<b[j])
				{
					if(i)
						g[i][j]|=g[i-1][j];
					if(j)
						g[i][j]|=g[i][j-1];
					if(i&&j)
						g[i][j]|=g[i-1][j-1];
				}
			}
		fout<<(f[n-1][m-1]||g[n-1][m-1]);
	}
	return 0;
}