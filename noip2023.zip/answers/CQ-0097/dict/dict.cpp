#include <bits/stdc++.h>
#define pc putchar
#define gc getchar
#define space pc(' ')
#define enter pc('\n')
#define pb push_back
#define me(x,p) memset(x,p,sizeof(x))
#define FOR(i,k,n,p) for(int i = (k) ; i <= (n) ; i += (p))
#define ROF(i,k,n,p) for(int i = (k) ; i >= (n) ; i -= (p))
using namespace std ;
inline void read(int &x)
{
    x = 0 ; char cc = gc() ; int ff = 0 ;
    while(!isdigit(cc)) ff |= (cc=='-'),cc = gc() ;
    while(isdigit(cc)) x = (x<<1)+(x<<3)+(cc^48),cc = gc() ; x = ff?-x:x ;
}
void print(int x)
{
    if(x < 0) pc('-'),x = -x ;
    if(x > 9) print(x/10) ; pc(x%10+'0') ;
}
const int N = 3e3+5 ;
int n,m,mi,tot ;
int ans[N] ;
string s[N],t[N] ;
signed main()
{
    freopen("dict.in","r",stdin) ;
    freopen("dict.out","w",stdout) ;
    read(n),read(m) ;
    if(n == 1)
    {
        print(0),enter ;
        return 0 ;
    }
    FOR(i,1,n,1) cin>>s[i] ;
    FOR(i,1,n,1) sort(s[i].begin(),s[i].end()),t[i] = s[i],reverse(t[i].begin(),t[i].end()) ;
    mi = 1 ;
    FOR(i,2,n,1)
    {
        if(t[i] < t[mi]) mi = i,tot = 0 ;
        if(t[i] == t[mi]) ++tot ;
    }
    FOR(i,1,n,1)
    {
        if(s[i] > t[mi]) continue ;
        if(s[i] == t[mi] && tot > 1) continue ;
        ans[i] = 1 ;
    }
    FOR(i,1,n,1) print(ans[i]) ;
    return 0 ;
}