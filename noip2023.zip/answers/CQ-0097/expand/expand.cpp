#include <bits/stdc++.h>
#define pc putchar
#define gc getchar
#define space pc(' ')
#define enter pc('\n')
#define pb push_back
#define me(x,p) memset(x,p,sizeof(x))
#define FOR(i,k,n,p) for(int i = (k) ; i <= (n) ; i += (p))
#define ROF(i,k,n,p) for(int i = (k) ; i >= (n) ; i -= (p))
using namespace std ;
inline void read(int &x)
{
    x = 0 ; char cc = gc() ; int ff = 0 ;
    while(!isdigit(cc)) ff |= (cc=='-'),cc = gc() ;
    while(isdigit(cc)) x = (x<<1)+(x<<3)+(cc^48),cc = gc() ; x = ff?-x:x ;
}
void print(int x)
{
    if(x < 0) pc('-'),x = -x ;
    if(x > 9) print(x/10) ; pc(x%10+'0') ;
}
const int N = 2e3+5 ;
int ty,n,m,q ;
int c[N],d[N],a[N],b[N] ;
int f[N][N],g1[N],g2[N] ;
void Solve()
{
    // FOR(i,1,n,1) print(a[i]),space ; enter ;
    // FOR(i,1,m,1) print(b[i]),space ; enter ;
    me(f,0),f[1][1] = 1 ;
    if(a[1] == b[1]) {print(0) ; return ;}
    if(n <= 200 && m <= 200)
    {
        FOR(i,1,n,1) FOR(j,1,m,1)
        {
            if(!f[i][j]) continue ;
            int mx = 0,mi = 1e9,chk = 0 ;
            FOR(l,j+1,m,1)
            {
                if(a[1] < b[1]) 
                {
                    if(b[l] <= a[i]) chk = 1 ;
                    if(chk) break ; f[i][l] = 1 ;
                }
                else
                {
                    if(b[l] >= a[i]) chk = 1 ;
                    if(chk) break ; f[i][l] = 1 ;
                }
            }
            chk = 0 ;
            FOR(l,i+1,n,1)
            {
                if(a[1] < b[1]) 
                {
                    if(a[l] >= b[j]) chk = 1 ;
                    if(chk) break ; f[l][j] = 1 ;
                }
                else
                {
                    if(a[l] <= b[j]) chk = 1 ;
                    if(chk) break ; f[l][j] = 1 ;
                }   
            }
        }
        print(f[n][m]) ;// enter ;
    }
    else
    {
        me(g1,0),me(g2,0),g1[1] = g2[1] = 1 ;
        FOR(l,1,500,1) FOR(i,1,max(n,m),1) FOR(r,1,2,1)
        {
            int las = g1[i] ;
            if(i <= n) 
            {
                int chk = 0 ;
                FOR(j,las,m,1) 
                {
                    if(a[1] < b[1])
                    {
                        if(a[i] >= b[j]) chk = 1 ;
                        if(chk) break ; g1[i] = j,g2[j] = max(g2[j],i) ;
                    }
                    else 
                    {
                        if(a[i] <= b[j]) chk = 1 ;
                        if(chk) break ; g1[i] = j,g2[j] = max(g2[j],i) ;
                    }
                }
            }
            las = g2[i] ;
            if(i <= m)
            {
                FOR(j,las,n,1)
                {
                    int chk = 0 ;
                    if(a[1] < b[1])
                    {
                        if(a[j] >= b[i]) chk = 1 ;
                        if(chk) break ;  g2[i] = j,g1[j] = max(g1[j],i) ;
                    }
                    else
                    {
                        if(a[j] <= b[i]) chk = 1 ;
                        if(chk) break ;  g2[i] = j,g1[j] = max(g1[j],i) ;
                    }
                }
            }
        }
        print(g1[n]==m||g2[m]==n) ;
    }
    // FOR(i,1,n,1)
    // {
    //     FOR(j,1,m,1) print(f[i][j]) ; enter ;
    // }
}
signed main()
{
    freopen("expand.in","r",stdin) ;
    freopen("expand.out","w",stdout) ;
    //cerr<<(double)clock()/CLOCKS_PER_SEC<<"\n" ;
    read(ty),read(n),read(m),read(q) ; 
    FOR(i,1,n,1) read(c[i]),a[i] = c[i] ; FOR(i,1,m,1) read(d[i]),b[i] = d[i] ; Solve() ;
    while(q--)
    {
        int tot1,tot2,A,B,C,D ; read(tot1),read(tot2) ;
        FOR(i,1,n,1) a[i] = c[i] ;
        FOR(i,1,m,1) b[i] = d[i] ;
        while(tot1--) read(A),read(B),a[A] = B ;
        while(tot2--) read(C),read(D),b[C] = D ;
        Solve() ;
    }
    return 0 ;
}