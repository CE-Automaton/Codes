#include <bits/stdc++.h>
#define int long long
#define pii pair<int,int>
#define pc putchar
#define gc getchar
#define space pc(' ')
#define enter pc('\n')
#define pb push_back
#define me(x,p) memset(x,p,sizeof(x))
#define FOR(i,k,n,p) for(int i = (k) ; i <= (n) ; i += (p))
#define ROF(i,k,n,p) for(int i = (k) ; i >= (n) ; i -= (p))
using namespace std ;
inline void read(int &x)
{
    x = 0 ; char cc = gc() ; int ff = 0 ;
    while(!isdigit(cc)) ff |= (cc=='-'),cc = gc() ;
    while(isdigit(cc)) x = (x<<1)+(x<<3)+(cc^48),cc = gc() ; x = ff?-x:x ;
}
void print(int x)
{
    if(x < 0) pc('-'),x = -x ;
    if(x > 9) print(x/10) ; pc(x%10+'0') ;
}
const int N = 1e3+5 ;
int ty,T,n,m,k,d ;
int f[N][5],val[N][N] ;
vector<pii>e[N] ;
void Init()
{ 
    me(val,0) ;
    FOR(i,1,n,1)
    {
        val[i][i] = 0 ;
        FOR(j,i,min(i+k-1,n),1)
        {
            for(auto p:e[j])
            {
                int l = p.first,v = p.second ;
                if(l >= i) val[i][j] += v ;
            }
            val[i][j] += val[i][j-1] ;
        }
    }
}
void Solve()
{
    read(n),read(m),read(k),read(d),k = min(k,n+1) ;
    FOR(i,1,n,1) e[i].clear() ;
    FOR(i,1,m,1)
    {
        int x,y,v ; read(x),read(y),read(v) ;
        e[x].pb({x-y+1,v}) ;
    }
    me(f,0),Init() ;
    FOR(i,1,n,1)
    {
        f[i][0] = max(f[i-1][0],f[i-1][1]) ;
        ROF(j,i,max(1ll,i-k+1),1) f[i][1] = max(f[i][1],f[j-1][0]+val[j][i]-(i-j+1)*d) ;
    }
    int ans = 0 ;
    FOR(i,0,1,1) ans = max(ans,f[n][i]) ; print(ans),enter ;
}
signed main()
{
    freopen("run.in","r",stdin) ;
    freopen("run.out","w",stdout) ;
    //cerr<<(double)clock()/CLOCKS_PER_SEC<<"\n" ;
    read(ty),read(T) ; while(T--) Solve() ;
    return 0 ;
}