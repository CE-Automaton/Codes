#include <bits/stdc++.h>
#define pc putchar
#define gc getchar
#define space pc(' ')
#define enter pc('\n')
#define pb push_back
#define me(x,p) memset(x,p,sizeof(x))
#define FOR(i,k,n,p) for(int i = (k) ; i <= (n) ; i += (p))
#define ROF(i,k,n,p) for(int i = (k) ; i >= (n) ; i -= (p))
using namespace std ;
inline void read(int &x)
{
    x = 0 ; char cc = gc() ; int ff = 0 ;
    while(!isdigit(cc)) ff |= (cc=='-'),cc = gc() ;
    while(isdigit(cc)) x = (x<<1)+(x<<3)+(cc^48),cc = gc() ; x = ff?-x:x ;
}
void print(int x)
{
    if(x < 0) pc('-'),x = -x ;
    if(x > 9) print(x/10) ; pc(x%10+'0') ;
}
const int N = 3e5+5 ;
int ty,T,n,m,idx,ans ;
int rt0 = N-5,rt1 = N-6,rt2 = N-7 ;
int cnt[N],val[N],fu[N],vis[N],of[N],srt[N],in[N],yys[N] ;
struct Edge{int v,pe ;} ;
//N-5 0,N-6 1,N-7 ?
vector<int>id[N],k[N],po,fan[N] ;
vector<Edge>e[N],g[N] ;
void Dfs(int x)
{
    vis[x] = 1 ;
    for(Edge p:e[x])
    {
        int v = p.v,pe = p.pe ;
        val[v] = val[x],fu[v] = fu[x]*pe,Dfs(v) ;
    }
}
void solve(int x)
{
    vis[x] = 1,srt[x] = 2 ;
    for(auto vv:g[x]) 
    {
        int v = vv.v ;
        if(!vis[v]) solve(v) ;
    }
}
void check(int x,int rt)
{
    vis[x] = 1 ;
    for(auto vv:g[x])
    {
        int v = vv.v,pe = vv.pe ;
        if(!vis[v]) srt[v] = srt[x]*pe ,check(v,rt) ;
        else if(srt[v] != srt[x]*pe) srt[rt] = 2 ;//print(x),space,print(v),space,print(srt[x]),space,print(srt[v]),space,print(pe),enter,
    }
}
void dfs(int x)
{
    vis[x] = 1,po.pb(x) ; //cerr<<x<<"\n" ;
    for(auto v:k[x]) if(!vis[v]) dfs(v) ;
}
void Solve()
{
    read(n),read(m),ans = 0 ;
    me(srt,-1),me(vis,0),e[rt1].clear(),e[rt0].clear(),e[rt2].clear() ;
    FOR(i,1,idx,1) e[i].clear(),val[i] = 0 ; idx = n ;
    FOR(i,1,n,1) id[i].clear(),id[i].pb(i),cnt[i] = 1,of[i] = i,g[i].clear(),fan[i].clear(),k[i].clear() ;
    FOR(i,1,m,1)
    {
        char op ; int I,J ; scanf(" %c",&op) ;
        if(op != '+' && op != '-')
        {
            read(I),id[I].pb(++idx) ;
            if(op == 'T') e[rt1].pb({idx,1}) ;
            if(op == 'F') e[rt0].pb({idx,1}) ;
            if(op == 'U') e[rt2].pb({idx,1}) ;
        }
        else
        {
            read(I),read(J);
            e[id[J].back()].pb({++idx,(op == '+') ? 1 : -1}),id[I].pb(idx) ;
        }
    }
    FOR(i,1,n,1) if(!vis[i]) val[i] = i,fu[i] = 1,Dfs(i) ;
    // FOR(i,1,n,1) print(val[id[i].back()]),space ; enter;
    // FOR(i,1,idx,1) print(fu[i]),space ; enter ;
    val[rt0] = rt0,val[rt1] = rt1,val[rt2] = rt2,Dfs(rt0),Dfs(rt1),Dfs(rt2) ;
    // FOR(i,1,idx,1) print(val[i]),space ; enter ;
    // FOR(i,1,idx,1) print(vis[i]),space ; enter ;
    // FOR(i,1,n,1) print(id[i].back()), ; enter ;
    me(in,0) ;
    FOR(i,1,n,1)
    {
        int vl = val[id[i].back()] ; //print(vl),space ;
        if(vl == i && fu[id[i].back()] == -1) {srt[i] = 2 ; continue ;}
        if(vl == rt0 || vl == rt1 || vl == rt2)
        {
            if(vl == rt0) srt[i] = 4 ;
            if(vl == rt1) srt[i] = 3 ;
            if(vl == rt2) srt[i] = 2 ;
        }
        else 
        {
            g[vl].pb({i,fu[id[i].back()]}),fan[i].pb(vl),in[vl]++,yys[i]++ ;//,print(vl),space,print(i),space,print(fu[id[i].back()]),enter ;
            k[vl].pb(i),k[i].pb(vl) ;
        }
    } 
    me(vis,0) ;
    FOR(i,1,n,1) if(!vis[i] && srt[i] == -1)
    {
        po.clear(),dfs(i) ;
        queue<int>q ; int chk = 0 ;
        for(auto pos:po) 
        {
            if(srt[pos] == 2)
            {
                for(auto jd:po) vis[jd] = 1 ; chk = 1 ;
                break ;
            }
            vis[pos] = 0 ;
        }
        if(chk) continue ;
        for(auto pos:po) if(!in[pos]) q.push(pos) ;
        while(!q.empty())
        {
            int x = q.front() ; q.pop() ;
            for(auto v:fan[x])
            {
                in[v]-- ;
                if(!in[v]) q.push(v) ;
            }
        }
        for(auto pos:po) if(in[pos]) {srt[pos] = 1,check(pos,pos) ; break ;}
    }me(vis,0) ;
    FOR(i,1,n,1) if(srt[i] == 2 && !vis[i]) solve(i) ;
    FOR(i,1,n,1) if(srt[i] == 2) ++ans ; 
    // FOR(i,1,n,1) print(srt[i]),space ; enter ;
    print(ans),enter ;
}
signed main()
{
    freopen("tribool.in","r",stdin) ;
    freopen("tribool.out","w",stdout) ;
    //cerr<<(double)clock()/CLOCKS_PER_SEC<<"\n" ;
    read(ty),read(T) ; while(T--) Solve() ;
    return 0 ;
}