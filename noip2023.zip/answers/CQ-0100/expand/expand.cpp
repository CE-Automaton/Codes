#include <bits/stdc++.h>
using namespace std;
int read();

int c, n, m, q;
int x, y, _x, _y;

int main() {
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);
	
	cin >> c >> n >> m >> q;
	cin >> x >> y;
	
	printf("%d", x != y);
	
	int kx, ky;
	int px, vx, py, vy;
	while (q--) {
		_x = x, _y = y;
		cin >> kx >> ky;
		if (kx) {
			cin >> px >> vx;
			_x = vx;
		}
		if (ky) {
			cin >> py >> vy;
			_y = vy;
		}
		printf("%d", _x != _y);
	}
	return 0;
}

int read() {
	char x = 0; int y = 0;
	while (x < '0' || x > '9') {
		x = getchar();
	}
	while (x >= '0' && x <= '9') {
		y = (y<<1) + (y<<3) + (x^48);
		x = getchar();
	}
	return y;
} 
