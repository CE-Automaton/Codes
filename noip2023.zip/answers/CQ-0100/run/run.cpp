#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int MAXN = 100005;
int read();

int n, m, k, d; ll dp[MAXN][2];

int l[MAXN], r[MAXN], v[MAXN], lsh[MAXN];

#define pii pair<int,int>
#define px first
#define py second
#define pr make_pair
vector<pii > p[MAXN];

#define lowbit(x) ((x) & (-x))
ll bit[MAXN];
void add(int x, int y) {
	if (!x) {
		bit[0] += y;
		return;
	}
	for (; x <= m; x+=lowbit(x)) {
		bit[x] += y;
	}
}
ll ask(int x) {
	ll res = 0;
	for (; x; x-=lowbit(x))
		res += bit[x];
	return res + bit[0];
}

int main() {
	freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);
	
	int c, T; cin >> c >> T; while (T--) {
		cin >> n >> m >> k >> d;
		memset(bit, 0, sizeof bit);
		ll ans = 0;
		for (int i = 1; i <= m; i++) {
			l[i] = read(), r[i] = read(), v[i] = read();
			swap(l[i], r[i]);
			l[i] = r[i] - l[i] + 1;
			if (l[i] <= 0) {
				i--, m--;
			} else {
				lsh[i] = r[i];
			}
			p[i].clear();
		}
		
		if (!m) {
			puts("0"); continue;
		}
		sort(lsh + 1, lsh + m + 1); 
		for (int i = 1, tmp; i <= m; i++) {
			tmp = lower_bound(lsh + 1, lsh + m + 1, r[i]) - lsh;
			p[tmp].push_back(pr(l[i], v[i]));
		}
		for (int i = 1; i <= m; i++) {
			sort(p[i].begin(), p[i].end());
			reverse(p[i].begin(), p[i].end());
			
			dp[i][0] = max(dp[i-1][0], dp[i-1][1]);
			dp[i][1] = 0;

			ll tmp = 0, more = 0;
			for (int j = 0, to, len; j < p[i].size(); j++) {
				len = lsh[i] - p[i][j].px + 1;
				if (len > k) break;
				tmp += p[i][j].py;
				to = lower_bound(lsh + 1, lsh + m + 1, p[i][j].px) - lsh - 1;
//				if (to) more = ask(to-1);
//				else more = 0; 
				dp[i][1] = max(dp[i][1], dp[to][0] + tmp + more - (ll)len * d);
			}
			for (int j = 0, to; j < p[i].size(); j++) {
				to = lower_bound(lsh + 1, lsh + m + 1, p[i][j].px) - lsh - 1;
				add(to, p[i][j].py); 
			}
			ans = max(ans, dp[i][1]);
		}
		cout << ans << '\n';
	}
	return 0;
}

int read() {
	char x = 0; int y = 0;
	while (x < '0' || x > '9') {
		x = getchar();
	}
	while (x >= '0' && x <= '9') {
		y = (y<<1) + (y<<3) + (x^48);
		x = getchar();
	}
	return y;
}
