#include <bits/stdc++.h>
using namespace std;
int read(); char readop();
const int MAXN = (int)1e5+5;


/*
1 1
10 10
- 9 8
- 8 6
- 6 5
- 5 4
- 4 3
+ 3 9
- 1 2
+ 2 7
+ 7 10
- 10 1

*/

int n, q;
int ukn[MAXN], gx[MAXN], val[MAXN];  

#define pii pair<int,int>
#define px first
#define py second
#define pr make_pair
pii fset(int x) {
	if (ukn[x] == x) {
		return pr(x, gx[x]);
	}
	pii tmp = fset(ukn[x]);
	ukn[x] = tmp.px;
	gx[x] = (tmp.py ? (!gx[x]) : gx[x]);
	return pr(ukn[x], gx[x]);
}

int main() {
	freopen("tribool.in", "r", stdin);
	freopen("tribool.out", "w", stdout);
	
	int id = read(), T = read();

	while (T--) {
		n = read(), q = read();
		for (int i = 1; i <= n; i++) { 
			ukn[i] = i, gx[i] = 0;
			val[i] = -1;
		}
		char op; int x, y; pii res; 
		while (q--) {
			op = readop(); x = read();
			if (op == 'T') val[x] = 1;
			if (op == 'F') val[x] = 0;
			if (op == 'U') val[x] = 2;
			if (op == '+') {
				y = read();
				if (~val[y]) {
					val[x] = val[y];
				} else {
					val[x] = -1;
					res = fset(y);
					ukn[x] = res.px;
					gx[x] = res.py;
				}
			}
			if (op == '-') {
				y = read();
				if (~val[y]) {
					if (val[y] == 2) val[x] = 2;
					else val[x] = 1 - val[y];
				} else {
					val[x] = -1;
					res = fset(y); 
					ukn[x] = res.px;
					gx[x] = !res.py;
				}
			}
		}

		int ans = 0;
		for (int i = 1; i <= n; i++) {
			if (val[i] == -1 && ukn[i] == i && gx[i]) {
				val[i] = 2;
			}
		}
		for (int i = 1; i <= n; i++) {
			if (val[i] == -1) {
				res = fset(ukn[i]);
				ukn[i] = res.px;
				gx[i] = (res.py ? (!gx[i]) : gx[i]);
				if (~val[ukn[i]]) { 
					if (val[ukn[i]] == 2) val[i] = 2;
					else val[i] = (gx[i] ? (!val[ukn[i]]) : val[ukn[i]]);
				}
			}
			if (val[i] == 2) {
				ans ++;
			}
		}
		printf("%d\n", ans);
	}
	return 0;
}

char readop() {
	char x = 0;
	while (x != 'T' && x != 'F' && x != 'U' && x != '+' && x != '-')
		x = getchar();
	return x;
}
int read() {
	char x = 0; int y = 0;
	while (x < '0' || x > '9') {
		x = getchar();
	}
	while (x >= '0' && x <= '9') {
		y = (y<<1) + (y<<3) + (x^48);
		x = getchar();
	}
	return y;
}
