#include<bits/stdc++.h>
using namespace std;
int T,n,m,k,d;
long long dp[1005][1005];
struct st{
	int a,b;st(){}
	st(int A,int B){a=A,b=B;}
};
vector<st>V[1005];
int main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	scanf("%*d%d",&T);
	while(T--){long long ans=0;
		scanf("%d%d%d%d",&n,&m,&k,&d);
		for(int i=1,u,v,w;i<=m;i++){
			scanf("%d%d%d",&u,&v,&w);
			V[u].push_back(st(v,w));
		}for(int i=1;i<=n;i++){dp[i][0]=dp[i-1][0];
			for(int j=1;j<=k;j++)dp[i][j]=dp[i-1][j-1]-d,dp[i][0]=max(dp[i][0],dp[i-1][j]);
			for(int l=0;l<V[i].size();l++){
				for(int j=V[i][l].a;j<=k;j++)dp[i][j]+=V[i][l].b;
			}V[i].clear();
		}for(int j=0;j<=k;j++)ans=max(ans,dp[n][j]);
		printf("%lld\n",ans);
	}
}
