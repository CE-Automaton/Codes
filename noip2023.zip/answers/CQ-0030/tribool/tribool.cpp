#include<bits/stdc++.h>
using namespace std;
int T,n,m,sum,col[100005];
int cnt,k[100005],f[100005],F[100005];
struct st{
	int v,w;st(){}
	st(int V,int W){v=V,w=W;}
};
vector<st>g[100005];
bool dfs(int x,int y){sum++;
	F[x]=1;col[x]=y;int fl=1;
	for(int i=0;i<g[x].size();i++){
		if(F[g[x][i].v])fl&=(col[g[x][i].v]==(y^g[x][i].w));
		else fl&=dfs(g[x][i].v,y^g[x][i].w);
	}return fl;
}
int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	scanf("%*d%d",&T);
	while(T--){cnt=0;
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;i++)k[i]=i,f[i]=0;
		for(int i=1,u,v;i<=m;i++){
			char s[5];scanf("%s",s);
			if(s[0]=='+'){
				scanf("%d%d",&u,&v);
				k[u]=k[v];f[u]=f[v];
			}else if(s[0]=='-'){
				scanf("%d%d",&u,&v);
				k[u]=k[v];f[u]=f[v]^1;
			}else if(s[0]=='T'){
				scanf("%d",&u);
				k[u]=n+1;f[u]=0;
			}else if(s[0]=='F'){
				scanf("%d",&u);
				k[u]=n+2;f[u]=0;
			}else if(s[0]=='U'){
				scanf("%d",&u);
				k[u]=n+3;f[u]=0;
			}
		}
		for(int i=1;i<=n;i++)g[k[i]].push_back(st(i,f[i])),g[i].push_back(st(k[i],f[i]));
		int ans=0;for(int i=n+1;i<=n+2;i++)dfs(i,0);sum=0;dfs(n+3,0);ans+=sum-1;
		for(int i=1;i<=n;i++){sum=0;if(!F[i]&&!dfs(i,0))ans+=sum;}
		printf("%d\n",ans);for(int i=1;i<=n+3;i++)g[i].clear(),F[i]=col[i]=0;
	}
}
