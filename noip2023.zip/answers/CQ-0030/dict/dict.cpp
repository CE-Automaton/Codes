#include<bits/stdc++.h>
using namespace std;
int n,m,SUM;
char s[3005];
int a[6005][3005],k[6005],ans[6005],sum[30];
vector<int>v[30];
void JSsort(int x,int l,int r){
	if(x==m+1)return;
	int R=l-1,siz[30];
	for(int i=l;i<=r;i++)v[a[k[i]][x]].push_back(k[i]);
	for(int i=0;i<26;i++){
		for(int j=0;j<v[i].size();j++)k[++R]=v[i][j];
		siz[i]=v[i].size();v[i].clear();
	}R=l-1;
	for(int i=0;i<26;i++){
		int L=R+1;R+=siz[i];
		if(L<=R)JSsort(x+1,L,R);
	}
}
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){scanf("%s",s);
		for(int j=1;j<=m;j++)sum[s[j-1]-'a']++;int kk=0;
		for(int j=0;j<26;j++)while(sum[j])a[i][++kk]=j,sum[j]--;
		for(int j=1;j<=m;j++)a[i+n][j]=a[i][m-j+1];
	}for(int i=1;i<=2*n;i++)k[i]=i;JSsort(1,1,2*n);
	for(int i=2*n;i>=1;i--)if(k[i]>n)SUM++;else if(SUM==n)ans[k[i]]=1;
	for(int i=1;i<=n;i++)printf("%d",ans[i]);
}
