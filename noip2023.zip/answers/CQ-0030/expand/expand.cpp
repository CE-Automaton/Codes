#include<bits/stdc++.h>
using namespace std;
void read(int &x){
	x=0;char c=getchar();
	while(c<'0'||c>'9')c=getchar();
	while('0'<=c&&c<='9')x=x*10+c-'0',c=getchar();
}
int LOG[500005],g[500005][19],f[500005][19];
int MIN(int l,int r){int k=LOG[r-l+1];
	return min(g[l][k],g[r-(1<<k)+1][k]);
}
int MAX(int l,int r){int k=LOG[r-l+1];
	return max(f[l][k],f[r-(1<<k)+1][k]);
}
int F(int n,int m,int a[],int b[]){
	int R=1;b[0]=0;b[m+1]=0x3f3f3f3f;
	for(int j=0;j<=m+1;j++)f[j][0]=g[j][0]=b[j];
	for(int i=1;i<=18;i++){
		for(int j=0;j<=m-(1<<i)+2;j++)f[j][i]=max(f[j][i-1],f[j+(1<<(i-1))][i-1]),g[j][i]=min(g[j][i-1],g[j+(1<<(i-1))][i-1]);
	}
	for(int i=1;i<=n;i++){
		if(i==1||i==n||(!(a[i-1]<=a[i]&&a[i]<=a[i+1])&&!(a[i-1]>=a[i]&&a[i]>=a[i+1]))){
			if(a[i]<b[R]){
				int l=R,r=m;
				while(l<r){int mid=l+r+1>>1;
					if(MIN(R,mid)>a[i])l=mid;else r=mid-1;
				}R=l;
			}else{
				int l=0,r=R;
				while(l<r){int mid=l+r+1>>1;
					if(MAX(mid,R)<=a[i])r=mid-1;else l=mid;
				}R=l;
			}
		}
	}return R==m;
}
int n,m,q,cnt;
int A[500005],B[500005],kx[65],ky[65];
int a[500005],b[500005];
struct st{
	int a,b;st(){}
	st(int A,int B){a=A,b=B;}
};vector<st>vx[65],vy[65];
void Solve(){
	if(a[1]<b[1])printf("%d",F(n,m,a,b));
	else if(a[1]>b[1])printf("%d",F(m,n,b,a));
	else printf("0");
}
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	scanf("%*d%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)read(a[i]),A[i]=a[i],LOG[i]=log2(i);
	for(int i=1;i<=m;i++)read(b[i]),B[i]=b[i];
	for(int i=1;i<=q;i++){Solve();
		scanf("%d%d",&kx[i],&ky[i]);
		for(int j=1;j<=n;j++)a[j]=A[j];
		for(int j=1;j<=m;j++)b[j]=B[j];
		for(int j=1,x,X;j<=kx[i];j++)read(x),read(X),a[x]=X;
		for(int j=1,y,Y;j<=ky[i];j++)read(y),read(Y),b[y]=Y;
	}Solve();
}
