#include<bits/stdc++.h>
#define ll long long
#define For(i,a,b) for(ll i=(a);i<=(b);++i)
#define Rep(i,a,b) for(ll i=(a);i>=(b);--i)
#define pb push_back
const ll N=1e6+10;
using namespace std;

ll sid;
ll n,m,k,d;
ll a[N],b[N],c[N];
vector<ll>dp[N];
vector<pair<ll,ll>>e[N];



void mian(){
	
	ll ans=0;
	scanf("%lld%lld%lld%lld",&n,&m,&k,&d);
	For(i,1,n){
		e[i].clear();
		dp[i].clear();
	}
	For(i,1,m){
		scanf("%lld%lld%lld",&a[i],&b[i],&c[i]);
		if(b[i]>k){
			--i,--m;
			continue;
		}
		e[a[i]].pb({b[i],c[i]});
		if(sid==17||sid==18){
			ans+=max(c[i]-b[i]*d,0ll);
		}
	}
	if(sid==17||sid==18){
		printf("%lld\n",ans);
		return;
	}
	For(i,1,n){
		sort(e[i].begin(),e[i].end());
		For(j,1,(ll)e[i].size()-1){
			e[i][j].second+=e[i][j-1].second;
		}
	}
	dp[0].resize(k+1);
	For(j,1,k)dp[0][j]=-1e18;
	For(i,1,n){
		dp[i].resize(k+1);
		For(j,1,k)dp[i][j]=-1e18;
		For(j,0,k)dp[i][0]=max(dp[i][0],dp[i-1][j]);
		For(j,1,k){
			ll pos=lower_bound(e[i].begin(),e[i].end(),make_pair(j+1,0ll))-e[i].begin()-1;
			dp[i][j]=dp[i-1][j-1]-d;
			if(pos!=-1)dp[i][j]+=e[i][pos].second;
		}
	}
	For(j,0,k)ans=max(ans,dp[n][j]);
	printf("%lld\n",ans);
	
}

int main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	int T=1;
	scanf("%lld%d",&sid,&T);
	while(T--)mian();
	return 0;
}
//12:57
//36-52
