#include<bits/stdc++.h>
#define ll long long
#define For(i,a,b) for(ll i=(a);i<=(b);++i)
#define Rep(i,a,b) for(ll i=(a);i>=(b);--i)
#define pb push_back
const ll N=1e6+10;
using namespace std;

struct seg{
	#define lson rt<<1
	#define rson rt<<1|1
	ll mx[N],mn[N];
	void change(ll rt,ll l,ll r,ll x,ll y){
		if(l==r){
			mx[rt]=y;
			mn[rt]=y;
			return;
		}
		ll mid=(l+r)>>1;
		if(x<=mid)change(lson,l,mid,x,y);
		else change(rson,mid+1,r,x,y);
		mx[rt]=max(mx[lson],mx[rson]);
		mn[rt]=min(mn[lson],mn[rson]);
	}
}t1,t2;
ll sid;
ll n,m,q;
ll a[N],b[N];
ll c[N],d[N];
ll ta[N],tb[N];
ll dp[2010][2010];



void mian(){
	
	scanf("%lld%lld%lld%lld",&sid,&n,&m,&q);
	For(i,1,n)scanf("%lld",&a[i]),t1.change(1,1,n,i,a[i]),ta[i]=a[i];
	For(i,1,m)scanf("%lld",&b[i]),t2.change(1,1,m,i,b[i]),tb[i]=b[i];
	if(sid<=7){
		if(ta[1]==tb[1]||(ta[1]-tb[1])*(ta[n]-tb[m])<0){
			putchar('0');
		}else if(ta[1]>tb[1]){
			For(i,1,n)For(j,1,m)dp[i][j]=0;
			dp[1][1]=1;
			For(i,1,n){
				For(j,1,m){
					if(!dp[i][j])continue;
					if(j<m&&ta[i]>tb[j+1])dp[i][j+1]=1;
					if(i<n&&ta[i+1]>tb[j])dp[i+1][j]=1;
				}
			}
			printf("%lld",dp[n][m]);
		}else{
			For(i,1,n)For(j,1,m)dp[i][j]=0;
			dp[1][1]=1;
			For(i,1,n){
				For(j,1,m){
					if(!dp[i][j])continue;
					if(j<m&&ta[i]<tb[j+1])dp[i][j+1]=1;
					if(i<n&&ta[i+1]<tb[j])dp[i+1][j]=1;
				}
			}
			printf("%lld",dp[n][m]);
		}
		while(q--){
			ll kx,ky;
			scanf("%lld%lld",&kx,&ky);
			For(i,1,kx){
				ll x,y;
				scanf("%lld%lld",&x,&y);
				c[i]=x,ta[x]=y;
			}
			For(i,1,ky){
				ll x,y;
				scanf("%lld%lld",&x,&y);
				d[i]=x,tb[x]=y;
			}
			if(ta[1]==tb[1]||(ta[1]-tb[1])*(ta[n]-tb[m])<0){
				putchar('0');
			}else if(ta[1]>tb[1]){
				For(i,1,n)For(j,1,m)dp[i][j]=0;
				dp[1][1]=1;
				For(i,1,n){
					For(j,1,m){
						if(!dp[i][j])continue;
						if(j<m&&ta[i]>tb[j+1])dp[i][j+1]=1;
						if(i<n&&ta[i+1]>tb[j])dp[i+1][j]=1;
					}
				}
				printf("%lld",dp[n][m]);
			}else{
				For(i,1,n)For(j,1,m)dp[i][j]=0;
				dp[1][1]=1;
				For(i,1,n){
					For(j,1,m){
						if(!dp[i][j])continue;
						if(j<m&&ta[i]<tb[j+1])dp[i][j+1]=1;
						if(i<n&&ta[i+1]<tb[j])dp[i+1][j]=1;
					}
				}
				printf("%lld",dp[n][m]);
			}
			For(i,1,kx)ta[c[i]]=a[i];
			For(i,1,ky)tb[d[i]]=b[i];
		}
		return;
	}
	putchar('0');
	while(q--)putchar('0');
}

int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	int T=1;
	while(T--)mian();
	return 0;
}
//12:28
//35
