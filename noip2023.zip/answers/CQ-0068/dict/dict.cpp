#include<bits/stdc++.h>
#define ll long long
#define For(i,a,b) for(ll i=(a);i<=(b);++i)
#define Rep(i,a,b) for(ll i=(a);i>=(b);--i)
#define pb push_back
const ll N=3000+10;
using namespace std;

ll n,m;
char a[N][N];
char s[N][N];
char t[N][N];



void mian(){
	
	scanf("%lld%lld",&n,&m);
	For(j,0,m-1)s[0][j]='z',t[n+1][j]='z';
	For(i,1,n){
		scanf("%s",a[i]);
		sort(a[i],a[i]+m);
		reverse(a[i],a[i]+m);
		if(strcmp(s[i-1],a[i])==1)strcpy(s[i],a[i]);
		else strcpy(s[i],s[i-1]);
	}
	Rep(i,n,1){
		if(strcmp(t[i+1],a[i])==1)strcpy(t[i],a[i]);
		else strcpy(t[i],t[i+1]);
	}
	For(i,1,n){
		reverse(a[i],a[i]+m);
		if(strcmp(a[i],s[i-1])==-1&&strcmp(a[i],t[i+1])==-1)printf("1");
		else printf("0");
	}
	
}

int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	int T=1;
	while(T--)mian();
	return 0;
}
//8:45
//100
