#include<bits/stdc++.h>
#define ll long long
#define For(i,a,b) for(ll i=(a);i<=(b);++i)
#define Rep(i,a,b) for(ll i=(a);i>=(b);--i)
#define pb push_back
const ll N=1e6+10;
using namespace std;

ll sid;
ll n,m;
ll vis[N],a[N],t[N];
ll vvv[N],in[N];

ll cnt,fir[N],nxt[N],v[N],w[N];
void add(ll x,ll y,ll z){
	v[++cnt]=y,w[cnt]=z;
	nxt[cnt]=fir[x];
	fir[x]=cnt;
}

void dfs(ll x){
	in[x]=1;
	for(ll i=fir[x];i;i=nxt[i]){
		ll y=v[i],z=w[i];
		if(in[y]){
			if(((vvv[x]==vvv[y])==z)){
				vvv[x]=114514;
				in[x]=0;
				return;
			}
			continue;
		}
		if(t[y]||vvv[y]==114514){
			vvv[x]=114514;
			in[x]=0;
			return;
		}
		if(vvv[y])continue;
		vvv[y]=z==1?-vvv[x]:vvv[x];
		dfs(y);
		if(vvv[y]==114514){
			vvv[x]=114514;
			in[x]=0;
			return;
		}
	}
	in[x]=0;
}

void mian(){
	
	scanf("%lld%lld",&n,&m);
	cnt=1;
	For(i,1,n){
		vis[i]=0,a[i]=i,t[i]=0;
		fir[i]=0,vvv[i]=0;
	}
	For(i,1,m){
		char c=getchar();
		while(c==' '||c=='\n')c=getchar();
		ll x,y;
		if(c=='+'){
			scanf("%lld%lld",&x,&y);
			vis[x]=vis[y],a[x]=a[y];
		}
		if(c=='-'){
			scanf("%lld%lld",&x,&y);
			vis[x]=vis[y],a[x]=-a[y];
		}
		if(c=='T'){
			scanf("%lld",&x);
			vis[x]=1,a[x]=1;
		}
		if(c=='F'){
			scanf("%lld",&x);
			vis[x]=1,a[x]=-1;
		}
		if(c=='U'){
			scanf("%lld",&x);
			vis[x]=1,a[x]=0;
		}
	}
	ll ans=0;
	For(i,1,n){
		if(vis[i]&&a[i]==0)t[i]=1,vvv[i]=114514;
		if(!vis[i])add(i,abs(a[i]),a[i]<0?1:0);
	}
	For(i,1,n){
		if(!vvv[i]){
			vvv[i]=1;
			dfs(i);
		}
	}
	For(i,1,n){
		ans+=(vvv[i]==114514);
	}
	printf("%lld\n",ans);
	
}

int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	int T=1;
	scanf("%lld%d",&sid,&T);
	while(T--)mian();
	return 0;
}
//10:01
//100
