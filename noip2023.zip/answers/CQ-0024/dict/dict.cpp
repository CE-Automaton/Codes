#include <stdio.h>

char s[3007][3007];
int sp[3007][27], x[3007], y[3007];

inline void getss(char s[], int n, int cnt[]){
	for (int i = 1; i <= n; i++){
		cnt[s[i] - 'a' + 1]++;
	}
}

int main(){
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);
	int n, m;
	scanf("%d %d", &n, &m);
	for (int i = 1; i <= n; i++){
		scanf("%s", &s[i][1]);
	}
	for (int i = 1; i <= n; i++){
		getss(s[i], m, sp[i]);
		for (int j = 1; j <= 26; j++){
			if (sp[i][j]){
				x[i] = j;
				break;
			}
		}
		for (int j = 26; j >= 1; j--){
			if (sp[i][j]){
				y[i] = j;
				break;
			}
		}
	}
	for (int i = 1; i <= n; i++){
		bool flag = true;
		for (int j = 1; j <= n; j++){
			if (i != j && x[i] >= y[j]){
				flag = false;
				break;
			}
		}
		if (flag){
			printf("1");
		} else {
			printf("0");
		}
	}
	return 0;
}
