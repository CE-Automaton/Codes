#include <stdio.h>
#include <assert.h>

#include <iostream>
#include <queue>
#include <vector>

using namespace std;

int fa[200007], refers[200007], val[200007];
char op[7];
queue<int> q;
vector<pair<int, int> > v[100007];
vector<pair<int, int> > edge[200007], edges2[200007];

inline int tsp(int x, int y){
	return x == -1 ? x : x ^ y;
}

int cop[200007];
bool endp[200007];

void run_dfs(int u){
	if (refers[u] != u && endp[u]){
		assert(refers[u] != 0);
		val[refers[u]] = val[u];
		q.push(refers[u]);
	}
	for (pair<int, int> i : edge[u]){
//		printf("cop[%d] = %d\n", i.first, i.second);
		val[i.first] = tsp(val[u], i.second);
		run_dfs(i.first);
	}
}

int sums[200007], sz[200007];
bool vis[200007];

bool dfs(int u){
	bool ans = true;
	vis[u] = true;
	sz[u] = refers[u] == u || (fa[u] != 0 && refers[u] != 0);
	for (pair<int, int> i : edges2[u]){
		if (!vis[i.first]){
			val[i.first] = val[u] ^ i.second;
			ans &= dfs(i.first);
			sz[u] += sz[i.first];
		} else {
			ans &= !(val[u] ^ val[i.first] ^ i.second);
		}
	}
	return ans;
}

int main(){
	freopen("tribool.in", "r", stdin);
	freopen("tribool.out", "w", stdout);
	int c, t;
	scanf("%d %d", &c, &t);
	for (int i = 1; i <= t; i++){
		int n, m, tot = 0;
		scanf("%d %d", &n, &m);
		for (int j = 1; j <= n; j++){
			v[j].clear();
			v[j].push_back(make_pair(++tot, 114514));
			fa[tot] = 0;
		}
		for (int j = 1; j <= m; j++){
			scanf("%s", &op[1]);
			if (op[1] == '+'){
				int x, y;
				scanf("%d %d", &x, &y);
				tot++;
				fa[tot] = v[y].back().first;
				v[x].push_back(make_pair(tot, 0));
			} else if (op[1] == '-'){
				int x, y;
				scanf("%d %d", &x, &y);
				tot++;
				fa[tot] = v[y].back().first;
				v[x].push_back(make_pair(tot, 1));
			} else {
				int x;
				scanf("%d", &x);
				if (op[1] == 'T'){
					v[x].push_back(make_pair(++tot, 1));
				} else if (op[1] == 'F'){
					v[x].push_back(make_pair(++tot, 0));
				} else {
					v[x].push_back(make_pair(++tot, -1));
				}
				fa[tot] = 0;
			}
		}
		for (int j = 1; j <= tot; j++){
			refers[j] = 0;
			val[j] = 114514;
			endp[j] = false;
			edge[j].clear();
		}
		while (!q.empty()) q.pop();
		for (int j = 1; j <= n; j++){
			refers[v[j][0].first] = v[j].back().first;
			refers[v[j].back().first] = v[j][0].first;
			endp[v[j].back().first] = true;
//			printf("at %d\n", j);
			for (pair<int, int> k : v[j]){
//				printf("ok: (%d, %d)\n", k.first, k.second);
//				printf("fa = %d\n", fa[k.first]);
				if (fa[k.first] != 0){
					edge[fa[k.first]].push_back(k);
					cop[k.first] = k.second;
				}
				if (fa[k.first] == 0 && k.second != 114514){
					val[k.first] = k.second;
					q.push(k.first);
				}
			}
		}
		while (!q.empty()){
			int cur = q.front();
			q.pop();
			run_dfs(cur);
		}
		int ans = 0;
		for (int j = 1; j <= n; j++){
//			printf("vals[%d] = %d\n", j, val[v[j][0].first]);
			if (val[v[j][0].first] != 114514) ans += val[v[j][0].first] == -1;
		}
		for (int j = 1; j <= tot; j++){
			vis[j] = false;
			edges2[j].clear();
		}
		for (int j = 1; j <= tot; j++){
			if (val[j] == 114514){
				if (fa[j] == 0){
					assert(refers[j] != 0);
					if (refers[j] != j){
						edges2[j].push_back(make_pair(refers[j], 0));
						edges2[refers[j]].push_back(make_pair(j, 0));
					}
				} else {
					edges2[j].push_back(make_pair(fa[j], cop[j]));
					edges2[fa[j]].push_back(make_pair(j, cop[j]));
				}
			}
		}
		for (int j = 1; j <= n; j++){
			if (val[v[j][0].first] == 114514 && !vis[v[j][0].first]){
				val[v[j][0].first] = 0;
				if (!dfs(v[j][0].first)) ans += sz[v[j][0].first];
			}
		}
		printf("%d\n", ans);
	}
	return 0;
}
