#include <stdio.h>

#include <algorithm>
#include <vector>

using namespace std;

typedef long long ll;

int x[100007], y[100007], v[100007];
vector<int> vec[400007];

inline int read(){
	int ans = 0;
	char ch = getchar();
	while (ch < '0' || ch > '9'){
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9'){
		ans = ans * 10 + (ch ^ 48);
		ch = getchar();
	}
	return ans;
}

int pos[400007], l[100007], r[100007], trans[400007];

typedef struct {
	int l;
	int r;
	ll add;
	ll max;
} Node;

Node tree[1600007];

void build(int x, int l, int r){
	tree[x].l = l;
	tree[x].r = r;
	tree[x].add = tree[x].max = 0;
	if (l == r) return;
	int mid = (l + r) >> 1;
	build(x * 2, l, mid);
	build(x * 2 + 1, mid + 1, r);
}

inline void update(int x){
	tree[x].max = max(tree[x * 2].max, tree[x * 2 + 1].max) + tree[x].add;
}

void assign(int x, int pos, ll k){
	if (tree[x].l == tree[x].r){
		tree[x].max = k;
		return;
	}
	if (pos <= ((tree[x].l + tree[x].r) >> 1)){
		assign(x * 2, pos, k);
	} else {
		assign(x * 2 + 1, pos, k);
	}
	update(x);
}

void add(int x, int l, int r, ll k){
	if (l > r) return;
	if (l <= tree[x].l && tree[x].r <= r){
		tree[x].add += k;
		tree[x].max += k;
		return;
	}
	int mid = (tree[x].l + tree[x].r) >> 1;
	if (l <= mid) add(x * 2, l, r, k);
	if (r > mid) add(x * 2 + 1, l, r, k);
	update(x);
}

ll get_max(int x, int l, int r){
	if (l > r) return 0;
	if (l <= tree[x].l && tree[x].r <= r) return tree[x].max;
	int mid = (tree[x].l + tree[x].r) >> 1;
	ll ans = 0;
	if (l <= mid) ans = get_max(x * 2, l, r);
	if (r > mid) ans = max(ans, get_max(x * 2 + 1, l, r));
	return ans + tree[x].add;
}

ll dp[1007][1007], suf[1007];

int main(){
	freopen("run.in", "r", stdin);
	freopen("run.out", "w", stdout);
	int c = read(), t = read();
	for (int i = 1; i <= t; i++){
		int n = read(), m = read(), k = read(), d = read(), m_ = 0;
		for (int j = 1; j <= m; j++){
			int X = read(), Y = read(), V = read();
			if (Y <= k){
				m_++;
				x[m_] = X;
				y[m_] = Y;
				v[m_] = V;
			}
		}
		m = m_;
		if (c <= 9){
			for (int j = 1; j <= n; j++){
				vec[j].clear();
			}
			for (int j = 1; j <= m; j++){
				vec[x[j]].push_back(j);
			}
			for (int j = 0; j <= n; j++){
				for (int x = 0; x <= j; x++){
					dp[j][x] = -1e18;
				}
			}
			dp[0][0] = 0;
			for (int j = 1; j <= n; j++){
				for (int x = max(j - k, 0); x <= j - 1; x++){
					dp[j][x] = dp[j - 1][x] - d;
				}
				for (int x = 0; x <= j; x++){
					suf[x] = 0;
				}
				for (int p : vec[j]){
					suf[j - y[p]] += v[p];
				}
				for (int x = j - 1; x >= max(j - k, 0); x--){
					suf[x] += suf[x + 1];
					dp[j][x] += suf[x];
				}
				for (int x = max(j - k - 1, 0); x <= j - 1; x++){
					dp[j][j] = max(dp[j][j], dp[j - 1][x]);
				}
			}
			ll ans = 0;
			for (int j = n - k; j <= n; j++){
				ans = max(ans, dp[n][j]);
			}
			printf("%lld\n", ans);
			continue;
		}
		if (c == 17 || c == 18){
			ll ans = 0;
			for (int j = 1; j <= m; j++){
				ans += max(v[j] - (ll)d * y[j], 0ll);
			}
			printf("%lld\n", ans);
			continue;
		}
		int tot = 0;
		pos[++tot] = 0;
		pos[++tot] = n;
		for (int j = 1; j <= m; j++){
			y[j] = x[j] - y[j];
			pos[++tot] = x[j];
			pos[++tot] = y[j];
			if (y[j] + k < n) pos[++tot] = y[j] + k;
			if (x[j] - k + 1 >= 1) pos[++tot] = x[j] - k + 1;
		}
		sort(pos + 1, pos + tot + 1);
		tot = unique(pos + 1, pos + tot + 1) - pos - 1;
		for (int j = 1; j <= m; j++){
			l[j] = lower_bound(pos + 1, pos + tot + 1, y[j]) - pos;
			r[j] = lower_bound(pos + 1, pos + tot + 1, x[j]) - pos;
		}
		for (int j = 1; j <= tot; j++){
			vec[j].clear();
		}
		for (int j = 1; j <= m; j++){
			vec[r[j]].push_back(j);
		}
		build(1, 1, tot);
		trans[1] = 1;
		for (int j = 2; j <= tot; j++){
			trans[j] = trans[j - 1];
			while (pos[j] - pos[trans[j]] > k) trans[j]++;
			assign(1, j, get_max(1, trans[j - 1], j - 1));
			add(1, trans[j], j - 1, -(ll)d * (pos[j] - pos[j - 1]));
			for (int p : vec[j]){
				add(1, trans[j], l[p], v[p]);
			}
		}
		printf("%lld\n", get_max(1, trans[tot], tot));
	}
	return 0;
}
