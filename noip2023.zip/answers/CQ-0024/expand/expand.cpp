#include <stdio.h>
#include <string.h>

int c;
int x[500007], y[500007], bx[500007], by[500007];
bool dp[2007][2007];

inline int read(){
	int ans = 0;
	char ch = getchar();
	while (ch < '0' || ch > '9'){
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9'){
		ans = ans * 10 + (ch ^ 48);
		ch = getchar();
	}
	return ans;
}

inline bool rsolve(int x[], int y[], int n, int m){
	if (x[1] >= y[1] || x[n] >= y[m]) return false;
	if (c <= 7){
		memset(dp, 0, sizeof(dp));
		dp[1][1] = true;
		for (int i = 1; i <= n; i++){
			for (int j = 1; j <= m; j++){
				dp[i][j] &= x[i] < y[j];
				if (dp[i][j]) dp[i + 1][j] = dp[i][j + 1] = dp[i + 1][j + 1] = true;
			}
		}
		return dp[n][m];
	}
}

inline int solve(int n, int m){
	return rsolve(x, y, n, m) || rsolve(y, x, m, n);
}

int main(){
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);
	c = read();
	int n = read(), m = read(), q = read();
	for (int i = 1; i <= n; i++){
		x[i] = read();
	}
	for (int i = 1; i <= m; i++){
		y[i] = read();
	}
	printf("%d", solve(n, m));
	for (int i = 1; i <= q; i++){
		int kx = read(), ky = read();
		for (int j = 1; j <= n; j++){
			bx[j] = x[j];
		}
		for (int j = 1; j <= m; j++){
			by[j] = y[j];
		}
		for (int j = 1; j <= kx; j++){
			int px = read(), vx = read();
			x[px] = vx;
		}
		for (int j = 1; j <= ky; j++){
			int py = read(), vy = read();
			y[py] = vy;
		}
		printf("%d", solve(n, m));
		for (int j = 1; j <= n; j++){
			x[j] = bx[j];
		}
		for (int j = 1; j <= m; j++){
			y[j] = by[j];
		}
	}
	return 0;
}
