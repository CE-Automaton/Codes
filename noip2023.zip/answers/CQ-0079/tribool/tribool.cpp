#include <bits/stdc++.h>
const int N = 1e5;
#define gc() (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1000000, stdin), p1 == p2) ? EOF : *p1 ++ )
char buf[1000005], *p1 = buf, *p2 = buf;
bool is_num(char ch) {return '0' <= ch && ch <= '9';}
int read()
{
	char ch;
	int x = 0, f = 1;
	while (!is_num(ch = gc())) if (ch == '-') f = -1;
	do x = x * 10 + ch - '0'; while (is_num(ch = gc()));
	return f * x;
}
//int read() {int x; return scanf("%d", &x), x;}
int n, m;
int col[N + 5];
int f(int x)
{
	if (x > 2 * n) return x == 2 * n + 3 ? x : 4 * n + 3 - x;
	return x > n ? x - n : x + n;
}
int fa[2 * N + 5], cnt[2 * N + 5];
int get(int u) {return u == fa[u] ? u : fa[u] = get(fa[u]);}
int Merge(int u, int v)
{
	u = get(u), v = get(v);
	if (u == v) return 0;
	cnt[v] += cnt[u];
	fa[u] = v;
	return 1;
}
int vis[2 * N + 5];
int main()
{
	freopen("tribool.in", "r", stdin);
	freopen("tribool.out", "w", stdout);
	int c = read(), T = read();
	while (T -- )
	{
		n = read(), m = read();
		for (int i = 1; i <= n; i ++ ) col[i] = i;
		for (int i = 1; i <= m; i ++ )
		{
			char op = gc();
			if (op == 'T')
			{
				int x = read();
				col[x] = 2 * n + 1;
			}
			if (op == 'F')
			{
				int x = read();
				col[x] = 2 * n + 2;
			}
			if (op == 'U')
			{
				int x = read();
				col[x] = 2 * n + 3;
			}
			if (op == '+')
			{
				int x = read(), y = read();
				col[x] = col[y];
			}
			if (op == '-')
			{
				int x = read(), y = read();
				col[x] = f(col[y]);
			}
		}
		for (int i = 1; i <= 2 * n + 3; i ++ ) fa[i] = i, cnt[i] = (i <= n);
		for (int i = 1; i <= n; i ++ ) Merge(i, col[i]), Merge(f(i), f(col[i]));
		std :: memset(vis, 0, sizeof vis);
		int res = cnt[get(2 * n + 3)];
		vis[get(2 * n + 3)] = 1;
		for (int i = 1; i <= n; i ++ )
			if (get(i) == get(f(i)) && !vis[get(i)])
				res += cnt[get(i)], vis[get(i)] = 1;
		printf("%d\n", res);
	}
	return 0;
}
