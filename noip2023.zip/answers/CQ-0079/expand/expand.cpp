#include <bits/stdc++.h>
const int N = 4e4;
#define gc() (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1000000, stdin), p1 == p2) ? EOF : *p1 ++ )
char buf[1000005], *p1 = buf, *p2 = buf;
bool is_num(char ch) {return '0' <= ch && ch <= '9';}
int read()
{
	char ch;
	int x = 0, f = 1;
	while (!is_num(ch = gc())) if (ch == '-') f = -1;
	do x = x * 10 + ch - '0'; while (is_num(ch = gc()));
	return f * x;
}
//int read() {int x; return scanf("%d", &x), x;}
int c, n, m, q;
int f[2][N + 5], g[2][N + 5];
int s[N + 5], t[N + 5];
int a[N + 5], b[N + 5];
int o[N + 5][25], p[N + 5][25];
void init()
{
	std :: memset(o, 0x3f, sizeof o);
	for (int i = 1; i <= m; i ++ ) o[i][0] = b[i];
	for (int j = 1; j <= 20; j ++ )
		for (int i = 1 << j; i <= m; i ++ )
			o[i][j] = std :: max(o[i][j - 1], o[i - (1 << j - 1)][j - 1]);
	std :: memset(p, -0x3f, sizeof p);
	for (int i = 1; i <= m; i ++ ) p[i][0] = b[i];
	for (int j = 1; j <= 20; j ++ )
		for (int i = 1 << j; i <= m; i ++ )
			p[i][j] = std :: min(p[i][j - 1], p[i - (1 << j - 1)][j - 1]);
}
bool solve()
{
	init();
	//>
	std :: memset(f, 0, sizeof f);
	for (int i = 0; i <= m; i ++ ) f[0][i] = 1;
	for (int i = 1; i <= n; i ++ )
	{
		std :: memset(f[i & 1], 0, sizeof f[i & 1]);
		for (int j = 1; j <= m; j ++ )
		{
			if (a[i] <= b[j]) {f[i & 1][j] = f[i & 1][j - 1]; continue;}
			int x = j;
			for (int k = 20; k >= 0; k -- ) if (o[x][k] < a[i]) x -= 1 << k;
			bool flg = f[i - 1 & 1][j] - (x ? f[i - 1 & 1][x - 1] : 0);
			f[i & 1][j] = f[i & 1][j - 1] + flg;
		}
	}
	//<
	std :: memset(g, 0, sizeof g);
	for (int i = 0; i <= m; i ++ ) g[0][i] = 1;
	for (int i = 1; i <= n; i ++ )
	{
		std :: memset(g[i & 1], 0, sizeof g[i & 1]);
		for (int j = 1; j <= m; j ++ )
		{
			if (a[i] >= b[j]) {g[i & 1][j] = g[i & 1][j - 1]; continue;}
			int x = j;
			for (int k = 20; k >= 0; k -- ) if (p[x][k] > a[i]) x -= 1 << k;
			bool flg = g[i - 1 & 1][j] - (x ? g[i - 1 & 1][x - 1] : 0);
			g[i & 1][j] = g[i & 1][j - 1] + flg;
		}
	}
	return f[n & 1][m] - f[n & 1][m - 1] || g[n & 1][m] - g[n & 1][m - 1];
}
int main()
{
	freopen("expand.in", "r", stdin);
	freopen("expand.out", "w", stdout);
	c = read(), n = read(), m = read(), q = read();
	for (int i = 1; i <= n; i ++ ) s[i] = read();
	for (int i = 1; i <= m; i ++ ) t[i] = read();
	for (int i = 1; i <= n; i ++ ) a[i] = s[i];
	for (int i = 1; i <= m; i ++ ) b[i] = t[i];
	printf("%d", solve());
	while (q -- )
	{
		int k1 = read(), k2 = read();
		for (int i = 1; i <= n; i ++ ) a[i] = s[i];
		for (int i = 1; i <= m; i ++ ) b[i] = t[i];
		for (int i = 1; i <= k1; i ++ )
		{
			int x = read(), d = read();
			a[x] = d;
		}
		for (int i = 1; i <= k2; i ++ )
		{
			int x = read(), d = read();
			b[x] = d;
		}
		printf("%d", solve());
	}
	return 0;
}
