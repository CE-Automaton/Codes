#include <bits/stdc++.h>
const int N = 3e3;
#define gc() (p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1000000, stdin), p1 == p2) ? EOF : *p1 ++ )
char buf[1000005], *p1 = buf, *p2 = buf;
bool is_num(char ch) {return '0' <= ch && ch <= '9';}
int read()
{
	char ch;
	int x = 0, f = 1;
	while (!is_num(ch = gc())) if (ch == '-') f = -1;
	do x = x * 10 + ch - '0'; while (is_num(ch = gc()));
	return f * x;
}
//int read() {int x; return scanf("%d", &x), x;}
int cnt[N + 5][26];
bool cmp(int x, int y)
{
	for (int i = 25; i >= 0; i -- )
	{
		if (cnt[x][i] == cnt[y][i]) continue;
		return cnt[x][i] > cnt[y][i] ? 1 : 0;
	}
	return 1;
}
int a[N + 5], b[N + 5];
bool check(int x, int y)
{
	int idx = 0;
	for (int i = 0; i <= 25; i ++ )
		for (int j = 1; j <= cnt[x][i]; j ++ )
			a[ ++ idx] = i;
	idx = 0;
	for (int i = 25; i >= 0; i -- )
		for (int j = 1; j <= cnt[y][i]; j ++ )
			b[ ++ idx] = i;
	for (int i = 1; i <= idx; i ++ )
	{
		if (a[i] == b[i]) continue;
		return a[i] < b[i] ? 1 : 0;
	}
	return 0;
}
int main()
{
	freopen("dict.in", "r", stdin);
	freopen("dict.out", "w", stdout);
	int n = read(), m = read();
	if (n == 1) return printf("1"), 0;
	for (int i = 1; i <= n; i ++ )
	{
		if (i != 1) gc();
		for (int j = 1; j <= m; j ++ ) cnt[i][gc() - 'a'] ++ ;
	}
	cnt[0][25] = m;
	int p = 0, q = 0;
	for (int i = 1; i <= n; i ++ )
	{
		if (cmp(p, i)) q = p, p = i;
		else if (cmp(q, i)) q = i;
	}
	for (int i = 1; i <= n; i ++ )
	{
		int r = (i == p ? q : p);
		printf("%d", check(i, r));
	}
	return 0;
}
