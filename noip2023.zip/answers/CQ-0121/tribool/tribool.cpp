#include<bits/stdc++.h>
using namespace std;
int c,t,n,m,x,y,z[100005],father[100005],b[15],cnt,ans;
char s;
bool flag;
struct node{
	int x,y,opt;
}d[15];
int findfather(int v){
	ans++;
	return (v==father[v]||ans>n)?v:father[v]=findfather(father[v]);
}
int f(int o){
	if(o<=1){
		return o^1;
	}
	return 2;
} 
void dfs(int i){
	if(i==n+1){
		for(int j=1;j<=n;j++){
			b[j]=z[j];
		}
		for(int j=1;j<=m;j++){
			if(d[j].opt<3){
				b[d[j].x]=d[j].opt;
			}
			else if(d[j].opt==3){
				b[d[j].x]=b[d[j].y];
			}
			else{
				b[d[j].x]=f(b[d[j].y]);
			}
		}
		flag=1;
		cnt=0;
		for(int j=1;j<=n;j++){
			if(b[j]!=z[j]){
				flag=0;
				break;
			}
			if(b[j]==2){
				cnt++;
			}
		}
		if(flag){
			ans=min(cnt,ans);
		}
		return;
	}
	for(int j=0;j<=2;j++){
		z[i]=j;
		dfs(i+1);
	}
}
int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>c>>t;
	if(c<=2){
		while(t--){
			cin>>n>>m;
			for(int i=1;i<=m;i++){
				cin>>s;
				if(s=='T'){
					d[i].opt=1;
					cin>>d[i].x;
				}
				else if(s=='F'){
					d[i].opt=0;
					cin>>d[i].x;
				}
				else if(s=='U'){
					d[i].opt=2;
					cin>>d[i].x;
				}
				else if(s=='+'){
					d[i].opt=3;
					cin>>d[i].x>>d[i].y;
				}
				else{
					d[i].opt=4;
					cin>>d[i].x>>d[i].y;
				}
			}
			ans=100;
			dfs(1);
			cout<<ans<<'\n';
		}
	}
	else if(c<=4){
		while(t--){
			cin>>n>>m;
			memset(z,-1,sizeof(z));
			while(m--){
				cin>>s>>x;
				if(s=='T'){
					z[x]=1;
				} 
				else if(s=='F'){
					z[x]=0;
				}
				else{
					z[x]=3;
				}
			}
			cnt=0;
			for(int i=1;i<=n;i++){
				if(z[i]==3){
					cnt++;
				}
			}
			cout<<cnt<<'\n';
		}
	}
	return 0;
}

