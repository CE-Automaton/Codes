#include<bits/stdc++.h>
using namespace std;
int n,m,a[3005][3005],maxn,maxx;
char c[3005];
bool flag,vis;
bool is_first_more_max(int i,int j){
	for(int k=1;k<=m;k++){
		if(a[i][k]<a[j][k]){
			return 0;
		}
		if(a[i][k]>a[j][k]){
			return 1;
		}
	}
	return 1;
}
bool cmp(int x,int y){
	return x>y;
}
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	cin>>n>>m;
	if(n==1){
		cout<<1;
		return 0;
	}
	for(int i=1;i<=n;i++){
		scanf("%s",c);
		for(int j=1;j<=m;j++){
			a[i][j]=c[j-1];
		}
		sort(a[i]+1,a[i]+1+m,cmp);
		if(i==1){
			maxn=1;
		}
		else if(i==2){
			if(is_first_more_max(maxn,i)){
				maxx=maxn;
				maxn=i;
			}
			else{
				maxx=2;
			}
		}
		else if(is_first_more_max(maxn,i)){
			maxx=maxn;
			maxn=i;
		}
		else if(is_first_more_max(maxx,i)){
			maxx=i;
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j*2<=m;j++){
			swap(a[i][j],a[i][m-j+1]);
		}
		if(i==maxn){
			if(is_first_more_max(maxx,i)){
				printf("1");
			}
			else{
				printf("0");
			}
		}
		else{
			if(is_first_more_max(maxn,i)){
				printf("1");
			}
			else{
				printf("0");
			}
		}
		for(int j=1;j*2<=m;j++){
			swap(a[i][j],a[i][m-j+1]);
		}
	}
	return 0;
}

