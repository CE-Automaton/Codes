#include<bits/stdc++.h>
using namespace std;
int c,n,m,q,x[205],y[205],gx[205],gy[205],kx,ky,opt;
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	cin>>c>>n>>m>>q;
	if(c<=2){
		for(int i=1;i<=n;i++){
			scanf("%d",&x[i]);
			gx[i]=x[i];
		}
		for(int i=1;i<=m;i++){
			scanf("%d",&y[i]);
			gy[i]=y[i];
		}
		if((x[1]<y[1]&&x[n]<y[m])||(x[1]>y[1]&&x[n]>y[m])){
			cout<<'1';
		}
		else{
			cout<<'0';
		}
		while(q--){
			scanf("%d%d",&kx,&ky);
			for(int i=1;i<=kx;i++){
				scanf("%d%d",&opt,&x[0]);
				gx[opt]=x[0];
			}
			for(int i=1;i<=ky;i++){
				scanf("%d%d",&opt,&y[0]);
				gx[opt]=y[0];
			}
			if((x[1]<y[1]&&x[n]<y[m])||(x[1]>y[1]&&x[n]>y[m])){
				printf("1");
			}
			else{
				printf("0");
			} 
			for(int i=1;i<=n;i++){
				gx[i]=x[i];
			}
			for(int i=1;i<=m;i++){
				gy[i]=y[i];
			}
		}
	}
	return 0;
}

