#include<bits/stdc++.h>
using namespace std;
int c,t,n,m,k;
long long d,dp[1005][1005],ans;
struct node{
	int r,len;
	long long v;
}e[100005]; 
bool cmp(node x,node y){
	return x.r<y.r;
}
int main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	cin>>c>>t;
	if(c<=9){
		while(t--){
			scanf("%d%d%d%lld",&n,&m,&k,&d);
			for(int i=1;i<=m;i++){
				scanf("%d%d%lld",&e[i].r,&e[i].len,&e[i].v);
			}
			sort(e+1,e+1+m,cmp);
			for(int i=1,j=1;i<=n;i++){
				int r=min(i,k);
				dp[i][0]=0;
				for(int o=1;o<=r;o++){
					dp[i][o]=dp[i-1][o-1]-d;
					dp[i][0]=max(dp[i][0],dp[i-1][o-1]);
				}
				if(r==k){
					dp[i][0]=max(dp[i][0],dp[i-1][k]);
				}
				while(e[j].r==i){
					for(int o=e[j].len;o<=r;o++){
						dp[i][o]+=e[j].v;
					}
					j++;
				}
			}
			ans=0;
			for(int i=0;i<=k;i++){
				ans=max(ans,dp[n][i]);
			}
			printf("%lld\n",ans);
		}
	}
	else if(c==17||c==18){
		while(t--){
			scanf("%d%d%d%lld",&n,&m,&k,&d);
			ans=0;
			for(int i=1;i<=m;i++){
				scanf("%d%d%lld",&e[i].r,&e[i].len,&e[i].v);
				if((long long)e[i].len*d<e[i].v&&e[i].len<=k){
					ans=ans+e[i].v-e[i].len*d;
				}
			} 
			printf("%lld\n",ans);
		}
	}
	return 0;
}

