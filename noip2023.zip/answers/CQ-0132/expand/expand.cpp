#include <bits/stdc++.h>
using namespace std;
const int N = 5e5 + 5;
int C,n,m,q,X[N],Y[N],x[N],yy[N],y[N],p[N],st[21][N];
char ans[N];
int que(int l,int r) {
	int k = __lg(r - l + 1);
	r = r - (1 << k) + 1;
	return max(st[k][l],st[k][r]);
}
void solve(int id) {
	if (1ll * (X[1] - Y[1]) * (X[n] - Y[m]) <= 0ll) {
		ans[id] = '0';
		return ;
	}
	if (C <= 2) {
		ans[id] = '1';
		return ;
	}
	bool f = 0;
	if (n > m) swap(n,m),swap(x,y),f = 1;
	if (x[1] < y[1]) {
		for (int i = 1; i <= n; i ++) x[i] = -x[i];
		for (int i = 1; i <= m; i ++) y[i] = -y[i];
	}
	for (int i = 1; i <= m; i ++) st[0][i] = y[i];
	for (int s = 1; s <= 20; s ++)
		for (int i = 1; i <= m; i ++)
			st[s][i] = max(st[s - 1][i],st[s - 1][i + (1 << (s - 1))]);
	bool fl = 1;
	x[0] = 0x3f3f3f3f;
	int ct = 0,pp = 0;
	for (int j = 1,i = 1,mx = -0x3f3f3f3f; j <= m; j ++) {
		mx = max(y[j],mx);
		if (x[i] > y[j]) {
			if (mx > x[i - 1]) {
				fl = 0;
				pp = i - 1;
			}
			p[i] = j,i ++,mx = -0x3f3f3f3f,ct ++;
		}
	}
	if (ct < n) {
		ans[id] = '0';
		return ;
	} else if (fl) {
		ans[id] = '1';
		return ;
	}
	bool lf = 1;
	x[n + 1] = 0x3f3f3f3f;
	for (int j = m,i = n; j > 0; j --) {
		if (y[j] < x[i]) p[i] = j,i --;
		else if (y[j] > x[i + 1]) {
			lf = 0;
			break;
		}
		if (i == pp) {
			if (que(p[i],p[i + 1]) < x[i]) break;
			else lf = 0;
		}
	}
	if (lf) ans[id] = '1';
	else ans[id] = '0';
	if (f) swap(n,m);
}
int main() {
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	scanf("%d%d%d%d",&C,&n,&m,&q);
	for (int i = 1; i <= n; i ++) scanf("%d",&X[i]);
	for (int i = 1; i <= m; i ++) scanf("%d",&Y[i]);
	solve(1);
	for (int t = 1; t <= q; t ++) {
		for (int i = 1; i <= n; i ++) x[i] = X[i];
		for (int i = 1; i <= m; i ++) y[i] = Y[i];
		int kx,ky;
		scanf("%d%d",&kx,&ky);
		for (int i = 1,p,v; i <= kx; i ++) 
			scanf("%d%d",&p,&v),x[p] = v;
		for (int i = 1,p,v; i <= ky; i ++) 
			scanf("%d%d",&p,&v),y[p] = v;
		solve(t + 1);
	}
	puts(ans + 1);
	return 0;
}
