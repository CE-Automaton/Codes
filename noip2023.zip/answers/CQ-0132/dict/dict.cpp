#include <bits/stdc++.h>
using namespace std;
int n,m,ct[30];
char s[3005][3005],a[3005][3005],b[3005][3005],d1,m1[3005],d2,m2[3005],ans[3005];
bool cmp(char *s1,char *s2) {
	for (int i = 1; i <= m; i ++)
		if (s1[i] != s2[i]) return s1[i] > s2[i];
	return 0;
}
void cpy(char *s1,char *s2) {for (int i = 1; i <= m; i ++) s1[i] = s2[i];}
int main() {
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i = 1; i <= n; i ++) {
		scanf("%s",s[i] + 1);
		for (int j = 0; j < 26; j ++) ct[j] = 0;
		for (int j = 1; j <= m; j ++) ct[s[i][j] - 'a'] ++;
		int tt = 0;
		for (int j = 0; j < 26; j ++)
			for (int k = 0; k < ct[j]; k ++)
				a[i][++ tt] = j + 'a';
		tt = 0;
		for (int j = 25; j >= 0; j --)
			for (int k = 0; k < ct[j]; k ++)
				b[i][++ tt] = j + 'a';
	}
	for (int i = 1; i <= n; i ++)
		if (!d1 || cmp(m1,b[i])) cpy(m1,b[i]),d1 = i;
		else if (!d2 || cmp(m2,b[i])) cpy(m2,b[i]),d2 = i;
	for (int i = 1; i <= n; i ++) 
		if (d1 == i) ans[i] = (int)cmp(m2,a[i]) + '0';
		else ans[i] = (int)cmp(m1,a[i]) + '0';
	puts(ans + 1);
	return 0;
}
