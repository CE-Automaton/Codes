#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int C,T;
int n,m,k,d;
ll f[2][100005];
vector <pair<int,int> > p[100005];
void solve() {
	scanf("%d%d%d%d",&n,&m,&k,&d);
	memset(f,-0x3f3f3f3f,sizeof(f));
	for (int i = 1; i <= n; i ++) p[i].clear();
	for (int i = 1; i <= m; i ++) {
		int x,y,v;
		scanf("%d%d%d",&x,&y,&v);
		p[x].push_back(make_pair(y,v));
	}
	for (int i = 1; i <= n; i ++) sort(p[i].begin(),p[i].end());
	f[0][0] = 0;
	for (int i = 1; i <= n; i ++) {
		int j_ = 0;
		ll mx = f[i - 1 & 1][0],s = 0ll;
		for (int j = 1; j <= k; j ++) {
			while (j_ < (int)p[i].size() && p[i][j_].first <= j) {
				s += p[i][j_].second;
				j_ ++;
			}
			f[i & 1][j] = f[i - 1 & 1][j - 1] + s - d;
			mx = max(f[i - 1 & 1][j],mx);
		}
		f[i & 1][0] = mx;
	}
	ll ans = 0ll;
	for (int j = 0; j <= k; j ++) ans = max(ans,f[n & 1][j]);
	printf("%lld\n",ans);
}
int main() {
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	scanf("%d%d",&C,&T);
	if (C <= 11) while (T --) solve();
	return 0;
}
