#include <bits/stdc++.h>
using namespace std;
const int N = 1e5 + 5;
int C,T,n,m,d[N];
struct Node {
	int op,s;
	void rst(int tp,int ss) {op = tp,s = ss;}
} a[N];
inline void cpy(Node &x,Node &y,int tp) {
	x = y;
	if (tp) {
		if (y.op < 0) x.op = (y.op == -1 ? -2 : -1);
		else if (y.op < 2) x.op = y.op ^ 1;
	}
}
int tt,h[N],to[N],nxt[N];
inline void add(int x,int y) {
	nxt[++ tt] = h[x];
	h[x] = tt;
	to[tt] = y;
}
inline int dfs(int x,int tc) {
	int sz = 1;
	for (int E = h[x]; E; E = nxt[E]) {
		int y = to[E];
		if (y != tc) sz += dfs(y,tc);
	}
	return sz;
}
int vs[N],xy,f;
inline void ch(int x,int tc,int tp) {
	if (a[x].op == -2) tp ^= 1;
	vs[x] = tp;
	for (int E = h[x]; E; E = nxt[E]) {
		int y = to[E];
		if (y == tc) {
			xy = tc;
			if (a[xy].op == -2) tp ^= 1;
			if (vs[xy] != tp) f = 0;
			return ;
		} else if (!vs[y]) ch(y,tc,tp);
	}
}
void solve() {
	scanf("%d%d",&n,&m);
	for (int i = 1; i <= n; i ++) a[i].rst(-1,i);
	for (int i = 1; i <= m; i ++) {
		char op;
		int u,v;
		scanf(" %c%d",&op,&u);
		if (op == '-') {
			scanf("%d",&v);
			cpy(a[u],a[v],1);
		} else if (op == '+') {
			scanf("%d",&v);
			cpy(a[u],a[v],0);
		} 
		else if (op == 'U') a[u].rst(2,0);
		else if (op == 'T') a[u].rst(1,0);
		else a[u].rst(0,0);
	}
	tt = 0;
	for (int i = 1; i <= n; i ++) h[i] = d[i] = vs[i] = 0;
	for (int i = 1; i <= n; i ++)
		if (a[i].s && a[i].s != i)
			d[i] = 1,add(a[i].s,i);
	int ans = 0;
	for (int i = 1; i <= n; i ++)
		if (!d[i]) {
			if (a[i].op == 2 || a[i].op == -2) ans += dfs(i,i);
		} else if (!vs[i]) {
			f = 1;
			ch(i,i,2);
			if (!f) ans += dfs(i,xy);
		}
	printf("%d\n",ans);
}
int main() {
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	scanf("%d%d",&C,&T);
	while (T --) solve();
	return 0;
}
