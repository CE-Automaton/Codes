#include<bits/stdc++.h>
using namespace std;
#define N 5005
#define INF 1145141919
template<typename T>
void read(T&x){
x=0;/*T fl=1;*/char c=getchar();while(c<'0'||'9'<c){/*if(c=='-')fl=-1;*/c=getchar();}
while('/'<c&&c<':'){x=x*10+(c^'0');c=getchar();}/*x*=fl;*/}
template<typename T>T Max(T x,T y){return (x<y?y:x);}
template<typename T>T Min(T x,T y){return (x<y?x:y);}
#define int long long 
int ff[N][N];
int vis[N][N];
int dp[N]; 
int n,m,k,d;
vector<pair<int,int> > v[N];
int f(int l,int r){
	if(l>r)return 0;
	if(vis[l][r])return ff[l][r];
	int sm=-(r-l+1)*d;
	for(int i=l;i<=r;i++){
		for(auto x:v[i]){
			if(x.first>=l)sm+=x.second;
		}
	}
//	cout<<l<<','<<r<<"::"<<sm<<endl; 
	vis[l][r]=1;
	return ff[l][r]=sm;
}
#undef int
int main(){
#define int long long
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	int c,t;
	read(c);
	read(t);
	while(t--){
		read(n);
		read(m);
		read(k);
		read(d);
		for(int i=0;i<=n+1;i++)v[i].clear(),dp[i]=0;
		for(int i=0;i<=n+1;i++)for(int j=0;j<=n+1;j++)vis[i][j]=0;
		for(int i=1;i<=m;i++){
			int x,y,z;
			read(x);
			read(y);
			read(z);
			v[x].push_back({x-y+1,z});
		}
		dp[0]=0;
		for(int i=1;i<=n+1;i++){
//			cout<<
			for(int j=i;i-j<=k&&j>0;j--){
//			 	puts("+"); 
				dp[i]=Max(dp[i],dp[j-1]+f(j,i-1));
			}
//			cout<<dp[i]<<endl; 
		}
		printf("%lld\n",dp[n+1]);
		
	} 
	return 0;
}

