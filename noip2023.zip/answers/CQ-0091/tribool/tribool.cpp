#include<bits/stdc++.h>
using namespace std;
#define N 400015
#define INF 1145141919
#define int long long 
template<typename T>
void read(T&x){
x=0;/*T fl=1;*/char c=getchar();while(c<'0'||'9'<c){/*if(c=='-')fl=-1;*/c=getchar();}
while('/'<c&&c<':'){x=x*10+(c^'0');c=getchar();}/*x*=fl;*/}
template<typename T>T Max(T x,T y){return (x<y?y:x);}
template<typename T>T Min(T x,T y){return (x<y?x:y);}
#define T (n+1)
#define F (n+2)
#define U 0
int cc,tt;
int n,m;
int val[N];
int t[N],las[N],fir[N],c[N],num=1;
void add(int u,int v,int w){
//cout<<u<<','<<v<<','<<w<<endl; 
t[++num]=v;las[num]=fir[u];fir[u]=num;c[num]=w;
t[++num]=u;las[num]=fir[v];fir[v]=num;c[num]=w;}
int vis[N];
int cnt=0;
int sm=0;
int fl;
int s[N];
void dfs(int u,int cm){
	vis[u]=1;
	cnt++;
	s[u]=sm;
	if(val[u]==0)fl=1;
	for(int i=fir[u];i;i=las[i]){
		if(i==(cm^1)||i==(cm))continue;
		sm+=c[i];
		if(vis[t[i]]){
//			cout<<u<<"->"<<t[i]<<endl;
			if((sm-s[t[i]])<0&&(((-(sm-s[t[i]]))&1)==1)){
				fl=1;
			}
		}
		else{
			dfs(t[i],i);
		}
		sm-=c[i];
	}
}
#undef int
int main(){
#define int long long 
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	read(cc);
	read(tt);
	while(tt--){
		read(n);
		read(m);
		for(int i=1;i<=n;i++)val[i]=i,vis[i]=0,fir[i]=0;
		num=1;
		//��ⲻ��գ�(__________);
		//��ⲻ��գ�(__________);
		//��ⲻ��գ�(__________);
		//��ⲻ��գ�(__________);
		//��ⲻ��գ�(__________);
		for(int i=1;i<=m;i++){
			char c=getchar();
			while(c!='-'&&c!='+'&&c!='T'&&c!='F'&&c!='U')c=getchar();
			if(c=='+'){
				int x,y;
				read(x);
				read(y);
				val[x]=val[y];
			}
			else if(c=='-'){
				int x,y;
				read(x);
				read(y);
				val[x]=-val[y];
			}
			else if(c=='T'){
				int x;
				read(x);
				val[x]=T;
			}
			else if(c=='F'){
				int x;
				read(x);
				val[x]=F;
			}else if(c=='U'){
				int x;
				read(x);
				val[x]=0;
			}
		}
		for(int i=1;i<=n;i++){
			int x=val[i];
			int fh=0;
			if(x<0)x=-x,fh=-1;
			if(x>0&&x<=n)add(x,i,fh);
//			cout<<val[i]<<' ';
		}
//		puts("\n-------");
		int ans=0;
		for(int i=1;i<=n;i++){
			if(!vis[i]){
//				cout<<i<<"::\n";
				fl=0;
				cnt=0;
				sm=0;
				dfs(i,0);
//				cout<<fl<<endl; 
				if(fl)ans+=cnt;
			}
		}
		printf("%lld\n",ans);
		//��ⲻ���У�(__________);
		//��ⲻ���У�(__________);
		//��ⲻ���У�(__________);
		//��ⲻ���У�(__________);
		//��ⲻ���У�(__________);
	}
	return 0;
}
/*
2 1
10 10
T 3
+ 1 2
- 7 1
+ 2 10
T 6
- 1 4
U 3
+ 7 10
F 5
+ 6 9
*/
/*
2 1
10 10
- 9 8
- 8 6
- 6 5
- 5 4
- 4 3
+ 3 9
- 1 2
+ 2 7
+ 7 10
- 10 1

*/
/*
2 1
10 10
T 3
+ 1 2
- 7 1
+ 2 10
T 6
- 1 4
U 3
+ 7 10
F 5
+ 6 9
*/
/*�������
#define T (2*n+1)
#define F (2*n+2)
#define U 0
int c,t;
int n,m;
int val[N]; 
vector<int> v[N];
queue<int> q;
int vis[N];
void bfs(){
	while(q.size()){
		int u=q.front();
		q.pop();
		for(auto x:v[u]){
			if(vis[x])continue;
			vis[x]=1;
			q.push(x);
		}
	}
}
int main(){
//	freopen("tribool2.in","r",stdin);
//	freopen("tribool.out","w",stdout);
	read(c);
	read(t);
	while(t--){
		read(n);
		read(m);
//		for(int i=1;i<=(2*n+3);i++)fa[i]=i;
		for(int i=1;i<=n;i++)val[i]=i,vis[i]=0,v[i].clear();
		//��ⲻ��գ�(__________);
		//��ⲻ��գ�(__________);
		//��ⲻ��գ�(__________);
		//��ⲻ��գ�(__________);
		//��ⲻ��գ�(__________);
		for(int i=1;i<=m;i++){
			char c=getchar();
			while(c!='-'&&c!='+'&&c!='T'&&c!='F'&&c!='U')c=getchar();
			if(c=='+'){
				int x,y;
				read(x);
				read(y);
				val[x]=val[y];
//				merge(x,y);
			}
			else if(c=='-'){
				int x,y;
				read(x);
				read(y);
				val[x]=-val[y];
			}
			else if(c=='T'){
				int x;
				read(x);
				val[x]=T;
			}
			else if(c=='F'){
				int x;
				read(x);
				val[x]=F;
			}else if(c=='U'){
				int x;
				read(x);
				val[x]=0;
			}
		}
		for(int i=1;i<=n;i++){
			int u=val[i];
			cout<<val[i]<<' ';
			if(u<0)u=-u;
			if(u>0&&u<=n)v[u].push_back(i);
		}
		puts("\n-------");
		for(int i=1;i<=n;i++)
			if(val[i]==-i||val[i]==0)q.push(i),vis[i]=1;
		bfs();
		int ans=0;
		for(int i=1;i<=n;i++)ans+=vis[i];
		printf("%d\n",ans);
		//��ⲻ���У�(__________);
		//��ⲻ���У�(__________);
		//��ⲻ���У�(__________);
		//��ⲻ���У�(__________);
		//��ⲻ���У�(__________);
	}
	return 0;
} 
*/
/*�ڶ��� 
#define T (n+1)
#define F (n+2)
#define U 0
int c,t;
int n,m;
int val[N];
int tt[N];
vector<int> v[N];
int ts[N];
int vis[N];
int cnt;
void bfs(int rt,int Orz){
	cnt=0;
	queue<pair<int,int> >q;
	q.push({rt,Orz});
	while(q.size()){
		int u=q.front().first,w=q.front().second;
		q.pop();
		if(ts[u]==0)cnt++;
		if(tt[u]>0){
			if(ts[tt[u]]==INF){
				cout<<u<<"->"<<tt[u]<<endl; 
				if(val[u]<0)ts[tt[u]]=-w;
				else ts[tt[u]]=w;
				q.push({tt[u],ts[tt[u]]});
			}
		}
		for(int i:v[u]){
			if(ts[i]!=INF)continue;
			cout<<u<<"->"<<i<<endl;
			if(val[i]<0)ts[i]=-w;
			else ts[i]=w;
			q.push({i,ts[i]});
		}
	}
}
void rev(int rt){
	queue<int>q;
	q.push(rt);
	while(q.size()){
		int u=q.front();
		vis[u]=1;
		q.pop();
		if(tt[u]>0)
			if(ts[tt[u]]!=INF)
				q.push(tt[u]),ts[tt[u]]=INF;
		for(int i:v[u]){
			if(ts[i]==INF)continue;
			q.push(i),ts[i]=INF;;
		}
	}
}
void bfs2(int rt){
	queue<int>q;
	q.push(rt);
	while(q.size()){
		int u=q.front();
		q.pop();
		if(tt[u]>0)
			if(!vis[tt[u]])
				q.push(tt[u]),vis[tt[u]]=1;
		for(int i:v[u]){
			if(vis[i])continue;
			vis[i]=1;
			q.push(i);
		}
	}
}
int main(){
//	freopen("tribool2.in","r",stdin);
//	freopen("tribool.out","w",stdout);
	read(c);
	read(t);
	while(t--){
		read(n);
		read(m);
//		for(int i=1;i<=(2*n+3);i++)fa[i]=i;
		for(int i=1;i<=n;i++)val[i]=i,vis[i]=0,v[i].clear(),ts[i]=INF,tt[i]=-1;
		//��ⲻ��գ�(__________);
		//��ⲻ��գ�(__________);
		//��ⲻ��գ�(__________);
		//��ⲻ��գ�(__________);
		//��ⲻ��գ�(__________);
		for(int i=1;i<=m;i++){
			char c=getchar();
			while(c!='-'&&c!='+'&&c!='T'&&c!='F'&&c!='U')c=getchar();
			if(c=='+'){
				int x,y;
				read(x);
				read(y);
				val[x]=val[y];
//				merge(x,y);
			}
			else if(c=='-'){
				int x,y;
				read(x);
				read(y);
				val[x]=-val[y];
			}
			else if(c=='T'){
				int x;
				read(x);
				val[x]=T;
			}
			else if(c=='F'){
				int x;
				read(x);
				val[x]=F;
			}else if(c=='U'){
				int x;
				read(x);
				val[x]=0;
			}
		}
		for(int i=1;i<=n;i++){
			tt[i]=val[i];
			if(tt[i]<0)tt[i]=-tt[i];
			if(tt[i]>0&&tt[i]<=n)v[tt[i]].push_back(i);
			else tt[i]=-1;
			cout<<val[i]<<' ';
		}
		puts("\n-------");
		int ans=0;
		for(int i=1;i<=n;i++){
			if(!vis[i]){
				if(tt[i]<0){
					cout<<i<<"::\n";
					ts[i]=val[i];
					bfs(i,val[i]);
					ans+=cnt;
					bfs2(i);
					rev(i);
				}
			}
		}
		for(int i=1;i<=n;i++){
			if(!vis[i]){
				cout<<i<<"::\n";
				int x=INF;
				bfs(i,0);
//				if(ts[i]==0)x=Min(x,cnt);
				rev(i);
				bfs(i,F);
//				if(ts[i]==F)x=Min(x,cnt);
				rev(i);
				bfs(i,T);
				if(ts[i]==T)x=Min(x,cnt);
				cout<<ts[i]<<":\n";
				bfs2(i);
				rev(i);
				ans+=x;
			}
		}
		printf("%d\n",ans);
		//��ⲻ���У�(__________);
		//��ⲻ���У�(__________);
		//��ⲻ���У�(__________);
		//��ⲻ���У�(__________);
		//��ⲻ���У�(__________);
	}
	return 0;
}
*/
/*������ 
#define T (n+1)
#define F (n+2)
#define U 0
int cc,tt;
int n,m;
int val[N];
int t[N],las[N],fir[N],c[N],num=1;
void add(int u,int v,int w){
//cout<<u<<"     "<<v<<' '<<w<<endl;
t[++num]=v;las[num]=fir[u];fir[u]=num;c[num]=w;
t[++num]=u;las[num]=fir[v];fir[v]=num;c[num]=w;
//cout<<num<<','<<(num^1)<<endl;
//cout<<u<<"<->"<<v<<endl;
}
int vis[N];
int cnt=0;
int sm=0;
int fl;
void dfs(int u,int cm){
	vis[u]=1;
	cnt++;
	if(val[u]==0)fl=1;
	for(int i=fir[u];i;i=las[i]){
		if(i==(cm^1))continue;
		sm+=c[i];
		if(vis[t[i]]){
			if(sm<0&&((-sm)&1)==1){
//				cout<<i<<":"<<cm<<','<<(cm^1)<<endl;
//				cout<<u<<"->"<<t[i]<<endl;
				fl=1;
			}
		}
		else{
			dfs(t[i],i);
		}
		sm-=c[i];
	}
}
int main(){
	freopen("tribool2.in","r",stdin);
	freopen("tribool.out","w",stdout);
	read(cc);
	read(tt);
	while(tt--){
		read(n);
		read(m);
//		for(int i=1;i<=(2*n+3);i++)fa[i]=i;
		for(int i=1;i<=n;i++)val[i]=i,vis[i]=0,fir[i]=0;
		num=1;
		//��ⲻ��գ�(__________);
		//��ⲻ��գ�(__________);
		//��ⲻ��գ�(__________);
		//��ⲻ��գ�(__________);
		//��ⲻ��գ�(__________);
		for(int i=1;i<=m;i++){
			char c=getchar();
			while(c!='-'&&c!='+'&&c!='T'&&c!='F'&&c!='U')c=getchar();
			if(c=='+'){
				int x,y;
				read(x);
				read(y);
				val[x]=val[y];
			}
			else if(c=='-'){
				int x,y;
				read(x);
				read(y);
				val[x]=-val[y];
			}
			else if(c=='T'){
				int x;
				read(x);
				val[x]=T;
			}
			else if(c=='F'){
				int x;
				read(x);
				val[x]=F;
			}else if(c=='U'){
				int x;
				read(x);
				val[x]=0;
			}
		}
		for(int i=1;i<=n;i++){
			int x=val[i];
			int fh=0;
			if(x<0)x=-x,fh=-1;
			if(x>0&&x<=n)add(x,i,fh);
//			cout<<val[i]<<' ';
		}
//		puts("\n-------");
		int ans=0;
		for(int i=1;i<=n;i++){
			if(!vis[i]){
//				cout<<i<<"::\n";
				fl=0;
				cnt=0;
				dfs(i,0);
				if(fl)ans+=cnt;
				
			}
		}
		printf("%d\n",ans);
		//��ⲻ���У�(__________);
		//��ⲻ���У�(__________);
		//��ⲻ���У�(__________);
		//��ⲻ���У�(__________);
		//��ⲻ���У�(__________);
	}
	return 0;
}
*/ 
