#include<bits/stdc++.h>
using namespace std;
#define N 100005
#define INF 1145141919
template<typename T>
void read(T&x){
x=0;/*T fl=1;*/char c=getchar();while(c<'0'||'9'<c){/*if(c=='-')fl=-1;*/c=getchar();}
while('/'<c&&c<':'){x=x*10+(c^'0');c=getchar();}/*x*=fl;*/}
template<typename T>T Max(T x,T y){return (x<y?y:x);}
template<typename T>T Min(T x,T y){return (x<y?x:y);}
int c,n,m,q;
int xy[N];
int yy[N];
int x[N],y[N];
vector<int>ans;
vector<int> v1,v2;
int fl;
void dfs2(int u){
	if(fl==1)return ;
	if(v1.size()<v2.size())return;
	if(u==n+1){
		if(v1.size()!=v2.size())return;
		int fh=0;
//		for(int i=0;i<(int)v1.size();i++){
//			cout<<v1[i]<<' ';
//		}
//		puts("");
//		for(int i=0;i<(int)v1.size();i++){
//			cout<<v2[i]<<' ';
//		}
//		puts("\n-----");
		for(int i=0;i<(int)v1.size();i++){
			if(v1[i]==v2[i])return ;
			if(fh==0){
				if(v1[i]<v2[i])fh=-1;
				else fh=1; 
			}
			else if((v1[i]-v2[i]>0?1:-1)!=fh)return ;
		}
		fl=1;
		return ;
	}
	for(int i=1;i<=n;i++){
		v2.push_back(y[u]);
		dfs2(u+1);
	}
	for(int i=1;i<=n;i++)v2.pop_back();
}
void dfs(int u){
	if(fl==1)return ;
	if(u==n+1){
		dfs2(1);
		return ;
	}
	for(int i=1;i<=n;i++){
		v1.push_back(x[u]);
		dfs(u+1); 
	}
	for(int i=1;i<=n;i++)v1.pop_back();
}
int main(){
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
	read(c);
	read(n);
	read(m);
	read(q);
	for(int i=1;i<=n;i++)read(xy[i]),x[i]=xy[i];
	for(int i=1;i<=n;i++)read(yy[i]),y[i]=yy[i];
	dfs(1);
	ans.push_back(fl);
	while(q--){
		int kx,ky;
		read(kx),read(ky);
		for(int i=1;i<=n;i++)x[i]=xy[i];
		for(int i=1;i<=n;i++)y[i]=yy[i];
		while(kx--){
			int id,k;
			read(id),read(k);
			x[id]=k;
		}
		while(ky--){
			int id,k;
			read(id),read(k);
			y[id]=k;
		}
		fl=0;
		dfs(1);
		ans.push_back(fl);
	}
	for(auto i:ans){
		putchar('0'+i);
	}
	return 0;
}
/*
3 3 3 3
8 6 9
1 7 4
1 0
3 0
0 2
1 8
3 5
1 1
2 8
1 7

*/ 
