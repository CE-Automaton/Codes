#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[39],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[tp++]=x%10;while(x/=10);
        while(tp)putchar(stk[--tp]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 400005;
vector<pair<int,int>> g[N];
struct{int x,y,v;} c[N];
int f[N][2];
int n,m,K,d;

vector<int> ha;
int h(int x){return lower_bound(ha.begin(),ha.end(),x)-ha.begin();}

class segtree{
    private:
        int tr[N*4],tag[N*4];
        void modify(int u,int v){
            tr[u] += v;
            tag[u] += v;
        }
        void pushup(int u){tr[u] = max(tr[u<<1],tr[u<<1|1]);}
        void pushdown(int u){
            if(tag[u]){
                modify(u<<1,tag[u]);
                modify(u<<1|1,tag[u]);
                tag[u] = 0;
            }
        }
    public:
        void modify(int u,int l,int r,int L,int R,int v){
            if(l>=L&&r<=R){
                modify(u,v);
                return;
            }
            pushdown(u);
            int mid = (l+r)>>1;
            if(L<=mid)
                modify(u<<1,l,mid,L,R,v);
            if(R>mid)
                modify(u<<1|1,mid+1,r,L,R,v);
            pushup(u);
        }
        int query(int u,int l,int r,int L,int R){
            if(l>=L&&r<=R)
                return tr[u];
            pushdown(u);
            int mid = (l+r)>>1;
            if(L<=mid&&R>mid)
                return max(query(u<<1,l,mid,L,R),query(u<<1|1,mid+1,r,L,R));
            if(L<=mid)
                return query(u<<1,l,mid,L,R);
            return query(u<<1|1,mid+1,r,L,R);
        }
        void clear(){
            memset(tr,0,sizeof(tr));
            memset(tag,0,sizeof(tag));
        }
}tr;

signed main(){
    freopen("run.in","r",stdin);
    freopen("run.out","w",stdout);
    int C = in,T = in;
    while(T--){
        n = in,m = in,K = in,d = in;
        ha.clear();
        for(int k=1;k<=m;k++){
            c[k].x = in,c[k].y = in,c[k].v = in;
            auto add = [&](int x){if(x>=0&&x<=n)ha.push_back(x);};
            add(c[k].x-1);
            add(c[k].x);
            add(c[k].x-c[k].y);
            add(c[k].x-c[k].y+1);
        }
        sort(ha.begin(),ha.end());
        ha.erase(unique(ha.begin(),ha.end()),ha.end());
        n = ha.size();
        for(int k=0;k<n;k++)
            g[k].clear();
        for(int k=1;k<=m;k++)
            if(c[k].x-c[k].y+1>=1)
                g[h(c[k].x)].emplace_back(h(c[k].x-c[k].y+1),c[k].v);
        tr.clear();
        for(int k=0;k<n;k++){
            for(auto x:g[k])
                tr.modify(1,0,n-1,1,x.first,x.second);
            tr.modify(1,0,n-1,k,k,ha[k]*d+(k>0?f[k-1][0]:0));
            int j = lower_bound(ha.begin(),ha.end(),ha[k]-K+1)-ha.begin();
            if(j<0)
                j = 0;
            f[k][1] = tr.query(1,0,n-1,j,k)-ha[k]*d-d;
            if(k)
                f[k][0] = max(f[k-1][1],f[k-1][0]);
        }
        out(max(f[n-1][0],f[n-1][1]),'\n');
    }
    return 0;
}