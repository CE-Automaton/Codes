#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 3005;
string mx[N],mn[N];
int n,m;

int main(){
    freopen("dict.in","r",stdin);
    freopen("dict.out","w",stdout);
    cin >> n >> m;
    for(int k=1;k<=n;k++){
        cin >> mn[k];
        sort(mn[k].begin(),mn[k].end());
        mx[k] = mn[k];
        reverse(mx[k].begin(),mx[k].end());
    }
    for(int k=1;k<=n;k++){
        bool flag = true;
        for(int j=1;j<=n;j++)
            if(k!=j&&mn[k]>=mx[j]){
                flag = false;
                break;
            }
        putchar(flag?'1':'0');
    }
    return 0;
}