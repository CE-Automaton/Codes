#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[39],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[tp++]=x%10;while(x/=10);
        while(tp)putchar(stk[--tp]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 200005;
vector<pair<int,int>> g[N];
int c[N],p[N],v[N];
int n,m;

bool dfs(int u){
    if(v[u]&&v[u]!=c[u])
        return false;
    for(auto tmp:g[u]){
        int v = tmp.first,w = tmp.second;
        int col = c[u];
        if(w&&col<3)
            col ^= 3;
        if(c[v]){
            if(c[v]!=col)
                return false;
            continue;
        }
        c[v] = col;
        if(!dfs(v))
            return false;
    }
    return true;
}

void clear(int u){
    c[u] = 0;
    for(auto tmp:g[u])
        if(c[tmp.first])
            clear(tmp.first);
}

int main(){
    freopen("tribool.in","r",stdin);
    freopen("tribool.out","w",stdout);
    int C = in,T = in;
    while(T--){
        n = in,m = in;
        for(int k=0;k<=n+m;k++)
            g[k].clear();
        memset(c,0,sizeof(c));
        memset(v,0,sizeof(v));
        int idx = n;
        for(int k=0;k<=n;k++)
            p[k] = k;
        for(int k=1;k<=m;k++){
            char op = getchar();
            while(op!='T'&&op!='F'&&op!='U'&&op!='+'&&op!='-')
                op = getchar();
            if(op=='+'){
                int x = in,y = in;
                p[x] = ++idx;
                g[p[y]].emplace_back(p[x],0);
                g[p[x]].emplace_back(p[y],0);
            }
            else if(op=='-'){
                int x = in,y = in;
                p[x] = ++idx;
                g[p[y]].emplace_back(p[x],1);
                g[p[x]].emplace_back(p[y],1);
            }
            else{
                int x = in;
                p[x] = ++idx;
                if(op=='T')
                    v[idx] = 1;
                else if(op=='F')
                    v[idx] = 2;
                else if(op=='U')
                    v[idx] = 3;
            }
        }
        for(int k=1;k<=n;k++){
            g[k].emplace_back(p[k],0);
            g[p[k]].emplace_back(k,0);
        }
        for(int k=1;k<=idx;k++)
            if(!c[k])
                for(int j:{1,2,3}){
                    clear(k);
                    c[k] = j;
                    if(dfs(k))
                        break;
                }
        int ans = 0;
        for(int k=1;k<=n;k++)
            if(c[k]==3)
                ans++;
        out(ans,'\n');
    }
    return 0;
}