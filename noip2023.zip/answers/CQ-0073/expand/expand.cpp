#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

namespace fastio{
    struct{template<typename T>operator T(){
        T x=0;char f=0,c=getchar();
        while(c<'0'||c>'9'){if(c=='-')f=1;c=getchar();}
        while(c>='0'&&c<='9'){x=x*10+(c^48);c=getchar();}
        return f?-x:x;
    }}in;int stk[39],tp;
    template<typename T>void out(T x,char c=0){
        if(x<0)putchar('-'),x=-x;
        do stk[tp++]=x%10;while(x/=10);
        while(tp)putchar(stk[--tp]^48);
        if(c)putchar(c);
    }
}using fastio::in;using fastio::out;

const int N = 500005;
int x[N],y[N],X[N],Y[N];
int C,n,m,q;

bool check(){
    if(x[1]<y[1]){
        for(int k=1,j=1;k<=n;k++){
            if(x[k]<y[j]){
                k++;
                if(y[j+1]>=y[j]&&j<m)
                    j++;
            }
            else
                return false;
        }
        return true;
    }
    for(int k=1,j=1;k<=n;k++){
        if(x[k]>y[j]){
            k++;
            if(y[j+1]<=y[j]&&j<m)
                j++;
        }
        else
            return false;
    }
    return true;
}

int main(){
    freopen("expand.in","r",stdin);
    freopen("expand.out","w",stdout);
    C = in,n = in,m = in,q = in;
    for(int k=1;k<=n;k++)
        X[k] = x[k] = in;
    for(int k=1;k<=m;k++)
        Y[k] = y[k] = in;
    putchar(check()?'1':'0');
    while(q--){
        int kx = in,ky = in;
        while(kx--){
            int p = in,v = in;
            x[p] = v;
        }
        while(ky--){
            int p = in,v = in;
            y[p] = v;
        }
        putchar(check()?'1':'0');
        for(int k=1;k<=n;k++)
            x[k] = X[k],y[k] = Y[k];
    }
    return 0;
}