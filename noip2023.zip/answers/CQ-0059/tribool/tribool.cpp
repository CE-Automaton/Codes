#include <bits/stdc++.h>
using namespace std;
#define rg register
#define il inline

namespace FastIO {
    const int LEN = 1 << 20;

    static char ibuf[LEN], *iS = ibuf, *iT = ibuf;
    #define getchar() (iS == iT ? iT = (iS = ibuf) + fread(ibuf, 1, LEN, stdin), iS == iT ? EOF : *iS++ : *iS++)
    il int read() { return 0; }
    template<typename T, typename...Arg>
    il int read(T& val, Arg&...arg) {
        if (is_same<T, char>::value) {
            val = getchar();
            while (val == ' ' || val == '\n' || val == '\r') val = getchar();
            if (val == EOF) return 0;
        } else {
            val = 0;
            rg char x = getchar();
            rg int g = 1;
            while (x < '0' || x > '9') { if (x == EOF) return 0; g = (x == '-' ? -1 : g), x = getchar(); }
            while (x >= '0' && x <= '9') val = (val << 1) + (val << 3) + (x ^ 48), x = getchar();
            val *= g;
        }
        return read(arg...) + 1;
    }

    static char obuf[LEN], *iP = obuf;
    #define putchar(x) (iP - obuf < LEN ? (*iP++ = x) : (fwrite(obuf, iP - obuf, 1, stdout), iP = obuf, *iP++ = x))
    il void write() { return; }
    il void write(int val) { if (val > 9) write(val / 10); putchar(val % 10 ^ 48); }
    il void write(char val) { putchar(val); }
    template<typename T, typename...Arg>
    il void write(T val, Arg...arg) {
        write(val);
        write(arg...);
    }
}
using namespace FastIO;

int CSDBH, T, n, m, fa[200005], id[200005], res;
char c;

il int FindSet(int x) { return fa[x] == x ? x : fa[x] = FindSet(fa[x]); }
il void UnionSet(int x, int y) { fa[FindSet(x)] = FindSet(y); }

signed main() {
    freopen("tribool.in", "r", stdin);
    freopen("tribool.out", "w", stdout);
    read(CSDBH, T);
    while (T--) {
        res = 0;
        read(n, m);
        for (rg int i = 1; i <= n; i++) id[i] = i, id[i + n] = i + n;
        for (rg int i = 0; i <= 2 * n + 2; i++) fa[i] = i;
        for (rg int i = 1, x, y; i <= m; i++) {
            read(c);
            if (c != '-' && c != '+') {
                read(x);
                id[x] = (c == 'U' ? 0 : c == 'T' ? 2 * n + 1 : 2 * n + 2);
                id[x + n] = (c == 'U' ? 0 : c == 'T' ? 2 * n + 2 : 2 * n + 1);
            } else {
                read(x, y);
                if (c == '+') id[x] = id[y], id[x + n] = id[y + n];
                else if (x != y) id[x] = id[y + n], id[x + n] = id[y];
                else swap(id[x], id[x + n]);
            }
        }
        for (rg int i = 1; i <= n; i++) {
            UnionSet(i, id[i]), UnionSet(i + n, id[i + n]);
        }
        for (rg int i = 1; i <= n; i++) {
            if (FindSet(i) == FindSet(i + n)) res++;
        }
        write(res, '\n');
    }
    fwrite(obuf, iP - obuf, 1, stdout);
    return 0;
}