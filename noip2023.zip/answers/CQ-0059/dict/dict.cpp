#include <bits/stdc++.h>
using namespace std;
#define rg register
#define il inline

namespace FastIO {
    const int LEN = 1 << 20;

    static char ibuf[LEN], *iS = ibuf, *iT = ibuf;
    #define getchar() (iS == iT ? iT = (iS = ibuf) + fread(ibuf, 1, LEN, stdin), iS == iT ? EOF : *iS++ : *iS++)
    il int read() { return 0; }
    template<typename T, typename...Arg>
    il int read(T& val, Arg&...arg) {
        if (is_same<T, char>::value) {
            val = getchar();
            while (val == ' ' || val == '\n' || val == '\r') val = getchar();
            if (val == EOF) return 0;
        } else {
            val = 0;
            rg char x = getchar();
            rg int g = 1;
            while (x < '0' || x > '9') { if (x == EOF) return 0; g = (x == '-' ? -1 : g), x = getchar(); }
            while (x >= '0' && x <= '9') val = (val << 1) + (val << 3) + (x ^ 48), x = getchar();
            val *= g;
        }
        return read(arg...) + 1;
    }

    static char obuf[LEN], *iP = obuf;
    #define putchar(x) (iP - obuf < LEN ? (*iP++ = x) : (fwrite(obuf, iP - obuf, 1, stdout), iP = obuf, *iP++ = x))
    il void write() { return; }
    il void write(int val) { if (val > 9) write(val / 10); putchar(val % 10 ^ 48); }
    il void write(char val) { putchar(val); }
    template<typename T, typename...Arg>
    il void write(T val, Arg...arg) {
        write(val);
        write(arg...);
    }
}
using namespace FastIO;

int n, m, t[3005][26], ifs[3005], ils[3005];
char s[3005][3005];

signed main() {
    freopen("dict.in", "r", stdin);
    freopen("dict.out", "w", stdout);
    read(n, m);
    for (rg int i = 1; i <= n; i++) {
        for (rg int j = 1; j <= m; j++) read(s[i][j]), t[i][s[i][j] - 'a']++;
    }
    for (rg int i = 1; i <= n; i++) {
        ifs[i] = -1;
        for (rg int j = 0; j < 26; j++) if (t[i][j]) {
            if (ifs[i] == -1) ifs[i] = j;
            ils[i] = j;
        }
    }
    for (rg int i = 1; i <= n; i++) {
        bool fg = 1;
        for (rg int j = 1; j <= n; j++) if (i != j) {
            if (ifs[i] >= ils[j]) {
                fg = 0;
                break;
            }
        }
        write(fg ? '1' : '0');
    }
    fwrite(obuf, iP - obuf, 1, stdout);
    return 0;
}