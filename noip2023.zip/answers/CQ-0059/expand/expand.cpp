#include <bits/stdc++.h>
using namespace std;
#define rg register
#define il inline

namespace FastIO {
    const int LEN = 1 << 20;

    static char ibuf[LEN], *iS = ibuf, *iT = ibuf;
    #define getchar() (iS == iT ? iT = (iS = ibuf) + fread(ibuf, 1, LEN, stdin), iS == iT ? EOF : *iS++ : *iS++)
    il int read() { return 0; }
    template<typename T, typename...Arg>
    il int read(T& val, Arg&...arg) {
        if (is_same<T, char>::value) {
            val = getchar();
            while (val == ' ' || val == '\n' || val == '\r') val = getchar();
            if (val == EOF) return 0;
        } else {
            val = 0;
            rg char x = getchar();
            rg int g = 1;
            while (x < '0' || x > '9') { if (x == EOF) return 0; g = (x == '-' ? -1 : g), x = getchar(); }
            while (x >= '0' && x <= '9') val = (val << 1) + (val << 3) + (x ^ 48), x = getchar();
            val *= g;
        }
        return read(arg...) + 1;
    }

    static char obuf[LEN], *iP = obuf;
    #define putchar(x) (iP - obuf < LEN ? (*iP++ = x) : (fwrite(obuf, iP - obuf, 1, stdout), iP = obuf, *iP++ = x))
    il void write() { return; }
    il void write(int val) { if (val > 9) write(val / 10); putchar(val % 10 ^ 48); }
    il void write(char val) { putchar(val); }
    template<typename T, typename...Arg>
    il void write(T val, Arg...arg) {
        write(val);
        write(arg...);
    }
}
using namespace FastIO;

int CSDBH, n, m, Q, x[500005], y[500005], ix[500005], iy[500005];
bool dp[22500][22500];

signed main() {
    freopen("expand.in", "r", stdin);
    freopen("expand.out", "w", stdout);
    read(CSDBH, n, m, Q);
    for (rg int i = 1; i <= n; i++) read(x[i]);
    for (rg int i = 1; i <= m; i++) read(y[i]);
    if (x[1] > y[1]) {
        for (rg int i = 1; i <= n; i++) ix[i] = x[i];
        for (rg int i = 1; i <= m; i++) iy[i] = y[i];
    } else {
        for (rg int i = 1; i <= n; i++) ix[i] = -x[i];
        for (rg int i = 1; i <= m; i++) iy[i] = -y[i];
    }
    dp[n][m] = (ix[n] > iy[m]);
    for (rg int i = n; i >= 1; i--) for (rg int j = m - (i == n); j >= 1; j--) dp[i][j] = (ix[i] > iy[j] && (dp[i + 1][j] || dp[i][j + 1]));
    write(dp[1][1] ? '1' : '0');
    while (Q--) {
        int kx, ky;
        read(kx, ky);
        for (rg int i = 1; i <= n; i++) ix[i] = x[i];
        for (rg int i = 1; i <= m; i++) iy[i] = y[i];
        for (rg int i = 1, ax, vx; i <= kx; i++) read(ax, vx), ix[ax] = vx;
        for (rg int i = 1, ay, vy; i <= ky; i++) read(ay, vy), iy[ay] = vy;
        if (ix[1] < iy[1]) {
            for (rg int i = 1; i <= n; i++) ix[i] = -ix[i];
            for (rg int i = 1; i <= m; i++) iy[i] = -iy[i];
        }
        dp[n][m] = (ix[n] > iy[m]);
        for (rg int i = n; i >= 1; i--) for (rg int j = m - (i == n); j >= 1; j--) dp[i][j] = (ix[i] > iy[j] && (dp[i + 1][j] || dp[i][j + 1] || dp[i + 1][j + 1]));
        write(dp[1][1] ? '1' : '0');
    }
    fwrite(obuf, iP - obuf, 1, stdout);
    return 0;
}