#include <bits/stdc++.h>
#define int long long
using namespace std;
#define rg register
#define il inline

namespace FastIO {
    const int LEN = 1 << 20;

    static char ibuf[LEN], *iS = ibuf, *iT = ibuf;
    #define getchar() (iS == iT ? iT = (iS = ibuf) + fread(ibuf, 1, LEN, stdin), iS == iT ? EOF : *iS++ : *iS++)
    il int read() { return 0; }
    template<typename T, typename...Arg>
    il int read(T& val, Arg&...arg) {
        if (is_same<T, char>::value) {
            val = getchar();
            while (val == ' ' || val == '\n' || val == '\r') val = getchar();
            if (val == EOF) return 0;
        } else {
            val = 0;
            rg char x = getchar();
            rg int g = 1;
            while (x < '0' || x > '9') { if (x == EOF) return 0; g = (x == '-' ? -1 : g), x = getchar(); }
            while (x >= '0' && x <= '9') val = (val << 1) + (val << 3) + (x ^ 48), x = getchar();
            val *= g;
        }
        return read(arg...) + 1;
    }

    static char obuf[LEN], *iP = obuf;
    #define putchar(x) (iP - obuf < LEN ? (*iP++ = x) : (fwrite(obuf, iP - obuf, 1, stdout), iP = obuf, *iP++ = x))
    il void write() { return; }
    il void write(int val) { if (val > 9) write(val / 10); putchar(val % 10 ^ 48); }
    il void write(char val) { putchar(val); }
    template<typename T, typename...Arg>
    il void write(T val, Arg...arg) {
        write(val);
        write(arg...);
    }
}
using namespace FastIO;

int CSDBH, T, n, m, K, D, res, dp[2][100005];
struct node { int x, y, z; } a[100005];

signed main() {
    freopen("run.in", "r", stdin);
    freopen("run.out", "w", stdout);
    read(CSDBH, T);
    while (T--) {
        res = 0;
        read(n, m, K, D);
        for (rg int i = 1; i <= m; i++) read(a[i].x, a[i].y, a[i].z);
        sort(a + 1, a + m + 1, [](node x, node y) { return x.x < y.x; });
        dp[0][0] = 0;
        for (rg int i = 1; i <= K; i++) dp[0][i] = -0x3f3f3f3f3f3f;
        for (rg int i = 1; i <= m; i++) {
            dp[i & 1][0] = 0;
            for (rg int j = 0; j <= K; j++) if (a[i].x != a[i - 1].x || j == 0) dp[i & 1][0] = max(dp[i & 1][0], dp[i - 1 & 1][j]);
            for (rg int j = 1; j <= K; j++) {
                if (j - (a[i].x - a[i - 1].x) >= 0) dp[i & 1][j] = dp[i - 1 & 1][j - (a[i].x - a[i - 1].x)] - D * (a[i].x - a[i - 1].x);
                else dp[i & 1][j] = dp[i & 1][0] - D * j;
                if (j >= a[i].y) dp[i & 1][j] += a[i].z;
            }
        }
        for (rg int i = 0; i <= K; i++) res = max(res, dp[m & 1][i]);
        write(res, '\n');
    }
    fwrite(obuf, iP - obuf, 1, stdout);
    return 0;
}