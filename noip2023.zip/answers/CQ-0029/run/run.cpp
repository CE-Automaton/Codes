#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cassert>
#include<vector>
#define int long long
const int Q=100005;
const int INF=1ll<<60;
typedef long long ll;
#define rg register int
#define cint const register int
char ibuf[1<<21],*IP1=ibuf,*IP2=ibuf;
#define gc() (IP1==IP2&&(IP2=(IP1=ibuf)+fread(ibuf,1,1<<21,stdin),IP1==IP2)?EOF:*IP1++)
#define pc putchar
inline bool ig(const char c){return c>=48&&c<=57;}
inline void read(rg&oi){char c;rg f=1,res=0;while(c=gc(),!ig(c)&&c^'-');c^'-'?res=(c^48):f=-1;while(c=gc(),ig(c))res=res*10+(c^48);oi=f*res;}
inline void print(rg oi){char io[23];rg l=0;if(oi<0)pc('-'),oi=~oi+1;do io[++l]=oi%10+48;while(oi/=10);for(;l;pc(io[l--]));}
inline void write(cint oi,const char c){print(oi);pc(c);}char _ST_;
inline void Max(rg&x,cint y){(x<y)&&(x=y);}
inline int max(cint x,cint y){return x>y?x:y;}
inline int min(cint x,cint y){return x<y?x:y;}
int CC,T,n,m,K,D,b[Q],Mx;
struct oper{int l,r,v;oper()=default;
oper(cint l,cint r,cint v):l(l),r(r),v(v){}};oper a[Q];
std::vector<oper>op[Q];
int tg;
//the tag of interval move
struct node{
//(l,r,v):f_l=v,f_{l+1}=v-D,...,f_{r}=v-(r-l+1)*D
	int l,r,v;node()=default;
//p.s.:the real l,r is l+tg,r+tg
	node(cint l,cint r,cint v):l(l),r(r),v(v){}
};
namespace Splay{
	struct sply{int ch[2],fa,mx,tg;node v;}t[Q*6];int tot,rt;
	inline void upd(cint x){
	if(x)t[x].mx=max(t[x].v.v,max(t[t[x].ch[0]].mx,t[t[x].ch[1]].mx));}
	inline bool islr(cint x){return t[t[x].fa].ch[0]^x;}
	inline void rot(cint x){
		cint y=t[x].fa,z=t[y].fa,l=islr(x),r=l^1;
		t[z].ch[islr(y)]=x;t[x].fa=z;
		t[y].ch[l]=t[x].ch[r];t[t[x].ch[r]].fa=y;
		t[x].ch[r]=y;t[y].fa=x;upd(y);
	}
	inline void psh(cint x,cint y){if(x)t[x].tg+=y,t[x].v.v+=y,t[x].mx+=y;}
	inline void spd(cint x){
	if(x&&t[x].tg)psh(t[x].ch[0],t[x].tg),psh(t[x].ch[1],t[x].tg),t[x].tg=0;}
	inline void spds(cint x){if(t[x].fa)spds(t[x].fa);spd(x);}
	inline void splay(cint x,cint g){
		if(!x)return;if(!g)rt=x;spds(x);
		for(rg y=t[x].fa;y^g;rot(x),y=t[x].fa)
		if(t[y].fa^g)rot((islr(x)^islr(y))?x:y);upd(x);
	}
	inline void init(){
		t[0]=(sply){0,0,0,-INF,-INF,node(0,0,-INF)};for(rg i=1;i<=tot;++i)
		t[i]=(sply){0,0,0,0,0,node(0,0,0)};tot=rt=1;tg=0;
	}
	inline int Gpos(cint x,cint y){
		if(!x)return 0;spd(x);if(t[x].v.l+tg<=y&&t[x].v.r+tg>=y)return x;
		if(t[x].v.l+tg<=y){cint res=Gpos(t[x].ch[1],y);if(!res)return x;return res;}
		return Gpos(t[x].ch[0],y);
	}
	inline int insert(rg&x,const node y,cint fa){
		if(!x)return x=++tot,t[x]=(sply){0,0,fa,y.v,0,y},x;
		spd(x);cint res=(t[x].v.l+tg<=y.l+tg)?
		insert(t[x].ch[1],y,x):insert(t[x].ch[0],y,x);return upd(x),res;
	}
	inline void mdy(cint p,cint v){
		cint x=Gpos(rt,p);if(!(t[x].v.l+tg<=p&&t[x].v.r+tg>=p))return;
		if(t[x].v.l+tg==p){splay(x,0);t[x].v.v+=v;psh(t[x].ch[1],v);upd(x);return;}
		cint rr=t[x].v.r;t[x].v.r=p-1-tg;splay(x,0);
		cint y=insert(rt,node(p-tg,rr,t[x].v.v-(p-t[x].v.l-tg)*D),0);
		splay(y,0);t[y].v.v+=v;psh(t[y].ch[1],v);upd(y);
	}
	inline void updx(cint i){
		cint k=b[i]-b[i-1],mx=t[rt].mx;if(k>K){
			rt=++tot;t[rt]=(sply){0,0,0,mx,0,node(0,K,mx)};tg=0;
			for(auto o:op[i])mdy(o.l,o.v);return;
		}
		cint rp=Gpos(rt,K-k);
		t[rp].v.r=min(t[rp].v.r,K-k-tg);splay(rp,0);
		t[t[rp].ch[1]].fa=0;t[rp].ch[1]=0;upd(rp);psh(rp,-k*D);tg+=k;
		rg lp=rt;for(;t[lp].ch[0];spd(lp),lp=t[lp].ch[0]);
		spd(lp);t[lp].ch[0]=++tot;
		t[tot]=(sply){0,0,lp,mx,0,node(0-tg,k-1-tg,mx)};
		for(rg o=lp;o;o=t[o].fa)upd(o);
		lp=tot;splay(lp,0);for(auto o:op[i])mdy(o.l,o.v);
	}
}
char _ED_;signed main(){
//system("fc run6.ans run.out");return 0;
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
//	fprintf(stderr,"static memory:%.6lf MB\n",(&_ST_-&_ED_)/1024./1024.);
	read(CC);read(T);for(;T--;){
		read(n);read(m);read(K);read(D);Mx=0;
		for(rg i=1;i<=m;++i)read(a[i].r),read(a[i].l),read(a[i].v),b[++Mx]=a[i].r;
		std::sort(b+1,b+1+Mx);Mx=std::unique(b+1,b+1+Mx)-b-1;
		for(rg i=1;i<=Mx;++i)op[i].clear();
		for(rg i=1;i<=m;++i)a[i].r=std::lower_bound(b+1,b+1+Mx,a[i].r)-b,
		op[a[i].r].emplace_back(a[i]);Splay::init();
		for(rg i=1;i<=Mx;++i)Splay::updx(i);
		write(Splay::t[Splay::rt].mx,'\n');
	}
	return 0;
}
