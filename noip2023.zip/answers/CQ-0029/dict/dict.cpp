#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cassert>
#include<string>
#include<iostream>
const int Q=3005;
const int INF=1<<30;
typedef long long ll;
#define rg register int
#define cint const register int
//char ibuf[1<<21],*IP1=ibuf,*IP2=ibuf;
//#define gc() (IP1==IP2&&(IP2=(IP1=ibuf)+fread(ibuf,1,1<<21,stdin),IP1==IP2)?EOF:*IP1++)
#define gc getchar
#define pc putchar
inline bool ig(const char c){return c>=48&&c<=57;}
inline void read(rg&oi){char c;rg f=1,res=0;while(c=gc(),!ig(c)&&c^'-');c^'-'?res=(c^48):f=-1;while(c=gc(),ig(c))res=res*10+(c^48);oi=f*res;}
inline void print(rg oi){char io[23];rg l=0;if(oi<0)pc('-'),oi=~oi+1;do io[++l]=oi%10+48;while(oi/=10);for(;l;pc(io[l--]));}
inline void write(cint oi,const char c){print(oi);pc(c);}char _ST_;
int n,m,cn[Q];
std::string mn[Q],mx[Q];
char _ED_;int main(){
//system("fc dict4.ans dict.out");return 0;
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
//	fprintf(stderr,"static memory:%.6lf MB\n",(&_ST_-&_ED_)/1024./1024.);
	std::ios::sync_with_stdio(false);
	std::cin.tie(0);std::cin>>n>>m;
	for(rg i=1;i<=n;++i){
		std::string s;std::cin>>s;
		for(rg j=0;j<(int)s.length();++j)++cn[s[j]-'a'];
		for(rg j=0;j<26;++j)for(rg k=0;k<cn[j];++k)mn[i]+=j+'a';
		for(rg j=25;j>=0;--j)for(rg k=0;k<cn[j];++k)mx[i]+=j+'a';
		for(rg j=0;j<26;++j)cn[j]=0;
	}
	if(n==1)return write(1,'\n'),0;
	std::string m1=mx[1],m2=mx[2];rg p=1;
	if(mx[1]<mx[2])m1=mx[2],m2=mx[1],p=2;
	for(rg i=3;i<=n;++i){
		if(m1>mx[i])m2=m1,p=i,m1=mx[i];
		else if(m2>mx[i])m2=mx[i];
	}
	for(rg i=1;i<=n;++i)pc('0'+((p==i?m2:m1)>mn[i]));
	pc('\n');return 0;
}
