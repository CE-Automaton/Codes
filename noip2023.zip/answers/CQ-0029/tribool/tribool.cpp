#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cassert>
const int Q=100005;
const int INF=1<<30;
typedef long long ll;
#define rg register int
#define cint const register int
char ibuf[1<<21],*IP1=ibuf,*IP2=ibuf;
#define gc() (IP1==IP2&&(IP2=(IP1=ibuf)+fread(ibuf,1,1<<21,stdin),IP1==IP2)?EOF:*IP1++)
#define pc putchar
inline bool ig(const char c){return c>=48&&c<=57;}
inline void read(rg&oi){char c;rg f=1,res=0;while(c=gc(),!ig(c)&&c^'-');c^'-'?res=(c^48):f=-1;while(c=gc(),ig(c))res=res*10+(c^48);oi=f*res;}
inline void print(rg oi){char io[23];rg l=0;if(oi<0)pc('-'),oi=~oi+1;do io[++l]=oi%10+48;while(oi/=10);for(;l;pc(io[l--]));}
inline void write(cint oi,const char c){print(oi);pc(c);}char _ST_;
inline int Abs(cint x){return x>0?x:-x;}
int CC,T,n,m,N,id[Q],res,s[Q];bool vst[Q],is[Q];
struct node{int x,y;node()=default;node(cint x,cint y):x(x),y(y){}};node a[Q];
inline int Gid(const char c){
	if(c=='T')return 0;if(c=='F')return 1;if(c=='U')return 2;
	if(c=='+')return 3;if(c=='-')return 4;return-1;
}
inline node Grev(const node&x){
	if(x.x)return node(x.x,x.y^1);if(x.y==0)return node(0,1);
	if(x.y==1)return node(0,0);return node(0,2);
}
namespace dsu{
	int prt[Q];inline void init(cint N){for(rg i=1;i<=N;++i)prt[i]=i;}
	inline int Grt(cint x){return prt[x]^x?prt[x]=Grt(prt[x]):x;}
	inline void mg(cint x,cint y){cint rx=Grt(x),ry=Grt(y);if(rx^ry)prt[rx]=ry;}
}
int h[Q],ce;struct Edge{int to,nxt;}e[Q<<1];
inline void edge(cint x,cint y){e[++ce]=(Edge){y,h[x]};h[x]=ce;}
inline void gph(cint x,cint y){edge(x,y);edge(y,x);}
int dep[Q],cnt;bool fl;
inline void dfs1(cint x,cint fa){
	dep[x]=dep[fa]+1;vst[x]=1;cnt+=s[x];fl|=is[x];
	for(rg i=h[x];i;i=e[i].nxt){
		cint y=e[i].to;if(y==fa)continue;if(!vst[y])dfs1(y,x);
		else if((1+Abs(dep[x]-dep[y]))&1)fl=1;
	}
}
inline void solve(cint rt){cnt=0;fl=0;dfs1(rt,0);if(fl)res+=cnt;}
char _ED_;int main(){
//system("fc tribool4.ans tribool.out");return 0;
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
//	fprintf(stderr,"static memory:%.6lf MB\n",(&_ST_-&_ED_)/1024./1024.);
	read(CC);read(T);for(;T--;){
		read(n);read(m);for(rg i=1;i<=n;++i)a[i]=node(i,0);
		N=res=0;for(rg i=1,x,y;i<=m;++i){
			char c;while(c=gc(),!~Gid(c));cint t=Gid(c);
			if(t>=0&&t<=2)read(x),a[x]=node(0,t);
			else read(x),read(y),a[x]=(t==3)?a[y]:Grev(a[y]);
		}
		dsu::init(n);for(rg i=1;i<=n;++i)if(a[i].x&&!a[i].y)dsu::mg(i,a[i].x);
		for(rg i=1;i<=n;++i)if(dsu::Grt(i)==i)id[i]=++N;
		for(rg i=1;i<=N;++i)h[i]=s[i]=dep[i]=0,vst[i]=is[i]=0;ce=0;
		for(rg i=1;i<=n;++i)id[i]=id[dsu::Grt(i)]
		,++s[id[i]],is[id[i]]|=(!a[i].x&&(a[i].y==2));
		for(rg i=1;i<=n;++i)if(a[i].x&&a[i].y)gph(id[i],id[a[i].x]);
		for(rg i=1;i<=N;++i)if(!vst[i])solve(i);write(res,'\n');
	}
	return 0;
}
