#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cassert>
const int Q=500005;
const int INF=1<<30;
typedef long long ll;
#define rg register int
#define cint const register int
//char ibuf[1<<21],*IP1=ibuf,*IP2=ibuf;
//#define gc() (IP1==IP2&&(IP2=(IP1=ibuf)+fread(ibuf,1,1<<21,stdin),IP1==IP2)?EOF:*IP1++)
#define gc getchar
#define pc putchar
inline bool ig(const char c){return c>=48&&c<=57;}
inline void read(rg&oi){char c;rg f=1,res=0;while(c=gc(),!ig(c)&&c^'-');c^'-'?res=(c^48):f=-1;while(c=gc(),ig(c))res=res*10+(c^48);oi=f*res;}
inline void print(rg oi){char io[23];rg l=0;if(oi<0)pc('-'),oi=~oi+1;do io[++l]=oi%10+48;while(oi/=10);for(;l;pc(io[l--]));}
inline void write(cint oi,const char c){print(oi);pc(c);}char _ST_;
inline void Min(rg&x,cint y){(x>y)&&(x=y);}
inline void Max(rg&x,cint y){(x<y)&&(x=y);}
inline int min(cint x,cint y){return x<y?x:y;}
inline int max(cint x,cint y){return x>y?x:y;}
int CC,n,m,qt,ask[66],a[Q],b[Q],ta[Q],tb[Q],L[Q],R[Q];
bool f[2005][2005];
struct node{int x,p;node()=default;node(cint x,cint p):x(x),p(p){}};
node s1[Q],s2[Q];
inline bool solve(cint*a,cint n,cint*b,cint m){
	if(a[1]<=b[1]||a[n]<=b[m])return 0;
	if(n<=2000&&m<=2000){
		f[0][0]=1;
		for(rg i=1;i<=n;++i){
			for(rg j=1;j<=m;++j)
			if(a[i]>b[j])f[i][j]=f[i-1][j]|f[i-1][j-1]|f[i][j-1];
			else f[i][j]=0;
		}
		return f[n][m];
	}
	rg mna=INF,mxa=0,mnb=INF,mxb=0;
	for(rg i=1;i<=n;++i)Min(mna,a[i]),Max(mxa,a[i]);
	for(rg i=1;i<=m;++i)Min(mnb,b[i]),Max(mxb,b[i]);
	if(mxa<=mxb||mna<=mnb)return 0;
	rg t1=0,t2=0;for(rg i=1;i<=n;++i)s1[++t1]=node(a[i],i);
	for(rg i=1;i<=m;++i)s2[++t2]=node(b[i],i);
	std::sort(s1+1,s1+1+t1,[](const node&x,const node&y)->bool{return x.x<y.x;});
	std::sort(s2+1,s2+1+t2,[](const node&x,const node&y)->bool{return x.x<y.x;});
	for(rg i=1,j=1,mn=m+1,mx=0;i<=t1;++i){
		for(;j<=t2&&s1[i].x>s2[j].x;Min(mn,s2[j].p),Max(mx,s2[j].p),++j);
		L[s1[i].p]=mn;R[s1[i].p]=mx;
	}
	for(rg i=1,mxl=0;i<=n;Max(mxl,L[i]),++i)if(R[i]<mxl)return 0;
	for(rg i=n,mnr=0;i>=1;Min(mnr,R[i]),--i)if(L[i]>mnr)return 0;return 1;
}
inline void solve(cint x){ask[x]|=solve(a,n,b,m);if(!ask[x])ask[x]=solve(b,m,a,n);}
char _ED_;int main(){
//system("fc expand3.ans expand.out");return 0;
	freopen("expand.in","r",stdin);
	freopen("expand.out","w",stdout);
//	fprintf(stderr,"static memory:%.6lf MB\n",(&_ST_-&_ED_)/1024./1024.);
	read(CC);read(n);read(m);read(qt);
	for(rg i=1;i<=n;++i)read(a[i]),ta[i]=a[i];
	for(rg i=1;i<=m;++i)read(b[i]),tb[i]=b[i];solve(0);
	for(rg _=1,k1,k2;_<=qt;++_){
		for(rg i=1;i<=n;++i)a[i]=ta[i];
		for(rg i=1;i<=n;++i)b[i]=tb[i];read(k1);read(k2);
		for(rg j=1,x,y;j<=k1;++j)read(x),read(y),a[x]=y;
		for(rg j=1,x,y;j<=k2;++j)read(x),read(y),b[x]=y;solve(_);
	}
	for(rg i=0;i<=qt;++i)pc(ask[i]+'0');pc('\n');
	return 0;
}
