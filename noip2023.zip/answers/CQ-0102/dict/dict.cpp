#include<bits/stdc++.h>
using namespace std;
inline void read(int &x){
	x=0;
	bool sgn=0;
	char ch;
	while(ch=getchar(),ch<'!');
	if(ch=='-'){
		sgn=1;
	}else{
		x=ch-48;
	}
	while(ch=getchar(),ch>'!'){
		x=x*10+ch-48;
	}
	if(sgn){
		x=-x;
	}
	return;
}
void write(int x){
	if(x<0){
		putchar('-');
		x=-x;
	}
	if(x>9){
		write(x/10);
	}
	putchar(x%10+48);
	return;
}
inline void read(long long &x){
	x=0;
	bool sgn=0;
	char ch;
	while(ch=getchar(),ch<'!');
	if(ch=='-'){
		sgn=1;
	}else{
		x=ch-48;
	}
	while(ch=getchar(),ch>'!'){
		x=x*10+ch-48;
	}
	if(sgn){
		x=-x;
	}
	return;
}
void write(long long x){
	if(x<0){
		putchar('-');
		x=-x;
	}
	if(x>9){
		write(x/10);
	}
	putchar(x%10+48);
	return;
}
long long n,m,pos[2];
char Min[3050][2],a[3050][3050];
inline bool cmp(char a,char b){
	return a>b;
}
inline bool Check(long long x,long long fl){
	if(pos[fl]==0){
		return 1;
	}
	for(int i=1;i<=m;i++){
		if(Min[i][fl]<a[x][i]){
			return 0;
		}
		if(Min[i][fl]>a[x][i]){
			return 1;
		}
	}
	return 0;
}
inline void Replace(long long x,long long fl){
	pos[fl]=x;
	for(int i=1;i<=m;i++){
		Min[i][fl]=a[x][i];
	}
//	cout<<fl<<endl;
//	for(int i=1;i<=m;i++){
//		cout<<Min[i];
//	}
//	cout<<endl;
	return;
}
int main(){
	freopen("dict.in","r",stdin);
	freopen("dict.out","w",stdout);
	read(n);
	read(m);
	char ch;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			while(ch=getchar(),ch<'!');
			a[i][j]=ch;
		}
		sort(a[i]+1,a[i]+1+m,cmp);
		if(Check(i,0)){
			pos[1]=pos[0];
			for(int j=1;j<=m;j++){
				Min[j][1]=Min[j][0];
			}
			Replace(i,0);
		}else{
			if(Check(i,1)){
				Replace(i,1);
			}
		}
		sort(a[i]+1,a[i]+1+m);
	}
//	for(int i=0;i<=2;i++){
//		for(int j=1;j<=m;j++){
//			cout<<Min[j][i]<<' ';
//		}
//		cout<<endl;
//	}
	long long ans;
	for(int i=1;i<=n;i++){
		ans=0;
		if(i==pos[0]){
			ans=Check(i,1);
		}else{
			ans=Check(i,0);
		}
		write(ans);
	}
	return 0;
}

