#include<bits/stdc++.h>
using namespace std;
inline void read(int &x){
	x=0;
	bool sgn=0;
	char ch;
	while(ch=getchar(),ch<'!');
	if(ch=='-'){
		sgn=1;
	}else{
		x=ch-48;
	}
	while(ch=getchar(),ch>'!'){
		x=x*10+ch-48;
	}
	if(sgn){
		x=-x;
	}
	return;
}
void write(int x){
	if(x<0){
		putchar('-');
		x=-x;
	}
	if(x>9){
		write(x/10);
	}
	putchar(x%10+48);
	return;
}
inline void read(long long &x){
	x=0;
	bool sgn=0;
	char ch;
	while(ch=getchar(),ch<'!');
	if(ch=='-'){
		sgn=1;
	}else{
		x=ch-48;
	}
	while(ch=getchar(),ch>'!'){
		x=x*10+ch-48;
	}
	if(sgn){
		x=-x;
	}
	return;
}
void write(long long x){
	if(x<0){
		putchar('-');
		x=-x;
	}
	if(x>9){
		write(x/10);
	}
	putchar(x%10+48);
	return;
}
long long c,fl,t,n,m,tot,top,siz,cnt,is_U,inc[1000050],fir[1000050],vis[1000050],op[1000000];
bool used[1000050];
pair<long long ,long long >tmp[1000050],sta[1000050];
struct edge{
	long long fr,to,val,nxt;
}e[1000050];
inline void add(long long fr,long long to,long long val){
	e[++cnt].fr=fr;
	e[cnt].to=to;
	e[cnt].val=val;
	e[cnt].nxt=fir[fr];
	fir[fr]=cnt;
	return;
}
void dfs(long long x,long long la,long long Las_val){
	tmp[++tot]=make_pair(x,Las_val);
	if(inc[x]){
		is_U=1;
	}
	siz+=(used[x]^1);
	used[x]=1;
	for(int i=fir[x];i;i=e[i].nxt){
		if(e[i].to==la){
			continue;
		}
		if(used[e[i].to]){
			if(top){
				continue;
			}
			sta[++top]=make_pair(e[i].to,e[i].val);
			for(int j=tot;j;j--){
				sta[++top]=tmp[j];
				if(sta[top].first==e[i].to){
					break;
				}
			}
		}else{
			dfs(e[i].to,x,e[i].val);
		}
	}
	tot--;
	return;
}
int main(){
	freopen("tribool.in","r",stdin);
	freopen("tribool.out","w",stdout);
	read(c);
	read(t);
	op[(int)'T']=1000001;
	op[(int)'F']=-1000001;
	op[(int)'U']=1000002;
	while(t--){
//		cout<<"hfjkshfjhds"<<endl;
		read(n);
		read(m);
		for(int i=1;i<=n;i++){
			vis[i]=i;
			inc[i]=0;
			used[i]=0;
		}
		for(int i=1;i<=m;i++){
			long long x,y;
			char ch;
			while(ch=getchar(),ch<'!');
			if(ch=='+'){
				read(x);
				read(y);
				vis[x]=vis[y];
				continue;
			}
			if(ch=='-'){
				read(x);
				read(y);
				vis[x]=-vis[y];
				if(vis[x]==-1000002){
					vis[x]=-vis[x];
				}
				continue;
			}
			if(ch>='A'){
				read(x);
				vis[x]=op[ch];
				continue;
			}
		}
//		for(int i=1;i<=n;i++){
//			cout<<vis[i]<<' ';
//		}
//		cout<<endl;
		cnt=0;
		for(int i=1;i<=n;i++){
			fir[i]=0;
		}
		bool fl=0;
		long long ans=0;
		for(int i=1;i<=n;i++){
			if(vis[i]==1000002||vis[i]==-i){
				inc[i]=1;
				vis[i]=i;
			}
			if(vis[i]<0&&vis[i]>-1000000){
				fl=1;
			}else{
				fl=0;
			}
			vis[i]=abs(vis[i]);
			if(vis[i]>=1000000){
				vis[i]=i;
			}
			if(vis[i]==i){
				continue;
			}
//			cout<<vis[i]<<' '<<i<<' '<<fl<<endl;
			add(vis[i],i,fl);
			add(i,vis[i],fl);
		}
		for(int i=1;i<=n;i++){
			if(used[i]){
				continue;
			}
			tot=0;
			siz=0;
			top=0;
			is_U=0;
			dfs(i,0,-1);
//			cout<<ans<<' '<<top<<' '<<siz<<endl;
//			for(int j=1;j<=top;j++){
//				cout<<sta[j].first<<' '<<sta[j].second<<endl;
//			}
			if(is_U){
				ans+=siz;
				continue;
			}
			if(top){
				long long cnt=0;
				for(int j=top-1;j;j--){
					cnt+=sta[j].second;
				}
				if(cnt%2){
					ans+=siz;
				}
			}
		}
		write(ans);
		putchar('\n');
	}
	return 0;
}

