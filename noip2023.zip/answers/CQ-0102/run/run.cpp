#include<bits/stdc++.h>
using namespace std;
inline void read(int &x){
	x=0;
	bool sgn=0;
	char ch;
	while(ch=getchar(),ch<'!');
	if(ch=='-'){
		sgn=1;
	}else{
		x=ch-48;
	}
	while(ch=getchar(),ch>'!'){
		x=x*10+ch-48;
	}
	if(sgn){
		x=-x;
	}
	return;
}
void write(int x){
	if(x<0){
		putchar('-');
		x=-x;
	}
	if(x>9){
		write(x/10);
	}
	putchar(x%10+48);
	return;
}
inline void read(long long &x){
	x=0;
	bool sgn=0;
	char ch;
	while(ch=getchar(),ch<'!');
	if(ch=='-'){
		sgn=1;
	}else{
		x=ch-48;
	}
	while(ch=getchar(),ch>'!'){
		x=x*10+ch-48;
	}
	if(sgn){
		x=-x;
	}
	return;
}
void write(long long x){
	if(x<0){
		putchar('-');
		x=-x;
	}
	if(x>9){
		write(x/10);
	}
	putchar(x%10+48);
	return;
}
long long c,t,Max[100050],Max2,f[3050][3050][2];
struct Trail{
	long long x,y,v;
}a[1000050];
bool cmp(Trail a,Trail b){
	if(a.x==b.x){
		return a.y<b.y;
	}
	return a.x<b.x;
}
int main(){
	freopen("run.in","r",stdin);
	freopen("run.out","w",stdout);
	read(c);
	read(t);
	while(t--){
		long long n,m,k,d;
		read(n);
		read(m);
		read(k);
		read(d);
		for(int i=1;i<=m;i++){
			read(a[i].x);
			read(a[i].y);
			read(a[i].v);
		}
		sort(a+1,a+1+m,cmp);
		long long p=1;
		for(long long i=0;i<=n;i++){
			for(long long j=0;j<=n;j++){
				f[i][j][0]=f[i][j][1]=-0x3f3f3f3f3f3f3f3f;
			}
		}
		f[0][0][0]=0;
		memset(Max,0,sizeof(Max));
		for(long long i=1;i<=n;i++){
			f[i][0][0]=Max[i-1];
			for(long long l=1;l<=min(1ll*i,k);l++){
				f[i][l][1]=max(f[i][l][1],f[i-1][l-1][min(1ll,l-1)]-d);
			}
			while(p<=m&&a[p].x==i){
				for(long long j=a[p].y;j<=min(1ll*i,k);j++){
					f[i][j][1]+=a[p].v;
				}
				p++;
			}
			for(int j=0;j<=i;j++){
				Max[i]=max(Max[i],f[i][j][min(1,j)]);
			}
		}
		long long ans=0;
		for(long long i=1;i<=n;i++){
			for(long long j=0;j<=i;j++){
				ans=max(ans,max(f[i][j][0],f[i][j][1]));
			}
		}
		write(ans);
		putchar('\n');
	}
	return 0;
}

